import{j as e}from"./vendor-query-PraSc8EQ.js";import{r,L as d}from"./vendor-router-L4ZCoGSs.js";import{A as h}from"./arrow-up-right-DIePtCQ0.js";import{P as l}from"./phone-D3JbSBfc.js";import{K as f}from"./index-37hjU4u5.js";import{M as m}from"./mail-CbeZpzUl.js";function E(){const[s,i]=r.useState(!1),n=r.useRef(null),a=r.useRef(null),x=()=>{a.current&&clearTimeout(a.current),i(!0)},c=()=>{a.current=setTimeout(()=>i(!1),450)};r.useEffect(()=>{const t=o=>{n.current&&!n.current.contains(o.target)&&i(!1)},p=o=>{o.key==="Escape"&&i(!1)};return document.addEventListener("mousedown",t),document.addEventListener("keydown",p),()=>{document.removeEventListener("mousedown",t),document.removeEventListener("keydown",p),a.current&&clearTimeout(a.current)}},[]);const g=[{label:"Call us",icon:e.jsx(l,{size:17}),href:"tel:+915813500381"},{label:"WhatsApp",icon:e.jsx(f,{size:17}),href:"https://wa.me/91XXXXXXXXXX?text=Hello%20TechTorch%20Solutions",external:!0},{label:"Email us",icon:e.jsx(m,{size:17}),href:"https://mail.google.com/mail/?view=cm&fs=1&to=contact@techtorch.solutions&su=Executive%20Strategy%20Enquiry",external:!0}];return e.jsxs("section",{className:"executive-strategy",children:[e.jsxs("div",{className:"executive-strategy-card",children:[e.jsxs("div",{className:"executive-strategy-content",children:[e.jsxs("div",{className:"executive-strategy-badge",children:[e.jsx("span",{className:"strategy-dot"}),"NEXT STEPS · EXECUTIVE STRATEGY"]}),e.jsxs("h2",{children:["Turn Information Into Better",e.jsx("br",{})," Decisions"]}),e.jsxs("p",{className:"strategy-description",children:["Your business already generates valuable information.",e.jsx("br",{}),"The opportunity is to connect it, understand it and use",e.jsx("br",{}),"it more effectively."]}),e.jsxs("p",{className:"strategy-highlight",children:["Improve visibility. Strengthen operations. Connect critical",e.jsx("br",{}),"business information. Make decisions with greater confidence."]}),e.jsx("p",{className:"strategy-action",children:"Let's build a clearer path from data to action."}),e.jsx("div",{className:"strategy-buttons",children:e.jsxs("div",{className:"strategy-contact-wrapper",ref:n,onMouseEnter:x,onMouseLeave:c,children:[e.jsxs(d,{to:"/talk-to-expert",className:"strategy-primary",children:[e.jsx("span",{className:"strategy-button-label",children:"Talk to Our Experts"}),e.jsx(h,{size:16,strokeWidth:1.8,className:"strategy-arrow"})]}),e.jsx("div",{className:`strategy-contact-options ${s?"show":""}`,"aria-hidden":!s,children:g.map(t=>e.jsx("a",{href:t.href,"aria-label":t.label,title:t.label,tabIndex:s?0:-1,target:t.external?"_blank":void 0,rel:t.external?"noopener noreferrer":void 0,className:"strategy-contact-icon",onClick:()=>i(!1),children:t.icon},t.label))})]})})]}),e.jsx("div",{className:"executive-strategy-image",children:e.jsx("img",{loading:"lazy",decoding:"async",src:"/ExecutiveStrategy.webp",alt:"Executive Strategy"})})]}),e.jsx("style",{children:`
        /* ================= SECTION (padding same as other sections) ================= */

        .executive-strategy {
          width: 100%;
          padding: 40px 16px;
          background: #ffffff;
          font-family: "Inter", sans-serif;
          overflow: hidden;
        }

        @media (min-width: 640px) {
          .executive-strategy {
            padding: 48px 24px;
          }
        }

        @media (min-width: 768px) {
          .executive-strategy {
            padding: 56px 40px;
          }
        }

        @media (min-width: 1024px) {
          .executive-strategy {
            padding: 64px 100px;
          }
        }

        @media (min-width: 1280px) {
          .executive-strategy {
            padding: 80px 100px;
          }
        }

        .executive-strategy-card {
          width: 100%;
          min-height: 520px;
          display: grid;
          grid-template-columns: 1fr 0.9fr;
          background: #f7fafc;
          border: 1px solid #e0e7ed;
          border-radius: 22px;
          overflow: hidden;
        }

        /* CONTENT */

        .executive-strategy-content {
          padding: 42px 45px 40px 55px;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: flex-start;
          min-width: 0;
        }

        /* BADGE */

        .executive-strategy-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          max-width: 100%;
          height: 32px;
          padding: 0 12px;
          border: 1px solid #e5bfd1;
          border-radius: 20px;
          background: #fff9fc;
          
          color: #8b0750;

          color: #730042;

          font-size: 9px;
          line-height: 1;
          font-weight: 800;
          letter-spacing: 0.7px;
          white-space: nowrap;
        }

        .strategy-dot {
          width: 7px;
          height: 7px;
          flex: 0 0 auto;
          border-radius: 50%;
          background: #970052;
        }

        /* HEADING */

        .executive-strategy-content h2 {
          margin: 23px 0 18px;
          color: #101629;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 34px;
          line-height: 1.12;
          letter-spacing: -1.4px;
          font-weight: 500;
        }

        /* DESCRIPTION */

        .strategy-description {
          margin: 0;
          color: #64738a;
          font-family: "Inter", sans-serif;
          font-size: 14px;
          line-height: 1.5;
          font-weight: 400;
        }

        /* HIGHLIGHT */

        .strategy-highlight {
          margin: 16px 0 0;
          color: #202a3e;
          font-size: 13px;
          line-height: 1.48;
          font-weight: 600;
        }

        /* ACTION */

        .strategy-action {
          margin: 16px 0 0;

          color: #8d0750;


          color: #730042;


          font-size: 14px;
          line-height: 1.4;
          font-weight: 750;
        }

        /* BUTTON CONTAINER */

        .strategy-buttons {
          margin-top: 22px;
          display: flex;
          flex-direction: column;
          align-items: flex-start;
        }

        /* PRIMARY BUTTON */

        .strategy-primary {
          min-width: 230px;
          height: 43px;
          padding: 0 10px;
          border: 1px solid #970052;
          border-radius: 10px;

          background: #970052;


          background: #730042;

          color: #ffffff;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          white-space: nowrap;
          box-shadow: 0 7px 15px rgba(151, 0, 82, 0.18);
          transition:
            background 0.45s ease,
            color 0.45s ease,
            border-color 0.45s ease,
            box-shadow 0.45s ease;
        }

        .strategy-primary:hover {

          background: #a91a68;
          border-color: #a91a68;
          box-shadow: 0 10px 20px rgba(151, 0, 82, 0.22);

          background: #970052;
          border-color: #970052;

          box-shadow:
            0 10px 20px rgba(151, 0, 82, 0.22);

        }

        .strategy-primary span {
          display: inline;
          margin-left: 5px;
          font-size: 17px;
        }

        /* BUTTON ARROW AND CONTACT OPTIONS */

        .strategy-contact-wrapper {
          position: relative;
          display: inline-block;
        }

        .strategy-primary {
          display: inline-flex;
          align-items: center;
          justify-content: space-between;
          gap: 9px;
          text-decoration: none;
        }

        .strategy-button-label {
          display: inline;
          margin: 0;
          font-size: inherit;
        }

        .strategy-arrow {
          flex-shrink: 0;
          transition: transform 0.3s ease;
        }

        .strategy-primary:hover .strategy-arrow {
          transform: translate(4px, -4px);
        }

        .strategy-contact-options {
          position: absolute;
          left: 100%;
          top: 50%;
          z-index: 20;
          display: flex;
          align-items: center;
          gap: 8px;
          margin-left: 10px;
          transform: translateY(-50%);
          visibility: hidden;
          opacity: 0;
          pointer-events: none;
          transition: opacity 0.3s ease, visibility 0.3s ease;
        }

        .strategy-contact-options.show {
          visibility: visible;
          opacity: 1;
          pointer-events: auto;
        }

        .strategy-contact-icon {
          width: 36px;
          height: 36px;
          flex: 0 0 36px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          border: 1px solid rgba(115, 0, 66, 0.2);
          border-radius: 50%;
          background: #ffffff;
          color: #730042;
          text-decoration: none;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.14);
          transition: background 0.2s ease, color 0.2s ease, transform 0.2s ease;
        }

        .strategy-contact-icon:hover {
          background: #730042;
          color: #ffffff;
          transform: translateY(-2px);
        }

        /* IMAGE */

        .executive-strategy-image {
          width: 100%;
          height: 100%;
          min-height: 520px;
          overflow: hidden;
          background: #202633;
        }

        .executive-strategy-image img {
          display: block;
          width: 100%;
          height: 100%;
          object-fit: cover;
          object-position: center;
        }

        /* LARGE DESKTOP */

        @media (min-width: 1600px) {
          .executive-strategy-card {
            min-height: 550px;
          }

          .executive-strategy-content {
            padding-left: 65px;
            padding-right: 50px;
          }

          .executive-strategy-image {
            min-height: 550px;
          }
        }

        /* LAPTOP */

        @media (max-width: 1200px) {
          .executive-strategy-content {
            padding: 38px 35px 38px 42px;
          }

          .executive-strategy-content h2 {
            font-size: 32px;
          }

          .strategy-description {
            font-size: 13px;
          }

          .strategy-highlight {
            font-size: 12px;
          }

          .strategy-action {
            font-size: 13px;
          }
        }

        /* TABLET LANDSCAPE */

        @media (max-width: 1000px) {
          .executive-strategy-card {
            min-height: 460px;
          }

          .executive-strategy-content {
            padding: 32px 25px 32px 32px;
          }

          .executive-strategy-badge {
            height: 30px;
            padding: 0 10px;
            font-size: 9px;
          }

          .executive-strategy-content h2 {
            margin: 20px 0 16px;
            font-size: 29px;
            letter-spacing: -1px;
          }

          .strategy-description {
            font-size: 12px;
          }

          .strategy-highlight {
            font-size: 11px;
          }

          .strategy-action {
            font-size: 12px;
          }

          .strategy-buttons {
            margin-top: 20px;
          }

          .strategy-primary {
            min-width: 205px;
            height: 42px;
            font-size: 11px;
          }

          .executive-strategy-image {
            min-height: 460px;
          }
        }

        /* TABLET */

        @media (max-width: 800px) {
          .executive-strategy-card {
            min-height: auto;
            grid-template-columns: 1fr;
          }

          .executive-strategy-content {
            padding: 35px 30px;
          }

          .executive-strategy-content h2 {
            font-size: 30px;
          }

          .strategy-description,
          .strategy-highlight {
            font-size: 13px;
          }

          .strategy-action {
            font-size: 14px;
          }

          .strategy-primary {
            min-width: 225px;
            height: 43px;
          }

          .executive-strategy-image {
            height: 320px;
            min-height: 320px;
          }
        }

        /* MOBILE */

        @media (max-width: 600px) {
          .executive-strategy-card {
            border-radius: 16px;
          }

          .executive-strategy-content {
            width: 100%;
            padding: 28px 22px 30px;
          }

          .executive-strategy-badge {
            width: fit-content;
            max-width: 100%;
            height: 28px;
            padding: 0 10px;
            font-size: 8px;
            letter-spacing: 0.5px;
            gap: 6px;
          }

          .strategy-dot {
            width: 6px;
            height: 6px;
          }

          .executive-strategy-content h2 {
            width: 100%;
            margin: 20px 0 16px;
            font-size: 27px;
            line-height: 1.12;
            letter-spacing: -1px;
          }

          .strategy-description {
            width: 100%;
            font-size: 12px;
            line-height: 1.55;
          }

          .strategy-description br,
          .strategy-highlight br {
            display: none;
          }

          .strategy-highlight {
            width: 100%;
            margin-top: 16px;
            font-size: 12px;
            line-height: 1.5;
          }

          .strategy-action {
            width: 100%;
            margin-top: 16px;
            font-size: 13px;
            line-height: 1.45;
          }

          .strategy-buttons {
            width: 100%;
            margin-top: 20px;
          }

          .strategy-contact-wrapper {
            width: 100%;
          }

          .strategy-primary {
            width: 100%;
            min-width: 0;
            height: 44px;
            padding: 0 8px;
            font-size: 11.5px;
          }

          .strategy-contact-options {
            left: auto;
            right: 0;
            top: calc(100% + 8px);
            margin-left: 0;
            transform: none;
          }

          .executive-strategy-image {
            height: 245px;
            min-height: 245px;
          }
        }

        /* SMALL MOBILE */

        @media (max-width: 480px) {
          .executive-strategy-content {
            padding: 26px 18px 28px;
          }

          .executive-strategy-content h2 {
            font-size: 25px;
          }

          .strategy-description,
          .strategy-highlight {
            font-size: 11px;
          }

          .strategy-action {
            font-size: 12px;
          }

          .strategy-primary {
            width: 100%;
            height: 42px;
            font-size: 10.5px;
            padding: 0 7px;
          }

          .executive-strategy-image {
            height: 220px;
            min-height: 220px;
          }
        }

        /* VERY SMALL MOBILE */

        @media (max-width: 350px) {
          .executive-strategy-content {
            padding: 23px 16px 25px;
          }

          .executive-strategy-badge {
            height: 26px;
            padding: 0 8px;
            font-size: 7px;
          }

          .executive-strategy-content h2 {
            font-size: 22px;
          }

          .strategy-description,
          .strategy-highlight {
            font-size: 10.5px;
          }

          .strategy-action {
            font-size: 11px;
          }

          .strategy-primary {
            height: 41px;
            font-size: 10px;
            padding: 0 6px;
          }

          .executive-strategy-image {
            height: 200px;
            min-height: 200px;
          }
        }
      `})]})}export{E as default};
