import{j as e}from"./vendor-query-PraSc8EQ.js";import{L as j,r as f,d as C}from"./vendor-router-L4ZCoGSs.js";import{t as S,u as E,b as O,a5 as A,a8 as M}from"./index-37hjU4u5.js";import{B as L}from"./book-open-BHDPYgUy.js";import{M as P}from"./map-pin-B0tD-pH2.js";const z={name:"log-in",size:24,node:[["path",{d:"m10 17 5-5-5-5",key:"1bsop3"}],["path",{d:"M15 12H3",key:"6jk70r"}],["path",{d:"M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4",key:"u53s6r"}]]};z.node;const R=S(z);function B(){const{data:s,isLoading:i}=E();if(i)return null;const l=s?.accountType==="admin"?"/admin-dashboard":"/candidate";return e.jsx("section",{className:"bg-[#f7f3f5] px-4 py-12 sm:py-16",id:"account",children:e.jsx("div",{className:"mx-auto max-w-5xl rounded-2xl border border-[#780042]/10 bg-white p-6 shadow-sm sm:p-10",children:s?e.jsxs("div",{className:"flex flex-wrap items-center justify-between gap-4",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-xs font-semibold uppercase tracking-widest text-[#780042]",children:"Signed in"}),e.jsxs("h2",{className:"mt-1 text-2xl font-semibold text-stone-900",children:["Welcome back, ",s.name?.split(" ")[0]]}),e.jsx("p",{className:"mt-1 text-sm text-stone-600",children:s.accountType==="admin"?"Manage content, candidates and enquiries from your dashboard.":"Write blogs and track the roles you showed interest in."})]}),e.jsx(j,{to:l,className:"rounded-lg bg-[#780042] px-5 py-3 text-sm font-medium text-white no-underline hover:opacity-90",children:"Go to my dashboard"})]}):e.jsxs("div",{className:"grid gap-8 md:grid-cols-2 md:items-center",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-xs font-semibold uppercase tracking-widest text-[#780042]",children:"Candidates & team"}),e.jsx("h2",{className:"mt-1 text-2xl font-semibold text-stone-900 sm:text-3xl",children:"Join the TechTorch community"}),e.jsxs("ul",{className:"mt-4 space-y-3 text-sm text-stone-700",children:[e.jsxs("li",{className:"flex gap-3",children:[e.jsx(L,{size:18,className:"mt-0.5 shrink-0 text-[#780042]"})," Write blogs and share your ideas with our readers."]}),e.jsxs("li",{className:"flex gap-3",children:[e.jsx(O,{size:18,className:"mt-0.5 shrink-0 text-[#780042]"})," Show interest in open roles and track your progress."]})]})]}),e.jsxs("div",{className:"flex flex-col gap-3",children:[e.jsxs(j,{to:"/signin",state:{from:"/candidate"},className:"flex items-center justify-center gap-2 rounded-lg bg-[#780042] px-5 py-3 text-sm font-medium text-white no-underline hover:opacity-90",children:[e.jsx(R,{size:17})," Sign in"]}),e.jsxs(j,{to:"/signup",state:{from:"/candidate"},className:"flex items-center justify-center gap-2 rounded-lg border border-[#780042] px-5 py-3 text-sm font-medium text-[#780042] no-underline hover:bg-[#780042]/5",children:[e.jsx(A,{size:17})," Create a candidate account"]}),e.jsx("p",{className:"text-center text-xs text-stone-500",children:"Admins use the same sign-in page."})]})]})})})}const h=[{id:"bareilly",label:"Bareilly Office",address:"M-1 Vrindavan Colony, IVRI Road, Near Izzatnagar Police Station, Bareilly, Uttar Pradesh 243122, India",embed:"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3509.967247293842!2d79.4325611!3d28.390057199999998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39a0075957e78e9f%3A0xf1d5b04ea8b3ab01!2sTechTorch%20Solutions%20Private%20Limited!5e0!3m2!1sen!2sin!4v1794547669301!5m2!1sen!2sin"},{id:"noida",label:"Noida Office",address:"Suite G/11, B-8 Sector-2, Near Sector-15 Metro Station, Noida, Uttar Pradesh 201301, India",embed:"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d897726.7896096581!2d77.71347262192192!3d28.487217002930922!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce5a6f57cf8fd%3A0x7cbdf4a92ebfcac7!2sTechTorch%20Solutions!5e0!3m2!1sen!2sin!4v1794547710725!5m2!1sen!2sin"}],D=s=>`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(s.address)}`;function F(){const[s,i]=f.useState(h[0].id),l=h.find(d=>d.id===s)||h[0];return e.jsxs("div",{className:"office-map-card",children:[e.jsx("p",{className:"office-map-title",children:"OUR LOCATIONS"}),e.jsx("div",{className:"office-map-tabs",role:"tablist",children:h.map(d=>e.jsx("button",{type:"button",role:"tab","aria-selected":d.id===s,className:`office-map-tab ${d.id===s?"is-active":""}`,onClick:()=>i(d.id),children:d.label},d.id))}),e.jsx("div",{className:"office-map-frame",children:e.jsx("iframe",{title:`${l.label} location map`,src:l.embed,loading:"lazy",allowFullScreen:!0,referrerPolicy:"strict-origin-when-cross-origin"},l.id)}),e.jsxs("a",{className:"office-map-link",href:D(l),target:"_blank",rel:"noopener noreferrer",children:[e.jsx(P,{size:16,strokeWidth:2.4}),"Open in Google Maps"]}),e.jsx("style",{children:`
        .office-map-card {
          background: #f4f6fa;
          border: 1px solid #e3e7ef;
          border-radius: 28px;
          padding: 24px;
          width: 100%;
          box-sizing: border-box;
        }

        .office-map-title {
          margin: 0 0 14px;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.08em;
          color: #5b6472;
        }

        .office-map-tabs {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          margin-bottom: 14px;
        }

        .office-map-tab {
          border: 1px solid #d9dde6;
          background: #fff;
          color: #333;
          font-size: 13px;
          font-weight: 600;
          padding: 7px 14px;
          border-radius: 999px;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .office-map-tab:hover {
          border-color: #8a0045;
          color: #8a0045;
        }

        .office-map-tab.is-active {
          background: #8a0045;
          border-color: #8a0045;
          color: #fff;
        }

        .office-map-frame {
          border-radius: 18px;
          overflow: hidden;
          background: #e8ebf1;
          aspect-ratio: 4 / 3;
          min-height: 260px;
        }

        .office-map-frame iframe {
          width: 100%;
          height: 100%;
          border: 0;
          display: block;
        }

        .office-map-link {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          margin-top: 14px;
          font-size: 14px;
          font-weight: 600;
          color: #8a0045;
          text-decoration: none;
        }

        .office-map-link:hover {
          text-decoration: underline;
        }

        @media (max-width: 480px) {
          .office-map-card { padding: 16px; border-radius: 20px; }
        }
      `})]})}function V(){const s=C(),[i,l]=f.useState({fullName:"",email:"",company:"",phone:"",service:"",requirement:"",stage:"",timeline:"",contactMethod:""}),[d,v]=f.useState(!1),[u,y]=f.useState(!1),[w,N]=f.useState(""),[t,g]=f.useState({}),x=f.useRef({}),m=(o,a)=>{x.current[o]&&(clearTimeout(x.current[o]),delete x.current[o]),g(n=>({...n,[o]:a})),a&&(x.current[o]=setTimeout(()=>{g(n=>({...n,[o]:""})),delete x.current[o]},3e3))},b=(o,a)=>{const n=a.trim();switch(o){case"fullName":return n?/^[A-Za-zÀ-ÖØ-öø-ÿ .'-]+$/.test(n)?"":"Enter a valid name .":"Full name is required.";case"email":return n?/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(n)?"":"Please enter a valid email address.":"Work email is required.";case"company":return n&&!/^[A-Za-zÀ-ÖØ-öø-ÿ ]+$/.test(n)?"Enter a valid name.":"";case"phone":return n&&!/^[6-9]\d{9}$/.test(n)?"Enter a valid mobile number ":"";case"service":return a?"":"Please select a service.";case"requirement":return n?n.length>500?"Requirement must be 500 characters or fewer.":"":"Please describe your requirement.";default:return""}},c=o=>{const{name:a,value:n}=o.target;let r=n;if(a==="phone"){const p=/\D/.test(n),I=n.replace(/\D/g,"").length>10;r=n.replace(/\D/g,"").slice(0,10),l(T=>({...T,[a]:r})),p?m(a,"Phone number must contain digits only."):I?m(a,"Phone number can contain only 10 digits."):m(a,b(a,r));return}l(p=>({...p,[a]:r})),["fullName","email","company","service","requirement"].includes(a)&&m(a,b(a,r))},k={"web-development":"Web Development","software-development":"Software Development",cloud:"Cloud Solutions",ai:"AI & Machine Learning",consulting:"Technology Consulting"},q=async o=>{if(o.preventDefault(),u)return;const n=["fullName","email","company","phone","service","requirement"].reduce((r,p)=>(r[p]=b(p,i[p]),r),{});if(Object.entries(n).forEach(([r,p])=>{m(r,p)}),!Object.values(n).some(Boolean)){N(""),y(!0);try{await M.general({fullName:i.fullName.trim(),businessEmail:i.email.trim(),phoneNumber:i.phone.trim(),companyOrganization:i.company.trim(),areaOfInterest:k[i.service]||i.service,requirement:i.requirement.trim(),projectStage:i.stage,timeline:i.timeline,preferredContactMethod:i.contactMethod,contactConsent:!0}),v(!0),l({fullName:"",email:"",company:"",phone:"",service:"",requirement:"",stage:"",timeline:"",contactMethod:""}),g({}),setTimeout(()=>v(!1),6e3)}catch(r){N(r.message||"Could not send your enquiry. Please try again.")}finally{y(!1)}}};return e.jsxs("main",{className:"contact-page",children:[e.jsx("section",{className:"contact-hero",children:e.jsxs("div",{className:"contact-hero-inner",children:[e.jsxs("div",{className:"contact-hero-content",children:[e.jsx("span",{className:"eyebrow",children:"GET IN TOUCH"}),e.jsxs("h1",{children:["Let’s Turn Your",e.jsx("br",{className:"desktop-break"}),"Technology Needs Into",e.jsx("br",{className:"desktop-break"}),"Solutions"]}),e.jsx("p",{children:"Have a business challenge, a new project, or a technology requirement? Tell us what you’re looking to achieve. Our team will understand your needs and connect with you to discuss the right approach."}),e.jsxs("button",{type:"button",className:"primary-button",onClick:()=>s("/conversation-toggle"),children:["Start a Conversation",e.jsx("span",{children:"→"})]})]}),e.jsx("div",{className:"contact-hero-image-wrapper",children:e.jsx("img",{loading:"lazy",decoding:"async",src:"/StartConversation.webp",alt:"Business conversation",className:"contact-hero-image"})})]})}),e.jsx(B,{}),e.jsx("section",{className:"contact-form-section",id:"contact-form",children:e.jsxs("div",{className:"contact-grid",children:[e.jsxs("form",{className:"contact-form-card",onSubmit:q,children:[e.jsxs("div",{className:"form-header",children:[e.jsx("span",{className:"eyebrow",children:"GET IN TOUCH"}),e.jsx("h2",{children:"Let's Understand Your Needs"}),e.jsx("p",{children:"Tell us a little about your business, project, or technology requirement. The more we understand, the better we can discuss the right approach for your needs."})]}),e.jsx("div",{className:"form-divider"}),e.jsxs("div",{className:"form-section",children:[e.jsxs("h3",{children:[e.jsx("span",{className:"section-icon",children:"♟"}),"Your Details"]}),e.jsxs("div",{className:"form-row",children:[e.jsxs("div",{className:"field",children:[e.jsxs("label",{children:["Full Name",e.jsx("span",{children:"*"})]}),e.jsx("input",{type:"text",name:"fullName",value:i.fullName,onChange:c,placeholder:"Enter your full name",required:!0,"aria-invalid":!!t.fullName,"aria-describedby":t.fullName?"fullName-error":void 0}),t.fullName&&e.jsx("small",{id:"fullName-error",className:"field-error",role:"alert",children:t.fullName})]}),e.jsxs("div",{className:"field",children:[e.jsxs("label",{children:["Work Email",e.jsx("span",{children:"*"})]}),e.jsx("input",{type:"email",name:"email",value:i.email,onChange:c,placeholder:"Enter your business email",required:!0,"aria-invalid":!!t.email,"aria-describedby":t.email?"email-error":void 0}),t.email&&e.jsx("small",{id:"email-error",className:"field-error",role:"alert",children:t.email})]})]}),e.jsxs("div",{className:"form-row",children:[e.jsxs("div",{className:"field",children:[e.jsx("label",{children:"Company Name"}),e.jsx("input",{type:"text",name:"company",value:i.company,onChange:c,placeholder:"Enter your company name","aria-invalid":!!t.company,"aria-describedby":t.company?"company-error":void 0}),t.company&&e.jsx("small",{id:"company-error",className:"field-error",role:"alert",children:t.company})]}),e.jsxs("div",{className:"field",children:[e.jsx("label",{children:"Phone Number"}),e.jsx("input",{type:"tel",maxLength:10,name:"phone",value:i.phone,onChange:c,placeholder:"Enter your phone number",inputMode:"numeric",autoComplete:"tel","aria-invalid":!!t.phone,"aria-describedby":t.phone?"phone-error":void 0}),t.phone&&e.jsx("small",{id:"phone-error",className:"field-error",role:"alert",children:t.phone})]})]})]}),e.jsxs("div",{className:"form-section",children:[e.jsxs("h3",{children:[e.jsx("span",{className:"section-icon",children:"✦"}),"Your Requirement"]}),e.jsxs("div",{className:"field full-width",children:[e.jsxs("label",{children:["What can we help you with?",e.jsx("span",{children:"*"})]}),e.jsxs("select",{name:"service",value:i.service,onChange:c,required:!0,"aria-invalid":!!t.service,"aria-describedby":t.service?"service-error":void 0,children:[e.jsx("option",{value:"",children:"Select a service"}),e.jsx("option",{value:"web-development",children:"Web Development"}),e.jsx("option",{value:"software-development",children:"Software Development"}),e.jsx("option",{value:"cloud",children:"Cloud Solutions"}),e.jsx("option",{value:"ai",children:"AI & Machine Learning"}),e.jsx("option",{value:"consulting",children:"Technology Consulting"})]}),t.service&&e.jsx("small",{id:"service-error",className:"field-error",role:"alert",children:t.service})]}),e.jsxs("div",{className:"field full-width",children:[e.jsxs("label",{children:["Tell us about your requirement",e.jsx("span",{children:"*"})]}),e.jsx("textarea",{name:"requirement",value:i.requirement,onChange:c,maxLength:500,placeholder:"Briefly describe your project, business challenge or technology requirement...",required:!0,"aria-invalid":!!t.requirement,"aria-describedby":t.requirement?"requirement-error":void 0}),t.requirement&&e.jsx("small",{id:"requirement-error",className:"field-error",role:"alert",children:t.requirement}),e.jsxs("div",{className:"character-count",children:[i.requirement.length,"/500"]})]})]}),e.jsxs("div",{className:"form-section",children:[e.jsxs("h3",{children:[e.jsx("span",{className:"section-icon",children:"▣"}),"Project Information"]}),e.jsxs("div",{className:"form-row",children:[e.jsxs("div",{className:"field",children:[e.jsx("label",{children:"Current Stage"}),e.jsxs("select",{name:"stage",value:i.stage,onChange:c,children:[e.jsx("option",{value:"",children:"Select current stage"}),e.jsx("option",{value:"idea",children:"Idea / Planning"}),e.jsx("option",{value:"development",children:"Development"}),e.jsx("option",{value:"existing",children:"Existing System"})]})]}),e.jsxs("div",{className:"field",children:[e.jsx("label",{children:"Expected Timeline"}),e.jsxs("select",{name:"timeline",value:i.timeline,onChange:c,children:[e.jsx("option",{value:"",children:"Select timeline"}),e.jsx("option",{value:"immediate",children:"Immediate"}),e.jsx("option",{value:"1-3-months",children:"1–3 Months"}),e.jsx("option",{value:"3-6-months",children:"3–6 Months"}),e.jsx("option",{value:"6-plus-months",children:"6+ Months"})]})]})]}),e.jsxs("div",{className:"preferred-contact",children:[e.jsx("label",{className:"preferred-title",children:"Preferred Way to Connect"}),e.jsxs("div",{className:"radio-group",children:[e.jsxs("label",{className:"radio-option",children:[e.jsx("input",{type:"radio",name:"contactMethod",value:"Email",checked:i.contactMethod==="Email",onChange:c}),e.jsx("span",{children:"Email"})]}),e.jsxs("label",{className:"radio-option",children:[e.jsx("input",{type:"radio",name:"contactMethod",value:"Phone Call",checked:i.contactMethod==="Phone Call",onChange:c}),e.jsx("span",{children:"Phone Call"})]}),e.jsxs("label",{className:"radio-option",children:[e.jsx("input",{type:"radio",name:"contactMethod",value:"Online Meeting",checked:i.contactMethod==="Online Meeting",onChange:c}),e.jsx("span",{children:"Online Meeting"})]})]})]})]}),e.jsxs("button",{type:"submit",className:"submit-button",disabled:u,children:[u?"Sending…":"Send Enquiry",e.jsx("span",{children:"→"})]}),w&&e.jsx("div",{className:"success-message",role:"alert",style:{background:"#fdecea",color:"#b42318"},children:w}),e.jsx("p",{className:"form-note",children:"By submitting this form, you agree to be contacted by TechTorch Solutions regarding your enquiry."}),d&&e.jsx("div",{className:"success-message",children:"Your enquiry has been submitted successfully."})]}),e.jsxs("aside",{className:"conversation-card",children:[e.jsx("h2",{children:"Let's Start a Conversation"}),e.jsx("p",{className:"conversation-description",children:"Whether you're exploring a new technology initiative, modernizing an existing system, or looking for specialized expertise, our team is ready to understand your requirements."}),e.jsx("div",{className:"card-divider"}),e.jsx("h3",{className:"next-title",children:"WHAT HAPPENS NEXT?"}),e.jsxs("div",{className:"process-step",children:[e.jsx("div",{className:"step-number",children:"01"}),e.jsxs("div",{children:[e.jsx("h4",{children:"Share Your Requirement"}),e.jsx("p",{children:"Tell us about your business needs, project or technology challenge."})]})]}),e.jsxs("div",{className:"process-step",children:[e.jsx("div",{className:"step-number",children:"02"}),e.jsxs("div",{children:[e.jsx("h4",{children:"We Understand Your Needs"}),e.jsx("p",{children:"Our team reviews your requirement and identifies the relevant area of expertise."})]})]}),e.jsxs("div",{className:"process-step",children:[e.jsx("div",{className:"step-number",children:"03"}),e.jsxs("div",{children:[e.jsx("h4",{children:"Let's Connect"}),e.jsx("p",{children:"We'll get in touch to discuss your requirement and possible next steps."})]})]}),e.jsx("div",{className:"card-divider"}),e.jsx("h3",{className:"quick-title",children:"NEED A QUICKER RESPONSE?"}),e.jsxs("div",{className:"question-card",children:[e.jsx("div",{className:"question-icon",children:"?"}),e.jsxs("div",{className:"question-content",children:[e.jsx("h4",{children:"Have a Question?"}),e.jsx("p",{children:"Not sure where to start? Ask us anything about our services, solutions or your specific requirement."}),e.jsxs("button",{type:"button",className:"outline-button",onClick:()=>s("/explore-questions"),children:["Ask a Question",e.jsx("span",{children:"→"})]})]})]}),e.jsx("div",{className:"card-divider"}),e.jsx("h3",{className:"direct-title",children:"DIRECT CONTACT"}),e.jsxs("div",{className:"direct-contact",children:[e.jsxs("div",{className:"direct-item",children:[e.jsx("strong",{children:"✉"}),e.jsxs("div",{children:[e.jsx("b",{children:"Email"}),e.jsx("span",{children:"contact@techtorch.solutions"})]})]}),e.jsxs("div",{className:"direct-item",children:[e.jsx("strong",{children:"⌕"}),e.jsxs("div",{children:[e.jsx("b",{children:"Phone"}),e.jsx("span",{children:"+91 581 3500381 | +91 7251090147"})]})]}),e.jsxs("div",{className:"direct-item",children:[e.jsx("strong",{children:"●"}),e.jsxs("div",{children:[e.jsx("b",{children:"Our Offices"}),e.jsx("span",{children:"Noida  |  Bareilly "})]})]})]})]})]})}),e.jsx("section",{className:"question-cta",children:e.jsxs("div",{className:"question-cta-inner",children:[e.jsxs("div",{className:"question-cta-content",children:[e.jsx("span",{className:"eyebrow light",children:"ASK A QUESTION"}),e.jsxs("h2",{children:["Have a Question?",e.jsx("br",{}),"We’re Here to Help"]}),e.jsx("p",{children:"Find answers to common questions about our services, solutions, technology capabilities, and engagement process."}),e.jsxs("button",{type:"button",className:"white-button",onClick:()=>s("/explore-questions"),children:["Explore Questions",e.jsx("span",{children:"→"})]})]}),e.jsx("div",{className:"question-illustration",children:e.jsx("img",{loading:"lazy",decoding:"async",src:"/Question.webp",alt:"Question illustration"})})]})}),e.jsx("section",{className:"office-section",children:e.jsxs("div",{className:"office-inner",children:[e.jsxs("div",{className:"office-left",children:[e.jsx("span",{className:"eyebrow",children:"CONTACT"}),e.jsx("h2",{children:"Connect With TechTorch"}),e.jsx("p",{className:"office-intro",children:"For technology solutions, services, products and business requirements."}),e.jsxs("div",{className:"contact-details",children:[e.jsxs("div",{className:"contact-detail",children:[e.jsx("div",{className:"contact-icon",children:"✉"}),e.jsxs("div",{children:[e.jsx("span",{children:"EMAIL"}),e.jsx("strong",{children:"contact@techtorch.solutions"})]})]}),e.jsxs("div",{className:"contact-detail",children:[e.jsx("div",{className:"contact-icon",children:"☎"}),e.jsxs("div",{children:[e.jsx("span",{children:"PHONE"}),e.jsx("strong",{children:"+91 581 3500381"}),e.jsx("small",{children:"+91 7251090147"})]})]})]}),e.jsx("div",{className:"office-divider"}),e.jsxs("div",{className:"offices-heading",children:[e.jsx("span",{children:"●"}),"Our Offices"]}),e.jsxs("div",{className:"offices-grid",children:[e.jsxs("div",{className:"office-column",children:[e.jsx("h3",{children:"Noida Office"}),e.jsxs("p",{children:["Suite G/11, B-8 Sector-2,",e.jsx("br",{}),"Near Sector-15 Metro Station,",e.jsx("br",{}),"Noida, Uttar Pradesh – 201301, India"]})]}),e.jsxs("div",{className:"office-column",children:[e.jsx("h3",{children:"Corporate Office"}),e.jsxs("p",{children:["M-1 Vrindavan Colony,",e.jsx("br",{}),"IVRI Road, Near Izzatnagar",e.jsx("br",{}),"Police Station, Bareilly,",e.jsx("br",{}),"Uttar Pradesh – 243122, India"]})]})]}),e.jsx("div",{className:"office-divider"}),e.jsxs("div",{className:"business-hours",children:[e.jsx("span",{children:"●"}),e.jsx("strong",{children:"Business Hours:"}),"Monday – Friday | 10:00 AM – 7:00 PM (IST)"]})]}),e.jsx("div",{className:"map-wrapper",children:e.jsx(F,{})})]})}),e.jsx("section",{className:"final-cta",children:e.jsxs("div",{className:"final-cta-inner",children:[e.jsxs("div",{children:[e.jsx("span",{className:"eyebrow light",children:"HAVE A TECHNOLOGY CHALLENGE?"}),e.jsxs("h2",{children:["Let's Build the Right Solution for Your",e.jsx("br",{className:"desktop-break"}),"Business."]}),e.jsx("p",{children:"Discuss your requirement with TechTorch Solutions and explore the next step."})]}),e.jsxs("div",{className:"final-buttons",children:[e.jsxs("button",{type:"button",className:"final-white-button",onClick:()=>s("/talk-to-expert"),children:["Talk to Our Experts",e.jsx("span",{children:"→"})]}),e.jsxs("button",{type:"button",className:"final-outline-button",onClick:()=>s("/explore-questions"),children:["Ask a Question",e.jsx("span",{children:"→"})]})]})]})}),e.jsx("style",{children:`

        * {
          box-sizing: border-box;
        }

        html {
          scroll-behavior: smooth;
        }

        body {
          margin: 0;
        }

        .contact-page {
          width: 100%;
          overflow-x: hidden;
          background: #ffffff;
          color: #121826;
        }

        /* =====================================================
           FONTS
        ===================================================== */

        .contact-page h1,
        .contact-page h2,
        .contact-page h3,
        .contact-page h4,
        .contact-page .eyebrow,
        .contact-page button {
          font-family: "Plus Jakarta Sans", sans-serif;
        }

        .contact-page p,
        .contact-page label,
        .contact-page input,
        .contact-page textarea,
        .contact-page select,
        .contact-page span,
        .contact-page small {
          font-family: "Inter", sans-serif;
        }


        /* =====================================================
           COMMON
        ===================================================== */

        .eyebrow {
          display: inline-block;
          color: #8a0048;
          font-size: 13px;
          line-height: 1.3;
          font-weight: 700;
          letter-spacing: 0.04em;
          margin-bottom: 12px;
        }

        .eyebrow.light {
          color: #f5d9e7;
        }


        /* =====================================================
           HERO
        ===================================================== */

        .contact-hero {
          width: 100%;
          background: #ffffff;
          padding: 70px 100px 78px;
        }

        .contact-hero-inner {
          width: 100%;
          max-width: none;
          margin: 0 auto;

          display: grid;
          grid-template-columns: minmax(0, 1fr) minmax(420px, 1fr);
          align-items: center;
          gap: 70px;
        }

        .contact-hero-content {
          min-width: 0;
        }

        .contact-hero-content h1 {
          margin: 0 0 18px;
          color: #121826;
          word-spacing: 6px;
          font-size: 40px;
          line-height: 1.04;
          font-weight: 700;
          letter-spacing: -0.035em;
        }

        .contact-hero-content p {
          max-width: 610px;
          margin: 0 0 28px;

          color: #6c7482;
          font-size: 15px;
          line-height: 1.65;
          font-weight: 400;
        }

        .contact-hero-image-wrapper {
          width: 100%;
          min-width: 0;
        }

        .contact-hero-image {
          display: block;
          width: 100%;
          max-width: 560px;
          height: 420px;

          margin-left: auto;

          object-fit: cover;
          object-position: center;

          border-radius: 22px;

          box-shadow:
            0 18px 40px rgba(20, 20, 20, 0.14);
        }


        /* =====================================================
           BUTTONS
        ===================================================== */

        .primary-button,
        .submit-button,
        .white-button,
        .outline-button,
        .final-white-button,
        .final-outline-button {
          border: none;
          cursor: pointer;

          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 12px;

          white-space: nowrap;

          transition:
            transform 0.25s ease,
            background 0.25s ease,
            color 0.25s ease,
            border-color 0.25s ease;
        }

        .primary-button {
          min-height: 50px;
          padding: 0 25px;

          border-radius: 28px;

          background: #8a0048;
          color: #ffffff;

          font-size: 14px;
          font-weight: 600;
        }

        .primary-button span,
        .submit-button span,
        .white-button span,
        .outline-button span,
        .final-white-button span,
        .final-outline-button span {
          font-size: 18px;
          line-height: 1;
        }

        .primary-button:hover,
        .submit-button:hover {
          transform: translateY(-2px);
          background: #70003b;
        }


        /* =====================================================
           FORM SECTION
        ===================================================== */

        .contact-form-section {
          width: 100%;
          background: #faf9fb;
          padding: 90px 100px;
        }

        .contact-grid {
          width: 100%;
          max-width: none;
          margin: 0 auto;

          display: grid;
          grid-template-columns: minmax(0, 1.35fr) minmax(350px, 0.85fr);
          gap: 48px;

          align-items: start;
        }


        /* =====================================================
           FORM CARD
        ===================================================== */

        .contact-form-card {
          width: 100%;
          background: #ffffff;

          padding: 40px 42px;

          border: 1px solid #eeeeee;
          border-radius: 22px;

          box-shadow:
            0 5px 18px rgba(25, 25, 25, 0.035);
        }

        .form-header h2 {
          margin: 0 0 10px;

          color: #121826;
          font-size: 31px;
          line-height: 1.2;
          font-weight: 700;
          letter-spacing: -0.025em;
        }

        .form-header p {
          max-width: 760px;
          margin: 0;

          color: #818896;
          font-size: 14px;
          line-height: 1.65;
        }

        .form-divider,
        .card-divider,
        .office-divider {
          width: 100%;
          height: 1px;
          background: #eeeeee;
        }

        .form-divider {
          margin: 28px 0 34px;
        }

        .form-section {
          margin-bottom: 30px;
        }

        .form-section h3 {
          display: flex;
          align-items: center;
          gap: 10px;

          margin: 0 0 20px;

          color: #1c2432;
          font-size: 17px;
          line-height: 1.3;
          font-weight: 700;
        }

        .section-icon {
          width: 26px;
          height: 26px;

          display: inline-flex;
          align-items: center;
          justify-content: center;

          border-radius: 50%;

          background: #fcecf4;
          color: #8a0048;

          font-size: 12px;
        }

        .form-row {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 16px;
          margin-bottom: 18px;
        }

        .field {
          width: 100%;
          min-width: 0;
        }

        .field.full-width {
          margin-bottom: 18px;
        }

        .field label {
          display: block;

          margin-bottom: 8px;

          color: #38404d;
          font-size: 12px;
          line-height: 1.4;
          font-weight: 600;
        }

        .contact-page .field-error {
          display: block;
          margin-top: 6px;
          color: #b42318;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.4;
        }

        .contact-page .field input[aria-invalid="true"],
        .contact-page .field select[aria-invalid="true"],
        .contact-page .field textarea[aria-invalid="true"] {
          border-color: #b42318;
        }

        .field label span {
          color: #8a0048;
          margin-left: 2px;
        }

        .field input,
        .field select,
        .field textarea {
          width: 100%;

          border: 1px solid #e1e4e8;
          outline: none;

          background: #ffffff;
          color: #3f4652;

          border-radius: 12px;

          font-family: "Inter", sans-serif;
          font-size: 14px;
          font-weight: 400;

          transition:
            border-color 0.2s ease,
            box-shadow 0.2s ease;
        }

        .field input,
        .field select {
          height: 46px;
          padding: 0 16px;
        }

        .field textarea {
          min-height: 110px;
          padding: 14px 16px;
          resize: vertical;
        }

        .field input::placeholder,
        .field textarea::placeholder {
          color: #b6bcc5;
        }

        .field input:focus,
        .field select:focus,
        .field textarea:focus {
          border-color: #8a0048;

          box-shadow:
            0 0 0 3px rgba(138, 0, 72, 0.08);
        }

        .character-count {
          margin-top: 6px;
          text-align: right;

          color: #a7adb6;
          font-family: "Inter", sans-serif;
          font-size: 11px;
        }


        /* =====================================================
           RADIO
        ===================================================== */

        .preferred-contact {
          margin-top: 26px;
        }

        .preferred-title {
          display: block;

          margin-bottom: 14px;

          color: #3d4552;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 600;
        }

        .radio-group {
          display: flex;
          flex-wrap: wrap;
          gap: 26px;
        }

        .radio-option {
          display: flex;
          align-items: center;
          gap: 8px;

          cursor: pointer;

          color: #5d6572;

          font-family: "Inter", sans-serif;
          font-size: 14px;
        }

        .radio-option input {
          appearance: none;

          width: 17px;
          height: 17px;

          margin: 0;

          border: 2px solid #dfe2e6;
          border-radius: 50%;

          background: #ffffff;

          cursor: pointer;

          position: relative;
        }

        .radio-option input:checked {
          border-color: #8a0048;
        }

        .radio-option input:checked::after {
          content: "";

          position: absolute;
          top: 3px;
          left: 3px;

          width: 7px;
          height: 7px;

          border-radius: 50%;
          background: #8a0048;
        }


        /* =====================================================
           SUBMIT
        ===================================================== */

        .submit-button {
          min-height: 50px;

          padding: 0 26px;

          border-radius: 28px;

          background: #8a0048;
          color: #ffffff;

          font-size: 14px;
          font-weight: 600;
        }

        .form-note {
          margin: 14px 0 0;

          color: #b1b6bf;

          font-family: "Inter", sans-serif;
          font-size: 11px;
          line-height: 1.5;
        }

        .success-message {
          margin-top: 14px;
          padding: 11px 14px;

          border-radius: 8px;

          background: #f3e5ed;
          color: #8a0048;

          font-family: "Inter", sans-serif;
          font-size: 12px;
        }


        /* =====================================================
           CONVERSATION CARD
        ===================================================== */

        .conversation-card {
          width: 100%;

          padding: 34px 34px;

          border: 1px solid #f1dce6;
          border-radius: 22px;

          background: #fff8fb;
        }

        .conversation-card h2 {
          margin: 0 0 12px;

          color: #161e2d;
          font-size: 27px;
          line-height: 1.2;
          font-weight: 700;
          letter-spacing: -0.025em;
        }

        .conversation-description {
          margin: 0;

          color: #727987;

          font-family: "Inter", sans-serif;
          font-size: 14px;
          line-height: 1.65;
        }

        .card-divider {
          margin: 25px 0;
          background: #ecdde4;
        }

        .next-title,
        .quick-title,
        .direct-title {
          margin: 0 0 18px;

          color: #737b88;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.3;
          font-weight: 700;

          letter-spacing: 0.04em;
        }

        .process-step {
          display: grid;
          grid-template-columns: 38px minmax(0, 1fr);
          gap: 12px;

          margin-bottom: 21px;
        }

        .step-number {
          width: 34px;
          height: 34px;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 50%;

          background: #8a0048;
          color: #ffffff;

          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 700;
        }

        .process-step h4 {
          margin: 1px 0 4px;

          color: #202735;

          font-size: 14px;
          line-height: 1.3;
          font-weight: 700;
        }

        .process-step p {
          margin: 0;

          color: #89909b;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.5;
        }


        /* =====================================================
           QUESTION CARD
        ===================================================== */

        .question-card {
          display: flex;
          gap: 13px;

          padding: 20px;

          background: #ffffff;

          border: 1px solid #efdce6;
          border-radius: 16px;

          box-shadow:
            0 4px 10px rgba(40, 20, 30, 0.03);
        }

        .question-icon {
          flex: 0 0 32px;

          width: 32px;
          height: 32px;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 9px;

          background: #faeaf2;
          color: #8a0048;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 14px;
          font-weight: 700;
        }

        .question-content {
          min-width: 0;
        }

        .question-content h4 {
          margin: 0 0 6px;

          color: #202735;
          font-size: 14px;
          font-weight: 700;
        }

        .question-content p {
          margin: 0 0 14px;

          color: #8a919c;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.5;
        }

        .outline-button {
          min-height: 38px;

          padding: 0 17px;

          border: 1px solid #8a0048;
          border-radius: 20px;

          background: #ffffff;
          color: #8a0048;

          font-size: 12px;
          font-weight: 700;
        }

        .outline-button:hover {
          background: #8a0048;
          color: #ffffff;
        }


        /* =====================================================
           DIRECT CONTACT
        ===================================================== */

        .direct-contact {
          display: flex;
          flex-direction: column;
          gap: 17px;
        }

        .direct-item {
          display: flex;
          gap: 12px;
          align-items: flex-start;
        }

        .direct-item > strong {
          color: #8a0048;
          font-size: 14px;
          width: 16px;
        }

        .direct-item div {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }

        .direct-item b {
          color: #333b49;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 700;
        }

        .direct-item span {
          color: #818894;

          font-family: "Inter", sans-serif;
          font-size: 11px;
          line-height: 1.45;
        }


        /* =====================================================
           QUESTION CTA
        ===================================================== */

        .question-cta {
          width: 100%;

          background: #8a0048;

          padding: 72px 100px;
        }

        .question-cta-inner {
          width: 100%;
          max-width: none;

          margin: 0 auto;

          display: flex;
          align-items: center;
          justify-content: space-between;

          gap: 40px;
        }

        .question-cta-content {
          max-width: 650px;
        }

        .question-cta h2 {
          margin: 0 0 14px;

          color: #ffffff;

          font-size: 39px;
          line-height: 1.08;
          font-weight: 700;

          letter-spacing: -0.03em;
        }

        .question-cta p {
          max-width: 650px;

          margin: 0 0 25px;

          color: #f5d8e6;

          font-family: "Inter", sans-serif;
          font-size: 15px;
          line-height: 1.6;
        }

        .white-button {
          min-height: 48px;

          padding: 0 25px;

          border-radius: 25px;

          background: #ffffff;
          color: #8a0048;

          font-size: 13px;
          font-weight: 700;
        }

        .white-button:hover {
          transform: translateY(-2px);
        }

        .question-illustration {
          flex: 0 0 auto;

          width: 180px;
          height: 180px;
        }

        .question-illustration img {
          width: 100%;
          height: 100%;

          object-fit: contain;
        }


        /* =====================================================
           OFFICE SECTION
        ===================================================== */

        .office-section {
          width: 100%;
          background: #ffffff;

          padding: 78px 100px;
        }

        .office-inner {
          width: 100%;
          max-width: none;

          margin: 0 auto;

          display: grid;
          grid-template-columns: minmax(0, 1.35fr) minmax(350px, 0.85fr);

          gap: 55px;

          align-items: center;
        }

        .office-left h2 {
          margin: 0 0 8px;

          color: #121826;

          font-size: 37px;
          line-height: 1.15;
          font-weight: 700;

          letter-spacing: -0.03em;
        }

        .office-intro {
          margin: 0;

          color: #7f8793;

          font-family: "Inter", sans-serif;
          font-size: 14px;
          line-height: 1.5;
        }

        .contact-details {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));

          gap: 30px;

          margin-top: 40px;
        }

        .contact-detail {
          display: flex;
          gap: 14px;
          align-items: center;
        }

        .contact-icon {
          width: 48px;
          height: 48px;

          flex: 0 0 48px;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 50%;

          background: #8a0048;
          color: #ffffff;

          font-size: 17px;
        }

        .contact-detail > div:last-child {
          display: flex;
          flex-direction: column;
          gap: 3px;
        }

        .contact-detail span {
          color: #7f8793;

          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 700;

          letter-spacing: 0.05em;
        }

        .contact-detail strong,
        .contact-detail small {
          color: #252c38;

          font-family: "Inter", sans-serif;
          font-size: 14px;
        }

        .contact-detail small {
          font-size: 12px;
          color: #737b87;
        }

        .office-divider {
          margin: 28px 0;
        }

        .offices-heading {
          display: flex;
          align-items: center;
          gap: 8px;

          margin-bottom: 25px;

          color: #222a37;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 14px;
          font-weight: 700;
        }

        .offices-heading span {
          color: #8a0048;
        }

        .offices-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 25px;
        }

        .office-column h3 {
          margin: 0 0 7px;

          color: #222a37;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 14px;
          font-weight: 700;
        }

        .office-column p {
          margin: 0;

          color: #747d89;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.55;
        }

        .business-hours {
          display: flex;
          align-items: center;
          flex-wrap: wrap;
          gap: 5px;

          color: #626b78;

          font-family: "Inter", sans-serif;
          font-size: 12px;
        }

        .business-hours > span {
          color: #8a0048;
          margin-right: 4px;
        }

        .business-hours strong {
          color: #343c48;
        }


        /* =====================================================
           MAP
        ===================================================== */

        .map-wrapper {
          width: 100%;
        }

        .map-wrapper > span {
          position: absolute;

          top: 19px;
          left: 22px;

          z-index: 2;

          color: #68717d;

          font-family: "Inter", sans-serif;
          font-size: 8px;
          font-weight: 700;

          letter-spacing: 0.05em;
        }

        .map-wrapper img {
          display: block;

          width: 100%;
          height: 290px;

          object-fit: contain;
          object-position: center;
        }


        /* =====================================================
           FINAL CTA
        ===================================================== */

        .final-cta {
          width: 100%;

          padding: 55px 100px;

          background:
            linear-gradient(
              90deg,
              #8a0048 0%,
              #78003f 100%
            );

          position: relative;
          overflow: hidden;
        }

        .final-cta::before {
          content: "";

          position: absolute;

          width: 100%;
          height: 100%;

          left: 0;
          top: 0;

          opacity: 0.18;

          background:
            radial-gradient(
              ellipse at 20% 80%,
              transparent 0 45%,
              #ffffff 46% 46.2%,
              transparent 46.3%
            );

          pointer-events: none;
        }

        .final-cta-inner {
          position: relative;
          z-index: 1;

          width: 100%;
          max-width: none;

          margin: 0 auto;

          display: flex;
          align-items: center;
          justify-content: space-between;

          gap: 35px;
        }

        .final-cta h2 {
          margin: 0 0 5px;

          color: #ffffff;

          font-size: 28px;
          line-height: 1.15;
          font-weight: 700;

          letter-spacing: -0.025em;
        }

        .final-cta p {
          margin: 0;

          color: #f2d4e2;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.5;
        }

        .final-buttons {
          display: flex;
          align-items: center;
          gap: 12px;

          flex-shrink: 0;
        }

        .final-white-button {
          min-height: 46px;

          padding: 0 21px;

          border-radius: 25px;

          background: #ffffff;
          color: #8a0048;

          font-size: 12px;
          font-weight: 700;
        }

        .final-outline-button {
          min-height: 46px;

          padding: 0 21px;

          border: 1px solid rgba(255,255,255,0.6);
          border-radius: 25px;

          background: transparent;
          color: #ffffff;

          font-size: 12px;
          font-weight: 600;
        }

        .final-outline-button:hover {
          background: #ffffff;
          color: #8a0048;
        }


        /* =====================================================
           FOOTER-ALIGNED HORIZONTAL PADDING
        ===================================================== */

        @media (min-width: 1024px) {
          .contact-hero,
          .contact-form-section,
          .question-cta,
          .office-section,
          .final-cta {
            padding-left: 100px;
            padding-right: 100px;
          }
        }


        /* =====================================================
           LARGE TABLET
        ===================================================== */

        @media (max-width: 1100px) {

          .contact-hero-inner {
            grid-template-columns:
              minmax(0, 1fr)
              minmax(360px, 0.9fr);

            gap: 45px;
          }

          .contact-hero-content h1 {
            font-size: 42px;
          }

          .contact-grid,
          .office-inner {
            grid-template-columns:
              minmax(0, 1.25fr)
              minmax(320px, 0.8fr);

            gap: 30px;
          }

          .contact-form-card {
            padding: 34px;
          }

          .conversation-card {
            padding: 30px;
          }

          .question-cta h2 {
            font-size: 34px;
          }

        }


        /* =====================================================
           TABLET
        ===================================================== */

        @media (max-width: 900px) {

          .contact-hero {
            padding: 55px 40px 65px;
          }

          .contact-hero-inner {
            grid-template-columns: 1fr;
            gap: 38px;
          }

          .contact-hero-content {
            max-width: 700px;
          }

          .contact-hero-content h1 {
            font-size: 40px;
          }

          .contact-hero-image-wrapper {
            max-width: 650px;
          }

          .contact-hero-image {
            max-width: 100%;
            height: 390px;
            margin: 0;
          }


          .contact-form-section {
            padding: 65px 40px;
          }

          .contact-grid {
            grid-template-columns: 1fr;
            gap: 30px;
          }

          .conversation-card {
            max-width: 100%;
          }


          .question-cta {
            padding: 60px 40px;
          }

          .question-cta-inner {
            align-items: center;
          }


          .office-section {
            padding: 65px 40px;
          }

          .office-inner {
            grid-template-columns: 1fr;
            gap: 40px;
          }

          .map-wrapper {
            max-width: 650px;
          }


          .final-cta {
            padding: 50px 40px;
          }

        }


        /* =====================================================
           SMALL TABLET / IPAD
        ===================================================== */

        @media (max-width: 768px) {

          .contact-hero {
            padding: 50px 24px 60px;
          }

          .contact-hero-content h1 {
            font-size: 36px;
            line-height: 1.08;
          }

          .contact-hero-content p {
            font-size: 15px;
          }

          .contact-hero-image {
            height: 340px;
            border-radius: 18px;
          }


          .contact-form-section {
            padding: 55px 24px;
          }

          .contact-form-card {
            padding: 30px 26px;
            border-radius: 18px;
          }

          .form-header h2 {
            font-size: 28px;
          }

          .form-row {
            gap: 14px;
          }


          .question-cta {
            padding: 55px 24px;
          }

          .question-cta-inner {
            gap: 25px;
          }

          .question-cta h2 {
            font-size: 31px;
          }

          .question-illustration {
            width: 245px;
            height: 245px;
          }


          .office-section {
            padding: 55px 24px;
          }

          .office-left h2 {
            font-size: 32px;
          }

          .offices-grid {
            gap: 18px;
          }


          .final-cta {
            padding: 45px 24px;
          }

          .final-cta h2 {
            font-size: 25px;
          }

        }


        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 600px) {

          .desktop-break {
            display: none;
          }

          .eyebrow {
            font-size: 11px;
            margin-bottom: 9px;
          }


          /* HERO */

          .contact-hero {
            padding: 42px 16px 48px;
          }

          .contact-hero-inner {
            gap: 30px;
          }

          .contact-hero-content h1 {
            font-size: 32px;
            line-height: 1.1;
            letter-spacing: -0.025em;
          }

          .contact-hero-content p {
            margin-bottom: 22px;
            font-size: 14px;
            line-height: 1.6;
          }

          .primary-button {
            min-height: 46px;
            padding: 0 21px;
            font-size: 12px;
          }

          .contact-hero-image {
            height: 260px;
            border-radius: 15px;
          }


          /* FORM */

          .contact-form-section {
            padding: 40px 16px;
          }

          .contact-form-card {
            padding: 25px 18px;
            border-radius: 16px;
          }

          .form-header h2 {
            font-size: 25px;
            line-height: 1.2;
          }

          .form-header p {
            font-size: 13px;
          }

          .form-divider {
            margin: 22px 0 27px;
          }

          .form-row {
            grid-template-columns: 1fr;
            gap: 15px;
            margin-bottom: 15px;
          }

          .form-section {
            margin-bottom: 25px;
          }

          .form-section h3 {
            font-size: 15px;
            margin-bottom: 16px;
          }

          .field input,
          .field select {
            height: 44px;
            font-size: 13px;
          }

          .field textarea {
            min-height: 120px;
            font-size: 13px;
          }

          .radio-group {
            flex-direction: column;
            align-items: flex-start;
            gap: 13px;
          }

          .submit-button {
            width: 100%;
            min-height: 47px;
            font-size: 13px;
          }

          .form-note {
            font-size: 10px;
          }


          /* RIGHT CARD */

          .conversation-card {
            padding: 25px 20px;
            border-radius: 17px;
          }

          .conversation-card h2 {
            font-size: 24px;
          }

          .conversation-description {
            font-size: 13px;
          }

          .process-step {
            grid-template-columns: 35px minmax(0, 1fr);
          }

          .step-number {
            width: 32px;
            height: 32px;
          }

          .process-step h4 {
            font-size: 13px;
          }

          .process-step p {
            font-size: 11px;
          }

          .question-card {
            padding: 16px;
          }


          /* QUESTION CTA */

          .question-cta {
            padding: 48px 16px;
          }

          .question-cta-inner {
            flex-direction: column;
            align-items: flex-start;
          }

          .question-cta-content {
            max-width: 100%;
          }

          .question-cta h2 {
            font-size: 28px;
          }

          .question-cta p {
            font-size: 13px;
          }

          .question-illustration {
            align-self: center;

            width: 125px;
            height: 125px;
          }


          /* OFFICES */

          .office-section {
            padding: 45px 24px;
          }

          .office-left h2 {
            font-size: 29px;
          }

          .office-intro {
            font-size: 13px;
          }

          .contact-details {
            grid-template-columns: 1fr;
            gap: 22px;
            margin-top: 30px;
          }

          .offices-grid {
            grid-template-columns: 1fr;
            gap: 22px;
          }

          .office-column h3 {
            font-size: 13px;
          }

          .office-column p {
            font-size: 11px;
          }

          .business-hours {
            font-size: 10px;
          }


          /* FINAL CTA */

          .final-cta {
            padding: 42px 16px;
          }

          .final-cta-inner {
            flex-direction: column;
            align-items: flex-start;
          }

          .final-cta h2 {
            font-size: 24px;
          }

          .final-cta p {
            font-size: 11px;
          }

          .final-buttons {
            width: 100%;
            flex-wrap: wrap;
          }

          .final-white-button,
          .final-outline-button {
            flex: 1;
            min-width: 145px;
            font-size: 11px;
          }

        }


        /* =====================================================
           VERY SMALL MOBILE
        ===================================================== */

        @media (max-width: 380px) {

          .contact-hero {
            padding-left: 16px;
            padding-right: 16px;
          }

          .contact-hero-content h1 {
            font-size: 28px;
          }

          .contact-hero-content p {
            font-size: 13px;
          }

          .contact-hero-image {
            height: 220px;
          }


          .contact-form-section {
            padding-left: 16px;
            padding-right: 16px;
          }

          .contact-form-card {
            padding: 22px 15px;
          }

          .form-header h2 {
            font-size: 22px;
          }


          .conversation-card {
            padding: 22px 16px;
          }

          .conversation-card h2 {
            font-size: 21px;
          }


          .question-cta {
            padding-left: 16px;
            padding-right: 16px;
          }

          .question-cta h2 {
            font-size: 25px;
          }


          .office-section {
            padding-left: 16px;
            padding-right: 16px;
          }

          .office-left h2 {
            font-size: 26px;
          }


          .final-cta {
            padding-left: 16px;
            padding-right: 16px;
          }

          .final-buttons {
            flex-direction: column;
            align-items: stretch;
          }

          .final-white-button,
          .final-outline-button {
            width: 100%;
            flex: none;
          }

        }

      `})]})}export{V as default};
