import{j as e}from"./vendor-query-PraSc8EQ.js";import{d as i,L as a}from"./vendor-router-L4ZCoGSs.js";import{A as s}from"./index-37hjU4u5.js";import{S as m}from"./sparkle-DU3pd0Fh.js";const t="#7A1F3D",n="#1B1B2A",r="#5b5a63";function x(){const o=i();return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`

          .telecom-hero {
            font-family: "Inter", sans-serif;
          }

          .telecom-hero *,
          .telecom-hero *::before,
          .telecom-hero *::after {
            box-sizing: border-box;
          }

          .telecom-heading,
          .telecom-subheading {
            font-family: "Plus Jakarta Sans", sans-serif;
          }

          .telecom-image {
            transition: transform 0.5s ease;
          }

          .telecom-image:hover {
            transform: scale(1.02);
          }

          .telecom-primary-btn,
          .telecom-secondary-btn {
            transition:
              transform 0.3s ease,
              opacity 0.3s ease,
              background-color 0.3s ease;
          }

          .telecom-primary-btn:hover,
          .telecom-secondary-btn:hover {
            transform: translateY(-2px);
          }

          .telecom-primary-btn:hover {
            opacity: 0.92;
          }

          .telecom-secondary-btn:hover {
            background: #fbeef1;
          }

          /* =========================================
             DESKTOP
          ========================================= */

          .telecom-container {
            width: 100%;
            max-width: 1440px;
            margin: 0 auto;
            padding-left: 100px;
            padding-right: 100px;
          }

          /* =========================================
             LARGE TABLET / SMALL DESKTOP
          ========================================= */

          @media (max-width: 1200px) {
            .telecom-container {
              padding-left: 40px;
              padding-right: 40px;
              gap: 40px;
            }

            .telecom-heading {
              font-size: 2.2rem !important;
            }

            .telecom-image {
              height: 350px !important;
            }
          }

          /* =========================================
             TABLET
          ========================================= */

          @media (max-width: 900px) {
            .telecom-container {
              grid-template-columns: 1fr;
              padding-left: 40px;
              padding-right: 40px;
              padding-top: 55px;
              padding-bottom: 80px;
              gap: 60px;
            }

            .telecom-content {
              max-width: 750px;
            }

            .telecom-image-wrapper {
              max-width: 750px;
              width: 100%;
              margin: 0 auto;
            }

            .telecom-image {
              height: 400px !important;
            }
          }

          /* =========================================
             MOBILE
          ========================================= */

          @media (max-width: 640px) {
            .telecom-container {
              padding-left: 24px;
              padding-right: 24px;
              padding-top: 42px;
              padding-bottom: 75px;
              gap: 52px;
            }

            .telecom-heading {
              font-size: 1.85rem !important;
              line-height: 1.22 !important;
              margin-bottom: 18px !important;
            }

            .telecom-description {
              font-size: 14px !important;
              line-height: 1.7 !important;
            }

            .telecom-buttons {
              flex-direction: column;
              align-items: stretch;
              width: 100%;
            }

            .telecom-primary-btn,
            .telecom-secondary-btn {
              width: 100%;
              justify-content: center;
            }

            .telecom-image {
              height: 310px !important;
              border-radius: 18px !important;
            }

            .telecom-card {
              left: 12px !important;
              right: 12px !important;
              bottom: -38px !important;
              padding: 14px !important;
              border-radius: 14px !important;
            }

            .telecom-card-text {
              font-size: 12px !important;
            }
          }

          /* =========================================
             SMALL MOBILE
          ========================================= */

          @media (max-width: 480px) {
            .telecom-container {
              padding-left: 16px;
              padding-right: 16px;
            }

            .telecom-heading {
              font-size: 1.65rem !important;
            }

            .telecom-badge {
              font-size: 10px !important;
              padding: 6px 11px !important;
            }

            .telecom-image {
              height: 250px !important;
              border-radius: 16px !important;
            }

            .telecom-card {
              left: 7px !important;
              right: 7px !important;
              bottom: -42px !important;
              gap: 10px !important;
            }

            .telecom-card-icon {
              width: 34px !important;
              height: 34px !important;
            }

            .telecom-card-title {
              font-size: 8px !important;
            }

            .telecom-card-text {
              font-size: 11px !important;
              line-height: 1.4 !important;
            }
          }

          /* =========================================
             EXTRA SMALL MOBILE
          ========================================= */

          @media (max-width: 380px) {
            .telecom-container {
              padding-left: 16px;
              padding-right: 16px;
            }

            .telecom-heading {
              font-size: 1.5rem !important;
            }

            .telecom-image {
              height: 230px !important;
            }

            .telecom-card {
              left: 5px !important;
              right: 5px !important;
            }
          }
        `}),e.jsx("section",{className:"telecom-hero w-full bg-white",style:{color:n},children:e.jsxs("div",{className:`\r
            telecom-container\r
            grid\r
            md:grid-cols-2\r
            gap-14\r
            items-center\r
          `,style:{paddingTop:"64px",paddingBottom:"80px"},children:[e.jsxs("div",{className:"telecom-content",children:[e.jsxs("span",{className:`\r
                telecom-badge\r
                inline-flex\r
                items-center\r
                gap-1.5\r
                text-[11px]\r
                font-semibold\r
                tracking-wide\r
                px-3\r
                py-1.5\r
                rounded-full\r
                mb-6\r
              `,style:{background:"#fbeef1",color:t},children:[e.jsx("span",{className:"w-1.5 h-1.5 rounded-full",style:{background:t}}),"TELECOMMUNICATIONS"]}),e.jsx("h1",{className:`\r
                telecom-heading\r
                text-4xl\r
                md:text-[2.5rem]\r
                leading-[1.15]\r
                font-bold\r
                tracking-tight\r
                mb-6\r
              `,children:"Technology Solutions for a More Connected Telecommunications Business"}),e.jsx("p",{className:`\r
                telecom-description\r
                text-[15px]\r
                leading-relaxed\r
                mb-4\r
              `,style:{color:r},children:"Telecommunications businesses depend on technology across business operations, customer management, finance, software and digital processes. As these functions grow, organizations need technology that can support their business requirements and connect important areas of their operations."}),e.jsx("p",{className:`\r
                telecom-description\r
                text-[15px]\r
                leading-relaxed\r
                mb-8\r
              `,style:{color:r},children:"TechTorch Solutions provides technology services and digital solutions designed around business requirements, helping organizations develop, manage and improve the technology that supports their day-to-day operations."}),e.jsxs("div",{className:`\r
                telecom-buttons\r
                flex\r
                flex-wrap\r
                items-center\r
                gap-3\r
              `,children:[e.jsxs("button",{type:"button",className:`\r
                  telecom-primary-btn\r
                  inline-flex\r
                  items-center\r
                  gap-2\r
                  px-5\r
                  py-3\r
                  rounded-[6px]\r
                  text-white\r
                  text-sm\r
                  font-medium\r
                `,style:{background:t},onClick:()=>o("/telecommunication-get-in-touch"),children:["Get in Touch",e.jsx(s,{size:16})]}),e.jsx(a,{to:"/talk-to-expert",className:`\r
    telecom-secondary-btn\r
    inline-flex\r
    items-center\r
    gap-2\r
    px-5\r
    py-3\r
    rounded-[6px]\r
    text-sm\r
    font-medium\r
    border\r
  `,style:{borderColor:"#d8d5d0",color:n},children:"Talk to Our Experts"})]})]}),e.jsxs("div",{className:"telecom-image-wrapper relative",children:[e.jsx("div",{className:`\r
                telecom-image\r
                w-full\r
                h-[390px]\r
                rounded-2xl\r
                overflow-hidden\r
                bg-[#e9e8ec]\r
              `,children:e.jsx("img",{src:"/telecommunication.webp",alt:"Telecommunications technology solutions",className:`\r
                  w-full\r
                  h-full\r
                  object-cover\r
                  object-center\r
                `})}),e.jsxs("div",{className:`\r
                telecom-card\r
                absolute\r
                -bottom-8\r
                left-6\r
                right-6\r
                bg-white\r
                rounded-xl\r
                shadow-lg\r
                px-4\r
                py-4\r
                flex\r
                items-start\r
                gap-3\r
              `,children:[e.jsx("span",{className:`\r
                  telecom-card-icon\r
                  w-9\r
                  h-9\r
                  flex\r
                  items-center\r
                  justify-center\r
                  rounded-lg\r
                  shrink-0\r
                `,style:{background:"#fbeef1",color:t},children:e.jsx(m,{size:16})}),e.jsxs("div",{children:[e.jsx("p",{className:`\r
                    telecom-card-title\r
                    text-[10px]\r
                    font-semibold\r
                    tracking-wide\r
                    mb-1\r
                  `,style:{color:t},children:"INSTITUTIONAL STANDARD"}),e.jsx("p",{className:`\r
                    telecom-card-text\r
                    text-sm\r
                    font-semibold\r
                    leading-snug\r
                  `,children:"Telecommunications Technology — Connecting Technology With Business Operations"})]})]})]})]})})]})}export{x as default};
