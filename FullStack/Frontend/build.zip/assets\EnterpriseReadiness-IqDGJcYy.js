import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as i,L as p}from"./vendor-router-L4ZCoGSs.js";import{A as x}from"./arrow-up-right-DIePtCQ0.js";import{P as h}from"./phone-D3JbSBfc.js";import{K as f}from"./index-37hjU4u5.js";import{M as b}from"./mail-CbeZpzUl.js";const g="/Enterprise.webp";function N(){const[a,n]=i.useState(!1),l=i.useRef(null),t=i.useRef(null),m=()=>{t.current&&clearTimeout(t.current),n(!0)},d=()=>{t.current=setTimeout(()=>{n(!1)},400)};i.useEffect(()=>{const r=s=>{l.current&&!l.current.contains(s.target)&&n(!1)},o=s=>{s.key==="Escape"&&n(!1)};return document.addEventListener("mousedown",r),document.addEventListener("keydown",o),()=>{document.removeEventListener("mousedown",r),document.removeEventListener("keydown",o),t.current&&clearTimeout(t.current)}},[]);const u=[{label:"Call Us",Icon:h,href:"tel:+915813500381"},{label:"WhatsApp",Icon:f,href:"https://wa.me/91XXXXXXXXXX?text=Hi%2C%20I%27d%20like%20to%20know%20more%20about%20your%20enterprise%20technology%20solutions.",external:!0},{label:"Email Us",Icon:b,href:"https://mail.google.com/mail/?view=cm&fs=1&to=contact@techtorch.solutions&su=Enquiry%20from%20TechTorch%20Website",external:!0}];return e.jsx("section",{className:"w-full bg-black font-inter",style:{minHeight:"420px"},children:e.jsx("div",{className:`\r
          relative\r
          w-full\r
          min-h-[420px]\r
          sm:min-h-[460px]\r
          md:min-h-[500px]\r
          flex\r
          items-center\r
          overflow-hidden\r
          bg-cover\r
          bg-center\r
        `,style:{backgroundImage:`
            linear-gradient(
              90deg,
              rgba(10,10,20,0.98) 0%,
              rgba(10,10,20,0.90) 35%,
              rgba(10,10,20,0.55) 65%,
              rgba(10,10,20,0.20) 100%
            ),
            url(${g})
          `,backgroundSize:"cover",backgroundPosition:"center"},children:e.jsxs("div",{className:`\r
            w-full\r
            max-w-3xl\r
            px-6\r
            sm:px-10\r
            md:px-14\r
            lg:px-20\r
            py-14\r
            sm:py-16\r
            md:py-20\r
          `,children:[e.jsx("p",{className:"text-[11px] sm:text-[12px] md:text-[13px] tracking-[0.14em] font-semibold text-white mb-4 sm:mb-5 -mt-1 sm:-mt-3",children:"Enterprise Readiness"}),e.jsxs("h1",{className:`\r
              font-plus-jakarta\r
              text-white\r
              font-bold\r
              leading-[1.08]\r
              text-[30px]\r
              sm:text-[38px]\r
              md:text-[42px]\r
              lg:text-[46px]\r
              mb-4\r
              sm:mb-5\r
              md:mb-6\r
            `,children:["Architecting the Future of",e.jsx("br",{className:"hidden sm:block"}),e.jsx("span",{className:"sm:hidden",children:" "}),"Enterprise Technology"]}),e.jsx("p",{className:`\r
              text-white/80\r
              text-[13px]\r
              sm:text-sm\r
              md:text-base\r
              leading-relaxed\r
              max-w-xl\r
              mb-6\r
              sm:mb-8\r
              font-inter\r
            `,children:"We build digital foundations engineered for scale at speed. Bridging deep technical infrastructure with strategic executive clarity to deliver unshakeable performance."}),e.jsxs("div",{ref:l,className:"relative inline-block mt-2 sm:mt-4",onMouseEnter:m,onMouseLeave:d,children:[e.jsxs(p,{to:"/talk-to-expert",className:`\r
                group\r
                inline-flex\r
                items-center\r
                justify-center\r
                gap-2\r
                px-5\r
                sm:px-6\r
                py-3\r
                text-[13px]\r
                sm:text-sm\r
                font-semibold\r
                text-white\r
                rounded-sm\r
                border\r
                border-[#730042]\r
                bg-[#730042]\r
                transition-all\r
                duration-300\r
                hover:bg-white\r
                hover:text-[#730042]\r
                hover:border-white\r
                hover:scale-[1.02]\r
                whitespace-nowrap\r
              `,children:["Talk To Experts",e.jsx(x,{size:16,strokeWidth:1.8,className:`\r
                  shrink-0\r
                  transition-transform\r
                  duration-300\r
                  group-hover:translate-x-1\r
                  group-hover:-translate-y-1\r
                `})]}),e.jsx("div",{className:`
                absolute
                left-full
                top-1/2
                ml-2
                flex
                -translate-y-1/2
                items-center
                gap-2
                transition-all
                duration-300
                ${a?"visible opacity-100":"invisible opacity-0 pointer-events-none"}
              `,"aria-hidden":!a,children:u.map(({label:r,Icon:o,href:s,external:c})=>e.jsx("a",{href:s,title:r,"aria-label":r,target:c?"_blank":void 0,rel:c?"noopener noreferrer":void 0,tabIndex:a?0:-1,onClick:()=>n(!1),className:`\r
                      flex\r
                      h-10\r
                      w-10\r
                      sm:h-11\r
                      sm:w-11\r
                      shrink-0\r
                      items-center\r
                      justify-center\r
                      rounded-full\r
                      border\r
                      border-white/50\r
                      bg-black/80\r
                      text-white\r
                      backdrop-blur-md\r
                      transition-all\r
                      duration-300\r
                      hover:scale-110\r
                      hover:border-[#730042]\r
                      hover:bg-[#730042]\r
                    `,children:e.jsx(o,{size:18})},r))})]})]})})})}export{N as default};
