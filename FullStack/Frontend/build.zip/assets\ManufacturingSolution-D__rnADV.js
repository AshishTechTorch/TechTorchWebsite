import{j as i}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";import{E as r}from"./eye-DGs19ht-.js";import{T as l,N as c}from"./index-37hjU4u5.js";import{S as d}from"./share-2-C38FnL_n.js";import{S as h}from"./shield-DihDJwH1.js";const n="#7A1F3D",a="#1B1B2A",e="#5b5a63",m=[{num:"01",icon:r,title:"End-to-End Visibility",body:"Access information across inventory, orders and supplier activities."},{num:"02",icon:l,title:"Demand Forecasting",body:"Support demand planning through forecasting and analytics."},{num:"03",icon:d,title:"Supplier Collaboration",body:"Improve communication and coordination with suppliers."},{num:"04",icon:c,title:"Logistics Management",body:"Support transportation, shipment tracking and logistics activities."},{num:"05",icon:h,title:"Risk Management",body:"Identify supply chain risks and support planning around potential disruptions."}];function A(){return i.jsxs("div",{className:"supply-chain-section",children:[i.jsx("style",{children:`

        * {
          box-sizing: border-box;
        }

        .supply-chain-section {
          width: 100%;
          background: #f2f2f5;
          color: ${a};
          font-family: "Inter", Arial, sans-serif;
          overflow: hidden;
        }

        /* =====================================================
           MAIN CONTAINER
           Desktop: 100px
           Tablet: 40px
           Mobile: 24px
           Small Mobile: 16px
        ===================================================== */

        .supply-chain-container {
          width: 100%;
          max-width: 1440px;
          margin: 0 auto;
          padding: 72px 100px;
        }

        /* =====================================================
           MAIN CARD
        ===================================================== */

        .supply-chain-card {
          width: 100%;
          background: #ffffff;
          border-radius: 24px;
          padding: 44px;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
        }

        /* =====================================================
           BADGE
        ===================================================== */

        .supply-chain-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 7px 12px;
          margin-bottom: 18px;
          border-radius: 999px;
          background: #fbeef1;
          color: ${n};
          font-family: "Inter", Arial, sans-serif;
          font-size: 11px;
          font-weight: 600;
          letter-spacing: 0.04em;
          line-height: 1;
        }

        .supply-chain-badge-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: ${n};
          flex-shrink: 0;
        }

        /* =====================================================
           HEADING
           Plus Jakarta Sans
        ===================================================== */

        .supply-chain-heading {
          margin: 0 0 16px;
          max-width: 850px;
          color: ${a};
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 36px;
          line-height: 1.2;
          font-weight: 700;
          letter-spacing: -0.025em;
        }

        /* =====================================================
           SUBHEADING
           Plus Jakarta Sans
        ===================================================== */

        .supply-chain-subheading {
          max-width: 950px;
          margin: 0 0 36px;
          color: ${e};
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 14px;
          line-height: 1.8;
          font-weight: 500;
        }

        /* =====================================================
           CARDS GRID
        ===================================================== */

        .supply-chain-grid {
          display: grid;
          grid-template-columns: repeat(5, minmax(0, 1fr));
          gap: 16px;
        }

        .supply-chain-item {
          min-width: 0;
          padding: 19px;
          border: 1px solid #ece9e4;
          border-radius: 16px;
          background: #ffffff;
          transition:
            transform 0.25s ease,
            box-shadow 0.25s ease,
            border-color 0.25s ease;
        }

        .supply-chain-item:hover {
          transform: translateY(-4px);
          border-color: #e4d8dc;
          box-shadow: 0 10px 25px rgba(122, 31, 61, 0.08);
        }

        /* =====================================================
           CARD TOP
        ===================================================== */

        .supply-chain-item-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
          margin-bottom: 24px;
        }

        .supply-chain-number {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-width: 30px;
          height: 25px;
          padding: 0 8px;
          border-radius: 6px;
          background: #fbeef1;
          color: ${n};
          font-family: "Inter", Arial, sans-serif;
          font-size: 10px;
          font-weight: 600;
        }

        .supply-chain-icon {
          color: #c9c4bc;
          flex-shrink: 0;
        }

        /* =====================================================
           CARD TITLE
           Plus Jakarta Sans
        ===================================================== */

        .supply-chain-item-title {
          margin: 0 0 8px;
          color: ${a};
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 14px;
          line-height: 1.4;
          font-weight: 700;
        }

        /* =====================================================
           CARD BODY
           Inter
        ===================================================== */

        .supply-chain-item-body {
          margin: 0;
          color: ${e};
          font-family: "Inter", Arial, sans-serif;
          font-size: 12px;
          line-height: 1.65;
          font-weight: 400;
        }

        /* =====================================================
           LARGE TABLET
           40px horizontal spacing
        ===================================================== */

        @media (max-width: 1100px) {
          .supply-chain-container {
            padding: 60px 40px;
          }

          .supply-chain-card {
            padding: 36px;
          }

          .supply-chain-grid {
            grid-template-columns: repeat(3, minmax(0, 1fr));
          }

          .supply-chain-heading {
            font-size: 32px;
          }
        }

        /* =====================================================
           TABLET
           40px horizontal spacing
        ===================================================== */

        @media (max-width: 800px) {
          .supply-chain-container {
            padding: 50px 40px;
          }

          .supply-chain-card {
            padding: 30px;
            border-radius: 20px;
          }

          .supply-chain-heading {
            font-size: 29px;
          }

          .supply-chain-subheading {
            font-size: 13.5px;
            line-height: 1.75;
            margin-bottom: 28px;
          }

          .supply-chain-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
          }

          .supply-chain-item {
            padding: 17px;
          }
        }

        /* =====================================================
           MOBILE
           24px horizontal spacing
        ===================================================== */

        @media (max-width: 600px) {
          .supply-chain-container {
            padding: 40px 24px;
          }

          .supply-chain-card {
            padding: 24px 18px;
            border-radius: 18px;
          }

          .supply-chain-badge {
            font-size: 10px;
            padding: 7px 10px;
            margin-bottom: 15px;
          }

          .supply-chain-heading {
            font-size: 25px;
            line-height: 1.25;
            letter-spacing: -0.02em;
            margin-bottom: 13px;
          }

          .supply-chain-subheading {
            font-size: 13px;
            line-height: 1.7;
            margin-bottom: 24px;
          }

          .supply-chain-grid {
            grid-template-columns: 1fr;
            gap: 12px;
          }

          .supply-chain-item {
            padding: 17px;
          }

          .supply-chain-item-top {
            margin-bottom: 20px;
          }

          .supply-chain-item-title {
            font-size: 14px;
          }

          .supply-chain-item-body {
            font-size: 12px;
            line-height: 1.6;
          }
        }

        /* =====================================================
           SMALL MOBILE
           16px horizontal spacing
        ===================================================== */

        @media (max-width: 400px) {
          .supply-chain-container {
            padding: 32px 16px;
          }

          .supply-chain-card {
            padding: 21px 15px;
          }

          .supply-chain-heading {
            font-size: 22px;
          }

          .supply-chain-subheading {
            font-size: 12.5px;
          }

          .supply-chain-item {
            padding: 15px;
          }

          .supply-chain-item-title {
            font-size: 13.5px;
          }

          .supply-chain-item-body {
            font-size: 11.5px;
          }
        }

        /* =====================================================
           VERY SMALL MOBILE
           16px horizontal spacing
        ===================================================== */

        @media (max-width: 340px) {
          .supply-chain-container {
            padding: 28px 16px;
          }

          .supply-chain-card {
            padding: 18px 13px;
          }

          .supply-chain-heading {
            font-size: 20px;
          }

          .supply-chain-subheading {
            font-size: 12px;
          }

          .supply-chain-badge {
            font-size: 9px;
          }
        }

        /* =====================================================
           REDUCED MOTION
        ===================================================== */

        @media (prefers-reduced-motion: reduce) {
          .supply-chain-item {
            transition: none;
          }

          .supply-chain-item:hover {
            transform: none;
          }
        }
      `}),i.jsx("div",{className:"supply-chain-container",children:i.jsxs("div",{className:"supply-chain-card",children:[i.jsxs("span",{className:"supply-chain-badge",children:[i.jsx("span",{className:"supply-chain-badge-dot"}),"SUPPLY CHAIN MANAGEMENT"]}),i.jsx("h2",{className:"supply-chain-heading",children:"From Procurement to Delivery"}),i.jsx("p",{className:"supply-chain-subheading",children:"A connected supply chain depends on visibility across procurement, inventory, suppliers, orders and logistics. TechTorch Supply Chain Management solutions are designed to support supply chain activities from procurement through delivery, helping businesses manage important information across their supply chain environment."}),i.jsx("div",{className:"supply-chain-grid",children:m.map(({num:p,icon:s,title:t,body:o})=>i.jsxs("div",{className:"supply-chain-item",children:[i.jsxs("div",{className:"supply-chain-item-top",children:[i.jsx("span",{className:"supply-chain-number",children:p}),i.jsx(s,{size:16,strokeWidth:1.8,className:"supply-chain-icon"})]}),i.jsx("h3",{className:"supply-chain-item-title",children:t}),i.jsx("p",{className:"supply-chain-item-body",children:o})]},p))})]})})]})}export{A as default};
