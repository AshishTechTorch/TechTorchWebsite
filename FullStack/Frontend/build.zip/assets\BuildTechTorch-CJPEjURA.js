import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as i,L}from"./vendor-router-L4ZCoGSs.js";import{A as S}from"./arrow-up-right-DIePtCQ0.js";import{P as O}from"./phone-D3JbSBfc.js";import{t as P,K as M,X as D,a2 as W,v as G,w as $,I as H}from"./index-37hjU4u5.js";import{M as R}from"./mail-CbeZpzUl.js";import{C as q}from"./clipboard-list-ivKQuMBl.js";import{U as F}from"./user-cog-DR4rZ0mg.js";import{C as V}from"./code-xml-CIX-EOu2.js";import{R as U}from"./rocket-B8Wt4fTK.js";import{S as _}from"./smartphone-CoEIwl-3.js";import{B as Y}from"./box-pPhQi2CY.js";import{S as J}from"./share-2-C38FnL_n.js";import{C as K}from"./chevron-left-IInL7UPY.js";const C={name:"component",size:24,node:[["path",{d:"M15.536 11.293a1 1 0 0 0 0 1.414l2.376 2.377a1 1 0 0 0 1.414 0l2.377-2.377a1 1 0 0 0 0-1.414l-2.377-2.377a1 1 0 0 0-1.414 0z",key:"1uwlt4"}],["path",{d:"M2.297 11.293a1 1 0 0 0 0 1.414l2.377 2.377a1 1 0 0 0 1.414 0l2.377-2.377a1 1 0 0 0 0-1.414L6.088 8.916a1 1 0 0 0-1.414 0z",key:"10291m"}],["path",{d:"M8.916 17.912a1 1 0 0 0 0 1.415l2.377 2.376a1 1 0 0 0 1.414 0l2.377-2.376a1 1 0 0 0 0-1.415l-2.377-2.376a1 1 0 0 0-1.414 0z",key:"1tqoq1"}],["path",{d:"M8.916 4.674a1 1 0 0 0 0 1.414l2.377 2.376a1 1 0 0 0 1.414 0l2.377-2.376a1 1 0 0 0 0-1.414l-2.377-2.377a1 1 0 0 0-1.414 0z",key:"1x6lto"}]]};C.node;const Z=P(C);function Q(){const[o,r]=i.useState(!1),l=i.useRef(null),s=i.useRef(null),d=()=>{s.current&&clearTimeout(s.current),r(!0)},c=()=>{s.current=setTimeout(()=>{r(!1)},400)};i.useEffect(()=>{const t=n=>{l.current&&!l.current.contains(n.target)&&r(!1)},a=n=>{n.key==="Escape"&&r(!1)};return document.addEventListener("mousedown",t),document.addEventListener("keydown",a),()=>{document.removeEventListener("mousedown",t),document.removeEventListener("keydown",a),s.current&&clearTimeout(s.current)}},[]);const h=[{label:"Call Us",Icon:O,href:"tel:+915813500381"},{label:"WhatsApp",Icon:M,href:"https://wa.me/91XXXXXXXXXX?text=Hi%2C%20I%27d%20like%20to%20know%20more%20about%20your%20software%20development%20solutions.",external:!0},{label:"Email Us",Icon:R,href:"https://mail.google.com/mail/?view=cm&fs=1&to=contact@techtorch.solutions&su=Software%20Development%20Enquiry",external:!0}];return e.jsxs("section",{className:`\r
        relative\r
        w-full\r
        overflow-hidden\r
        bg-[#0b0b0b]\r
        min-h-[560px]\r
        sm:min-h-[580px]\r
        md:min-h-[540px]\r
        lg:h-[500px]\r
        lg:min-h-0\r
      `,children:[e.jsx("img",{loading:"lazy",decoding:"async",src:"/Slide3.1.webp",alt:"Software Development",className:`\r
          absolute\r
          inset-0\r
          h-full\r
          w-full\r
          object-cover\r
          object-[65%_center]\r
          sm:object-[60%_center]\r
          md:object-[55%_center]\r
          lg:object-[52%_center]\r
          xl:object-center\r
        `}),e.jsx("div",{className:`\r
          absolute\r
          inset-0\r
          bg-gradient-to-r\r
          from-black/95\r
          via-black/80\r
          to-black/35\r
          sm:from-black/95\r
          sm:via-black/75\r
          sm:to-black/20\r
          md:from-black/95\r
          md:via-black/70\r
          md:to-transparent\r
          lg:from-black/95\r
          lg:via-black/70\r
          lg:to-transparent\r
        `}),e.jsx("div",{className:`\r
          relative\r
          z-10\r
          flex\r
          w-full\r
          items-center\r
          min-h-[560px]\r
          px-4\r
          py-14\r
          sm:min-h-[580px]\r
          sm:px-6\r
          sm:py-16\r
          md:min-h-[540px]\r
          md:px-10\r
          md:py-14\r
          lg:h-full\r
          lg:min-h-0\r
          lg:px-[100px]\r
          lg:py-10\r
        `,children:e.jsxs("div",{className:`\r
            w-full\r
            max-w-[560px]\r
            text-white\r
            sm:max-w-[580px]\r
            md:max-w-[540px]\r
            lg:max-w-[520px]\r
          `,children:[e.jsx("p",{className:`\r
              mb-4\r
              font-['Plus_Jakarta_Sans']\r
              text-[11px]\r
              font-semibold\r
              tracking-[0.7px]\r
              min-[400px]:text-[12px]\r
              sm:mb-5\r
              sm:text-[13px]\r
              md:text-[14px]\r
              lg:mb-5\r
              lg:text-[13px]\r
            `,children:"SOFTWARE DEVELOPMENT"}),e.jsxs("h1",{className:`\r
              mb-5\r
              font-['Plus_Jakarta_Sans']\r
              text-[34px]\r
              font-medium\r
              leading-[1.08]\r
              tracking-[-0.8px]\r
              min-[400px]:text-[34px]\r
              sm:text-[34px]\r
              sm:tracking-[-1px]\r
              md:text-[36px]\r
              lg:mb-6\r
              lg:text-[38px]\r
              xl:text-[38px]\r
            `,children:["Software Built",e.jsx("br",{}),"Around Your Business"]}),e.jsxs("div",{className:`\r
              max-w-[520px]\r
              font-['Inter']\r
              text-[14px]\r
              font-normal\r
              leading-[1.6]\r
              text-white/95\r
              sm:text-[15px]\r
              sm:leading-[1.65]\r
              md:max-w-[500px]\r
              md:text-[16px]\r
              lg:text-[15px]\r
              lg:leading-[1.5]\r
            `,children:[e.jsx("p",{children:"Your business has its own way of working. Your software should support that—not force you to work around it."}),e.jsx("p",{className:`\r
                mt-4\r
                sm:mt-5\r
                md:mt-5\r
                lg:mt-5\r
              `,children:"At TechTorch, we build software around your processes, your people and your business goals. From new applications to modernizing existing systems, we create practical digital solutions that solve real business needs and are built to grow with you."})]}),e.jsx("div",{className:"mt-7 sm:mt-8 md:mt-8 lg:mt-8",children:e.jsxs("div",{ref:l,className:"relative inline-block",onMouseEnter:d,onMouseLeave:c,children:[e.jsxs(L,{to:"/talk-to-expert",className:`\r
                  group\r
                  inline-flex\r
                  items-center\r
                  justify-center\r
                  gap-2\r
                  rounded-[3px]\r
                  bg-[#730042]\r
                  px-5\r
                  py-[10px]\r
                  font-['Inter']\r
                  text-[13px]\r
                  font-semibold\r
                  text-white\r
                  transition-all\r
                  duration-300\r
                  hover:bg-white\r
                  hover:text-[#730042]\r
                  sm:px-6\r
                  sm:py-[11px]\r
                  sm:text-[15px]\r
                  lg:px-5\r
                  lg:py-[10px]\r
                `,children:[e.jsx("span",{children:"Talk To Experts"}),e.jsx(S,{size:17,strokeWidth:1.8,className:`\r
                    shrink-0\r
                    transition-transform\r
                    duration-300\r
                    group-hover:translate-x-1\r
                    group-hover:-translate-y-1\r
                  `})]}),e.jsx("div",{className:`
                  absolute
                  left-full
                  top-1/2
                  ml-2
                  flex
                  -translate-y-1/2
                  items-center
                  gap-2
                  transition-all
                  duration-300
                  ${o?"visible opacity-100":"invisible opacity-0 pointer-events-none"}
                `,"aria-hidden":!o,children:h.map(({label:t,Icon:a,href:n,external:p})=>e.jsx("a",{href:n,title:t,"aria-label":t,target:p?"_blank":void 0,rel:p?"noopener noreferrer":void 0,tabIndex:o?0:-1,onClick:()=>r(!1),className:`\r
                        flex\r
                        h-10\r
                        w-10\r
                        sm:h-11\r
                        sm:w-11\r
                        shrink-0\r
                        items-center\r
                        justify-center\r
                        rounded-full\r
                        border\r
                        border-white/50\r
                        bg-black/80\r
                        text-white\r
                        backdrop-blur-md\r
                        transition-all\r
                        duration-300\r
                        hover:scale-110\r
                        hover:border-[#730042]\r
                        hover:bg-[#730042]\r
                      `,children:e.jsx(a,{size:18})},t))})]})})]})})]})}function ee(){return e.jsxs("section",{className:"software-works-section",style:{background:"#f7f4ef",fontFamily:"'Plus Jakarta Sans', sans-serif",overflow:"hidden"},children:[e.jsx("div",{className:"software-works-container",children:e.jsxs("div",{className:"software-works-grid",children:[e.jsxs("div",{className:"software-works-content",children:[e.jsxs("h2",{className:"software-works-heading",children:["Software That Works",e.jsx("br",{}),"For ",e.jsx("span",{children:"Your Business"})]}),e.jsx("p",{children:"Every organization has different processes, priorities and challenges. Yet many businesses still rely on software that doesn't fully fit the way their teams work. We take a different approach."}),e.jsx("p",{children:"At TechTorch, we start by understanding your business and the problem you want to solve. We look at your existing processes, systems and user needs before defining the right solution."}),e.jsx("p",{children:"That could mean building a new application, connecting systems that currently operate separately, or modernizing an existing platform."}),e.jsx("p",{children:"The technology is important, but the business outcome comes first."})]}),e.jsxs("div",{className:"software-works-right",children:[e.jsx("div",{className:"software-works-image",children:e.jsx("img",{loading:"lazy",decoding:"async",src:"/Slide3.2.webp",alt:"Business team working together"})}),e.jsxs("p",{className:"software-works-highlight",children:["We build software to make your business",e.jsx("br",{className:"desktop-break"}),"work better—not simply to add another",e.jsx("br",{className:"desktop-break"}),"system."]})]})]})}),e.jsx("style",{children:`

        /* =====================================================
           SECTION
        ====================================================== */

        .software-works-section {
          width: 100%;
          box-sizing: border-box;
        }


        /* =====================================================
           CONTAINER

           SAME ALIGNMENT AS FOOTER

           Mobile  = 16px
           Small   = 24px
           Tablet  = 40px
           Desktop = 100px
        ====================================================== */

        .software-works-container {
          width: 100%;
          margin: 0;

          padding: 45px 100px;

          box-sizing: border-box;
        }


        /* =====================================================
           GRID
        ====================================================== */

        .software-works-grid {
          display: grid;

          grid-template-columns:
            minmax(0, 1.15fr)
            minmax(0, 0.85fr);

          gap: 70px;

          align-items: start;
        }


        /* =====================================================
           LEFT CONTENT
        ====================================================== */

        .software-works-content {
          min-width: 0;

          padding-top: 10px;

          /*
            No horizontal transform.
            Text starts exactly with Footer alignment.
          */

          transform: none;
        }


        /* =====================================================
           HEADING
        ====================================================== */

        .software-works-heading {
          margin: 0;

          max-width: 700px;

          font-size: 38px;
          font-weight: 600;
          line-height: 1.1;

          letter-spacing: -1.8px;

          color: #111111;
        }


        .software-works-heading span {
          color: #730042;
        }


        /* =====================================================
           PARAGRAPHS
        ====================================================== */

        .software-works-content > p {
          max-width: 680px;

          margin: 0;
          margin-top: 28px;

          font-family: "Inter", sans-serif;

          font-size: 16px;
          font-weight: 400;

          line-height: 1.65;

          color: #292929;
        }


        .software-works-content > p:first-of-type {
          margin-top: 40px;
        }


        /* =====================================================
           RIGHT CONTENT

           IMAGE IS SHIFTED TOWARDS RIGHT
           TO MATCH FOOTER'S RIGHT SIDE.
        ====================================================== */

        .software-works-right {
          min-width: 0;

          display: flex;
          flex-direction: column;

          align-items: flex-start;

          padding-top: 0;

          /*
            Desktop right-side shift.
            This moves the image closer to the
            right Footer alignment.
          */

          transform: translateX(45px);
        }


        /* =====================================================
           IMAGE
        ====================================================== */

        .software-works-image {
          width: 100%;

          max-width: 400px;

          border-radius: 20px;

          overflow: hidden;
        }


        .software-works-image img {
          width: 100%;
          height: auto;

          display: block;

          object-fit: contain;
        }


        /* =====================================================
           HIGHLIGHT TEXT
        ====================================================== */

        .software-works-highlight {
          width: 100%;

          max-width: 520px;

          margin: 38px 0 0;

          font-size: 18px;
          font-weight: 700;

          line-height: 1.3;

          letter-spacing: -0.4px;

          color: #730042;
        }


        /* =====================================================
           LARGE LAPTOP
        ====================================================== */

        @media (max-width: 1200px) {

          .software-works-container {
            padding-left: 70px;
            padding-right: 70px;
          }


          .software-works-grid {
            gap: 50px;
          }


          .software-works-right {
            transform: translateX(25px);
          }


          .software-works-heading {
            font-size: 42px;
          }


          .software-works-image {
            max-width: 480px;
          }


          .software-works-highlight {
            font-size: 20px;
          }
        }


        /* =====================================================
           TABLET / SMALL LAPTOP
        ====================================================== */

        @media (max-width: 1000px) {

          .software-works-container {
            padding-left: 40px;
            padding-right: 40px;
          }


          .software-works-grid {
            grid-template-columns:
              minmax(0, 1fr)
              minmax(0, 0.9fr);

            gap: 35px;
          }


          .software-works-right {
            transform: translateX(15px);
          }


          .software-works-heading {
            font-size: 38px;
          }


          .software-works-content > p {
            font-size: 15.5px;
            line-height: 1.6;
          }


          .software-works-image {
            max-width: 100%;
          }


          .software-works-highlight {
            margin-top: 28px;
            font-size: 18px;
          }
        }


        /* =====================================================
           TABLET
        ====================================================== */

        @media (max-width: 768px) {

          .software-works-container {
            padding-left: 20px;
            padding-right: 20px;

            padding-top: 45px;
            padding-bottom: 45px;
          }


          .software-works-grid {
            grid-template-columns: 1fr;

            gap: 45px;
          }


          .software-works-content {
            transform: none;

            padding-top: 0;
          }


          .software-works-heading {
            font-size: 36px;

            line-height: 1.12;
          }


          .software-works-content > p {
            max-width: 100%;

            font-size: 16px;
          }


          /*
            On tablet the image becomes centered
            so it never gets cut off.
          */

          .software-works-right {
            align-items: center;

            width: 100%;

            transform: none;
          }


          .software-works-image {
            width: 100%;

            max-width: 600px;
          }


          .software-works-highlight {
            max-width: 600px;

            font-size: 20px;

            margin-top: 28px;
          }
        }


        /* =====================================================
           MOBILE
        ====================================================== */

        @media (max-width: 600px) {

          /*
            EXACT FOOTER MOBILE ALIGNMENT

            Footer = px-4 = 16px
          */

          .software-works-container {
            padding-left: 16px;
            padding-right: 16px;

            padding-top: 40px;
            padding-bottom: 40px;
          }


          .software-works-grid {
            gap: 38px;
          }


          .software-works-heading {
            font-size: 30px;

            line-height: 1.15;

            letter-spacing: -1px;
          }


          .software-works-content > p {
            margin-top: 20px;

            font-size: 15px;

            line-height: 1.6;
          }


          .software-works-content > p:first-of-type {
            margin-top: 28px;
          }


          /*
            Keep image centered on mobile.
          */

          .software-works-right {
            width: 100%;

            align-items: center;

            transform: none;
          }


          .software-works-image {
            width: 100%;

            max-width: 100%;

            border-radius: 14px;
          }


          .software-works-highlight {
            margin-top: 24px;

            font-size: 17px;

            line-height: 1.4;
          }


          .desktop-break {
            display: none;
          }
        }


        /* =====================================================
           VERY SMALL MOBILE
        ====================================================== */

        @media (max-width: 380px) {

          .software-works-container {
            padding-left: 14px;
            padding-right: 14px;

            padding-top: 35px;
            padding-bottom: 35px;
          }


          .software-works-heading {
            font-size: 27px;
          }


          .software-works-content > p {
            font-size: 14px;
          }


          .software-works-highlight {
            font-size: 16px;
          }
        }

      `})]})}const m="#7a1338",A=[{id:"custom",icon:Z,title:"Custom Business Applications",description:"Purpose-built applications designed around your processes, workflows and operational requirements."},{id:"enterprise",icon:G,title:"Enterprise Applications",description:"Scalable solutions that bring together people, processes and information across your organization."},{id:"web",icon:$,title:"Web Applications",description:"Reliable and intuitive web applications for employees, customers and business users."},{id:"mobile",icon:_,title:"Mobile Applications",description:"Mobile experiences that give teams and customers convenient access to the services and information they need."},{id:"modernization",icon:Y,title:"Application Modernization",description:"Modernize existing applications, improve performance and maintainability, and create a stronger foundation for the future."},{id:"integration",icon:J,title:"API & System Integration",description:"Connect applications, platforms and data sources to create smoother workflows and a more connected technology environment."}];function te(){const[o,r]=i.useState(0),[l,s]=i.useState(3);i.useEffect(()=>{const t=()=>{window.innerWidth<=600?s(1):window.innerWidth<=1e3?s(2):s(3)};return t(),window.addEventListener("resize",t),()=>{window.removeEventListener("resize",t)}},[]);const d=Math.max(0,A.length-l);i.useEffect(()=>{r(t=>Math.min(t,d))},[d]);const c=()=>{r(t=>Math.max(0,t-1))},h=()=>{r(t=>Math.min(d,t+1))};return e.jsxs("section",{className:"what-we-build-section",children:[e.jsxs("div",{className:"build-content-wrapper",children:[e.jsxs("div",{className:"build-heading",children:[e.jsxs("div",{className:"build-heading-left",children:[e.jsx("p",{className:"build-label",children:"WHAT WE BUILD"}),e.jsx("h2",{children:"Software Designed for Real Business Needs"})]}),e.jsx("p",{className:"build-heading-description",children:"We develop software across a range of business requirements, from focused applications to connected enterprise systems."})]}),e.jsx("div",{className:"cards-viewport",children:e.jsx("div",{className:"cards-track",style:{transform:`translateX(-${o*(100/l)}%)`},children:A.map(t=>{const a=t.icon;return e.jsx("div",{className:"card-slide",style:{flex:`0 0 ${100/l}%`},children:e.jsxs("div",{className:"build-card",children:[e.jsx("div",{className:"build-icon",children:e.jsx(a,{size:21,color:"#ffffff",strokeWidth:1.8})}),e.jsx("h3",{children:t.title}),e.jsx("p",{children:t.description})]})},t.id)})})}),e.jsxs("div",{className:"slider-buttons",children:[e.jsx("button",{onClick:c,disabled:o===0,className:"slider-button","aria-label":"Previous cards",children:e.jsx(K,{size:19})}),e.jsx("button",{onClick:h,disabled:o===d,className:"slider-button","aria-label":"Next cards",children:e.jsx(H,{size:19})})]})]}),e.jsx("style",{children:`
        /* ================= SECTION ================= */

        .what-we-build-section {
          position: relative;
          width: 100%;
          padding: 60px 80px;
          box-sizing: border-box;

          background: ${m};

          background-image:
            repeating-linear-gradient(
              90deg,
              rgba(255, 255, 255, 0.045) 0px,
              rgba(255, 255, 255, 0.045) 1px,
              transparent 1px,
              transparent 90px
            );

          font-family: "Plus Jakarta Sans", sans-serif;
          overflow: hidden;
        }

        /* ================= CONTENT ================= */

        .build-content-wrapper {
          width: 100%;
          max-width: 1300px;
          margin: 0 auto;
          box-sizing: border-box;

          transform: translateX(15px);
        }

        /* ================= HEADING ================= */

        .build-heading {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;

          width: 100%;

          gap: 40px;
          margin-bottom: 40px;
        }

        .build-heading-left {
          flex: 1;
          min-width: 0;
        }

        .build-label {
          font-size: 13px;
          font-weight: 700;
          letter-spacing: 1px;

          color: #f0c9d8;

          margin: 0 0 10px;
        }

        .build-heading h2 {
          max-width: 430px;

          font-size: 28px;
          font-weight: 700;
          line-height: 1.3;

          color: #ffffff;
          margin: 0;
        }

        .build-heading-description {
          width: 100%;
          max-width: 400px;

          font-size: 15px;
          line-height: 1.7;

          color: #e9d3dd;
          margin: 0;
        }

        /* ================= SLIDER ================= */

        .cards-viewport {
          width: 100%;
          overflow: hidden;
        }

        .cards-track {
          display: flex;
          width: 100%;

          transition: transform 0.5s ease;
          will-change: transform;
        }

        /* ================= CARD SLIDE ================= */

        .card-slide {
          flex-shrink: 0;
          box-sizing: border-box;

          /* Cards ke beech gap */
          padding-right: 75px;

          /* Halka right shift */
          transform: translateX(12px);
        }

        /* ================= CARD ================= */

        .build-card {
          width: 100%;
          min-height: 285px;

          padding: 25px 22px;
          box-sizing: border-box;

          display: flex;
          flex-direction: column;

          background: #ffffff;
          border-radius: 14px;
        }

        /* ================= ICON ================= */

        .build-icon {
          width: 46px;
          height: 46px;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 50%;
          background: ${m};

          margin-bottom: 16px;
          flex-shrink: 0;
        }

        /* ================= TITLE ================= */

        .build-card h3 {
          font-size: 16px;
          font-weight: 700;
          line-height: 1.3;

          color: #1a1a1a;

          margin: 0 0 11px;
        }

        /* ================= DESCRIPTION ================= */

        .build-card p {
          font-size: 13px;
          line-height: 1.6;

          color: #555555;
          margin: 0;
        }

        /* ================= BUTTONS ================= */

        .slider-buttons {
          display: flex;
          justify-content: center;
          align-items: center;

          gap: 14px;
          margin-top: 34px;
        }

        .slider-button {
          width: 40px;
          height: 40px;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.5);

          background: transparent;
          color: #ffffff;

          cursor: pointer;

          transition:
            background 0.2s ease,
            color 0.2s ease,
            transform 0.2s ease;
        }

        .slider-button:hover:not(:disabled) {
          background: #ffffff;
          color: ${m};

          transform: translateY(-2px);
        }

        .slider-button:disabled {
          opacity: 0.4;
          cursor: default;
        }

        /* ================= LARGE LAPTOP ================= */

        @media (max-width: 1200px) {
          .what-we-build-section {
            padding: 55px 55px;
          }

          .build-content-wrapper {
            transform: translateX(12px);
          }

          .card-slide {
            padding-right: 65px;
            transform: translateX(10px);
          }

          .build-card {
            min-height: 280px;
            padding: 24px 21px;
          }
        }

        /* ================= TABLET ================= */

        @media (max-width: 1000px) {
          .what-we-build-section {
            padding: 50px 40px;
          }

          .build-content-wrapper {
            transform: translateX(8px);
          }

          .build-heading {
            gap: 30px;
            margin-bottom: 35px;
          }

          .card-slide {
            padding-right: 50px;
            transform: translateX(8px);
          }

          .build-card {
            min-height: 275px;
            padding: 24px 21px;
          }
        }

        /* ================= TABLET / SMALL ================= */

        @media (max-width: 768px) {
          .what-we-build-section {
            padding: 48px 25px;
          }

          .build-content-wrapper {
            transform: translateX(0);
          }

          .build-heading {
            flex-direction: column;

            align-items: flex-start;

            gap: 18px;
            margin-bottom: 32px;
          }

          .build-heading h2 {
            max-width: 100%;
            font-size: 26px;
          }

          .build-heading-description {
            max-width: 550px;
            font-size: 15px;
          }

          .card-slide {
            padding-right: 35px;
            transform: translateX(5px);
          }

          .build-card {
            min-height: 270px;
            padding: 23px 20px;
          }

          .slider-buttons {
            margin-top: 30px;
          }
        }

        /* ================= MOBILE ================= */

        @media (max-width: 600px) {
          .what-we-build-section {
            padding: 42px 20px;
          }

          .build-content-wrapper {
            transform: none;
          }

          .build-heading {
            gap: 16px;
            margin-bottom: 28px;
          }

          .build-label {
            font-size: 12px;
          }

          .build-heading h2 {
            font-size: 24px;
            line-height: 1.35;
          }

          .build-heading-description {
            max-width: 100%;

            font-size: 14px;
            line-height: 1.65;
          }

          /* Mobile: single card full width */

          .card-slide {
            padding-right: 0;
            transform: none;
          }

          .build-card {
            min-height: 265px;

            padding: 22px 20px;

            border-radius: 12px;
          }

          .build-icon {
            width: 44px;
            height: 44px;

            margin-bottom: 15px;
          }

          .build-card h3 {
            font-size: 16px;
            margin-bottom: 10px;
          }

          .build-card p {
            font-size: 13px;
            line-height: 1.55;
          }

          .slider-buttons {
            margin-top: 26px;
            gap: 12px;
          }

          .slider-button {
            width: 38px;
            height: 38px;
          }
        }

        /* ================= SMALL MOBILE ================= */

        @media (max-width: 480px) {
          .what-we-build-section {
            padding: 38px 18px;
          }

          .build-heading h2 {
            font-size: 23px;
          }

          .build-heading-description {
            font-size: 13.5px;
          }

          .build-card {
            min-height: 255px;
            padding: 21px 18px;
          }
        }

        /* ================= VERY SMALL MOBILE ================= */

        @media (max-width: 380px) {
          .what-we-build-section {
            padding: 35px 15px;
          }

          .build-heading h2 {
            font-size: 21px;
          }

          .build-card {
            min-height: 250px;
            padding: 20px 17px;
          }

          .build-card h3 {
            font-size: 15px;
          }

          .build-card p {
            font-size: 12.5px;
          }

          .slider-button {
            width: 36px;
            height: 36px;
          }
        }
      `})]})}const ne=[{id:"understand",icon:D,title:"Understand",description:"We learn how your business works, understand your users and review the systems and processes already in place."},{id:"define",icon:q,title:"Define",description:"We translate business requirements into clear priorities, functionality and a practical technical direction."},{id:"design",icon:F,title:"Design",description:"We design user journeys, interfaces and workflows around the people who will use the solution."},{id:"develop",icon:V,title:"Develop",description:"Our engineering team builds the solution with a focus on quality, reliability, performance and maintainability."},{id:"validate",icon:W,title:"Validate",description:"We test the software against business requirements to make sure it works as intended and is ready for real users."},{id:"launch",icon:U,title:"Launch & Evolve",description:"Going live is only the beginning. We support improvements, enhancements and changes as your business continues to develop."}];function re(){const o=i.useRef(null),r=i.useRef(null),l=i.useRef({}),[s,d]=i.useState(""),[c,h]=i.useState({width:0,height:0}),[t,a]=i.useState(!1);return i.useEffect(()=>{const n=o.current;if(!n)return;const p=new IntersectionObserver(w=>{w.forEach(g=>{g.isIntersecting?(a(!1),requestAnimationFrame(()=>{requestAnimationFrame(()=>{a(!0)})})):a(!1)})},{threshold:.2});return p.observe(n),()=>{p.disconnect()}},[]),i.useLayoutEffect(()=>{const n=()=>{const N=r.current;if(!N)return;const x=N.getBoundingClientRect();h({width:x.width,height:x.height});const j=48,T=j/2,f=B=>{const I=l.current[B];if(!I)return null;const u=I.getBoundingClientRect();return{x:u.left+T-x.left,y:u.top+T-x.top,left:u.left-x.left,right:u.left+j-x.left,top:u.top-x.top,bottom:u.top+j-x.top}},z=f("understand"),b=f("define"),v=f("design"),y=f("develop"),k=f("validate"),E=f("launch");if(!z||!b||!v||!y||!k||!E)return;const X=`
        <!-- Understand -> Define -->
        M ${z.right} ${z.y}
        H ${b.left}

        <!-- Define -> Design -->
        M ${b.right} ${b.y}
        H ${v.left}

        <!-- Design -> Develop -->
        M ${v.x} ${v.bottom}
        V ${y.y}

        <!-- Develop -> Validate -->
        M ${y.right} ${y.y}
        H ${k.left}

        <!-- Validate -> Launch -->
        M ${k.right} ${k.y}
        H ${E.left}
      `;d(X)};n();const p=setTimeout(()=>{n()},100),w=setTimeout(()=>{n()},500),g=new ResizeObserver(()=>{requestAnimationFrame(()=>{n()})});return r.current&&g.observe(r.current),window.addEventListener("resize",n),()=>{g.disconnect(),window.removeEventListener("resize",n),clearTimeout(p),clearTimeout(w)}},[]),e.jsxs("section",{ref:o,className:"structured-approach-section",children:[e.jsxs("div",{className:"structured-container",children:[e.jsxs("h2",{children:["A Structured Approach to"," ",e.jsx("span",{children:"Software Development"})]}),e.jsx("p",{className:"intro-text",children:"Successful software starts with a clear understanding of the problem."}),e.jsx("p",{className:"intro-text intro-bottom",children:"Our development approach brings business requirements, user needs and technology together at every stage."}),e.jsxs("div",{ref:r,className:"structured-grid",children:[c.width>0&&s&&e.jsx("svg",{className:"connector-svg",viewBox:`0 0 ${c.width} ${c.height}`,preserveAspectRatio:"none","aria-hidden":"true",children:e.jsx("path",{d:s,fill:"none",stroke:m,strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",opacity:"0.9"})}),ne.map((n,p)=>{const w=n.icon;return e.jsxs("div",{ref:g=>{l.current[n.id]=g},className:`step-card ${t?"step-card-visible":""}`,children:[e.jsx("div",{className:"step-icon",style:{"--icon-delay":`${p*.16}s`},children:e.jsx(w,{size:20,color:m,strokeWidth:2})}),e.jsx("h3",{children:n.title}),e.jsx("p",{children:n.description})]},n.id)})]})]}),e.jsx("style",{children:`
        /* =====================================================
          MAIN SECTION
        ===================================================== */

        .structured-approach-section {
          padding: 70px 40px;

          background-color: #ffffff;

          background-image:
            repeating-linear-gradient(
              -45deg,
              rgba(122, 19, 56, 0.06) 0px,
              rgba(122, 19, 56, 0.06) 1px,
              transparent 1px,
              transparent 50px
            );

          font-family: "Segoe UI", Arial, sans-serif;

          box-sizing: border-box;

          overflow: hidden;
        }

        /* =====================================================
          CONTAINER
        ===================================================== */

        .structured-container {
          width: 100%;
          max-width: 1200px;

          margin: 0 auto;
        }

        /* =====================================================
          HEADING
        ===================================================== */

        .structured-container > h1 {
          font-size: 28px;

          font-weight: 700;

          text-align: center;

          color: #1a1a1a;

          margin: 0 0 12px;

          line-height: 1.3;
        }

        .structured-container > h1 span {
          color: ${m};
        }

        /* =====================================================
          INTRO
        ===================================================== */

        .intro-text {
          font-size: 15px;

          text-align: center;

          color: #333;

          margin: 0 auto 6px;

          max-width: 700px;

          line-height: 1.6;
        }

        .intro-bottom {
          margin-bottom: 60px;
        }

        /* =====================================================
          GRID
        ===================================================== */

        .structured-grid {
          position: relative;

          display: grid;

          grid-template-columns:
            repeat(3, minmax(0, 1fr));

          column-gap: 40px;

          row-gap: 70px;

          transform: translateX(35px);

          width: calc(100% - 35px);

          box-sizing: border-box;
        }

        /* =====================================================
          CONNECTOR SVG
        ===================================================== */

        .connector-svg {
          position: absolute;

          inset: 0;

          width: 100%;

          height: 100%;

          pointer-events: none;

          z-index: 0;

          overflow: visible;
        }

        /* =====================================================
          STEP CARD
        ===================================================== */

        .step-card {
          position: relative;

          z-index: 1;

          width: 100%;

          max-width: 340px;
        }

        /* =====================================================
          ICON
        ===================================================== */

        .step-icon {
          width: 48px;

          height: 48px;

          border-radius: 50%;

          border: 1.5px solid ${m};

          background: #ffffff;

          display: flex;

          align-items: center;

          justify-content: center;

          margin-bottom: 18px;

          position: relative;

          z-index: 2;

          flex-shrink: 0;

          opacity: 0;

          transform: translateY(25px);

          transition:
            opacity 0.55s ease,
            transform 0.7s cubic-bezier(
              0.22,
              1,
              0.36,
              1
            );

          transition-delay: var(--icon-delay);

          will-change: opacity, transform;
        }

        /* =====================================================
          ICON VISIBLE
        ===================================================== */

        .step-card-visible .step-icon {
          opacity: 1;

          transform: translateY(0);
        }

        /* =====================================================
          CARD HEADING
        ===================================================== */

        .step-card h3 {
          font-size: 17px;

          font-weight: 700;

          color: #1a1a1a;

          margin: 0 0 10px;

          line-height: 1.35;
        }

        /* =====================================================
          CARD TEXT
        ===================================================== */

        .step-card p {
          font-size: 14px;

          line-height: 1.6;

          color: #555;

          margin: 0;
        }

        /* =====================================================
          TABLET
        ===================================================== */

        @media (max-width: 1200px) {
          .structured-approach-section {
            padding: 65px 35px;
          }

          .structured-grid {
            column-gap: 35px;

            row-gap: 65px;

            transform: translateX(25px);

            width: calc(100% - 25px);
          }
        }

        /* =====================================================
          SMALL TABLET
        ===================================================== */

        @media (max-width: 900px) {
          .structured-approach-section {
            padding: 60px 30px;
          }

          .structured-container > h1 {
            font-size: 27px;
          }

          .intro-bottom {
            margin-bottom: 50px;
          }

          .structured-grid {
            column-gap: 28px;

            row-gap: 60px;

            transform: translateX(15px);

            width: calc(100% - 15px);
          }

          .step-card {
            max-width: 100%;
          }

          .step-card h3 {
            font-size: 16px;
          }

          .step-card p {
            font-size: 14px;
          }
        }

        /* =====================================================
          MOBILE
        ===================================================== */

        @media (max-width: 768px) {
          .structured-approach-section {
            padding: 55px 25px;
          }

          .structured-container > h1 {
            font-size: 26px;
          }

          .intro-text {
            font-size: 14px;
          }

          .intro-bottom {
            margin-bottom: 45px;
          }

          .structured-grid {
            grid-template-columns: 1fr;

            row-gap: 42px;

            transform: translateX(0);

            width: 100%;
          }

          /* Connector hidden on mobile */
          .connector-svg {
            display: none;
          }

          .step-card {
            max-width: 100%;
          }

          .step-icon {
            margin-bottom: 14px;
          }
        }

        /* =====================================================
          SMALL MOBILE
        ===================================================== */

        @media (max-width: 480px) {
          .structured-approach-section {
            padding: 45px 20px;
          }

          .structured-container > h1 {
            font-size: 24px;

            line-height: 1.3;
          }

          .intro-text {
            font-size: 14px;

            line-height: 1.55;
          }

          .intro-bottom {
            margin-bottom: 40px;
          }

          .structured-grid {
            row-gap: 38px;
          }

          .step-icon {
            width: 45px;

            height: 45px;
          }

          .step-card h3 {
            font-size: 16px;

            margin-bottom: 8px;
          }

          .step-card p {
            font-size: 14px;

            line-height: 1.55;
          }
        }

        /* =====================================================
          EXTRA SMALL MOBILE
        ===================================================== */

        @media (max-width: 360px) {
          .structured-approach-section {
            padding: 40px 16px;
          }

          .structured-container > h1 {
            font-size: 22px;
          }

          .structured-grid {
            row-gap: 35px;
          }

          .step-icon {
            width: 44px;

            height: 44px;
          }
        }

        /* =====================================================
          REDUCED MOTION
        ===================================================== */

        @media (prefers-reduced-motion: reduce) {
          .step-icon {
            opacity: 1;

            transform: none;

            transition: none;
          }
        }
      `})]})}const ie="/Apartment2.webp";function se(){return e.jsxs("section",{className:"software-growth-section",children:[e.jsxs("div",{className:"software-growth-container",children:[e.jsxs("div",{className:"software-growth-text",children:[e.jsxs("h2",{children:["Software That Can Grow",e.jsx("br",{}),"With ",e.jsx("span",{children:"Your Business"})]}),e.jsx("p",{children:"Business requirements don't stay the same."}),e.jsx("p",{children:"Teams change. Customers grow. Processes evolve. New systems are introduced and existing ones need to connect."}),e.jsx("p",{children:"That's why we consider the future from the beginning."}),e.jsx("p",{children:"We build with scalability, maintainability, integration and long-term requirements in mind, so your software can continue to support the business as it evolves."}),e.jsx("p",{children:"We don't believe good software needs to be unnecessarily complicated."}),e.jsx("p",{className:"software-growth-highlight",children:"It needs to be right for the business today—and ready for tomorrow."})]}),e.jsx("div",{className:"apartment-image-wrapper",children:e.jsx("img",{loading:"lazy",decoding:"async",src:ie,alt:"Residential apartment towers"})})]}),e.jsx("style",{children:`
        .software-growth-section {
          width: 100%;
          padding: 0 80px;
          background: #ffffff;
          font-family: "Plus Jakarta Sans", sans-serif;
          overflow: hidden;
          box-sizing: border-box;
        }

        .software-growth-container {
          width: 100%;
          max-width: 1300px;
          margin: 0 auto;

          display: flex;
          align-items: center;
          justify-content: space-between;

          gap: 60px;
          box-sizing: border-box;
        }

        /* ================= TEXT ================= */

        .software-growth-text {
          width: 100%;
          max-width: 500px;
          flex: 1 1 380px;

          padding: 60px 0;

          transform: translateX(35px);
          box-sizing: border-box;
        }

        .software-growth-text h1 {
          font-size: 36px;
          line-height: 1.25;
          font-weight: 700;
          color: #1a1a1a;

          margin: 0 0 32px 0;
        }

        .software-growth-text h1 span {
          color: #7a1338;
        }

        .software-growth-text p {
          font-size: 16px;
          line-height: 1.7;
          color: #4a4a4a;

          margin: 0 0 28px 0;
        }

        .software-growth-text .software-growth-highlight {
          font-size: 17px;
          line-height: 1.6;
          font-weight: 700;
          color: #7a1338;

          margin: 0;
        }

        /* ================= IMAGE ================= */

        .apartment-image-wrapper {
          width: 100%;
          max-width: 600px;
          flex: 1 1 340px;

          display: flex;
          align-items: center;
          justify-content: center;

          transform: translateX(80px);
          box-sizing: border-box;
        }

        .apartment-image-wrapper img {
          width: 100%;
          height: 660px;

          display: block;

          object-fit: contain;

          margin: 0;
          padding: 0;
        }


        /* =====================================================
           LARGE LAPTOP
        ===================================================== */

        @media (max-width: 1300px) {
          .software-growth-section {
            padding: 0 60px;
          }

          .software-growth-container {
            gap: 50px;
          }

          .software-growth-text {
            transform: translateX(28px);
          }

          .apartment-image-wrapper {
            transform: translateX(60px);
          }

          .apartment-image-wrapper img {
            height: 620px;
          }
        }


        /* =====================================================
           LAPTOP
        ===================================================== */

        @media (max-width: 1100px) {
          .software-growth-section {
            padding: 0 50px;
          }

          .software-growth-container {
            gap: 40px;
          }

          .software-growth-text {
            max-width: 470px;
            transform: translateX(20px);
          }

          .software-growth-text h1 {
            font-size: 34px;
          }

          .apartment-image-wrapper {
            max-width: 540px;
            transform: translateX(35px);
          }

          .apartment-image-wrapper img {
            height: 570px;
          }
        }


        /* =====================================================
           TABLET
        ===================================================== */

        @media (max-width: 900px) {
          .software-growth-section {
            padding: 0 40px;
          }

          .software-growth-container {
            gap: 30px;
          }

          .software-growth-text {
            flex: 1 1 320px;
            max-width: 440px;

            transform: translateX(10px);
          }

          .software-growth-text h1 {
            font-size: 32px;
          }

          .software-growth-text p {
            font-size: 15px;
          }

          .software-growth-highlight {
            font-size: 16px !important;
          }

          .apartment-image-wrapper {
            flex: 1 1 300px;
            max-width: 450px;

            transform: translateX(15px);
          }

          .apartment-image-wrapper img {
            height: 500px;
          }
        }


        /* =====================================================
           SMALL TABLET / MOBILE
        ===================================================== */

        @media (max-width: 768px) {
          .software-growth-section {
            padding: 0;
          }

          .software-growth-container {
            flex-direction: column;

            align-items: stretch;

            gap: 0;
          }

          .software-growth-text {
            width: 100%;
            max-width: none;

            flex: none;

            padding: 55px 30px;

            transform: translateX(0);
          }

          .software-growth-text h1 {
            font-size: 32px;
            margin-bottom: 28px;
          }

          .software-growth-text p {
            font-size: 16px;
            margin-bottom: 24px;
          }

          .software-growth-text .software-growth-highlight {
            font-size: 17px;
            margin-bottom: 0;
          }

          .apartment-image-wrapper {
            width: 100%;
            max-width: none;

            flex: none;

            transform: translateX(0);

            padding: 0;
          }

          .apartment-image-wrapper img {
            width: 100%;
            height: auto;

            max-height: none;

            object-fit: contain;
          }
        }


        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 480px) {
          .software-growth-text {
            padding: 45px 20px;
          }

          .software-growth-text h1 {
            font-size: 28px;
            line-height: 1.25;

            margin-bottom: 25px;
          }

          .software-growth-text p {
            font-size: 15px;
            line-height: 1.65;

            margin-bottom: 22px;
          }

          .software-growth-text .software-growth-highlight {
            font-size: 16px;
            line-height: 1.55;
          }
        }


        /* =====================================================
           SMALL MOBILE
        ===================================================== */

        @media (max-width: 360px) {
          .software-growth-text {
            padding: 40px 16px;
          }

          .software-growth-text h1 {
            font-size: 25px;
          }

          .software-growth-text p {
            font-size: 14px;
          }

          .software-growth-text .software-growth-highlight {
            font-size: 15px;
          }
        }
      `})]})}function ae(){return e.jsx("section",{className:"w-full overflow-hidden bg-[#faf9f4]",children:e.jsxs("div",{className:`\r
          mx-auto\r
          w-full\r
          max-w-[1400px]\r
\r
          px-5\r
          py-10\r
\r
          sm:px-7\r
          sm:py-12\r
\r
          md:px-10\r
          md:py-14\r
\r
          lg:px-12\r
          lg:py-16\r
\r
          xl:px-14\r
          xl:py-16\r
        `,children:[e.jsxs("h2",{className:`\r
            font-['Inter']\r
            text-[30px]\r
            font-semibold\r
            leading-[1.1]\r
            tracking-[-1.2px]\r
            text-[#111111]\r
\r
            min-[400px]:text-[32px]\r
\r
            sm:text-[36px]\r
            sm:tracking-[-1.5px]\r
\r
            md:relative\r
            md:left-4\r
            md:text-[40px]\r
\r
            lg:left-6\r
            lg:text-[42px]\r
\r
            xl:left-8\r
            xl:text-[38px]\r
          `,children:["Technology That",e.jsx("br",{}),"Delivers"," ",e.jsx("span",{className:"text-[#850052]",children:"Business Value"})]}),e.jsxs("div",{className:`\r
            mt-8\r
            grid\r
            grid-cols-1\r
            gap-10\r
\r
            sm:mt-10\r
            sm:gap-12\r
\r
            md:mt-12\r
            md:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)]\r
            md:gap-x-12\r
            md:gap-y-10\r
\r
            lg:gap-x-20\r
\r
            xl:gap-x-24\r
          `,children:[e.jsxs("div",{className:`\r
              min-w-0\r
\r
              md:relative\r
              md:left-4\r
\r
              lg:left-6\r
\r
              xl:left-8\r
            `,children:[e.jsx("p",{className:`\r
                max-w-[650px]\r
                font-['Inter']\r
                text-[15px]\r
                font-normal\r
                leading-[1.65]\r
                text-[#5c5c5c]\r
\r
                sm:text-[16px]\r
\r
                md:text-[16px]\r
\r
                lg:text-[16px]\r
              `,children:"Good software should do more than introduce new technology. It should make the business work better."}),e.jsx("p",{className:`\r
                mt-5\r
                max-w-[650px]\r
                font-['Inter']\r
                text-[15px]\r
                font-normal\r
                leading-[1.65]\r
                text-[#5c5c5c]\r
\r
                sm:mt-6\r
                sm:text-[16px]\r
\r
                md:mt-7\r
\r
                lg:mt-8\r
              `,children:"At TechTorch, we focus on building solutions that improve everyday operations, connect information and make work easier for the people who use them. Whether the goal is to reduce repetitive tasks, bring disconnected systems together or give teams better access to information, we look at the business outcome behind the technology."}),e.jsx("p",{className:`\r
                mt-5\r
                max-w-[650px]\r
                font-['Inter']\r
                text-[15px]\r
                font-normal\r
                leading-[1.65]\r
                text-[#5c5c5c]\r
\r
                sm:mt-6\r
                sm:text-[16px]\r
\r
                md:mt-7\r
\r
                lg:mt-8\r
              `,children:"As businesses grow, their requirements change. Teams expand, processes evolve and new systems need to work alongside existing ones. That's why we consider scalability, maintainability and integration from the beginning. We build software that can adapt to changing requirements without adding unnecessary complexity."})]}),e.jsxs("div",{className:`\r
              min-w-0\r
\r
              md:relative\r
              md:-top-2\r
              md:left-2\r
\r
              lg:-top-4\r
              lg:left-4\r
\r
              xl:-top-5\r
              xl:left-6\r
            `,children:[e.jsx("p",{className:`\r
                max-w-full\r
                font-['Inter']\r
                text-[15px]\r
                font-normal\r
                leading-[1.65]\r
                text-[#5c5c5c]\r
\r
                sm:max-w-[580px]\r
                sm:text-[16px]\r
\r
                md:max-w-[480px]\r
\r
                lg:max-w-[500px]\r
\r
                xl:max-w-[500px]\r
              `,children:"The right technology should also be practical. Not every business needs a large or complex system, and custom software isn't always the answer. But when standard solutions cannot support an important process or provide the flexibility a business needs, a tailored solution can make a meaningful difference."}),e.jsx("p",{className:`\r
                mt-5\r
                max-w-full\r
                font-['Inter']\r
                text-[15px]\r
                font-normal\r
                leading-[1.65]\r
                text-[#5c5c5c]\r
\r
                sm:mt-6\r
                sm:max-w-[580px]\r
                sm:text-[16px]\r
\r
                md:mt-7\r
                md:max-w-[480px]\r
\r
                lg:mt-8\r
                lg:max-w-[500px]\r
\r
                xl:max-w-[500px]\r
              `,children:"Our approach is simple: understand the problem, choose the right technology and build a solution that creates lasting value."}),e.jsx("p",{className:`\r
                mt-5\r
                max-w-full\r
                font-['Inter']\r
                text-[15px]\r
                font-normal\r
                leading-[1.65]\r
                text-[#5c5c5c]\r
\r
                sm:mt-6\r
                sm:max-w-[580px]\r
                sm:text-[16px]\r
\r
                md:mt-7\r
                md:max-w-[480px]\r
\r
                lg:mt-8\r
                lg:max-w-[500px]\r
\r
                xl:max-w-[500px]\r
              `,children:"Software should simplify work, connect people and information, support better decisions and give businesses room to grow."}),e.jsx("p",{className:`\r
                mt-7\r
                max-w-full\r
                font-['Plus_Jakarta_Sans']\r
                text-[17px]\r
                font-medium\r
                leading-[1.35]\r
                tracking-[-0.3px]\r
                text-[#850052]\r
\r
                sm:mt-8\r
                sm:max-w-[580px]\r
                sm:text-[18px]\r
\r
                md:mt-9\r
                md:max-w-[480px]\r
                md:text-[19px]\r
\r
                lg:max-w-[500px]\r
                lg:text-[20px]\r
\r
                xl:max-w-[500px]\r
                xl:text-[18px]\r
              `,children:"The goal isn't to build more technology. It's to build the right technology for the business—and make sure it continues to deliver value over time."})]})]})]})})}const oe="/bgslide07.webp",le="/hero03slide07.webp";function pe(){const[o,r]=i.useState(!1),l=i.useRef(null),s=i.useRef(null),d=()=>{s.current&&clearTimeout(s.current),r(!0)},c=()=>{s.current=setTimeout(()=>{r(!1)},400)};i.useEffect(()=>{const t=n=>{l.current&&!l.current.contains(n.target)&&r(!1)},a=n=>{n.key==="Escape"&&r(!1)};return document.addEventListener("mousedown",t),document.addEventListener("keydown",a),()=>{document.removeEventListener("mousedown",t),document.removeEventListener("keydown",a),s.current&&clearTimeout(s.current)}},[]);const h=[{label:"Call Us",Icon:O,href:"tel:+915813500381"},{label:"WhatsApp",Icon:M,href:"https://wa.me/91XXXXXXXXXX?text=Hi%2C%20I%27d%20like%20to%20discuss%20my%20business%20challenge.",external:!0},{label:"Email Us",Icon:R,href:"https://mail.google.com/mail/?view=cm&fs=1&to=contact@techtorch.solutions&su=Software%20Development%20Enquiry",external:!0}];return e.jsxs("section",{className:"business-challenge-section",children:[e.jsxs("div",{className:"business-challenge-container",children:[e.jsxs("div",{className:"business-challenge-content",children:[e.jsxs("h2",{className:"business-challenge-heading",children:["Have a Business",e.jsx("br",{}),"Challenge to Solve"]}),e.jsx("p",{className:"business-challenge-paragraph",children:"Whether you're planning a new application, modernizing an existing system or looking for a better way to manage a business process, the right place to start is with the problem."}),e.jsx("p",{className:"business-challenge-paragraph",children:"We'll work with you to understand the opportunity, define a practical solution and build software that fits the way your business works."}),e.jsxs("div",{ref:l,className:"business-challenge-contact-wrapper",onMouseEnter:d,onMouseLeave:c,children:[e.jsxs(L,{to:"/talk-to-expert",className:"business-challenge-button",children:[e.jsx("span",{children:"Talk to Experts"}),e.jsx(S,{size:18,strokeWidth:1.8,className:"business-challenge-arrow"})]}),e.jsx("div",{className:`business-challenge-contact-options ${o?"show":""}`,"aria-hidden":!o,children:h.map(({label:t,Icon:a,href:n,external:p})=>e.jsx("a",{href:n,title:t,"aria-label":t,target:p?"_blank":void 0,rel:p?"noopener noreferrer":void 0,tabIndex:o?0:-1,onClick:()=>r(!1),className:"business-challenge-contact-icon",children:e.jsx(a,{size:18})},t))})]})]}),e.jsx("div",{className:"business-challenge-image-wrapper",children:e.jsx("img",{loading:"lazy",decoding:"async",className:"business-challenge-image",src:le,alt:"Team discussing business challenge"})})]}),e.jsx("style",{children:`
        /* ================= MAIN SECTION ================= */

        .business-challenge-section {
          position: relative;
          width: 100%;
          overflow: hidden;

          padding: 55px 80px;

          background-color: #ffffff;
          background-image: url(${oe});
          background-repeat: no-repeat;
          background-position: right bottom;
          background-size: 55% auto;

          font-family: "Plus Jakarta Sans", sans-serif;
          box-sizing: border-box;
        }

        /* ================= CONTAINER ================= */

        .business-challenge-container {
          position: relative;
          z-index: 2;

          width: 100%;
          max-width: 1300px;

          margin: 0 auto;

          display: flex;
          align-items: center;
          justify-content: space-between;

          gap: 60px;
        }

        /* ================= LEFT CONTENT ================= */

        .business-challenge-content {
          flex: 1 1 420px;

          width: 100%;
          max-width: 500px;

          transform: translateX(15px);
        }

        /* ================= HEADING ================= */

        .business-challenge-heading {
          margin: 0 0 30px;

          font-size: 40px;
          font-weight: 700;
          line-height: 1.2;

          color: #1a1a1a;
        }

        /* ================= PARAGRAPH ================= */

        .business-challenge-paragraph {
          max-width: 420px;

          margin: 0 0 20px;

          font-size: 16px;
          line-height: 1.7;

          color: #4a4a4a;
        }

        /* ================= BUTTON WRAPPER ================= */

        .business-challenge-contact-wrapper {
          position: relative;
          display: inline-block;
          margin-top: 25px;
        }

        /* ================= BUTTON ================= */

        .business-challenge-button {
          display: inline-flex;

          align-items: center;
          justify-content: center;
          gap: 8px;

          padding: 14px 30px;

          background: #7a1338;
          color: #ffffff;

          font-size: 16px;
          font-weight: 600;

          text-decoration: none;

          border-radius: 6px;

          transition:
            background 0.25s ease,
            color 0.25s ease,
            transform 0.25s ease;

          white-space: nowrap;
        }

        .business-challenge-button:hover {
          background: #5c0e2a;
          color: #ffffff;
          transform: translateY(-2px);
        }

        /* ================= ARROW ================= */

        .business-challenge-arrow {
          flex-shrink: 0;
          transition: transform 0.3s ease;
        }

        .business-challenge-button:hover
        .business-challenge-arrow {
          transform: translate(3px, -3px);
        }

        /* ================= CONTACT ICONS ================= */

        .business-challenge-contact-options {
          position: absolute;
          left: 100%;
          top: 50%;

          display: flex;
          align-items: center;
          gap: 8px;

          margin-left: 10px;

          transform: translateY(-50%);

          visibility: hidden;
          opacity: 0;
          pointer-events: none;

          transition:
            opacity 0.3s ease,
            visibility 0.3s ease;

          z-index: 5;
        }

        .business-challenge-contact-options.show {
          visibility: visible;
          opacity: 1;
          pointer-events: auto;
        }

        .business-challenge-contact-icon {
          display: flex;
          align-items: center;
          justify-content: center;

          width: 42px;
          height: 42px;
          flex-shrink: 0;

          border: 1px solid rgba(122, 19, 56, 0.35);
          border-radius: 50%;

          background: #ffffff;
          color: #7a1338;

          text-decoration: none;

          transition:
            background 0.25s ease,
            color 0.25s ease,
            border-color 0.25s ease,
            transform 0.25s ease;
        }

        .business-challenge-contact-icon:hover {
          background: #730042;
          color: #ffffff;
          border-color: #730042;
          transform: scale(1.08);
        }

        /* ================= IMAGE WRAPPER ================= */

        .business-challenge-image-wrapper {
          flex: 1 1 420px;

          width: 100%;
          max-width: 620px;

          transform: translateX(40px);
        }

        /* ================= IMAGE ================= */

        .business-challenge-image {
          display: block;

          width: 100%;
          height: auto;

          min-height: 420px;
          max-height: 520px;

          object-fit: cover;

          border-radius: 18px;

          box-shadow:
            0 25px 50px rgba(122, 19, 56, 0.15);
        }

        /* =====================================================
           LARGE LAPTOP
        ====================================================== */

        @media (max-width: 1200px) {
          .business-challenge-section {
            padding: 55px 50px;
            background-size: 60% auto;
          }

          .business-challenge-container {
            gap: 45px;
          }

          .business-challenge-content {
            max-width: 460px;
            transform: translateX(10px);
          }

          .business-challenge-image-wrapper {
            max-width: 540px;
            transform: translateX(20px);
          }

          .business-challenge-heading {
            font-size: 38px;
          }

          .business-challenge-image {
            min-height: 400px;
            max-height: 480px;
          }
        }

        /* =====================================================
           TABLET / SMALL LAPTOP
        ====================================================== */

        @media (max-width: 950px) {
          .business-challenge-section {
            padding: 50px 35px;
            background-size: 65% auto;
          }

          .business-challenge-container {
            gap: 35px;
          }

          .business-challenge-content {
            flex: 1 1 330px;
            max-width: 430px;

            transform: translateX(5px);
          }

          .business-challenge-image-wrapper {
            flex: 1 1 330px;
            max-width: 470px;

            transform: translateX(0);
          }

          .business-challenge-heading {
            font-size: 34px;
          }

          .business-challenge-paragraph {
            font-size: 15px;
          }

          .business-challenge-image {
            min-height: 380px;
            max-height: 430px;
          }

          .business-challenge-contact-options {
            gap: 6px;
            margin-left: 8px;
          }

          .business-challenge-contact-icon {
            width: 38px;
            height: 38px;
          }
        }

        /* =====================================================
           MOBILE / TABLET PORTRAIT
        ====================================================== */

        @media (max-width: 700px) {
          .business-challenge-section {
            padding: 50px 25px;

            background-size: 100% auto;
            background-position: right bottom;
          }

          .business-challenge-container {
            flex-direction: column;

            align-items: flex-start;

            gap: 40px;
          }

          .business-challenge-content {
            flex: none;

            width: 100%;
            max-width: 100%;

            transform: translateX(0);
          }

          .business-challenge-heading {
            font-size: 32px;
            line-height: 1.22;

            margin-bottom: 25px;
          }

          .business-challenge-paragraph {
            width: 100%;
            max-width: 100%;

            font-size: 15px;
            line-height: 1.7;

            margin-bottom: 18px;
          }

          .business-challenge-contact-wrapper {
            margin-top: 20px;
          }

          .business-challenge-button {
            margin-top: 0;

            padding: 13px 26px;

            font-size: 15px;
          }

          .business-challenge-image-wrapper {
            flex: none;

            width: 100%;
            max-width: 100%;

            transform: translateX(0);
          }

          .business-challenge-image {
            width: 100%;

            min-height: unset;
            max-height: unset;

            aspect-ratio: 4 / 3;

            object-fit: cover;
          }

          .business-challenge-contact-options {
            gap: 6px;
            margin-left: 7px;
          }

          .business-challenge-contact-icon {
            width: 34px;
            height: 34px;
          }

          .business-challenge-contact-icon svg {
            width: 16px;
            height: 16px;
          }
        }

        /* =====================================================
           SMALL MOBILE
        ====================================================== */

        @media (max-width: 480px) {
          .business-challenge-section {
            padding: 40px 20px;
          }

          .business-challenge-container {
            gap: 32px;
          }

          .business-challenge-heading {
            font-size: 28px;
            line-height: 1.25;

            margin-bottom: 22px;
          }

          .business-challenge-paragraph {
            font-size: 14px;
            line-height: 1.65;

            margin-bottom: 16px;
          }

          .business-challenge-button {
            width: auto;

            padding: 12px 23px;

            font-size: 14px;
          }

          .business-challenge-image {
            aspect-ratio: 1 / 1;

            border-radius: 14px;
          }

          .business-challenge-contact-options {
            gap: 5px;
            margin-left: 6px;
          }

          .business-challenge-contact-icon {
            width: 31px;
            height: 31px;
          }

          .business-challenge-contact-icon svg {
            width: 15px;
            height: 15px;
          }
        }

        /* =====================================================
           VERY SMALL MOBILE
        ====================================================== */

        @media (max-width: 360px) {
          .business-challenge-section {
            padding: 35px 16px;
          }

          .business-challenge-heading {
            font-size: 25px;
          }

          .business-challenge-paragraph {
            font-size: 13.5px;
          }

          .business-challenge-contact-options {
            gap: 4px;
            margin-left: 5px;
          }

          .business-challenge-contact-icon {
            width: 28px;
            height: 28px;
          }

          .business-challenge-contact-icon svg {
            width: 14px;
            height: 14px;
          }
        }
      `})]})}function ze(){return e.jsxs(e.Fragment,{children:[e.jsx(Q,{}),e.jsx(ee,{}),e.jsx(te,{}),e.jsx(re,{}),e.jsx(se,{}),e.jsx(ae,{}),e.jsx(pe,{})]})}export{pe as BusinessChallengeSection,Q as SoftwareDevelopmentHero,se as SoftwareGrowthSection,ee as SoftwareThatWorks,re as StructuredApproachSection,ae as TechnologyBusinessValue,te as WhatWeBuildSection,ze as default};
