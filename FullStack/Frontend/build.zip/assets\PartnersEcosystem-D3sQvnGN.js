import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as h}from"./vendor-router-L4ZCoGSs.js";import{C as b}from"./cloud-C7BQ_lpB.js";import{P as u}from"./puzzle-Be_lEFVz.js";import{S as f}from"./settings-BNjID7h6.js";import{L as j}from"./link-2-DwassH_y.js";import{T as y}from"./target-BdO2Z0xV.js";import{U as w}from"./users-round-C3PwGoY0.js";import{r as v,A as N}from"./index-37hjU4u5.js";const p={handshake:"/PartnersEcosystem1.webp",network:"/PartnersEcosystem2.webp",building:"/PartnersEcosystem3.webp"},k=[{icon:b,title:"Technology Partnerships",description:"Explore opportunities to collaborate on software, technology platforms, and digital capabilities that support changing business requirements."},{icon:u,title:"Solution Partnerships",description:"Combine complementary products and expertise to address specific customer needs and deliver relevant business solutions."},{icon:f,title:"Service Partnerships",description:"Work together across implementation, technical services, and delivery capabilities to support customer projects and operational requirements."}],T=[{icon:j,title:"Complementary Capabilities",description:"Bring together relevant expertise and services to address a broader range of business and technology requirements."},{icon:y,title:"Business Collaboration",description:"Identify opportunities to work together on customer projects and shared business objectives."},{icon:w,title:"Customer-Focused Solutions",description:"Align technology and service capabilities with customer requirements and practical business outcomes."},{icon:v,title:"Professional Relationships",description:"Build partnerships grounded in transparency, accountability, and mutual value."}],i="px-4 sm:px-6 md:px-10 lg:px-[100px]",r="py-12 md:py-16 lg:py-24",o=({children:a,light:c})=>e.jsx("span",{className:`mb-3 block text-[11px] font-bold uppercase tracking-wide sm:text-xs ${c?"text-[#e6b6ca]":"text-[#b31962]"}`,children:a}),n="w-full rounded border border-[#cbd2dc] px-3 py-2.5 text-[13px] text-[#111a2e] placeholder:text-[#a7b0be] focus:border-[#730042] focus:outline-none focus:ring-2 focus:ring-[#730042]/20",l="mb-1.5 mt-3.5 block text-xs font-semibold text-[#4c5768]";function B(){const a=h.useRef(null),[c,m]=h.useState(!1),x=()=>a.current?.scrollIntoView({behavior:"smooth",block:"center"}),g=s=>{s.preventDefault();const t=s.currentTarget;m(!0),t.reset(),setTimeout(()=>m(!1),3500)};return e.jsxs("main",{className:"partners-ecosystem-page w-full overflow-x-hidden font-inter text-[#111a2e]",children:[e.jsx("section",{className:`bg-[#faf9f4] ${r} ${i}`,children:e.jsxs("div",{className:"grid min-w-0 grid-cols-1 items-center gap-8 md:grid-cols-2 md:gap-12",children:[e.jsxs("div",{children:[e.jsx(o,{children:"Partners Ecosystem"}),e.jsx("h1",{className:"text-[32px] font-extrabold leading-[1.1] tracking-tight sm:text-[40px] lg:text-[48px]",children:"Partnerships That Create Business Value"}),e.jsx("p",{className:"mt-5 max-w-[560px] text-[14px] leading-relaxed text-[#5b6b80] sm:text-[15px]",children:"At TechTorch Solutions, we recognise the role of strong partnerships in delivering effective technology solutions. We aim to build relationships with organisations whose expertise, capabilities, and business objectives complement our own."})]}),e.jsx("div",{className:"pe-hero-image-wrap relative min-w-0",children:e.jsx("img",{loading:"lazy",decoding:"async",src:p.handshake,alt:"Technology-enabled business handshake",className:"pe-hero-image aspect-[3/2] w-full max-w-full rounded-xl object-cover object-center shadow-xl"})})]})}),e.jsx("section",{className:`bg-white ${r} ${i}`,children:e.jsxs("div",{className:"grid min-w-0 grid-cols-1 items-center gap-8 md:grid-cols-2 md:gap-12",children:[e.jsxs("div",{children:[e.jsx(o,{children:"Our Partner Network"}),e.jsx("h2",{className:"text-[26px] font-extrabold leading-tight tracking-tight sm:text-[32px] lg:text-[38px]",children:"Collaboration Built Around Shared Objectives"}),e.jsx("p",{className:"mt-5 max-w-[560px] text-[14px] leading-relaxed text-[#5b6b80] sm:text-[15px]",children:"Our partner ecosystem is focused on bringing together complementary technology, services, and expertise. We believe effective collaboration starts with a clear understanding of customer requirements and a shared commitment to delivering relevant solutions."}),e.jsx("p",{className:"mt-4 max-w-[560px] text-[14px] leading-relaxed text-[#5b6b80] sm:text-[15px]",children:"We look for opportunities to work with organisations that value professional integrity, technical expertise, and long-term business relationships."})]}),e.jsx("img",{loading:"lazy",decoding:"async",src:p.network,alt:"Professionals collaborating around a glowing digital structure",className:"w-full max-w-[90%] aspect-[3/2] rounded-2xl object-cover object-center shadow-xl md:order-last"})]})}),e.jsxs("section",{className:`bg-[#faf9f4] ${r} ${i}`,children:[e.jsx(o,{children:"Partnership Opportunities"}),e.jsx("h2",{className:"text-[26px] font-extrabold leading-tight tracking-tight sm:text-[32px] lg:text-[38px]",children:"Areas of Collaboration"}),e.jsx("div",{className:"mt-8 grid grid-cols-1 gap-5 md:mt-12 md:grid-cols-3 md:gap-6",children:k.map(({icon:s,title:t,description:d})=>e.jsxs("article",{className:"rounded-xl border border-[#e6eaf0] bg-white p-6 lg:p-7",children:[e.jsx("span",{className:"mb-5 grid h-11 w-11 place-items-center rounded-[10px] bg-[#fdf0f6] text-[#b31962]",children:e.jsx(s,{size:22})}),e.jsx("h3",{className:"text-[17px] font-bold leading-snug",children:t}),e.jsx("p",{className:"mt-3 text-[14px] leading-relaxed text-[#5b6b80]",children:d})]},t))})]}),e.jsxs("section",{className:`bg-white ${r} ${i}`,children:[e.jsx(o,{children:"Why Partner With TechTorch?"}),e.jsx("h2",{className:"text-[26px] font-extrabold leading-tight tracking-tight sm:text-[32px] lg:text-[38px]",children:"Building Stronger Together"}),e.jsx("div",{className:"mt-8 grid grid-cols-1 gap-8 sm:grid-cols-2 md:mt-12 lg:grid-cols-4",children:T.map(({icon:s,title:t,description:d})=>e.jsxs("article",{children:[e.jsx(s,{size:26,className:"mb-4 text-[#b31962]"}),e.jsx("h3",{className:"text-[16px] font-bold leading-snug",children:t}),e.jsx("p",{className:"mt-2.5 text-[14px] leading-relaxed text-[#5b6b80]",children:d})]},t))})]}),e.jsx("section",{id:"partner-enquiry",className:`bg-gradient-to-br from-[#4b0021] to-[#730042] ${r} ${i}`,children:e.jsxs("div",{className:"grid min-w-0 grid-cols-1 items-center gap-10 lg:grid-cols-[1fr_1.2fr] lg:gap-14",children:[e.jsxs("div",{children:[e.jsx(o,{light:!0,children:"Start a Partnership Conversation"}),e.jsx("h2",{className:"text-[28px] font-extrabold leading-tight tracking-tight text-white sm:text-[34px] lg:text-[40px]",children:"Let's Explore Opportunities Together"}),e.jsx("p",{className:"mt-5 max-w-[560px] text-[14px] leading-relaxed text-[#e8becd] sm:text-[15px]",children:"Are you a technology provider, software company, or service organisation looking to explore potential collaboration?"}),e.jsx("p",{className:"mt-4 max-w-[560px] text-[14px] leading-relaxed text-[#e8becd] sm:text-[15px]",children:"Share your organisation's capabilities and partnership objectives with TechTorch Solutions. Our team can review your enquiry and discuss potential areas of alignment."}),e.jsxs("div",{className:"mt-7 flex flex-col gap-3 sm:flex-row",children:[e.jsxs("button",{type:"button",onClick:x,className:"inline-flex min-h-[46px] items-center justify-center gap-2.5 rounded-md border border-white bg-white px-5 text-[13px] font-bold text-[#730042] transition-colors hover:bg-[#f8eaf0]",children:["Submit a Partnership Enquiry ",e.jsx(N,{size:18})]}),e.jsx("button",{type:"button",onClick:x,className:"inline-flex min-h-[46px] items-center justify-center rounded-md border border-[#d49cb5] px-5 text-[13px] font-bold text-white transition-colors hover:bg-white/10",children:"Contact Us"})]})]}),e.jsxs("div",{ref:a,className:"grid grid-cols-1 overflow-hidden rounded-2xl bg-white shadow-2xl sm:grid-cols-[0.8fr_1fr]",children:[e.jsx("img",{loading:"lazy",decoding:"async",src:p.building,alt:"Modern illuminated corporate office building",className:"h-[180px] w-full max-w-full object-cover object-[58%_center] sm:h-full sm:min-h-[320px] lg:min-h-[420px]"}),e.jsxs("form",{onSubmit:g,className:"p-5 sm:p-6 lg:p-8",children:[e.jsxs("label",{htmlFor:"pe-name",className:`${l} !mt-0`,children:["Your Name ",e.jsx("b",{className:"text-[#b31962]",children:"*"})]}),e.jsx("input",{id:"pe-name",name:"name",type:"text",placeholder:"Enter your name",required:!0,className:n}),e.jsxs("label",{htmlFor:"pe-email",className:l,children:["Business Email ",e.jsx("b",{className:"text-[#b31962]",children:"*"})]}),e.jsx("input",{id:"pe-email",name:"email",type:"email",placeholder:"Enter your email",required:!0,className:n}),e.jsxs("label",{htmlFor:"pe-org",className:l,children:["Organisation Name ",e.jsx("b",{className:"text-[#b31962]",children:"*"})]}),e.jsx("input",{id:"pe-org",name:"organisation",type:"text",placeholder:"Enter your organisation",required:!0,className:n}),e.jsx("label",{htmlFor:"pe-message",className:l,children:"Message (Optional)"}),e.jsx("textarea",{id:"pe-message",name:"message",rows:4,placeholder:"Tell us about your partnership interest",className:`${n} resize-y`}),e.jsx("button",{type:"submit",className:"mt-6 min-h-[44px] w-full rounded bg-[#730042] text-[13px] font-bold text-white transition-colors hover:bg-[#59002d]",children:"Submit"}),c&&e.jsx("p",{role:"status",className:"mt-3 text-xs text-[#27633e]",children:"Thank you! Your enquiry has been received."})]})]})]})}),e.jsx("style",{children:`
        .partners-ecosystem-page,
        .partners-ecosystem-page * {
          box-sizing: border-box;
        }

        .partners-ecosystem-page img {
          display: block;
          max-width: 100%;
        }

        /* Hero image decoration to match the reference screenshot */
        .pe-hero-image-wrap { isolation: isolate; }
        .pe-hero-image-wrap::before {
          content: "";
          position: absolute;
          z-index: -1;
          width: 44%;
          height: 70%;
          right: -4%;
          bottom: -7%;
          border-radius: 18px;
          background: #f0dfe5;
          transform: rotate(-5deg);
        }
        .pe-hero-image-wrap::after {
          content: "";
          position: absolute;
          right: 0;
          bottom: 0;
          width: 24%;
          height: 28%;
          background: #730042;
          clip-path: polygon(20% 0, 100% 0, 100% 100%, 0 100%);
          border-bottom-right-radius: 12px;
          pointer-events: none;
        }
        .pe-hero-image { position: relative; z-index: 0; }

        /* Mobile phones */
        @media (max-width: 767px) {
          .partners-ecosystem-page > section > div {
            min-width: 0;
          }

          .partners-ecosystem-page > section:nth-of-type(1) .pe-hero-image,
          .partners-ecosystem-page > section:nth-of-type(2) img {
            width: 100%;
            height: auto;
            aspect-ratio: 3 / 2;
            object-fit: cover;
            object-position: center;
          }

          .partners-ecosystem-page > section:nth-of-type(5) > div > div:nth-child(2) > img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            object-position: center;
          }

          .partners-ecosystem-page input,
          .partners-ecosystem-page textarea,
          .partners-ecosystem-page button {
            max-width: 100%;
          }
        }

        /* Tablets and small laptops */
        @media (min-width: 768px) and (max-width: 1023px) {
          .partners-ecosystem-page > section:nth-of-type(1) .pe-hero-image,
          .partners-ecosystem-page > section:nth-of-type(2) img {
            width: 100%;
            height: auto;
            aspect-ratio: 3 / 2;
            object-fit: cover;
            object-position: center;
          }

          .partners-ecosystem-page > section:nth-of-type(5) > div > div:nth-child(2) > img {
            min-height: 320px;
            height: 100%;
            object-fit: cover;
            object-position: center;
          }
        }

        /* Desktop screens */
        @media (min-width: 1024px) {
          .partners-ecosystem-page > section:nth-of-type(1) .pe-hero-image,
          .partners-ecosystem-page > section:nth-of-type(2) img {
            width: 100%;
            height: auto;
            aspect-ratio: 3 / 2;
            object-fit: cover;
            object-position: center;
          }

          .partners-ecosystem-page > section:nth-of-type(5) > div > div:nth-child(2) > img {
            min-height: 420px;
            height: 100%;
            object-fit: cover;
            object-position: center;
          }
        }
      `})]})}export{B as default};
