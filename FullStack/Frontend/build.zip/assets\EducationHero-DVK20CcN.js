import{j as e}from"./vendor-query-PraSc8EQ.js";import{d as r,L as c}from"./vendor-router-L4ZCoGSs.js";import{A as p,a2 as x,G as l,b as u,D as g,s as h,I as m}from"./index-37hjU4u5.js";const t="#7A1F3D",f="#5C1730",i="#1B1B2A",b="/Educationhelp.webp",y="/Education2.webp";function o({children:n}){return e.jsxs("div",{className:"education-eyebrow",children:[e.jsx(m,{size:14,strokeWidth:3}),e.jsx("span",{children:n})]})}function d({src:n,alt:a}){return e.jsx("div",{className:"education-image-wrapper",children:e.jsx("img",{src:n,alt:a,className:"education-image"})})}const w=[{label:"Students",icon:l},{label:"Faculty",icon:u},{label:"Administration",icon:g},{label:"Parents",icon:h}];function z(){const n=r();return e.jsxs("section",{className:"education-section",style:{background:"#faf8f6",color:i},children:[e.jsx("style",{children:`

        /* =====================================================
           MAIN SECTION
        ===================================================== */

        .education-section {
          width: 100%;
          overflow: hidden;
          font-family: "Inter", sans-serif;
        }

        /* =====================================================
           CONTAINER

           Desktop  : 100px
           Tablet   : 40px
           Mobile   : 24px
           Small    : 16px
        ===================================================== */

        .education-container {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;
          padding: 80px 100px;
          box-sizing: border-box;
        }

        /* =====================================================
           GRID
        ===================================================== */

        .education-grid {
          display: grid;
          grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
          gap: 64px;
          align-items: center;
        }

        .education-grid + .education-grid {
          margin-top: 120px;
        }

        /* =====================================================
           EYEBROW
           INTER
        ===================================================== */

        .education-eyebrow {
          display: flex;
          align-items: center;
          gap: 4px;
          margin-bottom: 16px;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.4;
          font-weight: 700;
          letter-spacing: 0.06em;

          color: ${t};
        }

        /* =====================================================
           MAIN HEADING
           PLUS JAKARTA SANS
        ===================================================== */

        .education-main-heading {
          margin: 0 0 20px;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 44px;
          line-height: 1.1;
          font-weight: 700;
          letter-spacing: -0.8px;

          color: ${i};
        }

        /* =====================================================
           SECOND HEADING
           PLUS JAKARTA SANS
        ===================================================== */

        .education-secondary-heading {
          margin: 0 0 20px;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 38px;
          line-height: 1.15;
          font-weight: 700;
          letter-spacing: -0.7px;

          color: ${i};
        }

        /* =====================================================
           SUBHEADING
           PLUS JAKARTA SANS
        ===================================================== */

        .education-subheading {
          margin: 0 0 16px;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 17px;
          line-height: 1.55;
          font-weight: 600;

          color: ${t};
        }

        /* =====================================================
           BODY
           INTER
        ===================================================== */

        .education-body {
          margin: 0;

          font-family: "Inter", sans-serif;
          font-size: 15px;
          line-height: 1.75;
          font-weight: 400;

          color: #5b5a63;
        }

        .education-body + .education-body {
          margin-top: 20px;
        }

        /* =====================================================
           BUTTONS
           INTER
        ===================================================== */

        .education-buttons {
          display: flex;
          flex-wrap: wrap;
          align-items: center;
          gap: 12px;
          margin-top: 32px;
        }

        .education-primary-button,
        .education-secondary-button {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;

          min-height: 44px;
          padding: 12px 20px;

          border-radius: 6px;

          font-family: "Inter", sans-serif;
          font-size: 14px;
          line-height: 1.4;
          font-weight: 600;

          cursor: pointer;
          transition:
            background 0.25s ease,
            border-color 0.25s ease,
            transform 0.25s ease;
        }

        .education-primary-button {
          border: none;
          background: ${t};
          color: #ffffff;
        }

        .education-primary-button:hover {
          background: ${f};
          transform: translateY(-2px);
        }

        .education-secondary-button {
          border: 1px solid #d8d5d0;
          background: transparent;
          color: ${i};
        }

        .education-secondary-button:hover {
          border-color: ${t};
          background: #fffafb;
        }

        /* =====================================================
           IMAGE AREA
        ===================================================== */

        .education-image-area {
          position: relative;
          width: 100%;
          min-width: 0;
        }

        .education-image-wrapper {
          position: relative;
          width: 100%;
          height: 390px;

          overflow: hidden;
          border-radius: 24px;

          background: #e9e4e0;
        }

        .education-image {
          display: block;
          width: 100%;
          height: 100%;

          object-fit: cover;
          object-position: center;

          transition: transform 0.5s ease;
        }

        .education-image-wrapper:hover .education-image {
          transform: scale(1.025);
        }

        /* =====================================================
           FLOATING STAT CARD
        ===================================================== */

        .education-stat-card {
          position: absolute;
          right: 32px;
          bottom: -24px;

          display: flex;
          align-items: center;
          gap: 12px;

          width: 240px;
          max-width: calc(100% - 32px);

          padding: 14px 16px;
          box-sizing: border-box;

          background: #ffffff;
          border-radius: 12px;

          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
        }

        .education-stat-icon {
          flex-shrink: 0;
          color: ${t};
        }

        .education-stat-title {
          margin: 0 0 4px;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.35;
          font-weight: 700;

          color: ${i};
        }

        .education-stat-text {
          margin: 0;

          font-family: "Inter", sans-serif;
          font-size: 11px;
          line-height: 1.45;

          color: #8a8378;
        }

        .education-stat-text strong {
          color: ${i};
          font-weight: 700;
        }

        /* =====================================================
           ROLE CARD
        ===================================================== */

        .education-role-card {
          position: absolute;
          top: 24px;
          left: 24px;

          width: 176px;
          padding: 8px;
          box-sizing: border-box;

          background: #ffffff;
          border-radius: 12px;

          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
        }

        .education-role-item {
          display: flex;
          align-items: center;
          gap: 8px;

          padding: 8px;
          border-radius: 8px;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.4;
          font-weight: 500;

          color: ${i};
        }

        .education-role-icon {
          width: 24px;
          height: 24px;
          flex-shrink: 0;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 6px;

          background: #fbeef1;
          color: ${t};
        }

        /* =====================================================
           INFO BOX
        ===================================================== */

        .education-info-box {
          margin-top: 28px;
          padding: 16px 20px;

          border-left: 4px solid ${t};
          border-radius: 8px;

          background: #fdf1f3;
          color: ${i};

          font-family: "Inter", sans-serif;
          font-size: 14px;
          line-height: 1.7;
          font-weight: 400;
        }

        /* =====================================================
           LARGE DESKTOP
        ===================================================== */

        @media (min-width: 1440px) {
          .education-container {
            padding-left: 100px;
            padding-right: 100px;
          }

          .education-grid {
            gap: 72px;
          }

          .education-main-heading {
            font-size: 46px;
          }

          .education-secondary-heading {
            font-size: 40px;
          }
        }

        /* =====================================================
           DESKTOP / LAPTOP
        ===================================================== */

        @media (min-width: 1025px) and (max-width: 1439px) {
          .education-container {
            padding-left: 100px;
            padding-right: 100px;
          }

          .education-grid {
            gap: 56px;
          }

          .education-main-heading {
            font-size: 42px;
          }

          .education-secondary-heading {
            font-size: 36px;
          }

          .education-image-wrapper {
            height: 370px;
          }
        }

        /* =====================================================
           TABLET
        ===================================================== */

        @media (min-width: 768px) and (max-width: 1024px) {
          .education-container {
            padding: 64px 40px;
          }

          .education-grid {
            gap: 40px;
          }

          .education-grid + .education-grid {
            margin-top: 90px;
          }

          .education-main-heading {
            font-size: 36px;
            line-height: 1.15;
          }

          .education-secondary-heading {
            font-size: 31px;
          }

          .education-subheading {
            font-size: 16px;
          }

          .education-body {
            font-size: 14px;
            line-height: 1.7;
          }

          .education-image-wrapper {
            height: 330px;
            border-radius: 20px;
          }

          .education-stat-card {
            right: 20px;
            bottom: -20px;
          }

          .education-role-card {
            top: 18px;
            left: 18px;
          }
        }

        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 767px) {
          .education-container {
            padding: 56px 24px;
          }

          .education-grid {
            grid-template-columns: 1fr;
            gap: 44px;
          }

          .education-grid + .education-grid {
            margin-top: 82px;
          }

          .education-eyebrow {
            margin-bottom: 14px;
            font-size: 11px;
          }

          .education-main-heading {
            font-size: 32px;
            line-height: 1.15;
            letter-spacing: -0.5px;
            margin-bottom: 16px;
          }

          .education-secondary-heading {
            font-size: 29px;
            line-height: 1.2;
            letter-spacing: -0.5px;
            margin-bottom: 16px;
          }

          .education-subheading {
            font-size: 15px;
            line-height: 1.55;
            margin-bottom: 14px;
          }

          .education-body {
            font-size: 14px;
            line-height: 1.7;
          }

          .education-buttons {
            margin-top: 26px;
            gap: 10px;
          }

          .education-primary-button,
          .education-secondary-button {
            padding: 11px 16px;
            font-size: 13px;
          }

          .education-image-wrapper {
            height: 320px;
            border-radius: 20px;
          }

          .education-stat-card {
            right: 16px;
            bottom: -20px;

            width: 225px;
            padding: 12px 14px;
          }

          .education-role-card {
            top: 16px;
            left: 16px;
            width: 165px;
          }

          .education-role-item {
            padding: 7px;
            font-size: 11px;
          }

          .education-info-box {
            margin-top: 24px;
            padding: 14px 16px;
            font-size: 13px;
            line-height: 1.65;
          }
        }

        /* =====================================================
           SMALL MOBILE
        ===================================================== */

        @media (max-width: 480px) {
          .education-container {
            padding: 48px 16px;
          }

          .education-grid {
            gap: 36px;
          }

          .education-grid + .education-grid {
            margin-top: 70px;
          }

          .education-eyebrow {
            font-size: 10px;
            letter-spacing: 0.045em;
          }

          .education-main-heading {
            font-size: 28px;
            line-height: 1.17;
          }

          .education-secondary-heading {
            font-size: 26px;
            line-height: 1.2;
          }

          .education-subheading {
            font-size: 14px;
          }

          .education-body {
            font-size: 13.5px;
            line-height: 1.7;
          }

          .education-buttons {
            width: 100%;
            flex-direction: column;
            align-items: stretch;
          }

          .education-primary-button,
          .education-secondary-button {
            width: 100%;
          }

          .education-image-wrapper {
            height: 270px;
            border-radius: 18px;
          }

          .education-stat-card {
            right: 10px;
            bottom: -18px;

            width: 205px;
            max-width: calc(100% - 20px);

            padding: 10px 12px;
            gap: 9px;
          }

          .education-stat-icon {
            width: 18px;
            height: 18px;
          }

          .education-stat-title {
            font-size: 10.5px;
          }

          .education-stat-text {
            font-size: 9.5px;
          }

          .education-role-card {
            top: 12px;
            left: 12px;
            width: 150px;
            padding: 6px;
          }

          .education-role-item {
            gap: 7px;
            padding: 6px;
            font-size: 10.5px;
          }

          .education-role-icon {
            width: 22px;
            height: 22px;
          }

          .education-role-icon svg {
            width: 13px;
            height: 13px;
          }

          .education-info-box {
            padding: 13px 14px;
            font-size: 12.5px;
          }
        }

        /* =====================================================
           VERY SMALL MOBILE
        ===================================================== */

        @media (max-width: 360px) {
          .education-container {
            padding-left: 16px;
            padding-right: 16px;
          }

          .education-main-heading {
            font-size: 26px;
          }

          .education-secondary-heading {
            font-size: 24px;
          }

          .education-image-wrapper {
            height: 245px;
          }

          .education-role-card {
            transform: scale(0.92);
            transform-origin: top left;
          }

          .education-stat-card {
            transform: scale(0.92);
            transform-origin: bottom right;
          }
        }

        /* =====================================================
           REDUCED MOTION
        ===================================================== */

        @media (prefers-reduced-motion: reduce) {
          .education-image,
          .education-primary-button,
          .education-secondary-button {
            transition: none;
          }
        }
      `}),e.jsxs("div",{className:"education-container",children:[e.jsxs("div",{className:"education-grid",children:[e.jsxs("div",{className:"education-content",children:[e.jsx(o,{children:"EDUCATION"}),e.jsx("h1",{className:"education-main-heading",children:"Technology That Helps Education Move Forward"}),e.jsx("p",{className:"education-subheading",children:"Helping institutions create simpler, smarter and more connected ways of working."}),e.jsx("p",{className:"education-body",children:"Education is built around people — students, educators, administrators and families. The technology supporting them should make their everyday experience easier, not more complicated."}),e.jsxs("div",{className:"education-buttons",children:[e.jsxs("button",{type:"button",className:"education-primary-button",onClick:()=>n("/education-solutions"),children:["Explore Education Solutions",e.jsx(p,{size:16})]}),e.jsx(c,{to:"/talk-to-expert",className:"education-secondary-button",children:"Talk to Our Experts"})]})]}),e.jsxs("div",{className:"education-image-area",children:[e.jsx(d,{src:b,alt:"Education technology team reviewing dashboard"}),e.jsxs("div",{className:"education-stat-card",children:[e.jsx(x,{size:20,className:"education-stat-icon"}),e.jsxs("div",{children:[e.jsx("p",{className:"education-stat-title",children:"TechTorch Campus OS"}),e.jsxs("p",{className:"education-stat-text",children:[e.jsx("strong",{children:"99.4% User Adoption"}),e.jsx("br",{}),"Across 40+ Higher-Ed Campuses"]})]})]})]})]}),e.jsxs("div",{className:"education-grid education-grid-reverse",children:[e.jsxs("div",{className:"education-image-area",children:[e.jsx(d,{src:y,alt:"Students collaborating at a table"}),e.jsx("div",{className:"education-role-card",children:w.map(({label:a,icon:s})=>e.jsxs("div",{className:"education-role-item",children:[e.jsx("span",{className:"education-role-icon",children:e.jsx(s,{size:14})}),e.jsx("span",{children:a})]},a))})]}),e.jsxs("div",{className:"education-content",children:[e.jsx(o,{children:"BRINGING EVERY PART OF YOUR INSTITUTION CLOSER TOGETHER"}),e.jsx("h2",{className:"education-secondary-heading",children:"One institution. Many activities. One connected approach."}),e.jsx("p",{className:"education-body",children:"An educational institution has many moving parts. Students need access to information. Teachers manage academic responsibilities. Administrators handle records and processes. Management needs visibility. Parents want timely communication."}),e.jsx("p",{className:"education-body",children:"When these activities depend on disconnected systems, even simple tasks can become difficult to manage."}),e.jsx("div",{className:"education-info-box",children:"TechTorch brings a connected approach to education technology, helping institutions organize important processes and information within a more unified digital environment."})]})]})]})]})}export{z as default};
