import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as a}from"./vendor-router-L4ZCoGSs.js";import{F as w,s as S,a as C}from"./FormNotice-OE790tVc.js";import{S as m}from"./shield-DihDJwH1.js";import{N as x}from"./network-BTjPWaa_.js";import{B as h}from"./badge-check-CJFSwGzB.js";import{U as T}from"./user-BusR5MVP.js";import{t as k,v as E,a3 as r}from"./index-37hjU4u5.js";import{P as z}from"./phone-D3JbSBfc.js";import{S as I}from"./server-CVxnx5sL.js";import{M}from"./monitor-smartphone-ChH0sBNC.js";import{V as A}from"./video-Gc4NsB-v.js";import{L as P}from"./list-checks-BpQTkzZp.js";import{L}from"./lock-keyhole-iBzDZ1RM.js";import{C as D}from"./clock-3-BIKamG4f.js";const f={name:"at-sign",size:24,node:[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-4 8",key:"7n84p3"}]]};f.node;const R=k(f),Z=()=>{const[s,p]=a.useState({fullName:"",email:"",company:"",phone:"",serviceScope:"",supportTier:"",infrastructure:"",endpointScale:"",briefingMode:"30-Min Video Call",painPoints:"",nda:!1}),i=n=>{const{name:t,value:j,type:N,checked:v}=n.target;p(y=>({...y,[t]:N==="checkbox"?v:j}))},[o,l]=a.useState(!1),[u,c]=a.useState(""),[g,d]=a.useState(!1),b=async n=>{if(n.preventDefault(),!o){c(""),d(!1),l(!0);try{await S("inquiry",{formType:"msp-support",fullName:s.fullName.trim(),email:s.email.trim(),company:s.company.trim(),phone:s.phone.trim(),topic:s.serviceScope,message:s.painPoints.trim(),details:{supportTier:s.supportTier,infrastructure:s.infrastructure,endpointScale:s.endpointScale,briefingMode:s.briefingMode,mutualNdaRequested:!!s.nda}}),d(!0),p({fullName:"",email:"",company:"",phone:"",serviceScope:"",supportTier:"",infrastructure:"",endpointScale:"",briefingMode:"30-Min Video Call",painPoints:"",nda:!1})}catch(t){c(C(t))}finally{l(!1)}}};return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`
        /* =========================================================
           GLOBAL
        ========================================================= */

        * {
          box-sizing: border-box;
        }

        .msp-connect-page {
          width: 100%;
          min-height: 100vh;
          padding: 80px 100px 90px;
          background: #f6f8ff;
          color: #182238;
          font-family: "Inter", Arial, Helvetica, sans-serif;
          overflow: hidden;
        }

        .msp-connect-wrapper {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;
        }

        .msp-connect-page h1,
        .msp-connect-page h2,
        .msp-connect-page h3 {
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
        }

        /* =========================================================
           HEADER
        ========================================================= */

        .msp-connect-header {
          width: 100%;
          text-align: center;
          margin: 0 auto 42px;
        }

        .msp-connect-pill {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          max-width: 100%;
          padding: 8px 17px;
          border: 1px solid #d8aac5;
          border-radius: 999px;
          background: #f7eaf2;
          color: #65003c;
          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.7px;
          line-height: 1.4;
          text-transform: uppercase;
        }

        .msp-connect-pill::before {
          content: "";
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: #760044;
          flex-shrink: 0;
        }

        .msp-connect-header h1 {
          margin: 25px auto 14px;
          max-width: 900px;
          color: #172035;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 46px;
          font-weight: 700;
          line-height: 1.08;
          letter-spacing: -1.5px;
        }

        .msp-connect-header > p {
          width: 100%;
          max-width: 760px;
          margin: 0 auto;
          color: #50617d;
          font-family: "Inter", sans-serif;
          font-size: 16px;
          line-height: 1.65;
        }

        /* =========================================================
           HEADER BENEFITS
        ========================================================= */

        .msp-connect-benefits {
          display: flex;
          align-items: center;
          justify-content: center;
          flex-wrap: wrap;
          gap: 10px;
          margin-top: 24px;
        }

        .msp-benefit {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 7px;
          padding: 9px 14px;
          border: 1px solid #e0e5ef;
          border-radius: 999px;
          background: #ffffff;
          color: #4e5c73;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1;
          white-space: nowrap;
          box-shadow: 0 2px 7px rgba(20, 31, 55, 0.03);
        }

        .msp-benefit svg {
          width: 14px;
          height: 14px;
          color: #85004a;
          stroke-width: 2;
          flex-shrink: 0;
        }

        /* =========================================================
           FORM CARD
        ========================================================= */

        .msp-form-card {
          width: 100%;
          margin: 0 auto;
          padding: 48px 55px 52px;
          border: 1px solid #e0e5ee;
          border-radius: 18px;
          background: #ffffff;
          box-shadow:
            0 18px 40px rgba(34, 48, 76, 0.08),
            0 3px 8px rgba(34, 48, 76, 0.04);
        }

        .msp-form {
          width: 100%;
        }

        /* =========================================================
           FORM GRID
        ========================================================= */

        .msp-form-grid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          column-gap: 24px;
          row-gap: 25px;
        }

        .msp-field {
          width: 100%;
          min-width: 0;
        }

        .msp-field.full {
          grid-column: 1 / -1;
        }

        /* =========================================================
           LABEL
        ========================================================= */

        .msp-label {
          display: flex;
          align-items: center;
          gap: 7px;
          min-height: 20px;
          margin-bottom: 9px;
          color: #29354c;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 700;
          line-height: 1.35;
        }

        .msp-label svg {
          width: 16px;
          height: 16px;
          color: #810047;
          stroke-width: 2;
          flex-shrink: 0;
        }

        .msp-required {
          color: #810047;
          font-size: 15px;
          line-height: 1;
        }

        /* =========================================================
           INPUT / SELECT / TEXTAREA
        ========================================================= */

        .msp-input,
        .msp-select,
        .msp-textarea {
          width: 100%;
          border: 1px solid #dbe2ed;
          border-radius: 8px;
          background: #f8fafc;
          color: #1d293d;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          outline: none;
          transition:
            border-color 0.2s ease,
            box-shadow 0.2s ease,
            background 0.2s ease;
        }

        .msp-input {
          height: 51px;
          padding: 0 15px;
        }

        .msp-input::placeholder,
        .msp-textarea::placeholder {
          color: #9aabc4;
          opacity: 1;
        }

        .msp-input:focus,
        .msp-select:focus,
        .msp-textarea:focus {
          border-color: #9a175e;
          background: #ffffff;
          box-shadow: 0 0 0 3px rgba(128, 0, 72, 0.08);
        }

        /* =========================================================
           SELECT
        ========================================================= */

        .msp-select-wrapper {
          position: relative;
          width: 100%;
        }

        .msp-select {
          height: 51px;
          appearance: none;
          -webkit-appearance: none;
          padding: 0 42px 0 15px;
          cursor: pointer;
        }

        .msp-select-wrapper > svg {
          position: absolute;
          top: 50%;
          right: 14px;
          width: 16px;
          height: 16px;
          color: #8da0ba;
          pointer-events: none;
          transform: translateY(-50%);
        }

        /* =========================================================
           BRIEFING MODE
        ========================================================= */

        .msp-briefing {
          margin-top: 28px;
        }

        .msp-briefing-options {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 13px;
        }

        .msp-radio-card {
          position: relative;
          min-height: 66px;
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 11px 14px;
          border: 1px solid #dbe2ed;
          border-radius: 8px;
          background: #f8fafc;
          cursor: pointer;
          transition:
            border-color 0.2s ease,
            background 0.2s ease,
            transform 0.2s ease;
        }

        .msp-radio-card:hover {
          border-color: #c9a1b9;
          background: #fffafd;
          transform: translateY(-1px);
        }

        .msp-radio-card input {
          width: 16px;
          height: 16px;
          margin: 0;
          accent-color: #810047;
          flex-shrink: 0;
          cursor: pointer;
        }

        .msp-radio-content {
          display: flex;
          flex-direction: column;
          min-width: 0;
        }

        .msp-radio-title {
          color: #28354b;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 700;
          line-height: 1.3;
        }

        .msp-radio-subtitle {
          margin-top: 3px;
          color: #7d8da6;
          font-family: "Inter", sans-serif;
          font-size: 11px;
          line-height: 1.3;
        }

        /* =========================================================
           TEXTAREA
        ========================================================= */

        .msp-textarea-field {
          margin-top: 26px;
        }

        .msp-optional {
          margin-left: auto;
          color: #9aabc3;
          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 500;
        }

        .msp-textarea {
          min-height: 120px;
          padding: 14px 15px;
          resize: vertical;
          line-height: 1.55;
        }

        /* =========================================================
           NDA
        ========================================================= */

        .msp-nda {
          display: flex;
          align-items: flex-start;
          gap: 12px;
          margin-top: 28px;
          padding: 15px;
          border: 1px solid #dbe2ed;
          border-radius: 8px;
          background: #f8fafc;
        }

        .msp-nda input {
          width: 16px;
          height: 16px;
          margin: 1px 0 0;
          accent-color: #810047;
          flex-shrink: 0;
          cursor: pointer;
        }

        .msp-nda label {
          color: #4b5a72;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 600;
          line-height: 1.5;
          cursor: pointer;
        }

        /* =========================================================
           SECURITY STRIP
        ========================================================= */

        .msp-security-strip {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          align-items: center;
          width: 100%;
          min-height: 45px;
          margin-top: 18px;
          overflow: hidden;
          border: 1px solid #dbe2ed;
          border-radius: 8px;
          background: #f8fafc;
        }

        .msp-security-item {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 7px;
          min-width: 0;
          padding: 10px 12px;
          color: #56647a;
          font-family: "Inter", sans-serif;
          font-size: 11px;
          line-height: 1.3;
          text-align: center;
        }

        .msp-security-item:not(:last-child) {
          border-right: 1px solid #dbe2ed;
        }

        .msp-security-item svg {
          width: 14px;
          height: 14px;
          color: #810047;
          flex-shrink: 0;
        }

        /* =========================================================
           SUBMIT
        ========================================================= */

        .msp-submit {
          width: 100%;
          height: 52px;
          margin-top: 25px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 12px;
          border: none;
          border-radius: 8px;
          background: #85004a;
          color: #ffffff;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 700;
          letter-spacing: 0.5px;
          cursor: pointer;
          box-shadow: 0 5px 10px rgba(113, 0, 62, 0.14);
          transition:
            background 0.2s ease,
            transform 0.2s ease,
            box-shadow 0.2s ease;
        }

        .msp-submit:hover {
          background: #690039;
          transform: translateY(-1px);
          box-shadow: 0 8px 16px rgba(113, 0, 62, 0.18);
        }

        .msp-submit svg {
          width: 17px;
          height: 17px;
        }

        .msp-form-footer {
          margin-top: 21px;
          color: #60708a;
          font-family: "Inter", sans-serif;
          font-size: 11px;
          letter-spacing: 0.2px;
          line-height: 1.5;
          text-align: center;
        }

        /* =========================================================
           TABLET
           40px LEFT / RIGHT
        ========================================================= */

        @media (max-width: 1199px) {
          .msp-connect-page {
            padding: 70px 40px 80px;
          }

          .msp-connect-wrapper {
            max-width: 1400px;
          }

          .msp-connect-header h1 {
            font-size: 42px;
          }

          .msp-form-card {
            padding: 42px 42px 46px;
          }
        }

        /* =========================================================
           TABLET / SMALL LAPTOP
        ========================================================= */

        @media (max-width: 900px) {
          .msp-connect-page {
            padding-top: 60px;
            padding-bottom: 70px;
          }

          .msp-connect-header {
            margin-bottom: 34px;
          }

          .msp-connect-header h1 {
            font-size: 38px;
            letter-spacing: -1.1px;
          }

          .msp-connect-header > p {
            max-width: 700px;
            font-size: 15px;
          }

          .msp-form-card {
            padding: 36px 30px 40px;
          }

          .msp-form-grid {
            column-gap: 18px;
            row-gap: 22px;
          }

          .msp-briefing-options {
            grid-template-columns: 1fr;
          }

          .msp-radio-card {
            min-height: 60px;
          }
        }

        /* =========================================================
           MOBILE
           24px LEFT / RIGHT
        ========================================================= */

        @media (max-width: 700px) {
          .msp-connect-page {
            padding: 48px 24px 55px;
          }

          .msp-connect-header {
            margin-bottom: 28px;
          }

          .msp-connect-pill {
            padding: 7px 12px;
            font-size: 9px;
            letter-spacing: 0.45px;
            line-height: 1.4;
            white-space: normal;
            text-align: center;
          }

          .msp-connect-header h1 {
            margin-top: 19px;
            margin-bottom: 12px;
            font-size: 31px;
            line-height: 1.12;
            letter-spacing: -0.8px;
          }

          .msp-connect-header > p {
            font-size: 13px;
            line-height: 1.6;
          }

          .msp-connect-benefits {
            gap: 7px;
            margin-top: 18px;
          }

          .msp-benefit {
            padding: 7px 10px;
            font-size: 10px;
          }

          .msp-benefit svg {
            width: 12px;
            height: 12px;
          }

          .msp-form-card {
            padding: 28px 20px 31px;
            border-radius: 14px;
          }

          .msp-form-grid {
            grid-template-columns: 1fr;
            gap: 20px;
          }

          .msp-field.full {
            grid-column: auto;
          }

          .msp-label {
            font-size: 12px;
          }

          .msp-input,
          .msp-select {
            height: 48px;
            font-size: 12px;
          }

          .msp-briefing {
            margin-top: 22px;
          }

          .msp-briefing-options {
            grid-template-columns: 1fr;
            gap: 9px;
          }

          .msp-radio-card {
            min-height: 58px;
          }

          .msp-textarea-field {
            margin-top: 22px;
          }

          .msp-textarea {
            min-height: 125px;
            font-size: 12px;
          }

          .msp-nda {
            margin-top: 22px;
            padding: 13px;
          }

          .msp-nda label {
            font-size: 11px;
          }

          .msp-security-strip {
            grid-template-columns: 1fr;
          }

          .msp-security-item {
            justify-content: flex-start;
            padding: 10px 13px;
            text-align: left;
          }

          .msp-security-item:not(:last-child) {
            border-right: none;
            border-bottom: 1px solid #dbe2ed;
          }

          .msp-submit {
            height: 50px;
            font-size: 11px;
          }

          .msp-form-footer {
            font-size: 10px;
          }
        }

        /* =========================================================
           SMALL MOBILE
           16px LEFT / RIGHT
        ========================================================= */

        @media (max-width: 480px) {
          .msp-connect-page {
            padding: 40px 16px 48px;
          }

          .msp-connect-header h1 {
            font-size: 27px;
            letter-spacing: -0.65px;
          }

          .msp-connect-header > p {
            font-size: 12px;
          }

          .msp-connect-benefits {
            flex-direction: column;
            align-items: stretch;
          }

          .msp-benefit {
            justify-content: center;
            width: 100%;
            white-space: normal;
            text-align: center;
          }

          .msp-form-card {
            padding: 24px 15px 27px;
            border-radius: 12px;
          }

          .msp-label {
            font-size: 11px;
          }

          .msp-input,
          .msp-select {
            height: 47px;
            font-size: 11px;
          }

          .msp-radio-title {
            font-size: 11px;
          }

          .msp-radio-subtitle {
            font-size: 10px;
          }

          .msp-textarea {
            font-size: 11px;
          }

          .msp-nda label {
            font-size: 10.5px;
          }

          .msp-security-item {
            font-size: 10px;
          }

          .msp-submit {
            font-size: 10px;
            letter-spacing: 0.3px;
          }

          .msp-form-footer {
            font-size: 9.5px;
          }
        }
      `}),e.jsx("section",{className:"msp-connect-page",children:e.jsxs("div",{className:"msp-connect-wrapper",children:[e.jsxs("div",{className:"msp-connect-header",children:[e.jsx("span",{className:"msp-connect-pill",children:"TECHTORCH MSP SUPPORT • OPERATIONAL ONBOARDING"}),e.jsx("h1",{children:"Connect with TechTorch MSP"}),e.jsx("p",{children:"Share your infrastructure footprint and operational priorities to receive a tailored SLA framework and IT support architecture briefing within 1 business day."}),e.jsxs("div",{className:"msp-connect-benefits",children:[e.jsxs("span",{className:"msp-benefit",children:[e.jsx(m,{}),"Guaranteed SLA Alignment"]}),e.jsxs("span",{className:"msp-benefit",children:[e.jsx(x,{}),"24/7 Operations Command"]}),e.jsxs("span",{className:"msp-benefit",children:[e.jsx(h,{}),"Direct Systems Architect Review"]})]})]}),e.jsx("div",{className:"msp-form-card",children:e.jsxs("form",{className:"msp-form",onSubmit:b,children:[e.jsxs("div",{className:"msp-form-grid",children:[e.jsxs("div",{className:"msp-field",children:[e.jsxs("label",{className:"msp-label",children:[e.jsx(T,{}),"Full Name",e.jsx("span",{className:"msp-required",children:"*"})]}),e.jsx("input",{className:"msp-input",type:"text",name:"fullName",value:s.fullName,onChange:i,placeholder:"Alexander Wright",required:!0})]}),e.jsxs("div",{className:"msp-field",children:[e.jsxs("label",{className:"msp-label",children:[e.jsx(R,{}),"Business Email Address",e.jsx("span",{className:"msp-required",children:"*"})]}),e.jsx("input",{className:"msp-input",type:"email",name:"email",value:s.email,onChange:i,placeholder:"a.wright@enterprise.com",required:!0})]}),e.jsxs("div",{className:"msp-field",children:[e.jsxs("label",{className:"msp-label",children:[e.jsx(E,{}),"Organization / Company Name",e.jsx("span",{className:"msp-required",children:"*"})]}),e.jsx("input",{className:"msp-input",type:"text",name:"company",value:s.company,onChange:i,placeholder:"Vanguard Holdings LLC",required:!0})]}),e.jsxs("div",{className:"msp-field",children:[e.jsxs("label",{className:"msp-label",children:[e.jsx(z,{}),"Direct Phone / WhatsApp",e.jsx("span",{className:"msp-required",children:"*"})]}),e.jsx("input",{className:"msp-input",type:"tel",name:"phone",value:s.phone,onChange:i,placeholder:"+1 (555) 234-8900",required:!0})]}),e.jsxs("div",{className:"msp-field",children:[e.jsxs("label",{className:"msp-label",children:[e.jsx(x,{}),"Primary MSP Service Scope",e.jsx("span",{className:"msp-required",children:"*"})]}),e.jsxs("div",{className:"msp-select-wrapper",children:[e.jsxs("select",{className:"msp-select",name:"serviceScope",value:s.serviceScope,onChange:i,required:!0,children:[e.jsx("option",{value:"",disabled:!0,children:"Select Primary Focus Area"}),e.jsx("option",{value:"Infrastructure Support",children:"Infrastructure Support"}),e.jsx("option",{value:"Software Support",children:"Software Support"}),e.jsx("option",{value:"Cloud Support",children:"Cloud Support"}),e.jsx("option",{value:"Security Support",children:"Security Support"})]}),e.jsx(r,{})]})]}),e.jsxs("div",{className:"msp-field",children:[e.jsxs("label",{className:"msp-label",children:[e.jsx(m,{}),"Support Tier & Coverage Model",e.jsx("span",{className:"msp-required",children:"*"})]}),e.jsxs("div",{className:"msp-select-wrapper",children:[e.jsxs("select",{className:"msp-select",name:"supportTier",value:s.supportTier,onChange:i,required:!0,children:[e.jsx("option",{value:"",disabled:!0,children:"Select Support Model"}),e.jsx("option",{value:"Business Hours",children:"Business Hours"}),e.jsx("option",{value:"Extended Coverage",children:"Extended Coverage"}),e.jsx("option",{value:"24/7 Coverage",children:"24/7 Coverage"})]}),e.jsx(r,{})]})]}),e.jsxs("div",{className:"msp-field",children:[e.jsxs("label",{className:"msp-label",children:[e.jsx(I,{}),"IT Infrastructure / Environment Model",e.jsx("span",{className:"msp-required",children:"*"})]}),e.jsxs("div",{className:"msp-select-wrapper",children:[e.jsxs("select",{className:"msp-select",name:"infrastructure",value:s.infrastructure,onChange:i,required:!0,children:[e.jsx("option",{value:"",disabled:!0,children:"Select Infrastructure Model"}),e.jsx("option",{value:"On-Premises",children:"On-Premises"}),e.jsx("option",{value:"Cloud",children:"Cloud"}),e.jsx("option",{value:"Hybrid",children:"Hybrid"})]}),e.jsx(r,{})]})]}),e.jsxs("div",{className:"msp-field",children:[e.jsxs("label",{className:"msp-label",children:[e.jsx(M,{}),"User & Managed Endpoint Scale",e.jsx("span",{className:"msp-required",children:"*"})]}),e.jsxs("div",{className:"msp-select-wrapper",children:[e.jsxs("select",{className:"msp-select",name:"endpointScale",value:s.endpointScale,onChange:i,required:!0,children:[e.jsx("option",{value:"",disabled:!0,children:"Select Endpoint Volume"}),e.jsx("option",{value:"1 - 50 Users",children:"1 - 50 Users"}),e.jsx("option",{value:"51 - 200 Users",children:"51 - 200 Users"}),e.jsx("option",{value:"201 - 500 Users",children:"201 - 500 Users"}),e.jsx("option",{value:"500+ Users",children:"500+ Users"})]}),e.jsx(r,{})]})]})]}),e.jsxs("div",{className:"msp-field full msp-briefing",children:[e.jsxs("label",{className:"msp-label",children:[e.jsx(A,{}),"Preferred Mode of Initial Briefing"]}),e.jsxs("div",{className:"msp-briefing-options",children:[e.jsxs("label",{className:"msp-radio-card",children:[e.jsx("input",{type:"radio",name:"briefingMode",value:"30-Min Video Call",checked:s.briefingMode==="30-Min Video Call",onChange:i}),e.jsxs("span",{className:"msp-radio-content",children:[e.jsx("span",{className:"msp-radio-title",children:"30-Min Video Call"}),e.jsx("span",{className:"msp-radio-subtitle",children:"Screen share & Q&A"})]})]}),e.jsxs("label",{className:"msp-radio-card",children:[e.jsx("input",{type:"radio",name:"briefingMode",value:"Direct Phone Consultation",checked:s.briefingMode==="Direct Phone Consultation",onChange:i}),e.jsxs("span",{className:"msp-radio-content",children:[e.jsx("span",{className:"msp-radio-title",children:"Direct Phone Consultation"}),e.jsx("span",{className:"msp-radio-subtitle",children:"Immediate discussion"})]})]}),e.jsxs("label",{className:"msp-radio-card",children:[e.jsx("input",{type:"radio",name:"briefingMode",value:"Detailed SLA Proposal",checked:s.briefingMode==="Detailed SLA Proposal",onChange:i}),e.jsxs("span",{className:"msp-radio-content",children:[e.jsx("span",{className:"msp-radio-title",children:"Detailed SLA Proposal"}),e.jsx("span",{className:"msp-radio-subtitle",children:"Written assessment"})]})]})]})]}),e.jsxs("div",{className:"msp-field full msp-textarea-field",children:[e.jsxs("label",{className:"msp-label",children:[e.jsx(P,{}),"Current IT Support Pain Points & Primary Objectives",e.jsx("span",{className:"msp-optional",children:"Optional"})]}),e.jsx("textarea",{className:"msp-textarea",name:"painPoints",value:s.painPoints,onChange:i,placeholder:"Outline your immediate IT challenges (e.g. ticket backlogs, monitoring gaps, cloud maintenance, patching compliance, after-hours coverage, target onboarding timeline)..."})]}),e.jsxs("div",{className:"msp-nda",children:[e.jsx("input",{id:"msp-nda",type:"checkbox",name:"nda",checked:s.nda,onChange:i}),e.jsx("label",{htmlFor:"msp-nda",children:"I require a mutual Non-Disclosure Agreement (NDA) executed prior to sharing topology or architecture logs."})]}),e.jsxs("div",{className:"msp-security-strip",children:[e.jsxs("div",{className:"msp-security-item",children:[e.jsx(L,{}),"Confidential MSP Assessment"]}),e.jsxs("div",{className:"msp-security-item",children:[e.jsx(D,{}),"1 Business Day Response"]}),e.jsxs("div",{className:"msp-security-item",children:[e.jsx(h,{}),"ISO 27001 & SOC 2 Aligned"]})]}),e.jsx(w,{error:u,success:g}),e.jsxs("button",{type:"submit",disabled:o,className:"msp-submit",children:["SUBMIT MSP ENGAGEMENT REQUEST",e.jsx("span",{children:"→"})]}),e.jsx("div",{className:"msp-form-footer",children:"Professional Consultation · Direct Business-Focused Technology Discussion"})]})})]})})]})};export{Z as default};
