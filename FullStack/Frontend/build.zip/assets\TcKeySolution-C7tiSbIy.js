import{j as i}from"./vendor-query-PraSc8EQ.js";import{r as a}from"./vendor-router-L4ZCoGSs.js";import{B as u}from"./boxes-CTeM5RWv.js";import{t as f,z as g,w as h}from"./index-37hjU4u5.js";import{S as y}from"./sliders-horizontal-CjRtpOeo.js";import{C as b}from"./chart-line-DHh4JT0M.js";const x={name:"heart-handshake",size:24,node:[["path",{d:"M19.414 14.414C21 12.828 22 11.5 22 9.5a5.5 5.5 0 0 0-9.591-3.676.6.6 0 0 1-.818.001A5.5 5.5 0 0 0 2 9.5c0 2.3 1.5 4 3 5.5l5.535 5.362a2 2 0 0 0 2.879.052 2.12 2.12 0 0 0-.004-3 2.124 2.124 0 1 0 3-3 2.124 2.124 0 0 0 3.004 0 2 2 0 0 0 0-2.828l-1.881-1.882a2.41 2.41 0 0 0-3.409 0l-1.71 1.71a2 2 0 0 1-2.828 0 2 2 0 0 1 0-2.828l2.823-2.762",key:"17lmqv"}]]};x.node;const k=f(x),w="#7A1F3D",v="#1B1B2A",E="#5b5a63",c=[{icon:u,sys:"SYSTEM 01",title:"ERP"},{icon:k,sys:"SYSTEM 02",title:"CRM"},{icon:y,sys:"SYSTEM 03",title:"Operations Management"},{icon:b,sys:"SYSTEM 04",title:"Financial Management"},{icon:g,sys:"SYSTEM 05",title:"Payment Management"},{icon:h,sys:"SYSTEM 06",title:"Web Portals"}],p="Technology solutions designed around telecommunications business requirements.";function I(){const r=a.useRef(null),[m,l]=a.useState([]);return a.useEffect(()=>{const e=r.current;if(!e)return;const o=new IntersectionObserver(([s])=>{s.isIntersecting?c.forEach((d,t)=>{setTimeout(()=>{l(n=>n.includes(t)?n:[...n,t])},t*140)}):l([])},{threshold:.15});return o.observe(e),()=>o.disconnect()},[]),i.jsxs("section",{ref:r,className:"key-solutions-section",style:{"--wine":w,"--ink":v,"--muted":E},children:[i.jsx("style",{children:`
        /* =========================================
           FONTS
        ========================================= */


        /* =========================================
           SECTION
        ========================================= */

        .key-solutions-section {
          width: 100%;
          background: #ffffff;
          color: var(--ink);
          font-family: "Inter", sans-serif;
          overflow: hidden;
        }

        .key-solutions-section *,
        .key-solutions-section *::before,
        .key-solutions-section *::after {
          box-sizing: border-box;
        }

        /* =========================================
           CONTAINER
           Desktop: 100px
           Tablet: 40px
           Mobile: 24px
           Small Mobile: 16px
        ========================================= */

        .key-solutions-container {
          width: 100%;
          max-width: 1440px;
          margin: 0 auto;
          padding: 90px 100px;
        }

        /* =========================================
           HEADER
        ========================================= */

        .key-solutions-header {
          width: 100%;
          max-width: 720px;
          margin: 0 auto 56px;
          text-align: center;
        }

        .key-solutions-label {
          margin: 0 0 14px;
          color: var(--wine);

          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 700;
          letter-spacing: 0.14em;
          text-transform: uppercase;
        }

        .key-solutions-heading {
          margin: 0 0 16px;
          color: var(--ink);

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: clamp(28px, 3vw, 40px);
          line-height: 1.22;
          font-weight: 700;
          letter-spacing: -0.035em;
        }

        .key-solutions-description {
          max-width: 620px;
          margin: 0 auto;
          color: var(--muted);

          font-family: "Inter", sans-serif;
          font-size: 15px;
          line-height: 1.75;
          font-weight: 400;
        }

        /* =========================================
           GRID
        ========================================= */

        .key-solutions-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 22px;
        }

        /* =========================================
           CARD
        ========================================= */

        .solution-card {
          position: relative;
          min-height: 225px;
          padding: 26px;

          background: #ffffff;
          border: 1px solid #ece9e4;
          border-radius: 18px;

          opacity: 0;
          transform: translateY(35px) scale(0.97);

          transition:
            opacity 0.7s cubic-bezier(0.22, 1, 0.36, 1),
            transform 0.7s cubic-bezier(0.22, 1, 0.36, 1),
            border-color 0.3s ease,
            box-shadow 0.3s ease;
        }

        .solution-card.visible {
          opacity: 1;
          transform: translateY(0) scale(1);
        }

        .solution-card:hover {
          border-color: #dfd4d8;
          transform: translateY(-6px) scale(1.01);
          box-shadow: 0 16px 38px rgba(40, 20, 30, 0.08);
        }

        /* =========================================
           TOP ROW
        ========================================= */

        .solution-card-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 15px;
          margin-bottom: 30px;
        }

        /* =========================================
           ICON
        ========================================= */

        .solution-icon {
          width: 46px;
          height: 46px;
          flex-shrink: 0;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 12px;
          background: #fbeef1;
          color: var(--wine);

          transition:
            transform 0.45s cubic-bezier(0.22, 1, 0.36, 1),
            background-color 0.3s ease,
            box-shadow 0.3s ease;
        }

        .solution-card:hover .solution-icon {
          transform: scale(1.18);
          background: #f8e4e9;
          box-shadow: 0 8px 18px rgba(122, 31, 61, 0.12);
        }

        .solution-icon svg {
          transition: transform 0.45s cubic-bezier(0.22, 1, 0.36, 1);
        }

        .solution-card:hover .solution-icon svg {
          transform: scale(1.08);
        }

        /* =========================================
           SYSTEM BADGE
        ========================================= */

        .solution-system {
          display: inline-flex;
          align-items: center;
          justify-content: center;

          padding: 6px 10px;
          border-radius: 999px;

          background: #f2f1f5;
          color: var(--muted);

          font-family: "Inter", sans-serif;
          font-size: 9px;
          font-weight: 700;
          letter-spacing: 0.08em;
          white-space: nowrap;
        }

        /* =========================================
           CARD CONTENT
        ========================================= */

        .solution-title {
          margin: 0 0 9px;
          color: var(--ink);

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 16px;
          line-height: 1.4;
          font-weight: 700;
          letter-spacing: -0.015em;
        }

        .solution-description {
          margin: 0;
          color: var(--muted);

          font-family: "Inter", sans-serif;
          font-size: 12.5px;
          line-height: 1.7;
          font-weight: 400;
        }

        /* =========================================
           LARGE TABLET
           100px → 40px
        ========================================= */

        @media (max-width: 1200px) {
          .key-solutions-container {
            padding-left: 40px;
            padding-right: 40px;
            padding-top: 75px;
            padding-bottom: 75px;
          }

          .key-solutions-grid {
            gap: 18px;
          }
        }

        /* =========================================
           TABLET
        ========================================= */

        @media (max-width: 1000px) {
          .key-solutions-container {
            padding-left: 40px;
            padding-right: 40px;
            padding-top: 70px;
            padding-bottom: 70px;
          }

          .key-solutions-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
          }

          .solution-card {
            min-height: 215px;
          }
        }

        /* =========================================
           MOBILE
           40px → 24px
        ========================================= */

        @media (max-width: 650px) {
          .key-solutions-container {
            padding-left: 24px;
            padding-right: 24px;
            padding-top: 65px;
            padding-bottom: 65px;
          }

          .key-solutions-header {
            margin-bottom: 40px;
          }

          .key-solutions-label {
            font-size: 10px;
            margin-bottom: 11px;
          }

          .key-solutions-heading {
            font-size: 27px;
            line-height: 1.28;
          }

          .key-solutions-description {
            font-size: 13.5px;
            line-height: 1.7;
          }

          .key-solutions-grid {
            grid-template-columns: 1fr;
            gap: 15px;
          }

          .solution-card {
            min-height: auto;
            padding: 22px;
            border-radius: 16px;
          }

          .solution-card-top {
            margin-bottom: 24px;
          }

          .solution-icon {
            width: 44px;
            height: 44px;
          }

          .solution-title {
            font-size: 15px;
          }

          .solution-description {
            font-size: 12px;
          }
        }

        /* =========================================
           SMALL MOBILE
           24px → 16px
        ========================================= */

        @media (max-width: 400px) {
          .key-solutions-container {
            padding-left: 16px;
            padding-right: 16px;
            padding-top: 55px;
            padding-bottom: 55px;
          }

          .key-solutions-heading {
            font-size: 24px;
          }

          .key-solutions-description {
            font-size: 13px;
          }

          .solution-card {
            padding: 20px;
          }
        }

        /* =========================================
           REDUCED MOTION
        ========================================= */

        @media (prefers-reduced-motion: reduce) {
          .solution-card,
          .solution-icon,
          .solution-icon svg {
            transition: none !important;
          }

          .solution-card {
            opacity: 1;
            transform: none;
          }
        }
      `}),i.jsxs("div",{className:"key-solutions-container",children:[i.jsxs("div",{className:"key-solutions-header",children:[i.jsx("p",{className:"key-solutions-label",children:"Key Solutions"}),i.jsx("h2",{className:"key-solutions-heading",children:"Technology Solutions for Telecommunications"}),i.jsx("p",{className:"key-solutions-description",children:p})]}),i.jsx("div",{className:"key-solutions-grid",children:c.map(({icon:e,sys:o,title:s},d)=>i.jsxs("div",{className:`solution-card ${m.includes(d)?"visible":""}`,children:[i.jsxs("div",{className:"solution-card-top",children:[i.jsx("span",{className:"solution-icon",children:i.jsx(e,{size:20,strokeWidth:1.8})}),i.jsx("span",{className:"solution-system",children:o})]}),i.jsx("h3",{className:"solution-title",children:s}),i.jsx("p",{className:"solution-description",children:p})]},s))})]})]})}export{I as default};
