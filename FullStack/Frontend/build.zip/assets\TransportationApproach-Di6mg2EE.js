import{j as a}from"./vendor-query-PraSc8EQ.js";import{r as d}from"./vendor-router-L4ZCoGSs.js";import{t as l,r as f}from"./index-37hjU4u5.js";import{H as b}from"./headphones-B1SP7cCe.js";const x={name:"file-search",size:24,node:[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["circle",{cx:"11.5",cy:"14.5",r:"2.5",key:"1bq0ko"}],["path",{d:"M13.3 16.3 15 18",key:"2quom7"}]]};x.node;const u=l(x);const m={name:"wand-sparkles",size:24,node:[["path",{d:"m21.64 3.64-1.28-1.28a1.21 1.21 0 0 0-1.72 0L2.36 18.64a1.21 1.21 0 0 0 0 1.72l1.28 1.28a1.2 1.2 0 0 0 1.72 0L21.64 5.36a1.2 1.2 0 0 0 0-1.72",key:"ul74o6"}],["path",{d:"m14 7 3 3",key:"1r5n42"}],["path",{d:"M5 6v4",key:"ilb8ba"}],["path",{d:"M19 14v4",key:"blhpug"}],["path",{d:"M10 2v2",key:"7u0qdc"}],["path",{d:"M7 8H3",key:"zfb6yr"}],["path",{d:"M21 16h-4",key:"1cnmox"}],["path",{d:"M11 3H9",key:"1obp7u"}]],aliases:["wand-2"]};m.node;const y=l(m),i="#7A1F3D",c="#1B1B2A",h="#5b5a63",N=[{num:"01",icon:u,label:"REQUIREMENT ANALYSIS",title:"UNDERSTAND",body:"Understand your business objectives and technology requirements."},{num:"02",icon:y,label:"SOLUTION ARCHITECTURE",title:"DESIGN & DEVELOP",body:"Plan and develop the solution around your requirements."},{num:"03",icon:f,label:"QUALITY VERIFICATION",title:"TEST & DEPLOY",body:"Test the solution and prepare it for implementation."},{num:"04",icon:b,label:"CONTINUOUS EVOLUTION",title:"SUPPORT & MAINTAIN",body:"Provide ongoing support and maintenance as requirements evolve."}];function I(){const s=d.useRef([]);return d.useEffect(()=>{const p=s.current.filter(Boolean);if(!p.length)return;const r=new IntersectionObserver(e=>{e.forEach(o=>{const n=o.target;if(o.isIntersecting){const t=Number(n.dataset.index);setTimeout(()=>{n.classList.add("approach-card-visible")},t*180)}else n.classList.remove("approach-card-visible")})},{threshold:.18,rootMargin:"0px 0px -50px 0px"});return p.forEach(e=>r.observe(e)),()=>{p.forEach(e=>r.unobserve(e)),r.disconnect()}},[]),a.jsxs("section",{className:"connected-approach-section",children:[a.jsx("style",{children:`

        /* =========================================
           MAIN SECTION
        ========================================= */

        .connected-approach-section {
          width: 100%;
          overflow: hidden;

          background: #f5f6f8;
          color: ${c};

          font-family: "Inter", sans-serif;
        }

        .connected-approach-section *,
        .connected-approach-section *::before,
        .connected-approach-section *::after {
          box-sizing: border-box;
        }

        /* =========================================
           MAIN CONTAINER
           Desktop: 100px
           Tablet: 40px
           Mobile: 24px
           Small Mobile: 16px
        ========================================= */

        .connected-approach-container {
          width: 100%;
          max-width: 1440px;
          margin: 0 auto;

          padding: 85px 100px;
        }

        /* =========================================
           SECTION BADGE
        ========================================= */

        .approach-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;

          margin: 0 0 18px;
          padding: 6px 11px;

          border-radius: 999px;

          background: #fbeef1;
          color: ${i};

          font-family: "Inter", sans-serif;
          font-size: 10px;
          font-weight: 700;
          line-height: 1.3;
          letter-spacing: 0.08em;
        }

        .approach-badge-dot {
          width: 6px;
          height: 6px;
          flex-shrink: 0;

          border-radius: 50%;
          background: ${i};
        }

        /* =========================================
           HEADING
        ========================================= */

        .approach-heading {
          margin: 0 0 14px;

          color: ${c};

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: clamp(30px, 3.4vw, 42px);
          font-weight: 700;
          line-height: 1.2;
          letter-spacing: -0.04em;
        }

        /* =========================================
           SUBHEADING
        ========================================= */

        .approach-subheading {
          max-width: 720px;

          margin: 0 0 48px;

          color: ${h};

          font-family: "Inter", sans-serif;
          font-size: 13.5px;
          font-weight: 400;
          line-height: 1.8;
        }

        /* =========================================
           CARDS AREA
        ========================================= */

        .approach-cards-wrapper {
          position: relative;

          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));

          gap: 0;
        }

        /* =========================================
           CONNECTING LINE
        ========================================= */

        .approach-connecting-line {
          position: absolute;

          top: 51px;
          left: 7%;
          right: 7%;

          height: 1px;

          background: #ddd9d3;

          z-index: 0;
        }

        /* =========================================
           CARD WRAPPER
        ========================================= */

        .approach-card-wrapper {
          position: relative;

          min-width: 0;

          padding: 0 8px;

          z-index: 1;
        }

        /* =========================================
           CARD
        ========================================= */

        .approach-card {
          position: relative;

          width: 100%;
          height: 100%;
          min-height: 220px;

          display: flex;
          flex-direction: column;

          padding: 21px;

          border-radius: 16px;

          background: #ffffff;

          box-shadow:
            0 1px 3px rgba(0, 0, 0, 0.05);

          opacity: 0;
          transform: translateY(35px) scale(0.97);

          transition:
            opacity 0.65s ease,
            transform 0.65s cubic-bezier(0.22, 1, 0.36, 1),
            box-shadow 0.3s ease;
        }

        .approach-card-visible {
          opacity: 1;
          transform: translateY(0) scale(1);
        }

        .approach-card:hover {
          transform: translateY(-6px) scale(1);

          box-shadow:
            0 14px 32px rgba(30, 20, 25, 0.09);
        }

        /* =========================================
           CARD TOP
        ========================================= */

        .approach-card-top {
          display: flex;
          align-items: center;
          justify-content: space-between;

          margin-bottom: 18px;
        }

        .approach-number,
        .approach-icon {
          width: 38px;
          height: 38px;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 9px;

          background: #fbeef1;
          color: ${i};
        }

        .approach-number {
          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 700;
        }

        .approach-icon {
          transition:
            transform 0.35s ease,
            background 0.35s ease;
        }

        .approach-card:hover .approach-icon {
          transform: scale(1.14) rotate(-3deg);
          background: #f8e4e9;
        }

        /* =========================================
           CARD LABEL
        ========================================= */

        .approach-card-label {
          margin: 0 0 7px;

          color: ${i};

          font-family: "Inter", sans-serif;
          font-size: 9px;
          font-weight: 700;
          line-height: 1.4;
          letter-spacing: 0.09em;
        }

        /* =========================================
           CARD TITLE
        ========================================= */

        .approach-card-title {
          margin: 0 0 9px;

          color: ${c};

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 15px;
          font-weight: 700;
          line-height: 1.4;
          letter-spacing: -0.02em;
        }

        /* =========================================
           CARD BODY
        ========================================= */

        .approach-card-body {
          margin: 0;

          color: ${h};

          font-family: "Inter", sans-serif;
          font-size: 11.5px;
          font-weight: 400;
          line-height: 1.7;
        }

        /* =========================================
           LARGE TABLET
           Desktop 100px → Tablet 40px
        ========================================= */

        @media (max-width: 1200px) {
          .connected-approach-container {
            padding-left: 40px;
            padding-right: 40px;

            padding-top: 80px;
            padding-bottom: 80px;
          }
        }

        /* =========================================
           TABLET
        ========================================= */

        @media (max-width: 1050px) {
          .connected-approach-container {
            padding-left: 40px;
            padding-right: 40px;

            padding-top: 75px;
            padding-bottom: 75px;
          }

          .approach-cards-wrapper {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
          }

          .approach-connecting-line {
            display: none;
          }

          .approach-card-wrapper {
            padding: 0;
          }

          .approach-card {
            min-height: 220px;
          }
        }

        /* =========================================
           TABLET
        ========================================= */

        @media (max-width: 768px) {
          .connected-approach-container {
            padding-left: 40px;
            padding-right: 40px;

            padding-top: 65px;
            padding-bottom: 65px;
          }

          .approach-heading {
            font-size: 32px;
          }

          .approach-subheading {
            margin-bottom: 38px;
            font-size: 13px;
          }

          .approach-cards-wrapper {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 16px;
          }

          .approach-card {
            min-height: 220px;
            padding: 19px;
          }
        }

        /* =========================================
           MOBILE
           40px → 24px
        ========================================= */

        @media (max-width: 600px) {
          .connected-approach-container {
            padding-left: 24px;
            padding-right: 24px;

            padding-top: 55px;
            padding-bottom: 55px;
          }

          .approach-badge {
            margin-bottom: 15px;
            font-size: 9px;
          }

          .approach-heading {
            margin-bottom: 13px;

            font-size: 28px;
            line-height: 1.25;
            letter-spacing: -0.03em;
          }

          .approach-subheading {
            margin-bottom: 32px;

            font-size: 12px;
            line-height: 1.75;
          }

          .approach-cards-wrapper {
            grid-template-columns: 1fr;
            gap: 15px;
          }

          .approach-card-wrapper {
            width: 100%;
          }

          .approach-card {
            min-height: 0;
            padding: 19px;

            transform: translateY(30px) scale(0.98);
          }

          .approach-card-visible {
            transform: translateY(0) scale(1);
          }

          .approach-card:hover {
            transform: translateY(-4px) scale(1);
          }

          .approach-card-top {
            margin-bottom: 16px;
          }

          .approach-number,
          .approach-icon {
            width: 36px;
            height: 36px;
          }

          .approach-card-label {
            font-size: 8.5px;
          }

          .approach-card-title {
            font-size: 14px;
          }

          .approach-card-body {
            font-size: 11px;
            line-height: 1.7;
          }
        }

        /* =========================================
           SMALL MOBILE
           24px → 16px
        ========================================= */

        @media (max-width: 400px) {
          .connected-approach-container {
            padding-left: 16px;
            padding-right: 16px;

            padding-top: 48px;
            padding-bottom: 48px;
          }

          .approach-heading {
            font-size: 25px;
          }

          .approach-subheading {
            font-size: 11.5px;
          }

          .approach-card {
            padding: 17px;
          }

          .approach-card-title {
            font-size: 13.5px;
          }

          .approach-card-body {
            font-size: 10.5px;
          }
        }

        /* =========================================
           REDUCED MOTION
        ========================================= */

        @media (prefers-reduced-motion: reduce) {
          .approach-card {
            opacity: 1;
            transform: none;
            transition: none;
          }

          .approach-card:hover {
            transform: none;
          }

          .approach-icon {
            transition: none;
          }
        }
      `}),a.jsxs("div",{className:"connected-approach-container",children:[a.jsxs("span",{className:"approach-badge",children:[a.jsx("span",{className:"approach-badge-dot"}),"OUR APPROACH"]}),a.jsx("h2",{className:"approach-heading",children:"From Requirement to Support"}),a.jsx("p",{className:"approach-subheading",children:"A disciplined engineering workflow structured to deliver transparent governance, end-to-end integration, and continuous platform evolution."}),a.jsxs("div",{className:"approach-cards-wrapper",children:[a.jsx("div",{className:"approach-connecting-line"}),N.map(({num:p,icon:r,label:e,title:o,body:n},t)=>a.jsx("div",{className:"approach-card-wrapper",children:a.jsxs("div",{ref:g=>{s.current[t]=g},"data-index":t,className:"approach-card",children:[a.jsxs("div",{className:"approach-card-top",children:[a.jsx("span",{className:"approach-number",children:p}),a.jsx("span",{className:"approach-icon",children:a.jsx(r,{size:16,strokeWidth:1.8})})]}),a.jsx("p",{className:"approach-card-label",children:e}),a.jsx("h3",{className:"approach-card-title",children:o}),a.jsx("p",{className:"approach-card-body",children:n})]})},p))]})]})]})}export{I as default};
