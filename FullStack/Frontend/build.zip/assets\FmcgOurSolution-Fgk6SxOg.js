import{j as i}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";import{y as r,D as l,a5 as p,z as d,w as c}from"./index-37hjU4u5.js";import{S as u}from"./share-2-C38FnL_n.js";import{L as x}from"./layers-GER1Kp3Z.js";import{S as m}from"./square-check-big-DNkU2L-S.js";const o="#7A1F3D",n="#1B1B2A",g="#5b5a63",h=[{num:"01",icon:r,title:"ERP",body:"Bring core business processes together through an integrated ERP environment covering areas such as inventory, finance, human resources, customer relationships and supply chain management."},{num:"02",icon:u,title:"Operations Management",body:"Support and organize operational processes through technology designed around your business workflows."},{num:"03",icon:x,title:"Supply Chain Management",body:"Connect supply chain activities from procurement through delivery, with visibility across inventory, orders, suppliers and logistics."},{num:"04",icon:l,title:"Financial Management",body:"Support financial operations with organized information, financial processes and reporting capabilities."},{num:"05",icon:p,title:"Customer Relationship Management",body:"Manage customer information and interactions through a connected CRM environment."},{num:"06",icon:d,title:"E-Commerce",body:"Support online business activities through digital commerce solutions for managing online stores and customer experiences."},{num:"07",icon:c,title:"Web Portals",body:"Create digital portals that provide access to information and services for customers, employees and business users."},{num:"08",icon:m,title:"Project Management",body:"Support project planning, collaboration and workflow management through structured digital solutions."}];function j(){return i.jsxs(i.Fragment,{children:[i.jsx("style",{children:`

        .solutions-section,
        .solutions-section * {
          box-sizing: border-box;
        }

        .solutions-section {
          width: 100%;
          background: #ffffff;
          color: ${n};
          font-family: "Inter", Arial, sans-serif;
          overflow: hidden;
        }

        /* =========================
           MAIN CONTAINER
        ========================= */

        .solutions-container {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;

          /* HERO STANDARD SPACING */
          padding: 78px 100px;
        }

        /* =========================
           HEADER
        ========================= */

        .solutions-eyebrow {
          margin: 0 0 12px;

          color: ${o};

          font-family: "Inter", Arial, sans-serif;
          font-size: 12px;
          line-height: 1.2;
          font-weight: 700;
          letter-spacing: 1px;
          text-transform: uppercase;
        }

        .solutions-heading {
          max-width: 760px;

          margin: 0 0 42px;

          color: ${n};

          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 40px;
          line-height: 1.2;
          font-weight: 700;
          letter-spacing: -1px;
        }

        /* =========================
           GRID
        ========================= */

        .solutions-grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 20px;
        }

        /* =========================
           CARD
        ========================= */

        .solution-card {
          min-width: 0;

          padding: 22px;

          border: 1px solid #ece9e4;
          border-radius: 16px;

          background: #ffffff;

          transition:
            transform 0.25s ease,
            box-shadow 0.25s ease,
            border-color 0.25s ease;
        }

        .solution-card:hover {
          transform: translateY(-5px);

          border-color: rgba(122, 31, 61, 0.18);

          box-shadow: 0 12px 30px rgba(27, 27, 42, 0.07);
        }

        /* =========================
           CARD TOP
        ========================= */

        .solution-card-top {
          display: flex;
          align-items: center;
          justify-content: space-between;

          gap: 12px;
          margin-bottom: 20px;
        }

        .solution-number {
          display: inline-flex;
          align-items: center;
          justify-content: center;

          min-width: 32px;
          height: 26px;
          padding: 0 8px;

          border-radius: 7px;

          background: #fbeef1;
          color: ${o};

          font-family: "Inter", Arial, sans-serif;
          font-size: 10px;
          line-height: 1;
          font-weight: 700;
        }

        .solution-icon {
          display: flex;
          align-items: center;
          justify-content: center;

          width: 40px;
          height: 40px;

          flex-shrink: 0;

          border-radius: 10px;

          background: #fbeef1;
          color: ${o};
        }

        /* =========================
           CARD CONTENT
        ========================= */

        .solution-title {
          margin: 0 0 10px;

          color: ${n};

          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 16px;
          line-height: 1.35;
          font-weight: 700;
          letter-spacing: -0.2px;
        }

        .solution-body {
          margin: 0;

          color: ${g};

          font-family: "Inter", Arial, sans-serif;
          font-size: 13px;
          line-height: 1.65;
          font-weight: 400;
        }

        /* =========================
           TABLET / LAPTOP
        ========================= */

        @media (max-width: 1200px) {
          .solutions-container {
            padding-left: 40px;
            padding-right: 40px;
          }

          .solutions-grid {
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
          }

          .solutions-heading {
            font-size: 37px;
            margin-bottom: 38px;
          }

          .solution-card {
            padding: 20px;
          }
        }

        /* =========================
           TABLET
        ========================= */

        @media (max-width: 800px) {
          .solutions-container {
            padding-top: 60px;
            padding-bottom: 60px;
          }

          .solutions-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 16px;
          }

          .solutions-heading {
            max-width: 650px;

            font-size: 32px;
            margin-bottom: 32px;
          }

          .solution-card {
            padding: 19px;
            border-radius: 14px;
          }

          .solution-title {
            font-size: 15px;
          }

          .solution-body {
            font-size: 12.5px;
          }
        }

        /* =========================
           MOBILE
        ========================= */

        @media (max-width: 600px) {
          .solutions-container {
            padding-left: 24px;
            padding-right: 24px;

            padding-top: 48px;
            padding-bottom: 48px;
          }

          .solutions-eyebrow {
            margin-bottom: 10px;

            font-size: 10px;
            letter-spacing: 0.8px;
          }

          .solutions-heading {
            margin-bottom: 27px;

            font-size: 28px;
            line-height: 1.25;
            letter-spacing: -0.6px;
          }

          .solutions-grid {
            grid-template-columns: 1fr;
            gap: 12px;
          }

          .solution-card {
            padding: 18px;
            border-radius: 13px;
          }

          .solution-card-top {
            margin-bottom: 17px;
          }

          .solution-number {
            min-width: 30px;
            height: 24px;

            font-size: 9px;
          }

          .solution-icon {
            width: 37px;
            height: 37px;

            border-radius: 9px;
          }

          .solution-title {
            margin-bottom: 8px;
            font-size: 15px;
          }

          .solution-body {
            font-size: 12px;
            line-height: 1.6;
          }
        }

        /* =========================
           SMALL MOBILE
        ========================= */

        @media (max-width: 480px) {
          .solutions-container {
            padding-left: 16px;
            padding-right: 16px;

            padding-top: 40px;
            padding-bottom: 40px;
          }

          .solutions-heading {
            font-size: 25px;
            line-height: 1.25;
            letter-spacing: -0.4px;
          }

          .solutions-grid {
            gap: 10px;
          }

          .solution-card {
            padding: 16px;
          }

          .solution-title {
            font-size: 14px;
          }

          .solution-body {
            font-size: 11.5px;
          }
        }

        /* =========================
           VERY SMALL MOBILE
        ========================= */

        @media (max-width: 340px) {
          .solutions-container {
            padding-left: 16px;
            padding-right: 16px;

            padding-top: 34px;
            padding-bottom: 34px;
          }

          .solutions-heading {
            font-size: 23px;
          }

          .solution-card {
            padding: 15px;
          }

          .solution-icon {
            width: 34px;
            height: 34px;
          }

          .solution-title {
            font-size: 13.5px;
          }

          .solution-body {
            font-size: 11px;
          }
        }

        /* =========================
           REDUCED MOTION
        ========================= */

        @media (prefers-reduced-motion: reduce) {
          .solution-card {
            transition: none;
          }

          .solution-card:hover {
            transform: none;
          }
        }
      `}),i.jsx("section",{className:"solutions-section",children:i.jsxs("div",{className:"solutions-container",children:[i.jsxs("div",{children:[i.jsx("p",{className:"solutions-eyebrow",children:"Our Solutions"}),i.jsx("h2",{className:"solutions-heading",children:"Solutions Built Around Your Business"})]}),i.jsx("div",{className:"solutions-grid",children:h.map(({num:t,icon:e,title:s,body:a})=>i.jsxs("article",{className:"solution-card",children:[i.jsxs("div",{className:"solution-card-top",children:[i.jsx("span",{className:"solution-number",children:t}),i.jsx("span",{className:"solution-icon",children:i.jsx(e,{size:17,strokeWidth:1.8})})]}),i.jsx("h3",{className:"solution-title",children:s}),i.jsx("p",{className:"solution-body",children:a})]},t))})]})})]})}export{j as default};
