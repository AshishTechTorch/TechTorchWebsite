import{j as e}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";import{t as g,T as m,y as x,R as f,s as b,O as u,z as y}from"./index-37hjU4u5.js";import{G as N}from"./gauge-CiSx7q1J.js";import{S as w}from"./sliders-horizontal-CjRtpOeo.js";import{S as A}from"./sparkles-DOUwSwcm.js";import{D as S}from"./database-Dip2uwbp.js";import{U as I}from"./user-BusR5MVP.js";import{F as j}from"./flask-conical-B7RAl6Z1.js";import{T}from"./tag-Bqnvv1E3.js";const o={name:"table-2",size:24,node:[["path",{d:"M3 9h18",key:"1pudct"}],["path",{d:"M9 3v18",key:"fh3hqa"}],["rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",key:"h1oib"}]]};o.node;const z=g(o),a="#7A1F3D",n="#1B1B2A",r="#5b5a63",E=[{icon:x,miniIcon:m,title:"Operational Dashboards",body:"View important information in a structured format.",label:"Telemetry Sync",status:"99.8%",statusColor:"#1a9455",statusBg:"#e5f7ec"},{icon:N,miniIcon:f,title:"Performance Indicators",body:"Monitor selected operational measures.",label:"Bed Turnover Rate",status:"Optimal",statusColor:"#1a9455",statusBg:"#e5f7ec"},{icon:z,miniIcon:w,title:"Custom Reporting",body:"Create reports around organizational requirements.",label:"Audit Export",status:"Automated",statusColor:a,statusBg:"#fbeef1"},{icon:S,miniIcon:A,title:"Data Insights",body:"Use available information to understand operational trends and resource needs.",label:"Predictive Load",status:"Active",statusColor:"#1a9455",statusBg:"#e5f7ec"}],v=[{num:"01",icon:I,title:"Patient Management"},{num:"02",icon:b,title:"Staff & Operations"},{num:"03",icon:u,title:"Inventory & Supplies"},{num:"04",icon:y,title:"Billing & Finance"},{num:"05",icon:j,title:"Clinical & Laboratory"},{num:"06",icon:T,title:"Patient Engagement"}];function G(){return e.jsxs("div",{className:"healthcare-insights-page",children:[e.jsx("style",{children:`
        @import url(
          'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap'
        );

        /* =====================================================
           GLOBAL
        ===================================================== */

        .healthcare-insights-page {
          width: 100%;
          overflow: hidden;
          color: ${n};
          font-family: "Inter", sans-serif;
        }

        .healthcare-insights-page *,
        .healthcare-insights-page *::before,
        .healthcare-insights-page *::after {
          box-sizing: border-box;
        }

        /* =====================================================
           COMMON CONTAINER
           HERO SPACING SYSTEM
           
           Desktop  : 100px
           Tablet   : 40px
           Mobile   : 24px
           Small    : 16px
        ===================================================== */

        .healthcare-section-container {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;
          padding-left: 100px;
          padding-right: 100px;
        }

        /* =====================================================
           SECTION 1
        ===================================================== */

        .healthcare-insights-section {
          width: 100%;
          background: #ffffff;
          padding: 78px 0;
        }

        .healthcare-section-eyebrow {
          margin: 0 0 12px;
          color: ${a};
          font-family: "Inter", sans-serif;
          font-size: 10px;
          line-height: 1.4;
          font-weight: 700;
          letter-spacing: 0.08em;
        }

        /* =====================================================
           MAIN HEADING
           PLUS JAKARTA SANS
        ===================================================== */

        .healthcare-main-heading {
          max-width: 760px;
          margin: 0 0 16px;
          color: ${n};
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 30px;
          line-height: 1.25;
          font-weight: 700;
          letter-spacing: -0.8px;
        }

        /* =====================================================
           SUBHEADING
           PLUS JAKARTA SANS
        ===================================================== */

        .healthcare-main-subheading {
          max-width: 760px;
          margin: 0 0 42px;
          color: ${r};
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 13px;
          line-height: 1.75;
          font-weight: 500;
        }

        /* =====================================================
           INSIGHT CARDS
        ===================================================== */

        .healthcare-insights-grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 18px;
        }

        .healthcare-insight-card {
          min-width: 0;
          padding: 20px;
          border: 1px solid #ece9e4;
          border-radius: 12px;
          background: #ffffff;
          transition:
            transform 0.25s ease,
            box-shadow 0.25s ease,
            border-color 0.25s ease;
        }

        .healthcare-insight-card:hover {
          transform: translateY(-3px);
          border-color: #e3ddd7;
          box-shadow: 0 10px 28px rgba(0, 0, 0, 0.06);
        }

        .healthcare-insight-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
          margin-bottom: 17px;
        }

        .healthcare-insight-icon {
          display: flex;
          align-items: center;
          justify-content: center;

          width: 38px;
          height: 38px;

          flex-shrink: 0;

          border-radius: 9px;

          background: #fbeef1;
          color: ${a};
        }

        .healthcare-insight-mini-icon {
          flex-shrink: 0;
          color: #c9c4bc;
        }

        /* =====================================================
           CARD HEADING
           PLUS JAKARTA SANS
        ===================================================== */

        .healthcare-insight-title {
          margin: 0 0 7px;
          color: ${n};
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 13px;
          line-height: 1.45;
          font-weight: 700;
        }

        /* =====================================================
           CARD BODY
           INTER
        ===================================================== */

        .healthcare-insight-body {
          min-height: 58px;
          margin: 0 0 18px;
          color: ${r};
          font-family: "Inter", sans-serif;
          font-size: 11px;
          line-height: 1.65;
        }

        /* =====================================================
           STATUS
        ===================================================== */

        .healthcare-insight-status {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;

          padding-top: 12px;

          border-top: 1px solid #ece9e4;
        }

        .healthcare-insight-label {
          min-width: 0;

          color: ${r};

          font-family: "Inter", sans-serif;

          font-size: 10px;
          line-height: 1.4;
        }

        .healthcare-insight-badge {
          flex-shrink: 0;

          padding: 3px 8px;

          border-radius: 999px;

          font-family: "Inter", sans-serif;

          font-size: 9px;
          line-height: 1.3;
          font-weight: 700;
        }

        /* =====================================================
           SECTION 2
        ===================================================== */

        .healthcare-operations-section {
          width: 100%;
          background: #f4f1ec;
          padding: 78px 0;
        }

        .healthcare-operations-subheading {
          max-width: 760px;
          margin: 0 0 42px;
        }

        .healthcare-operations-description {
          margin: 0 0 9px;

          color: ${r};

          font-family: "Inter", sans-serif;

          font-size: 13px;
          line-height: 1.75;
          font-weight: 400;
        }

        .healthcare-operations-description:last-child {
          margin-bottom: 0;
        }

        /* =====================================================
           OPERATIONS GRID
        ===================================================== */

        .healthcare-operations-grid {
          display: grid;

          grid-template-columns:
            repeat(3, minmax(0, 1fr));

          gap: 18px;
        }

        .healthcare-operation-card {
          display: flex;

          align-items: center;

          gap: 13px;

          min-width: 0;

          padding: 18px;

          border-radius: 12px;

          background: #ffffff;

          box-shadow:
            0 1px 4px rgba(0, 0, 0, 0.05);

          transition:
            transform 0.25s ease,
            box-shadow 0.25s ease;
        }

        .healthcare-operation-card:hover {
          transform: translateY(-3px);

          box-shadow:
            0 9px 25px rgba(0, 0, 0, 0.07);
        }

        .healthcare-operation-icon {
          display: flex;

          align-items: center;
          justify-content: center;

          width: 40px;
          height: 40px;

          flex-shrink: 0;

          border-radius: 9px;

          background: #fbeef1;

          color: ${a};
        }

        .healthcare-operation-content {
          min-width: 0;
        }

        .healthcare-operation-number {
          margin: 0 0 2px;

          color: ${a};

          font-family: "Inter", sans-serif;

          font-size: 9px;
          line-height: 1.4;
          font-weight: 700;
        }

        /* =====================================================
           CARD HEADING
           PLUS JAKARTA SANS
        ===================================================== */

        .healthcare-operation-title {
          margin: 0;

          color: ${n};

          font-family: "Plus Jakarta Sans", sans-serif;

          font-size: 12px;
          line-height: 1.45;
          font-weight: 700;
        }

        /* =====================================================
           LARGE DESKTOP / LAPTOP
        ===================================================== */

        @media (max-width: 1200px) {
          .healthcare-section-container {
            padding-left: 40px;
            padding-right: 40px;
          }

          .healthcare-insights-section,
          .healthcare-operations-section {
            padding-top: 70px;
            padding-bottom: 70px;
          }

          .healthcare-insights-grid {
            grid-template-columns:
              repeat(3, minmax(0, 1fr));
          }
        }

        /* =====================================================
           TABLET
        ===================================================== */

        @media (max-width: 900px) {
          .healthcare-section-container {
            padding-left: 40px;
            padding-right: 40px;
          }

          .healthcare-insights-section,
          .healthcare-operations-section {
            padding-top: 60px;
            padding-bottom: 60px;
          }

          .healthcare-insights-grid {
            grid-template-columns:
              repeat(2, minmax(0, 1fr));
          }

          .healthcare-operations-grid {
            grid-template-columns:
              repeat(2, minmax(0, 1fr));
          }

          .healthcare-main-heading {
            font-size: 28px;
          }

          .healthcare-main-subheading,
          .healthcare-operations-subheading {
            margin-bottom: 34px;
          }
        }

        /* =====================================================
           SMALL TABLET
        ===================================================== */

        @media (max-width: 700px) {
          .healthcare-section-container {
            padding-left: 24px;
            padding-right: 24px;
          }

          .healthcare-insights-section,
          .healthcare-operations-section {
            padding-top: 52px;
            padding-bottom: 52px;
          }

          .healthcare-main-heading {
            font-size: 26px;
          }

          .healthcare-main-subheading,
          .healthcare-operations-description {
            font-size: 12px;
            line-height: 1.7;
          }

          .healthcare-insights-grid {
            gap: 14px;
          }

          .healthcare-operations-grid {
            gap: 14px;
          }
        }

        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 600px) {
          .healthcare-section-container {
            padding-left: 24px;
            padding-right: 24px;
          }

          .healthcare-insights-section,
          .healthcare-operations-section {
            padding-top: 48px;
            padding-bottom: 48px;
          }

          .healthcare-section-eyebrow {
            margin-bottom: 10px;
            font-size: 9px;
          }

          .healthcare-main-heading {
            margin-bottom: 15px;

            font-size: 25px;

            line-height: 1.3;

            letter-spacing: -0.5px;
          }

          .healthcare-main-subheading,
          .healthcare-operations-description {
            font-size: 12px;
            line-height: 1.7;
          }

          .healthcare-main-subheading,
          .healthcare-operations-subheading {
            margin-bottom: 28px;
          }

          .healthcare-insights-grid {
            grid-template-columns: 1fr;
            gap: 12px;
          }

          .healthcare-insight-card {
            padding: 17px;
          }

          .healthcare-insight-body {
            min-height: auto;
            margin-bottom: 16px;
          }

          .healthcare-operations-grid {
            grid-template-columns: 1fr;
            gap: 11px;
          }

          .healthcare-operation-card {
            padding: 16px;
          }

          .healthcare-operation-icon {
            width: 38px;
            height: 38px;
          }

          .healthcare-operation-title {
            font-size: 12px;
          }
        }

        /* =====================================================
           SMALL MOBILE
        ===================================================== */

        @media (max-width: 480px) {
          .healthcare-section-container {
            padding-left: 16px;
            padding-right: 16px;
          }

          .healthcare-insights-section,
          .healthcare-operations-section {
            padding-top: 42px;
            padding-bottom: 42px;
          }

          .healthcare-main-heading {
            font-size: 23px;
            line-height: 1.32;
          }

          .healthcare-main-subheading,
          .healthcare-operations-description {
            font-size: 11.5px;
          }

          .healthcare-insight-card {
            padding: 15px;
          }

          .healthcare-insight-title {
            font-size: 12px;
          }

          .healthcare-insight-body {
            font-size: 10.5px;
          }

          .healthcare-operation-card {
            padding: 14px;
          }

          .healthcare-operation-title {
            font-size: 11.5px;
          }
        }

        /* =====================================================
           VERY SMALL MOBILE
        ===================================================== */

        @media (max-width: 340px) {
          .healthcare-section-container {
            padding-left: 16px;
            padding-right: 16px;
          }

          .healthcare-main-heading {
            font-size: 21px;
          }

          .healthcare-main-subheading,
          .healthcare-operations-description {
            font-size: 11px;
          }

          .healthcare-insight-label {
            font-size: 9px;
          }

          .healthcare-insight-badge {
            font-size: 8px;
          }

          .healthcare-operation-card {
            gap: 10px;
          }

          .healthcare-operation-icon {
            width: 36px;
            height: 36px;
          }
        }

        /* =====================================================
           REDUCED MOTION
        ===================================================== */

        @media (prefers-reduced-motion: reduce) {
          .healthcare-insight-card,
          .healthcare-operation-card {
            transition: none;
          }
        }
      `}),e.jsx("section",{className:"healthcare-insights-section",children:e.jsxs("div",{className:"healthcare-section-container",children:[e.jsx("p",{className:"healthcare-section-eyebrow",children:"HEALTHCARE INSIGHTS"}),e.jsx("h2",{className:"healthcare-main-heading",children:"Turn Operational Data Into Clearer Visibility"}),e.jsx("p",{className:"healthcare-main-subheading",children:"Healthcare organizations generate information across patients, staff, resources, finance and clinical activities. TechTorch's healthcare solution includes dashboards, KPIs, predictive analytics and customizable reporting to help organizations review operational information and support decision-making."}),e.jsx("div",{className:"healthcare-insights-grid",children:E.map(({icon:i,miniIcon:s,title:t,body:h,label:c,status:l,statusColor:p,statusBg:d})=>e.jsxs("div",{className:"healthcare-insight-card",children:[e.jsxs("div",{className:"healthcare-insight-top",children:[e.jsx("span",{className:"healthcare-insight-icon",children:e.jsx(i,{size:16,strokeWidth:1.8})}),e.jsx(s,{size:16,className:"healthcare-insight-mini-icon"})]}),e.jsx("h3",{className:"healthcare-insight-title",children:t}),e.jsx("p",{className:"healthcare-insight-body",children:h}),e.jsxs("div",{className:"healthcare-insight-status",children:[e.jsx("span",{className:"healthcare-insight-label",children:c}),e.jsx("span",{className:"healthcare-insight-badge",style:{background:d,color:p},children:l})]})]},t))})]})}),e.jsx("section",{className:"healthcare-operations-section",children:e.jsxs("div",{className:"healthcare-section-container",children:[e.jsx("p",{className:"healthcare-section-eyebrow",children:"CONNECTED HEALTHCARE OPERATIONS"}),e.jsxs("h2",{className:"healthcare-main-heading",children:["One Connected Environment for Essential",e.jsx("br",{className:"desktop-line-break"}),"Functions"]}),e.jsxs("div",{className:"healthcare-operations-subheading",children:[e.jsx("p",{className:"healthcare-operations-description",children:"Healthcare delivery involves more than clinical services. Administration, workforce, resources, finance, information and technology all contribute to everyday operations."}),e.jsx("p",{className:"healthcare-operations-description",children:"TechTorch's healthcare management capabilities are designed to bring these areas into a more connected operational environment."})]}),e.jsx("div",{className:"healthcare-operations-grid",children:v.map(({num:i,icon:s,title:t})=>e.jsxs("div",{className:"healthcare-operation-card",children:[e.jsx("span",{className:"healthcare-operation-icon",children:e.jsx(s,{size:16,strokeWidth:1.8})}),e.jsxs("div",{className:"healthcare-operation-content",children:[e.jsx("p",{className:"healthcare-operation-number",children:i}),e.jsx("h3",{className:"healthcare-operation-title",children:t})]})]},i))})]})})]})}export{G as default};
