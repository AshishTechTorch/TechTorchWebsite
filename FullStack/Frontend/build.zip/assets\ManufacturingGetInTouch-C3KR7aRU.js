import{j as e}from"./vendor-query-PraSc8EQ.js";import{d as j,r as m}from"./vendor-router-L4ZCoGSs.js";import{F as w,s as v,a as N}from"./FormNotice-OE790tVc.js";import{a2 as k,V as S,A as g}from"./index-37hjU4u5.js";import{M as z}from"./mail-CbeZpzUl.js";import{M as E}from"./map-pin-B0tD-pH2.js";import{B as I}from"./briefcase-business-D4kLSYLp.js";import{G as C}from"./git-branch-BC7MuBqn.js";import{C as T}from"./code-xml-CIX-EOu2.js";import{L as A}from"./list-checks-BpQTkzZp.js";const M=[{icon:e.jsx(I,{size:17}),title:"Business-Focused Discussion",description:"Discuss your requirements around your business processes and objectives."},{icon:e.jsx(C,{size:17}),title:"ERP & Supply Chain Expertise",description:"Explore technology solutions across ERP, supply chain and business operations."},{icon:e.jsx(T,{size:17}),title:"Software & Technology Support",description:"Discuss custom software, integration, modernization and technology requirements."},{icon:e.jsx(A,{size:17}),title:"Clear Next Steps",description:"Understand the relevant capabilities and possible next steps for your requirement."}],q=[{number:"01",title:"ERP & Business Processes",description:"Discuss ERP requirements across inventory, finance, human resources, customer relationships and supply chain management."},{number:"02",title:"Supply Chain",description:"Discuss procurement, inventory, suppliers, logistics and related supply chain requirements."},{number:"03",title:"Software & Integration",description:"Discuss custom software, enterprise applications, system integration, modernization and ongoing support."}],R=[{number:"01",title:"Understand",description:"We review your business needs, existing technology environment and project requirements."},{number:"02",title:"Discuss",description:"Our team discusses relevant technology capabilities and possible approaches for your requirement."},{number:"03",title:"Next Steps",description:"We identify the appropriate way forward based on your business and technology needs."}],P={erp:"ERP & Business Processes","supply-chain":"Supply Chain",software:"Software & Integration","digital-transformation":"Digital Transformation","technology-support":"Technology Support"};function W(){j();const[f,r]=m.useState(!1),[t,c]=m.useState({fullName:"",email:"",phone:"",company:"",service:"",requirement:"",contactMethod:"",consent:!1}),n=i=>{const{name:s,value:a,type:u,checked:b}=i.target;c(y=>({...y,[s]:u==="checkbox"?b:a}))},[l,d]=m.useState(!1),[p,o]=m.useState(""),x=async i=>{if(i.preventDefault(),l)return;const s=i.currentTarget;if(!s.checkValidity()){const a=s.querySelector(":invalid");a&&(a.focus(),s.reportValidity(),setTimeout(()=>{a.blur()},4e3));return}if(!t.contactMethod){o("Please choose how you would like to be contacted.");return}if(!t.consent){o("Please agree to be contacted regarding your enquiry.");return}o(""),d(!0);try{await v("inquiry",{formType:"manufacturing",fullName:t.fullName.trim(),email:t.email.trim(),company:t.company.trim(),phone:t.phone.trim(),topic:P[t.service]||t.service,message:t.requirement.trim(),details:{preferredContactMethod:t.contactMethod==="phone"?"Phone":"Email",contactConsent:t.consent===!0}}),r(!0),setTimeout(()=>{r(!1)},3e3),c({fullName:"",email:"",phone:"",company:"",service:"",requirement:"",contactMethod:"",consent:!1})}catch(a){o(N(a))}finally{d(!1)}},h=()=>{document.getElementById("manufacturing-enquiry-form")?.scrollIntoView({behavior:"smooth",block:"start"})};return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`

        :root {
          --mfg-beetroot: #730042;
          --mfg-dark: #181818;
          --mfg-text: #555;
          --mfg-light-text: #777;
        }

        * {
          box-sizing: border-box;
        }

        /* =====================================================
           SUCCESS DIALOG - SAME STYLE AS INSURANCE GET IN TOUCH
        ===================================================== */

        .mfg-success-dialog {
          position: fixed;
          top: 24px;
          left: 50%;
          transform: translateX(-50%);
          z-index: 9999;
          width: min(420px, calc(100% - 32px));
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 16px 20px;
          background: #ffffff;
          border: 1px solid #E5D3DC;
          border-radius: 10px;
          box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
          font-family: "Inter", sans-serif;
          animation: mfgSuccessDialogIn 0.25s ease-out;
        }

        .mfg-success-dialog-icon {
          width: 44px;
          height: 44px;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          background: #ffffff;
          color: #22824D;
        }

        .mfg-success-dialog-content {
          min-width: 0;
        }

        .mfg-success-dialog-title {
          margin: 0;
          color: #202022;
          font-family: "Inter", sans-serif;
          font-size: 14px;
          font-weight: 700;
          line-height: 1.4;
        }

        .mfg-success-dialog-text {
          margin: 2px 0 0;
          color: #65595E;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 400;
          line-height: 1.5;
        }

        .mfg-success-dialog-ok {
          width: 34px;
          height: 34px;
          margin-left: auto;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 0;
          border: none;
          border-radius: 50%;
          background: #730042;
          color: #ffffff;
          font-family: "Inter", sans-serif;
          font-size: 10px;
          font-weight: 600;
          cursor: pointer;
          transition: background 0.2s ease, transform 0.2s ease;
        }

        .mfg-success-dialog-ok:hover {
          background: #620038;
          transform: scale(1.05);
        }

        @keyframes mfgSuccessDialogIn {
          from {
            opacity: 0;
            transform: translate(-50%, -12px);
          }
          to {
            opacity: 1;
            transform: translate(-50%, 0);
          }
        }

        .mfg-page {
          width: 100%;
          min-height: 100vh;
          background: #fff;
          color: var(--mfg-dark);
          overflow: hidden;
          font-family: "Inter", sans-serif;
        }

        /* =====================================================
           HERO
        ===================================================== */

        .mfg-hero {
          width: 100%;
          padding: 55px 40px 65px;
          background: #fff;
        }

        .mfg-hero-container {
          width: 100%;
          max-width: 1280px;
          margin: 0 auto;
        }

        .mfg-hero-heading {
          max-width: 900px;
          margin: 0 auto;
          text-align: center;
        }

        .mfg-eyebrow {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 7px 14px;
          background: #f5e5ed;
          color: var(--mfg-beetroot);
          border-radius: 999px;
          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.07em;
        }

        .mfg-eyebrow-dot {
          width: 6px;
          height: 6px;
          flex-shrink: 0;
          border-radius: 50%;
          background: var(--mfg-beetroot);
        }

        /* MAIN HEADING - PLUS JAKARTA SANS */

        .mfg-hero-heading h1 {
          margin: 22px auto 16px;
          max-width: 850px;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 38px;
          line-height: 1.14;
          letter-spacing: -0.035em;
          font-weight: 600;
          color: var(--mfg-dark);
        }

        /* SUBHEADING - PLUS JAKARTA SANS */

        .mfg-hero-heading p {
          max-width: 760px;
          margin: 0 auto;
          color: #707070;
          font-family: "Inter", sans-serif;
          font-size: 14px;
          line-height: 1.8;
          font-weight: 500;
        }

        /* =====================================================
           CONSULTATION CARDS
        ===================================================== */

        .mfg-consultation-grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 15px;
          margin-top: 48px;
        }

        .mfg-consultation-card {
          min-width: 0;
          display: flex;
          align-items: flex-start;
          gap: 12px;
          padding: 17px 15px;
          background: #fff;
          border: 1px solid #e8e8e8;
          border-radius: 12px;
          box-shadow: 0 3px 12px rgba(0, 0, 0, 0.035);
          transition:
            transform 0.25s ease,
            box-shadow 0.25s ease,
            border-color 0.25s ease;
        }

        .mfg-consultation-card:hover {
          transform: translateY(-4px);
          border-color: #dfc2d0;
          box-shadow: 0 12px 28px rgba(115, 0, 66, 0.08);
        }

        .mfg-card-icon {
          width: 38px;
          height: 38px;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--mfg-beetroot);
          background: #f4e8ee;
          border-radius: 9px;
        }

        .mfg-consultation-card h3 {
          margin: 0 0 5px;
          color: #252525;
          font-family: "Inter", sans-serif;
          font-size: 14px;
          line-height: 1.35;
          font-weight: 600;
        }

        .mfg-consultation-card p {
          margin: 0;
          color: #777;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          line-height: 1.55;
        }

        /* =====================================================
           MAIN CONTENT
        ===================================================== */

        .mfg-main-grid {
          width: 100%;
          max-width: 1250px;
          margin: 50px auto 0;
          display: grid;
          grid-template-columns: minmax(0, 0.95fr) minmax(0, 1.05fr);
          gap: 30px;
          align-items: start;
        }

        .mfg-left-column {
          min-width: 0;
        }

        /* =====================================================
           IMAGE CARD
        ===================================================== */

        .mfg-image-card {
          overflow: hidden;
          background: #fff;
          border: 1px solid #e8e8e8;
          border-radius: 16px;
          box-shadow: 0 5px 18px rgba(0, 0, 0, 0.04);
        }

        .mfg-image-wrapper {
          position: relative;
          width: 100%;
          height: 310px;
          overflow: hidden;
        }

        .mfg-image {
          display: block;
          width: 100%;
          height: 100%;
          object-fit: cover;
          object-position: center;
          transition: transform 0.5s ease;
        }

        .mfg-image-card:hover .mfg-image {
          transform: scale(1.03);
        }

        .mfg-image-overlay {
          position: absolute;
          inset: auto 0 0;
          height: 55%;
          background: linear-gradient(
            to top,
            rgba(115, 0, 66, 0.94),
            rgba(115, 0, 66, 0)
          );
        }

        .mfg-image-content {
          position: absolute;
          left: 22px;
          right: 22px;
          bottom: 20px;
          color: #fff;
        }

        .mfg-image-tag {
          display: inline-flex;
          padding: 6px 11px;
          margin-bottom: 9px;
          background: var(--mfg-beetroot);
          border-radius: 7px;
          font-family: "Inter", sans-serif;
          font-size: 10px;
          font-weight: 600;
        }

        .mfg-image-content h3 {
          margin: 0;
          font-family: "Inter", sans-serif;
          font-size: 16px;
          line-height: 1.4;
          font-weight: 600;
        }

        /* =====================================================
           REQUIREMENTS
        ===================================================== */

        .mfg-requirement-content {
          padding: 23px 24px 25px;
        }

        /* Heading - Plus Jakarta Sans */

        .mfg-requirement-content h2 {
          margin: 0 0 18px;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 20px;
          line-height: 1.4;
          font-weight: 600;
          letter-spacing: -0.02em;
        }

        .mfg-point {
          display: flex;
          gap: 11px;
          margin-bottom: 17px;
        }

        .mfg-point:last-child {
          margin-bottom: 0;
        }

        .mfg-point-number {
          width: 28px;
          height: 28px;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #f4e5ed;
          color: var(--mfg-beetroot);
          border-radius: 50%;
          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 700;
        }

        .mfg-point-text h4 {
          margin: 1px 0 4px;
          font-family: "Inter", sans-serif;
          font-size: 14px;
          font-weight: 600;
        }

        .mfg-point-text p {
          margin: 0;
          color: #777;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.6;
        }

        /* =====================================================
           CONTACT DESK
        ===================================================== */

        .mfg-contact-desk {
          margin-top: 18px;
          padding: 18px;
          background: #fff;
          border: 1px solid #e8e8e8;
          border-radius: 15px;
          box-shadow: 0 5px 18px rgba(0, 0, 0, 0.035);
        }

        .mfg-contact-heading {
          display: flex;
          align-items: center;
          gap: 8px;
          padding-bottom: 12px;
          border-bottom: 1px solid #ededed;
          color: var(--mfg-beetroot);
          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.04em;
        }

        .mfg-contact-item {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-top: 10px;
          padding: 10px;
          background: #f5f5f5;
          border-radius: 8px;
        }

        .mfg-contact-icon {
          width: 30px;
          height: 30px;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #eee2e9;
          color: var(--mfg-beetroot);
          border-radius: 7px;
        }

        .mfg-contact-item small {
          display: block;
          margin-bottom: 2px;
          color: #777;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 600;
        }

        .mfg-contact-item strong {
          display: block;
          color: #333;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 600;
          word-break: break-word;
        }

        /* =====================================================
           FORM
        ===================================================== */

        .mfg-form-card {
          width: 100%;
          padding: 34px 36px;
          background: #fff;
          border: 1px solid #e8e8e8;
          border-radius: 16px;
          box-shadow: 0 5px 18px rgba(0, 0, 0, 0.04);
          scroll-margin-top: 30px;
        }

        /* Heading - Plus Jakarta Sans */

        .mfg-form-heading h2 {
          margin: 0 0 8px;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 22px;
          line-height: 1.35;
          font-weight: 600;
          letter-spacing: -0.02em;
        }

        /* Subheading - Plus Jakarta Sans */

        .mfg-form-heading p {
          margin: 0 0 25px;
          color: #777;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.65;
          font-weight: 500;
        }

        .mfg-form-grid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 16px;
        }

        .mfg-field {
          width: 100%;
          min-width: 0;
        }

        .mfg-field.full-width {
          margin-top: 16px;
        }

        .mfg-field label {
          display: block;
          margin-bottom: 7px;
          color: #333;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 600;
        }

        .mfg-field label span {
          color: var(--mfg-beetroot);
        }

        .mfg-field input,
        .mfg-field select,
        .mfg-field textarea {
          width: 100%;
          border: 1px solid #e2e7ec;
          background: #fff;
          border-radius: 8px;
          outline: none;
          color: #333;
          font-family: "Inter", sans-serif;
          transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }

        .mfg-field input,
        .mfg-field select {
          height: 42px;
          padding: 0 12px;
          font-size: 13px;
        }

        .mfg-field textarea {
          min-height: 100px;
          padding: 11px 12px;
          resize: vertical;
          font-size: 13px;
          line-height: 1.55;
        }

        .mfg-field input::placeholder,
        .mfg-field textarea::placeholder {
          color: #aab0b8;
        }

        .mfg-field input:focus,
        .mfg-field select:focus,
        .mfg-field textarea:focus {
          border-color: #c48baa;
          box-shadow: 0 0 0 3px rgba(115, 0, 66, 0.06);
        }

        /* =====================================================
           RADIO
        ===================================================== */

        .mfg-radio-row {
          display: flex;
          align-items: center;
          gap: 20px;
        }

        .mfg-radio-box {
          display: inline-flex !important;
          align-items: center;
          gap: 7px;
          margin: 0 !important;
          cursor: pointer;
          font-size: 13px !important;
          font-weight: 400 !important;
        }

        .mfg-radio-box input {
          width: 13px !important;
          height: 13px !important;
          margin: 0;
          padding: 0;
          accent-color: var(--mfg-beetroot);
        }

        /* =====================================================
           CONSENT
        ===================================================== */

        .mfg-consent {
          display: flex;
          align-items: flex-start;
          gap: 9px;
          margin-top: 17px;
          padding: 11px 12px;
          background: #f7f7f7;
          border-radius: 8px;
          color: #777;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.5;
          cursor: pointer;
        }

        .mfg-consent input {
          width: 13px;
          height: 13px;
          flex-shrink: 0;
          margin: 1px 0 0;
          accent-color: var(--mfg-beetroot);
        }

        /* =====================================================
           SUBMIT
        ===================================================== */

        .mfg-submit-btn {
          width: 100%;
          min-height: 42px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 7px;
          margin-top: 16px;
          padding: 10px 16px;
          border: none;
          border-radius: 8px;
          background: var(--mfg-beetroot);
          color: #fff;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 700;
          letter-spacing: 0.03em;
          cursor: pointer;
          transition: background 0.2s ease, transform 0.2s ease;
        }

        .mfg-submit-btn:hover {
          background: #5d0035;
          transform: translateY(-1px);
        }

        /* =====================================================
           PROCESS
        ===================================================== */

        .mfg-process-section {
          width: 100%;
          max-width: 1250px;
          margin: 75px auto 0;
          padding-top: 58px;
          border-top: 1px solid #e8e8e8;
        }

        .mfg-process-heading {
          text-align: center;
          margin-bottom: 38px;
        }

        .mfg-process-heading span {
          color: var(--mfg-beetroot);
          font-family: "Inter", sans-serif;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.12em;
        }

        /* Heading - Plus Jakarta Sans */

        .mfg-process-heading h2 {
          margin: 9px 0 0;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 27px;
          line-height: 1.3;
          font-weight: 700;
          letter-spacing: -0.025em;
        }

        .mfg-process-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 20px;
        }

        .mfg-process-card {
          min-height: 155px;
          padding: 22px;
          background: #fff;
          border: 1px solid #e8e8e8;
          border-radius: 13px;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.025);
          transition:
            transform 0.25s ease,
            box-shadow 0.25s ease;
        }

        .mfg-process-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 14px 30px rgba(0, 0, 0, 0.07);
        }

        .mfg-process-number {
          margin-bottom: 14px;
          color: var(--mfg-beetroot);
          font-family: "Inter", sans-serif;
          font-size: 15px;
          font-weight: 700;
        }

        .mfg-process-card h3 {
          margin: 0 0 7px;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 600;
        }

        .mfg-process-card p {
          margin: 0;
          color: #777;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.6;
        }

        /* =====================================================
           BOTTOM CTA
        ===================================================== */

        .mfg-bottom-cta {
          margin-top: 40px;
          margin-bottom: 60px;
          padding: 36px 40px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 35px;
          background: var(--mfg-beetroot);
          border-radius: 14px;
        }

        /* Heading - Plus Jakarta Sans */

        .mfg-bottom-cta h2 {
          margin: 0 0 8px;
          color: #fff;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 22px;
          line-height: 1.35;
          font-weight: 700;
          letter-spacing: -0.02em;
        }

        /* Subheading - Plus Jakarta Sans */

        .mfg-bottom-cta p {
          max-width: 620px;
          margin: 0;
          color: rgba(255, 255, 255, 0.88);
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 12.5px;
          line-height: 1.7;
          font-weight: 500;
        }

        .mfg-bottom-cta button {
          flex-shrink: 0;
          min-width: 155px;
          min-height: 42px;
          padding: 0 18px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 7px;
          border: none;
          border-radius: 8px;
          background: #fff;
          color: var(--mfg-beetroot);
          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 700;
          cursor: pointer;
          transition:
            transform 0.2s ease,
            box-shadow 0.2s ease;
        }

        .mfg-bottom-cta button:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
        }

        /* =====================================================
           LARGE TABLET
        ===================================================== */

        @media (max-width: 1100px) {
          .mfg-hero {
            padding: 52px 32px 60px;
          }

          .mfg-consultation-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .mfg-main-grid {
            grid-template-columns: minmax(0, 0.95fr) minmax(0, 1.05fr);
            max-width: 1040px;
            gap: 22px;
          }

          .mfg-left-column {
            display: block;
          }

          .mfg-contact-desk {
            margin-top: 18px;
            height: auto;
          }

          .mfg-form-card {
            padding: 28px;
          }

          .mfg-process-section {
            margin-left: 32px;
            margin-right: 32px;
          }
        }

        /* =====================================================
           TABLET
        ===================================================== */

        @media (max-width: 800px) {
          .mfg-hero {
            padding: 48px 26px 55px;
          }

          .mfg-hero-heading h1 {
            font-size: 35px;
          }

          .mfg-hero-heading p {
            font-size: 13.5px;
          }

          .mfg-main-grid {
            margin-top: 42px;
          }

          .mfg-left-column {
            display: block;
          }

          .mfg-contact-desk {
            margin-top: 18px;
          }

          .mfg-image-wrapper {
            height: 330px;
          }

          .mfg-form-card {
            padding: 30px;
          }

          .mfg-process-section {
            margin-left: 26px;
            margin-right: 26px;
          }

          .mfg-process-grid {
            grid-template-columns: 1fr;
          }

          .mfg-process-card {
            min-height: auto;
          }

          .mfg-bottom-cta {
            flex-direction: column;
            align-items: flex-start;
          }

          .mfg-bottom-cta button {
            width: 100%;
          }
        }

        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 600px) {
          .mfg-success-dialog {
            top: 16px;
            width: calc(100% - 28px);
            padding: 14px 16px;
          }

          .mfg-success-dialog-title {
            font-size: 13px;
          }

          .mfg-success-dialog-text {
            font-size: 11px;
          }

          .mfg-success-dialog-icon {
            width: 40px;
            height: 40px;
          }

          .mfg-success-dialog-icon svg {
            width: 28px;
            height: 28px;
          }

          .mfg-hero {
            padding: 40px 18px 48px;
          }

          .mfg-eyebrow {
            font-size: 9px;
            padding: 6px 11px;
            letter-spacing: 0.05em;
          }

          .mfg-hero-heading h1 {
            margin-top: 18px;
            font-size: 29px;
            line-height: 1.18;
            letter-spacing: -0.025em;
          }

          .mfg-hero-heading p {
            font-size: 12.5px;
            line-height: 1.75;
          }

          .mfg-consultation-grid {
            grid-template-columns: 1fr;
            gap: 12px;
            margin-top: 32px;
          }

          .mfg-consultation-card {
            padding: 14px;
          }

          .mfg-card-icon {
            width: 36px;
            height: 36px;
          }

          .mfg-main-grid {
            margin-top: 35px;
          }

          .mfg-image-wrapper {
            height: 255px;
          }

          .mfg-image-content {
            left: 16px;
            right: 16px;
            bottom: 15px;
          }

          .mfg-image-content h3 {
            font-size: 14px;
          }

          .mfg-requirement-content {
            padding: 20px 18px 22px;
          }

          .mfg-requirement-content h2 {
            font-size: 18px;
          }

          .mfg-form-card {
            padding: 25px 18px;
          }

          .mfg-form-grid {
            grid-template-columns: 1fr;
            gap: 14px;
          }

          .mfg-field.full-width {
            margin-top: 14px;
          }

          .mfg-form-heading h2 {
            font-size: 19px;
          }

          .mfg-form-heading p {
            font-size: 12px;
          }

          .mfg-process-section {
            margin-top: 55px;
            margin-left: 18px;
            margin-right: 18px;
            padding-top: 42px;
          }

          .mfg-process-heading {
            margin-bottom: 30px;
          }

          .mfg-process-heading h2 {
            font-size: 23px;
          }

          .mfg-bottom-cta {
            padding: 28px 21px;
            margin-bottom: 35px;
            gap: 22px;
          }

          .mfg-bottom-cta h2 {
            font-size: 19px;
          }

          .mfg-bottom-cta h2 br {
            display: none;
          }

          .mfg-bottom-cta p {
            font-size: 12px;
          }
        }

        /* =====================================================
           SMALL MOBILE
        ===================================================== */

        @media (max-width: 400px) {
          .mfg-hero {
            padding: 35px 14px 42px;
          }

          .mfg-hero-heading h1 {
            font-size: 26px;
          }

          .mfg-hero-heading p {
            font-size: 12px;
          }

          .mfg-image-wrapper {
            height: 220px;
          }

          .mfg-image-tag {
            font-size: 9px;
            padding: 5px 8px;
          }

          .mfg-image-content h3 {
            font-size: 13px;
          }

          .mfg-form-card {
            padding: 22px 14px;
          }

          .mfg-requirement-content {
            padding-left: 15px;
            padding-right: 15px;
          }

          .mfg-point-text p {
            font-size: 11px;
          }

          .mfg-process-section {
            margin-left: 14px;
            margin-right: 14px;
          }

          .mfg-bottom-cta {
            padding: 24px 17px;
          }

          .mfg-bottom-cta h2 {
            font-size: 18px;
          }
        }

        /* =====================================================
           VERY SMALL MOBILE
        ===================================================== */

        @media (max-width: 340px) {
          .mfg-hero-heading h1 {
            font-size: 24px;
          }

          .mfg-image-wrapper {
            height: 200px;
          }

          .mfg-form-card {
            padding: 20px 12px;
          }

          .mfg-process-heading h2 {
            font-size: 21px;
          }

          .mfg-bottom-cta {
            padding: 22px 15px;
          }
        }

        /* =====================================================
           REDUCED MOTION
        ===================================================== */

        @media (prefers-reduced-motion: reduce) {
          .mfg-consultation-card,
          .mfg-image,
          .mfg-submit-btn,
          .mfg-process-card,
          .mfg-bottom-cta button {
            transition: none;
          }
        }
      `}),e.jsxs("div",{className:"mfg-page",children:[f&&e.jsxs("div",{className:"mfg-success-dialog",role:"alert","aria-live":"polite",tabIndex:-1,onKeyDown:i=>{i.key==="Enter"&&(i.preventDefault(),r(!1))},children:[e.jsx("div",{className:"mfg-success-dialog-icon",children:e.jsx(k,{size:30,strokeWidth:2.5})}),e.jsxs("div",{className:"mfg-success-dialog-content",children:[e.jsx("p",{className:"mfg-success-dialog-title",children:"Request Submitted"}),e.jsx("p",{className:"mfg-success-dialog-text",children:"Your enquiry has been submitted successfully."})]}),e.jsx("button",{type:"button",className:"mfg-success-dialog-ok",onClick:()=>r(!1),"aria-label":"Close success message",children:"OK"})]}),e.jsx("section",{className:"mfg-hero",children:e.jsxs("div",{className:"mfg-hero-container",children:[e.jsxs("div",{className:"mfg-hero-heading",children:[e.jsxs("div",{className:"mfg-eyebrow",children:[e.jsx("span",{className:"mfg-eyebrow-dot"}),"MANUFACTURING TECHNOLOGY · ENQUIRY"]}),e.jsxs("h1",{children:["Connect With TechTorch",e.jsx("br",{}),"Manufacturing Experts"]}),e.jsx("p",{children:"Discuss your manufacturing technology requirements, ERP needs, supply chain processes, software requirements and digital initiatives with our team."})]}),e.jsx("div",{className:"mfg-consultation-grid",children:M.map((i,s)=>e.jsxs("div",{className:"mfg-consultation-card",children:[e.jsx("div",{className:"mfg-card-icon",children:i.icon}),e.jsxs("div",{children:[e.jsx("h3",{children:i.title}),e.jsx("p",{children:i.description})]})]},s))}),e.jsxs("div",{className:"mfg-main-grid",children:[e.jsxs("div",{className:"mfg-left-column",children:[e.jsxs("div",{className:"mfg-image-card",children:[e.jsxs("div",{className:"mfg-image-wrapper",children:[e.jsx("img",{loading:"lazy",decoding:"async",src:"/ManufacturingGetInTouch.webp",alt:"Manufacturing technology",className:"mfg-image"}),e.jsx("div",{className:"mfg-image-overlay"}),e.jsxs("div",{className:"mfg-image-content",children:[e.jsx("div",{className:"mfg-image-tag",children:"Manufacturing Technology"}),e.jsx("h3",{children:"Connected solutions for modern manufacturing operations"})]})]}),e.jsxs("div",{className:"mfg-requirement-content",children:[e.jsx("h2",{children:"Discuss Your Manufacturing Technology Requirements"}),q.map(i=>e.jsxs("div",{className:"mfg-point",children:[e.jsx("div",{className:"mfg-point-number",children:i.number}),e.jsxs("div",{className:"mfg-point-text",children:[e.jsx("h4",{children:i.title}),e.jsx("p",{children:i.description})]})]},i.number))]})]}),e.jsxs("div",{className:"mfg-contact-desk",children:[e.jsxs("div",{className:"mfg-contact-heading",children:[e.jsx(S,{size:13}),"TECHTORCH CONTACT DESK"]}),e.jsxs("div",{className:"mfg-contact-item",children:[e.jsx("div",{className:"mfg-contact-icon",children:e.jsx(z,{size:14})}),e.jsxs("div",{children:[e.jsx("small",{children:"Email Enquiries"}),e.jsx("strong",{children:"contact@techtorch.solutions"})]})]}),e.jsxs("div",{className:"mfg-contact-item",children:[e.jsx("div",{className:"mfg-contact-icon",children:e.jsx(E,{size:14})}),e.jsxs("div",{children:[e.jsx("small",{children:"Office Locations"}),e.jsx("strong",{children:"Noida · Bareilly · Florida, USA"})]})]})]})]}),e.jsxs("div",{className:"mfg-form-card",id:"manufacturing-enquiry-form",children:[e.jsxs("div",{className:"mfg-form-heading",children:[e.jsx("h2",{children:"Submit Your Requirement"}),e.jsx("p",{children:"Please share your details and requirement. Our team will review and get in touch with you."})]}),e.jsxs("form",{onSubmit:x,children:[e.jsxs("div",{className:"mfg-form-grid",children:[e.jsxs("div",{className:"mfg-field",children:[e.jsxs("label",{children:["Full Name ",e.jsx("span",{children:"*"})]}),e.jsx("input",{type:"text",name:"fullName",value:t.fullName,onChange:n,placeholder:"Enter your full name",required:!0})]}),e.jsxs("div",{className:"mfg-field",children:[e.jsxs("label",{children:["Business Email ",e.jsx("span",{children:"*"})]}),e.jsx("input",{type:"email",name:"email",value:t.email,onChange:n,placeholder:"Enter your business email",required:!0})]}),e.jsxs("div",{className:"mfg-field",children:[e.jsx("label",{children:"Phone Number"}),e.jsx("input",{type:"tel",name:"phone",value:t.phone,onChange:n,placeholder:"Enter your phone number"})]}),e.jsxs("div",{className:"mfg-field",children:[e.jsxs("label",{children:["Company / Organization ",e.jsx("span",{children:"*"})]}),e.jsx("input",{type:"text",name:"company",value:t.company,onChange:n,placeholder:"Enter your company name",required:!0})]})]}),e.jsxs("div",{className:"mfg-field full-width",children:[e.jsxs("label",{children:["What Can We Help You With? ",e.jsx("span",{children:"*"})]}),e.jsxs("select",{name:"service",value:t.service,onChange:n,required:!0,children:[e.jsx("option",{value:"",disabled:!0,children:"Select an area of interest"}),e.jsx("option",{value:"erp",children:"ERP & Business Processes"}),e.jsx("option",{value:"supply-chain",children:"Supply Chain"}),e.jsx("option",{value:"software",children:"Software & Integration"}),e.jsx("option",{value:"digital-transformation",children:"Digital Transformation"}),e.jsx("option",{value:"technology-support",children:"Technology Support"})]})]}),e.jsxs("div",{className:"mfg-field full-width",children:[e.jsx("label",{children:"Tell Us About Your Requirement"}),e.jsx("textarea",{name:"requirement",value:t.requirement,onChange:n,placeholder:"Tell us about your business, current technology environment, project requirements or the challenge you would like to discuss."})]}),e.jsxs("div",{className:"mfg-field full-width",children:[e.jsx("label",{children:"Preferred Contact Method"}),e.jsxs("div",{className:"mfg-radio-row",children:[e.jsxs("label",{className:"mfg-radio-box",children:[e.jsx("input",{type:"radio",name:"contactMethod",value:"email",checked:t.contactMethod==="email",onChange:n}),e.jsx("span",{children:"Email"})]}),e.jsxs("label",{className:"mfg-radio-box",children:[e.jsx("input",{type:"radio",name:"contactMethod",value:"phone",checked:t.contactMethod==="phone",onChange:n}),e.jsx("span",{children:"Phone"})]})]})]}),e.jsxs("label",{className:"mfg-consent",children:[e.jsx("input",{type:"checkbox",name:"consent",checked:t.consent,onChange:n}),e.jsx("span",{children:"I agree to be contacted regarding my enquiry."})]}),e.jsx(w,{error:p}),e.jsxs("button",{type:"submit",disabled:l,className:"mfg-submit-btn",children:["SUBMIT ENQUIRY",e.jsx(g,{size:14})]})]})]})]})]})}),e.jsxs("section",{className:"mfg-process-section",children:[e.jsxs("div",{className:"mfg-process-heading",children:[e.jsx("span",{children:"ENGAGEMENT PROCESS"}),e.jsx("h2",{children:"From Requirement to Next Steps"})]}),e.jsx("div",{className:"mfg-process-grid",children:R.map(i=>e.jsxs("div",{className:"mfg-process-card",children:[e.jsx("div",{className:"mfg-process-number",children:i.number}),e.jsx("h3",{children:i.title}),e.jsx("p",{children:i.description})]},i.number))}),e.jsxs("div",{className:"mfg-bottom-cta",children:[e.jsxs("div",{children:[e.jsxs("h2",{children:["Let's Discuss Your Manufacturing Technology",e.jsx("br",{}),"Requirements"]}),e.jsx("p",{children:"Whether you need ERP, supply chain management, software development, system integration or broader technology support, our team is ready to discuss your requirements."})]}),e.jsxs("button",{type:"button",onClick:h,children:["Talk to Our Experts",e.jsx(g,{size:14})]})]})]})]})]})}export{W as default};
