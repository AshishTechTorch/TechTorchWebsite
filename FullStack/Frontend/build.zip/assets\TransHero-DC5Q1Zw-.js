import{j as t}from"./vendor-query-PraSc8EQ.js";import{d as n,L as e}from"./vendor-router-L4ZCoGSs.js";import{A as i}from"./index-37hjU4u5.js";import{S as s}from"./sparkle-DU3pd0Fh.js";const o="#7A1F3D",a="#1B1B2A",p="#5b5a63";function c(){const r=n();return t.jsxs("section",{className:"transportation-hero-section",children:[t.jsx("style",{children:`

        /* =========================================
           MAIN SECTION
        ========================================= */

        .transportation-hero-section {
          width: 100%;
          overflow: hidden;

          background: #ffffff;
          color: ${a};

          font-family: "Inter", sans-serif;
        }

        .transportation-hero-section *,
        .transportation-hero-section *::before,
        .transportation-hero-section *::after {
          box-sizing: border-box;
        }

        /* =========================================
           MAIN CONTAINER
           Desktop: 100px
           Tablet: 40px
           Mobile: 24px
           Small Mobile: 16px
        ========================================= */

        .transportation-hero-container {
          width: 100%;
          max-width: 1440px;
          margin: 0 auto;

          padding: 88px 100px;

          display: grid;
          grid-template-columns: minmax(0, 1fr) minmax(0, 0.95fr);

          gap: 65px;
          align-items: center;
        }

        /* =========================================
           LEFT CONTENT
        ========================================= */

        .transportation-hero-content {
          min-width: 0;
        }

        .transportation-hero-label {
          display: inline-flex;
          align-items: center;
          gap: 8px;

          margin: 0 0 20px;

          color: ${o};

          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 700;
          line-height: 1.4;
          letter-spacing: 0.14em;
        }

        .transportation-hero-label-dot {
          width: 6px;
          height: 6px;
          flex-shrink: 0;

          border-radius: 50%;
          background: ${o};
        }

        /* =========================================
           HEADING
        ========================================= */

        .transportation-hero-heading {
          max-width: 670px;
          margin: 0 0 25px;

          color: ${a};

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: clamp(32px, 4vw, 48px);
          font-weight: 700;
          line-height: 1.16;
          letter-spacing: -0.045em;
        }

        /* =========================================
           DESCRIPTION
        ========================================= */

        .transportation-hero-description {
          max-width: 650px;
          margin: 0 0 15px;

          color: ${p};

          font-family: "Inter", sans-serif;
          font-size: 14px;
          font-weight: 400;
          line-height: 1.8;
        }

        .transportation-hero-description:last-of-type {
          margin-bottom: 30px;
        }

        /* =========================================
           BUTTONS
        ========================================= */

        .transportation-hero-actions {
          display: flex;
          flex-wrap: wrap;
          align-items: center;
          gap: 12px;
        }

        .transportation-primary-btn,
        .transportation-secondary-btn {
          min-height: 46px;

          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 9px;

          padding: 12px 19px;

          border-radius: 7px;

          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 700;
          line-height: 1.3;
          letter-spacing: 0.06em;

          cursor: pointer;

          transition:
            transform 0.25s ease,
            box-shadow 0.25s ease,
            background 0.25s ease,
            border-color 0.25s ease,
            color 0.25s ease;
        }

        .transportation-primary-btn {
          border: 1px solid ${o};
          background: ${o};
          color: #ffffff;
        }

        .transportation-primary-btn:hover {
          transform: translateY(-2px);

          box-shadow:
            0 8px 22px rgba(122, 31, 61, 0.2);
        }

        .transportation-secondary-btn {
          border: 1px solid #d8d5d0;

          background: #ffffff;
          color: ${a};
        }

        .transportation-secondary-btn:hover {
          transform: translateY(-2px);

          border-color: ${o};
          color: ${o};

          box-shadow:
            0 6px 18px rgba(30, 20, 25, 0.07);
        }

        /* =========================================
           IMAGE CONTAINER
        ========================================= */

        .transportation-hero-visual {
          position: relative;

          width: 100%;
          height: 440px;
          min-width: 0;

          overflow: hidden;

          border-radius: 24px;

          background: #171923;

          box-shadow:
            0 18px 45px rgba(20, 20, 30, 0.12);
        }

        .transportation-hero-image {
          position: absolute;
          inset: 0;

          display: block;

          width: 100%;
          height: 100%;

          object-fit: cover;

          transition: transform 0.7s ease;
        }

        .transportation-hero-visual:hover
        .transportation-hero-image {
          transform: scale(1.035);
        }

        /* =========================================
           IMAGE OVERLAY
        ========================================= */

        .transportation-hero-image-overlay {
          position: absolute;
          inset: 0;

          background:
            linear-gradient(
              180deg,
              rgba(10, 13, 22, 0.05) 15%,
              rgba(10, 13, 22, 0.12) 45%,
              rgba(10, 13, 22, 0.75) 100%
            );

          pointer-events: none;
        }

        /* =========================================
           IMAGE LABEL
        ========================================= */

        .transportation-hero-image-bottom {
          position: absolute;

          left: 20px;
          right: 20px;
          bottom: 18px;

          display: flex;
          align-items: center;
          justify-content: space-between;

          gap: 15px;
        }

        .transportation-hero-image-label {
          display: inline-flex;
          align-items: center;
          gap: 8px;

          color: #ffffff;

          font-family: "Inter", sans-serif;
          font-size: 10px;
          font-weight: 700;
          line-height: 1.4;
          letter-spacing: 0.1em;
        }

        .transportation-hero-image-label svg {
          flex-shrink: 0;
          color: #e05a8a;
        }

        .transportation-hero-image-code {
          color: rgba(255, 255, 255, 0.68);

          font-family: "Inter", sans-serif;
          font-size: 10px;
          font-weight: 600;
          letter-spacing: 0.1em;
          white-space: nowrap;
        }

        /* =========================================
           LARGE TABLET
           Desktop 100px → Tablet 40px
        ========================================= */

        @media (max-width: 1200px) {
          .transportation-hero-container {
            padding-left: 40px;
            padding-right: 40px;

            padding-top: 80px;
            padding-bottom: 80px;

            gap: 55px;
          }
        }

        /* =========================================
           TABLET
        ========================================= */

        @media (max-width: 1050px) {
          .transportation-hero-container {
            padding-left: 40px;
            padding-right: 40px;

            padding-top: 75px;
            padding-bottom: 75px;

            gap: 45px;
          }

          .transportation-hero-heading {
            font-size: 38px;
          }

          .transportation-hero-visual {
            height: 390px;
            border-radius: 20px;
          }
        }

        /* =========================================
           SMALL TABLET
        ========================================= */

        @media (max-width: 850px) {
          .transportation-hero-container {
            grid-template-columns: 1fr;

            gap: 42px;

            padding-left: 40px;
            padding-right: 40px;

            padding-top: 70px;
            padding-bottom: 70px;
          }

          .transportation-hero-heading {
            max-width: 760px;
            font-size: 38px;
          }

          .transportation-hero-description {
            max-width: 760px;
          }

          .transportation-hero-visual {
            height: 380px;
            border-radius: 20px;
          }
        }

        /* =========================================
           MOBILE
           40px → 24px
        ========================================= */

        @media (max-width: 600px) {
          .transportation-hero-container {
            padding-left: 24px;
            padding-right: 24px;

            padding-top: 55px;
            padding-bottom: 55px;

            gap: 34px;
          }

          .transportation-hero-label {
            margin-bottom: 15px;

            font-size: 10px;
            letter-spacing: 0.12em;
          }

          .transportation-hero-label-dot {
            width: 5px;
            height: 5px;
          }

          .transportation-hero-heading {
            margin-bottom: 20px;

            font-size: 29px;
            line-height: 1.25;
            letter-spacing: -0.03em;
          }

          .transportation-hero-description {
            margin-bottom: 13px;

            font-size: 12.5px;
            line-height: 1.75;
          }

          .transportation-hero-description:last-of-type {
            margin-bottom: 25px;
          }

          .transportation-hero-actions {
            width: 100%;

            flex-direction: column;
            align-items: stretch;
          }

          .transportation-primary-btn,
          .transportation-secondary-btn {
            width: 100%;

            min-height: 46px;
            padding: 12px 16px;
          }

          .transportation-hero-visual {
            height: 300px;
            border-radius: 17px;
          }

          .transportation-hero-image-bottom {
            left: 15px;
            right: 15px;
            bottom: 14px;
          }

          .transportation-hero-image-label {
            font-size: 8.5px;
          }

          .transportation-hero-image-code {
            font-size: 8px;
          }
        }

        /* =========================================
           SMALL MOBILE
           24px → 16px
        ========================================= */

        @media (max-width: 400px) {
          .transportation-hero-container {
            padding-left: 16px;
            padding-right: 16px;

            padding-top: 48px;
            padding-bottom: 48px;
          }

          .transportation-hero-heading {
            font-size: 25px;
          }

          .transportation-hero-description {
            font-size: 12px;
          }

          .transportation-hero-visual {
            height: 250px;
            border-radius: 15px;
          }

          .transportation-hero-image-label {
            font-size: 7.5px;
          }

          .transportation-hero-image-code {
            font-size: 7px;
          }
        }

        /* =========================================
           REDUCED MOTION
        ========================================= */

        @media (prefers-reduced-motion: reduce) {
          .transportation-primary-btn,
          .transportation-secondary-btn,
          .transportation-hero-image {
            transition: none;
          }
        }
      `}),t.jsxs("div",{className:"transportation-hero-container",children:[t.jsxs("div",{className:"transportation-hero-content",children:[t.jsxs("span",{className:"transportation-hero-label",children:[t.jsx("span",{className:"transportation-hero-label-dot"}),"TRANSPORTATION"]}),t.jsx("h1",{className:"transportation-hero-heading",children:"Technology Solutions for a More Connected Transportation Business"}),t.jsx("p",{className:"transportation-hero-description",children:"Transportation businesses need connected operations, organized information and reliable technology across their day-to-day processes."}),t.jsx("p",{className:"transportation-hero-description",children:"TechTorch provides digital solutions and technology services designed around business requirements — helping transportation organizations connect operations, supply chain, finance, customers and technology."}),t.jsxs("div",{className:"transportation-hero-actions",children:[t.jsxs(e,{to:"/talk-to-expert",className:"transportation-primary-btn",children:["TALK TO OUR EXPERTS",t.jsx(i,{size:14})]}),t.jsx("button",{type:"button",className:"transportation-secondary-btn",onClick:()=>r("/transportation-get-in-touch"),children:"GET IN TOUCH"})]})]}),t.jsxs("div",{className:"transportation-hero-visual",children:[t.jsx("img",{src:"/transportationhero.webp",alt:"Connected transportation technology",className:"transportation-hero-image"}),t.jsx("div",{className:"transportation-hero-image-overlay"}),t.jsxs("div",{className:"transportation-hero-image-bottom",children:[t.jsxs("span",{className:"transportation-hero-image-label",children:[t.jsx(s,{size:13}),"OPERATIONAL ARCHITECTURE"]}),t.jsx("span",{className:"transportation-hero-image-code",children:"TECHTORCH SYS_01"})]})]})]})]})}export{c as default};
