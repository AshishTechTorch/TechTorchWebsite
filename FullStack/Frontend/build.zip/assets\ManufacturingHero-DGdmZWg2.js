import{j as a}from"./vendor-query-PraSc8EQ.js";import{d as i,L as t}from"./vendor-router-L4ZCoGSs.js";import{A as o}from"./index-37hjU4u5.js";import{C as s}from"./cpu-D2EjxXHQ.js";const n="#7A1F3D",e="#1B1B2A",u="#5b5a63",c="/manufacturinghero.webp";function d(){const r=i();return a.jsxs(a.Fragment,{children:[a.jsx("style",{children:`

        .manufacturing-hero {
          width: 100%;
          background: #f7f7fa;
          color: ${e};
          font-family: "Inter", sans-serif;
          overflow: hidden;
        }

        /* =====================================================
           MAIN CONTAINER
           Desktop: 100px
           Tablet: 40px
           Mobile: 24px
           Small Mobile: 16px
        ===================================================== */

        .manufacturing-hero-container {
          width: 100%;
          max-width: 1440px;
          margin: 0 auto;
          padding: 72px 100px;
          display: grid;
          grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
          gap: 64px;
          align-items: center;
          box-sizing: border-box;
        }

        /* =====================================================
           LEFT CONTENT
        ===================================================== */

        .manufacturing-hero-content {
          width: 100%;
          min-width: 0;
        }

        .manufacturing-hero-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 7px 13px;
          margin-bottom: 22px;
          border-radius: 999px;
          background: #fbeef1;
          color: ${n};
          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.08em;
        }

        .manufacturing-hero-badge-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: ${n};
          flex-shrink: 0;
        }

        .manufacturing-hero-heading {
          margin: 0 0 22px;
          max-width: 650px;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: clamp(36px, 4vw, 54px);
          line-height: 1.12;
          font-weight: 700;
          letter-spacing: -0.035em;
          color: ${e};
        }

        .manufacturing-hero-description {
          margin: 0 0 30px;
          max-width: 650px;
          color: ${u};
          font-family: "Inter", sans-serif;
          font-size: 15px;
          line-height: 1.8;
          font-weight: 400;
        }

        /* =====================================================
           BUTTONS
        ===================================================== */

        .manufacturing-hero-actions {
          display: flex;
          flex-wrap: wrap;
          align-items: center;
          gap: 12px;
        }

        .manufacturing-hero-primary,
        .manufacturing-hero-secondary {
          border: none;
          cursor: pointer;

          /* UPDATED */
          border-radius: 6px;

          padding: 13px 21px;
          min-height: 46px;

          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 600;

          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;

          transition:
            transform 0.25s ease,
            box-shadow 0.25s ease,
            background 0.25s ease;
        }

        .manufacturing-hero-primary {
          background: ${n};
          color: #ffffff;
        }

        .manufacturing-hero-secondary {
          background: #e9e8ec;
          color: ${e};
        }

        .manufacturing-hero-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 24px rgba(122, 31, 61, 0.22);
        }

        .manufacturing-hero-secondary:hover {
          transform: translateY(-2px);
          background: #dedde2;
        }

        /* =====================================================
           IMAGE
        ===================================================== */

        .manufacturing-hero-image-wrapper {
          position: relative;
          width: 100%;
          height: 470px;
          border-radius: 24px;
          overflow: hidden;
          background: #2a1a30;
          box-shadow: 0 24px 60px rgba(27, 27, 42, 0.14);
        }

        .manufacturing-hero-image {
          position: absolute;
          inset: 0;
          width: 100%;
          height: 100%;
          object-fit: cover;
          object-position: center;
          display: block;
        }

        .manufacturing-hero-image-overlay {
          position: absolute;
          inset: 0;
          background:
            linear-gradient(
              135deg,
              rgba(42, 26, 48, 0.20) 0%,
              rgba(74, 36, 64, 0.08) 45%,
              rgba(107, 42, 74, 0.20) 100%
            );
          pointer-events: none;
        }

        /* =====================================================
           IMAGE CENTER LABEL
        ===================================================== */

        .manufacturing-hero-image-caption {
          position: absolute;
          left: 50%;
          top: 50%;
          transform: translate(-50%, -50%);
          width: max-content;
          max-width: 80%;
          padding: 10px 16px;
          border-radius: 999px;
          background: rgba(20, 10, 20, 0.48);
          backdrop-filter: blur(8px);
          color: #ffffff;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 500;
          text-align: center;
          opacity: 0;
          transition: opacity 0.3s ease;
        }

        .manufacturing-hero-image-wrapper:hover
          .manufacturing-hero-image-caption {
          opacity: 1;
        }

        /* =====================================================
           IMAGE BOTTOM STATUS CARD
        ===================================================== */

        .manufacturing-hero-status {
          position: absolute;
          left: 14px;
          right: 14px;
          bottom: 14px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 14px;
          padding: 13px 15px;
          border-radius: 14px;
          background: rgba(20, 10, 20, 0.64);
          backdrop-filter: blur(12px);
          border: 1px solid rgba(255, 255, 255, 0.10);
        }

        .manufacturing-hero-status-content {
          min-width: 0;
          display: flex;
          align-items: center;
          gap: 9px;
        }

        .manufacturing-hero-status-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: #e05a8a;
          flex-shrink: 0;
          box-shadow: 0 0 10px rgba(224, 90, 138, 0.7);
        }

        .manufacturing-hero-status-text {
          margin: 0;
          color: #ffffff;
          font-family: "Inter", sans-serif;
          font-size: 10px;
          line-height: 1.5;
          font-weight: 700;
          letter-spacing: 0.07em;
        }

        .manufacturing-hero-status-icon {
          color: #e05a8a;
          flex-shrink: 0;
        }

        /* =====================================================
           LARGE TABLET
        ===================================================== */

        @media (max-width: 1200px) {
          .manufacturing-hero-container {
            padding: 68px 40px;
            gap: 48px;
          }

          .manufacturing-hero-heading {
            font-size: 46px;
          }

          .manufacturing-hero-description {
            font-size: 14px;
            line-height: 1.75;
          }

          .manufacturing-hero-image-wrapper {
            height: 440px;
          }
        }

        /* =====================================================
           TABLET
        ===================================================== */

        @media (max-width: 900px) {
          .manufacturing-hero-container {
            grid-template-columns: 1fr;
            gap: 42px;
            padding: 60px 40px;
          }

          .manufacturing-hero-content {
            max-width: 760px;
          }

          .manufacturing-hero-heading {
            max-width: 700px;
            font-size: 44px;
          }

          .manufacturing-hero-description {
            max-width: 720px;
            font-size: 15px;
          }

          .manufacturing-hero-image-wrapper {
            height: 440px;
            border-radius: 22px;
          }

          .manufacturing-hero-image-caption {
            opacity: 1;
          }
        }

        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 600px) {
          .manufacturing-hero-container {
            padding: 50px 24px;
            gap: 34px;
          }

          .manufacturing-hero-badge {
            margin-bottom: 18px;
            font-size: 10px;
            padding: 6px 11px;
          }

          .manufacturing-hero-heading {
            font-size: 34px;
            line-height: 1.15;
            letter-spacing: -0.025em;
            margin-bottom: 18px;
          }

          .manufacturing-hero-description {
            font-size: 14px;
            line-height: 1.75;
            margin-bottom: 25px;
          }

          .manufacturing-hero-actions {
            width: 100%;
            flex-direction: column;
            align-items: stretch;
          }

          .manufacturing-hero-primary,
          .manufacturing-hero-secondary {
            width: 100%;
            padding: 13px 18px;

            /* SAME RADIUS ON MOBILE */
            border-radius: 6px;
          }

          .manufacturing-hero-image-wrapper {
            height: 360px;
            border-radius: 18px;
          }

          .manufacturing-hero-image-caption {
            max-width: 88%;
            font-size: 11px;
            padding: 8px 12px;
          }

          .manufacturing-hero-status {
            left: 10px;
            right: 10px;
            bottom: 10px;
            padding: 11px 12px;
          }

          .manufacturing-hero-status-text {
            font-size: 8.5px;
          }
        }

        /* =====================================================
           SMALL MOBILE
        ===================================================== */

        @media (max-width: 400px) {
          .manufacturing-hero-container {
            padding: 42px 16px;
            gap: 28px;
          }

          .manufacturing-hero-heading {
            font-size: 30px;
          }

          .manufacturing-hero-description {
            font-size: 13px;
          }

          .manufacturing-hero-primary,
          .manufacturing-hero-secondary {
            border-radius: 6px;
          }

          .manufacturing-hero-image-wrapper {
            height: 310px;
          }

          .manufacturing-hero-status-icon {
            width: 14px;
            height: 14px;
          }
        }

        /* =====================================================
           VERY SMALL MOBILE
        ===================================================== */

        @media (max-width: 340px) {
          .manufacturing-hero-heading {
            font-size: 27px;
          }

          .manufacturing-hero-description {
            font-size: 12.5px;
          }

          .manufacturing-hero-primary,
          .manufacturing-hero-secondary {
            border-radius: 6px;
          }

          .manufacturing-hero-image-wrapper {
            height: 275px;
          }

          .manufacturing-hero-status-text {
            font-size: 7.5px;
          }
        }

        /* =====================================================
           ACCESSIBILITY
        ===================================================== */

        @media (prefers-reduced-motion: reduce) {
          .manufacturing-hero-primary,
          .manufacturing-hero-secondary,
          .manufacturing-hero-image-caption {
            transition: none;
          }
        }
      `}),a.jsx("section",{className:"manufacturing-hero",children:a.jsxs("div",{className:"manufacturing-hero-container",children:[a.jsxs("div",{className:"manufacturing-hero-content",children:[a.jsxs("span",{className:"manufacturing-hero-badge",children:[a.jsx("span",{className:"manufacturing-hero-badge-dot"}),"MANUFACTURING"]}),a.jsx("h1",{className:"manufacturing-hero-heading",children:"Technology Solutions for Modern Manufacturing"}),a.jsx("p",{className:"manufacturing-hero-description",children:"Manufacturing businesses depend on connected processes, reliable information and efficient supply chain operations. TechTorch Solutions provides technology solutions designed to help businesses connect important functions and manage their operations through a more organized digital environment."}),a.jsxs("div",{className:"manufacturing-hero-actions",children:[a.jsxs(t,{to:"/talk-to-expert",className:"manufacturing-hero-primary",children:["Talk to Our Experts",a.jsx(o,{size:16})]}),a.jsx("button",{className:"manufacturing-hero-secondary",onClick:()=>r("/manufacturing-get-in-touch"),children:"Get in Touch"})]})]}),a.jsxs("div",{className:"manufacturing-hero-image-wrapper",children:[a.jsx("img",{src:c,alt:"Modern manufacturing and smart factory operations",className:"manufacturing-hero-image"}),a.jsx("div",{className:"manufacturing-hero-image-overlay"}),a.jsx("div",{className:"manufacturing-hero-image-caption",children:"Engineers reviewing robotic assembly line"}),a.jsxs("div",{className:"manufacturing-hero-status",children:[a.jsxs("div",{className:"manufacturing-hero-status-content",children:[a.jsx("span",{className:"manufacturing-hero-status-dot"}),a.jsx("p",{className:"manufacturing-hero-status-text",children:"SMART FACTORY FABRIC · REAL-TIME TELEMETRY & FLOOR AUTOMATION"})]}),a.jsx(s,{size:17,className:"manufacturing-hero-status-icon"})]})]})]})})]})}export{d as default};
