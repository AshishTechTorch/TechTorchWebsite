import{j as e}from"./vendor-query-PraSc8EQ.js";import{L as s}from"./vendor-router-L4ZCoGSs.js";import{T as t}from"./index-37hjU4u5.js";function i(){return e.jsx("section",{className:"w-full overflow-hidden bg-white px-4 py-10 sm:px-6 sm:py-12 md:px-10 md:py-14 lg:px-[100px] lg:py-16 xl:py-20",children:e.jsx("div",{className:"w-full",children:e.jsxs("div",{className:"grid w-full grid-cols-1 gap-8 sm:gap-10 md:gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-center lg:gap-14 xl:gap-16",children:[e.jsxs("div",{className:"w-full min-w-0",children:[e.jsxs("span",{className:"inline-flex flex-wrap items-center gap-1.5 rounded-full bg-[#FBDCEA] px-3 py-1 text-[9px] font-semibold tracking-[0.1em] text-[#7A1443] sm:text-[10px]",style:{fontFamily:"'Inter', sans-serif"},children:[e.jsx("span",{className:"h-1.5 w-1.5 rounded-full bg-[#7A1443]"}),"TECHNOLOGY",e.jsx("span",{className:"h-1.5 w-1.5 rounded-full bg-[#7A1443]"}),"GROWTH",e.jsx("span",{className:"h-1.5 w-1.5 rounded-full bg-[#7A1443]"}),"POSSIBILITY"]}),e.jsx("h1",{className:"mt-7 w-full max-w-[500px] text-[23px] font-bold leading-[1.3] text-[#6B1E3F] sm:text-[27px] md:text-[30px] lg:text-[34px] xl:text-[38px]",style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Technology Should Grow With Your Business"}),e.jsx("p",{className:"mt-5 w-full max-w-xl text-[14px] font-semibold leading-[1.7] text-slate-900 sm:mt-6 sm:text-[15px] md:text-[16px]",style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Your business is growing. Your technology should grow with it."}),e.jsx("p",{className:"mt-4 w-full max-w-xl text-[13px] leading-[1.75] text-slate-600 sm:text-[14px] md:text-[15px] md:leading-[1.8]",style:{fontFamily:"'Inter', sans-serif"},children:"As your business evolves, so do your people, processes, customers, and challenges. The right technology helps you stay connected, work more efficiently, and make better decisions—without slowing down your next step."}),e.jsx("div",{className:"mt-6 w-full max-w-xl rounded-md bg-slate-50 px-4 py-3 sm:mt-7 sm:px-5 sm:py-4 md:px-6",children:e.jsx("p",{className:"text-[13px] leading-[1.7] text-slate-600 sm:text-[14px] md:text-[15px]",style:{fontFamily:"'Inter', sans-serif"},children:"TechTorch Solutions builds digital solutions that help businesses move forward with confidence."})}),e.jsxs(s,{to:"/talk-to-expert",className:`\r
    mt-6\r
    inline-flex\r
    w-fit\r
    items-center\r
    gap-2\r
    rounded-[6px]\r
    bg-[#730042]\r
    px-5\r
    py-3\r
    text-[11px]\r
    font-semibold\r
    tracking-wide\r
    text-white\r
    transition-all\r
    duration-300\r
    hover:-translate-y-0.5\r
    active:translate-y-0\r
    sm:mt-7\r
    sm:px-6\r
    sm:text-xs\r
    md:text-sm\r
  `,style:{fontFamily:"'Inter', sans-serif"},children:["TALK TO OUR EXPERTS",e.jsx("span",{"aria-hidden":"true",children:"→"})]})]}),e.jsx("div",{className:"w-full min-w-0 lg:ml-auto lg:max-w-[700px] xl:max-w-[760px]",children:e.jsxs("div",{className:"relative w-full overflow-hidden rounded-xl bg-slate-100 shadow-sm sm:rounded-2xl",children:[e.jsx("img",{src:"/DeploymentMethodology.webp",alt:"Executive briefing presentation",loading:"lazy",className:"block h-[300px] w-full object-cover object-center sm:h-[340px] md:h-[380px] lg:h-[400px] xl:h-[430px]"}),e.jsx("div",{className:"absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#5C1533]/90 via-[#5C1533]/35 to-transparent sm:h-28"}),e.jsx("div",{className:"absolute bottom-4 left-4 right-4 rounded-xl bg-white px-4 py-4 shadow-lg sm:bottom-5 sm:left-6 sm:right-6 sm:px-5 sm:py-4 md:left-7 md:right-7 md:px-6 md:py-5 lg:bottom-6 lg:left-8 lg:right-8 xl:left-10 xl:right-10",children:e.jsxs("div",{className:"flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between sm:gap-4",children:[e.jsxs("div",{className:"min-w-0",children:[e.jsx("span",{className:"block text-[9px] font-semibold tracking-[0.1em] text-[#7A1443] sm:text-[10px]",style:{fontFamily:"'Inter', sans-serif"},children:"STRATEGIC ARCHITECTURE"}),e.jsx("p",{className:"mt-1 text-[17px] font-bold leading-[1.3] text-slate-900 sm:text-[19px] md:text-[21px]",style:{fontFamily:"'Inter', sans-serif"},children:"Executive Briefing Q4"})]}),e.jsxs("span",{className:"inline-flex w-fit shrink-0 items-center gap-1.5 rounded-full bg-[#B8F5B0] px-3 py-1.5 text-[10px] font-medium text-[#225C28] sm:px-3.5 sm:py-2 sm:text-[11px]",style:{fontFamily:"'Inter', sans-serif"},children:[e.jsx(t,{size:13,strokeWidth:2}),"Active Metric"]})]})})]})})]})})})}export{i as default};
