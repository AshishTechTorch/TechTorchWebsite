import{j as e}from"./vendor-query-PraSc8EQ.js";import{L as n}from"./vendor-router-L4ZCoGSs.js";import{A as a,r as s}from"./index-37hjU4u5.js";import{S as p}from"./server-CVxnx5sL.js";import{C as t}from"./code-xml-CIX-EOu2.js";import{N as o}from"./network-BTjPWaa_.js";import{C as d}from"./cloud-C7BQ_lpB.js";import{A as c}from"./activity-DFDEKrG3.js";import{W as m}from"./wrench-BRbOSLaK.js";import{S as l}from"./settings-BNjID7h6.js";import{H as x}from"./headphones-B1SP7cCe.js";const S=()=>{const r=[{number:"01",category:"INFRASTRUCTURE CORE",title:"IT Infrastructure Support",icon:e.jsx(o,{}),description:"Maintain the systems and technology infrastructure your business relies on. Our support helps address infrastructure-related requirements and keeps essential operations resilient.",tag1:"Active Uptime",tag2:"Tier 1–3"},{number:"02",category:"APPLICATION LAYER",title:"Software Support & Maintenance",icon:e.jsx(t,{}),description:"Business applications require regular attention to remain reliable. We provide technical assistance, proactive troubleshooting, maintenance, and ongoing patch governance.",tag1:"App Health",tag2:"CI/CD Sync"},{number:"03",category:"HYBRID & MULTI-CLOUD",title:"Cloud Support",icon:e.jsx(d,{}),description:"As organizations adopt cloud technologies, effective management becomes critical. Our team provides dedicated support for cloud environments, tenant setups, and workload scale.",tag1:"Cloud Scaled",tag2:"AWS / Azure"},{number:"04",category:"PROACTIVE TELEMETRY",title:"System Monitoring & Maintenance",icon:e.jsx(c,{}),description:"Regular telemetry and automated health checks identify anomalies before they disrupt productivity, backing continuous operational stability around the clock.",tag1:"24/7 Observability",tag2:"Automated"},{number:"05",category:"RAPID RESOLUTION",title:"Technical Troubleshooting",icon:e.jsx(m,{}),description:"When an IT issue impacts operations, fast triage matters. Our experienced engineers isolate the root cause and execute decisive remedies with minimal downtime.",tag1:"Fast Triage",tag2:"Root Cause"},{number:"06",category:"THREAT DEFENSE",title:"IT Security Support",icon:e.jsx(s,{}),description:"Security is an essential consideration across modern applications and networks. Our support integrates security hygiene, identity controls, and access protection.",tag1:"Secure Access",tag2:"Protection"},{number:"07",category:"LIFECYCLE MANAGEMENT",title:"Updates & System Maintenance",icon:e.jsx(l,{}),description:"Keep environments current with structured change management, validated system patches, OS revisions, and routine maintenance without user disruption.",tag1:"Managed Updates",tag2:"Validated"},{number:"08",category:"HELPDESK & ADVISORY",title:"Ongoing IT Assistance",icon:e.jsx(x,{}),description:"Direct access to certified engineers whenever hurdles occur. Seamless escalation channels and dedicated account engineers ensure uninterrupted operations.",tag1:"Expert Access",tag2:"Always Available"}];return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`
        /* =========================================================
           GLOBAL
        ========================================================= */

        * {
          box-sizing: border-box;
        }

        html {
          scroll-behavior: smooth;
        }

        body {
          margin: 0;
          padding: 0;
          background: #f7f6f4;
          color: #242426;
          font-family: "Inter", Arial, Helvetica, sans-serif;
        }

        .msp-page {
          width: 100%;
          overflow: hidden;
          background: #f7f6f4;
        }

        .msp-page h1,
        .msp-page h2,
        .msp-page h3 {
          font-family: "Plus Jakarta Sans", Arial, Helvetica, sans-serif;
        }

        /* =========================================================
           COMMON
           Desktop = 100px
           Tablet  = 40px
           Mobile  = 24px
           Small   = 16px
        ========================================================= */

        .msp-container {
          width: 100%;
          padding-left: 100px;
          padding-right: 100px;
          margin: 0 auto;
        }

        .msp-section-label {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 6px 11px;
          border: 1px solid #dcc5d1;
          border-radius: 20px;
          background: #f0e7ec;
          color: #72003e;
          font-family: "Inter", Arial, sans-serif;
          font-size: 9px;
          font-weight: 800;
          letter-spacing: 0.8px;
          line-height: 1;
          text-transform: uppercase;
        }

        .msp-section-label::before {
          content: "";
          width: 5px;
          height: 5px;
          flex-shrink: 0;
          border-radius: 50%;
          background: #72003e;
        }

        /* =========================================================
           HERO
        ========================================================= */

        .msp-hero {
          width: 100%;
          background: #ffffff;
          padding: 80px 0 88px;
        }

        .msp-hero-inner {
          width: 100%;
          padding-left: 100px;
          padding-right: 100px;
          margin: 0 auto;
          display: grid;
          grid-template-columns: minmax(0, 1.04fr) minmax(420px, 0.78fr);
          gap: 65px;
          align-items: center;
        }

        .msp-hero-content {
          min-width: 0;
        }

        .msp-hero h1 {
          margin: 22px 0 8px;
          color: #222326;
          font-size: clamp(42px, 4.2vw, 60px);
          line-height: 1;
          letter-spacing: -3px;
          font-weight: 650;
        }

        .msp-hero-subtitle {
          margin: 0 0 20px;
          color: #69003c;
          font-size: clamp(21px, 2vw, 27px);
          line-height: 1.25;
          font-weight: 650;
          letter-spacing: -0.7px;
        }

        .msp-hero-description {
          max-width: 690px;
          margin: 0;
          color: #343438;
          font-family: "Inter", Arial, sans-serif;
          font-size: 14px;
          line-height: 1.7;
        }

        .msp-hero-description.secondary {
          margin-top: 14px;
          color: #71686d;
          font-size: 13px;
          line-height: 1.65;
        }

        .msp-primary-btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          margin-top: 27px;
          padding: 13px 24px;
          border: none;
          border-radius: 8px;
          background: #6d003d;
          color: #ffffff;
          font-family: "Inter", Arial, sans-serif;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.7px;
          text-transform: uppercase;
          cursor: pointer;
          transition:
            background 0.25s ease,
            transform 0.25s ease,
            box-shadow 0.25s ease;
        }

        .msp-primary-btn:hover {
          background: #8a0752;
          transform: translateY(-2px);
          box-shadow: 0 8px 20px rgba(109, 0, 61, 0.2);
        }

        .msp-hero-line {
          width: 100%;
          height: 1px;
          margin-top: 30px;
          background: #e5e2e2;
        }

        .msp-hero-points {
          display: flex;
          flex-wrap: wrap;
          align-items: center;
          gap: 9px 13px;
          margin-top: 18px;
        }

        .msp-hero-point {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 7px 11px;
          border-radius: 7px;
          background: #eeeeef;
          color: #424246;
          font-family: "Inter", Arial, sans-serif;
          font-size: 10px;
          font-weight: 600;
          letter-spacing: 0.25px;
        }

        .msp-hero-point::before {
          content: "";
          width: 5px;
          height: 5px;
          flex-shrink: 0;
          border-radius: 50%;
          background: #72003e;
        }

        /* =========================================================
           HERO IMAGE
        ========================================================= */

        .msp-hero-image-area {
          position: relative;
          width: 100%;
        }

        .msp-hero-image-wrapper {
          position: relative;
          width: 100%;
          aspect-ratio: 1.12 / 1;
          overflow: hidden;
          border-radius: 17px;
          background: #420026;
          box-shadow: 0 18px 35px rgba(42, 19, 30, 0.16);
        }

        .msp-hero-image-wrapper img {
          display: block;
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .msp-health-badge {
          position: absolute;
          top: 16px;
          right: 16px;
          display: flex;
          align-items: center;
          gap: 7px;
          padding: 8px 13px;
          border-radius: 20px;
          background: rgba(255, 255, 255, 0.95);
          color: #36363a;
          font-family: "Inter", Arial, sans-serif;
          font-size: 10px;
          font-weight: 700;
          box-shadow: 0 5px 16px rgba(0, 0, 0, 0.12);
        }

        .msp-health-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: #14b875;
        }

        .msp-hero-image-card {
          position: absolute;
          left: 20px;
          right: 20px;
          bottom: 20px;
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 14px 17px;
          border-radius: 14px;
          background: rgba(255, 255, 255, 0.96);
          box-shadow: 0 8px 22px rgba(0, 0, 0, 0.13);
        }

        .msp-image-card-icon {
          width: 39px;
          height: 39px;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 9px;
          background: #70003f;
          color: #ffffff;
        }

        .msp-image-card-content {
          min-width: 0;
        }

        .msp-image-card-title {
          margin: 0;
          color: #2c2c30;
          font-family: "Inter", Arial, sans-serif;
          font-size: 12px;
          line-height: 1.35;
          font-weight: 800;
        }

        .msp-image-card-text {
          margin: 3px 0 0;
          color: #827a7f;
          font-family: "Inter", Arial, sans-serif;
          font-size: 9px;
          line-height: 1.35;
        }

        .msp-image-card-shield {
          margin-left: auto;
          width: 31px;
          height: 31px;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          background: #eee9ed;
          color: #70003f;
        }

        /* =========================================================
           OPERATIONAL RESILIENCE
        ========================================================= */

        .msp-resilience {
          width: 100%;
          padding: 105px 100px 95px;
          background: #f8f7f2;
        }

        .msp-resilience-inner {
          width: 100%;
          margin: 0 auto;
          display: grid;
          grid-template-columns: minmax(380px, 0.8fr) minmax(0, 1.12fr);
          gap: 75px;
          align-items: center;
        }

        .msp-resilience-image {
          position: relative;
          width: 100%;
        }

        .msp-resilience-image-frame {
          width: 100%;
          aspect-ratio: 1.12 / 0.84;
          padding: 10px;
          border-radius: 18px;
          background: #eeeeeb;
          box-shadow: 0 10px 20px rgba(35, 27, 31, 0.1);
        }

        .msp-resilience-image-frame img {
          width: 100%;
          height: 100%;
          display: block;
          object-fit: cover;
          border-radius: 12px;
        }

        .msp-embedded-badge {
          position: absolute;
          top: 22px;
          left: 22px;
          display: flex;
          align-items: center;
          gap: 7px;
          padding: 9px 13px;
          border-radius: 9px;
          background: rgba(255, 255, 255, 0.96);
          color: #37373b;
          font-family: "Inter", Arial, sans-serif;
          font-size: 9px;
          font-weight: 800;
          letter-spacing: 0.35px;
        }

        .msp-embedded-badge svg {
          color: #72003e;
        }

        .msp-resilience-content {
          min-width: 0;
        }

        .msp-resilience-content h2 {
          margin: 19px 0 20px;
          max-width: 700px;
          color: #252529;
          font-size: clamp(32px, 3vw, 43px);
          line-height: 1.08;
          letter-spacing: -2px;
          font-weight: 650;
        }

        .msp-body-text {
          margin: 0;
          color: #776c71;
          font-family: "Inter", Arial, sans-serif;
          font-size: 13.5px;
          line-height: 1.7;
        }

        .msp-highlight {
          position: relative;
          margin: 22px 0;
          padding: 18px 22px;
          overflow: hidden;
          border-radius: 11px;
          background: #eeeeef;
        }

        .msp-highlight::after {
          content: "";
          position: absolute;
          width: 150px;
          height: 150px;
          right: -45px;
          top: -70px;
          border-radius: 50%;
          background: #e5e0e3;
        }

        .msp-highlight::before {
          content: "";
          position: absolute;
          left: 0;
          top: 0;
          bottom: 0;
          width: 3px;
          background: #72003e;
          z-index: 2;
        }

        .msp-highlight p {
          position: relative;
          z-index: 3;
          margin: 0;
          color: #29292d;
          font-family: "Inter", Arial, sans-serif;
          font-size: 13.5px;
          line-height: 1.6;
          font-weight: 600;
        }

        .msp-body-text + .msp-body-text {
          margin-top: 17px;
        }

        .msp-bottom-highlight {
          margin-top: 21px;
          padding: 17px 19px;
          border-radius: 10px;
          background: #e9eaeb;
        }

        .msp-bottom-highlight p {
          margin: 0;
          color: #303035;
          font-family: "Inter", Arial, sans-serif;
          font-size: 12.5px;
          line-height: 1.6;
          font-weight: 500;
        }

        /* =========================================================
           SERVICES
        ========================================================= */

        .msp-services {
          width: 100%;
          padding: 82px 0 105px;
          background: #ffffff;
        }

        .msp-services-header {
          margin-bottom: 40px;
        }

        .msp-services-header h2 {
          margin: 13px 0 9px;
          color: #28282c;
          font-size: clamp(32px, 3vw, 43px);
          line-height: 1.1;
          letter-spacing: -1.8px;
          font-weight: 650;
        }

        .msp-services-header p {
          max-width: 760px;
          margin: 0;
          color: #746b70;
          font-family: "Inter", Arial, sans-serif;
          font-size: 13.5px;
          line-height: 1.6;
        }

        .msp-services-grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 18px;
        }

        .msp-service-card {
          position: relative;
          min-width: 0;
          min-height: 330px;
          padding: 24px 23px 18px;
          overflow: hidden;
          border: 1px solid #ebe5e8;
          border-radius: 13px;
          background: #ffffff;
          box-shadow: 0 2px 4px rgba(31, 18, 24, 0.02);
          transition:
            transform 0.25s ease,
            border-color 0.25s ease,
            box-shadow 0.25s ease;
        }

        .msp-service-card::after {
          content: "";
          position: absolute;
          top: -50px;
          right: -50px;
          width: 120px;
          height: 120px;
          border-radius: 50%;
          background: #f5f1f3;
          z-index: 0;
          transition: transform 0.3s ease;
        }

        .msp-service-card:hover {
          transform: translateY(-5px);
          border-color: #d9bdcb;
          box-shadow: 0 12px 28px rgba(75, 15, 45, 0.08);
        }

        .msp-service-card:hover::after {
          transform: scale(1.2);
        }

        .msp-service-top {
          position: relative;
          z-index: 2;
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 24px;
        }

        .msp-service-icon {
          width: 37px;
          height: 37px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 9px;
          background: #f1e8ed;
          color: #72003e;
        }

        .msp-service-icon svg {
          width: 18px;
          height: 18px;
        }

        .msp-service-number {
          width: 27px;
          height: 27px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          background: #efeaed;
          color: #72003e;
          font-family: "Inter", Arial, sans-serif;
          font-size: 10px;
          font-weight: 700;
        }

        .msp-service-category {
          position: relative;
          z-index: 2;
          margin-bottom: 7px;
          color: #72003e;
          font-family: "Inter", Arial, sans-serif;
          font-size: 9px;
          line-height: 1.2;
          font-weight: 800;
          letter-spacing: 0.45px;
        }

        .msp-service-card h3 {
          position: relative;
          z-index: 2;
          margin: 0;
          min-height: 43px;
          color: #27272b;
          font-size: 17px;
          line-height: 1.18;
          letter-spacing: -0.45px;
          font-weight: 700;
        }

        .msp-service-description {
          position: relative;
          z-index: 2;
          margin: 14px 0 0;
          color: #746b70;
          font-family: "Inter", Arial, sans-serif;
          font-size: 12.5px;
          line-height: 1.65;
        }

        .msp-service-footer {
          position: absolute;
          left: 23px;
          right: 23px;
          bottom: 18px;
          z-index: 2;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
          padding-top: 15px;
          border-top: 1px solid #eee9eb;
        }

        .msp-service-tag-primary {
          display: flex;
          align-items: center;
          gap: 5px;
          color: #72003e;
          font-family: "Inter", Arial, sans-serif;
          font-size: 9px;
          font-weight: 700;
          white-space: nowrap;
        }

        .msp-service-tag-primary::before {
          content: "";
          width: 5px;
          height: 5px;
          flex-shrink: 0;
          border-radius: 50%;
          background: #72003e;
        }

        .msp-service-tag-secondary {
          padding: 4px 7px;
          border-radius: 4px;
          background: #ededee;
          color: #777177;
          font-family: "Inter", Arial, sans-serif;
          font-size: 8.5px;
          font-weight: 700;
          white-space: nowrap;
        }

        /* =========================================================
           RESPONSIVE - LARGE TABLET
        ========================================================= */

        @media (max-width: 1200px) {
          .msp-container,
          .msp-hero-inner {
            padding-left: 40px;
            padding-right: 40px;
          }

          .msp-resilience {
            padding-left: 40px;
            padding-right: 40px;
          }

          .msp-hero-inner {
            grid-template-columns: minmax(0, 1fr) minmax(360px, 0.8fr);
            gap: 42px;
          }

          .msp-resilience-inner {
            gap: 45px;
          }

          .msp-services-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }
        }

        /* =========================================================
           TABLET
        ========================================================= */

        @media (max-width: 900px) {
          .msp-hero {
            padding: 62px 0 70px;
          }

          .msp-hero-inner {
            grid-template-columns: 1fr;
            gap: 45px;
          }

          .msp-hero-content {
            max-width: 760px;
          }

          .msp-hero-image-area {
            width: min(100%, 680px);
            margin: 0 auto;
          }

          .msp-resilience {
            padding-top: 78px;
            padding-bottom: 78px;
          }

          .msp-resilience-inner {
            grid-template-columns: 1fr;
            gap: 45px;
          }

          .msp-resilience-image {
            width: min(100%, 680px);
            margin: 0 auto;
          }

          .msp-resilience-content {
            max-width: 780px;
          }

          .msp-services {
            padding-top: 68px;
            padding-bottom: 82px;
          }
        }

        /* =========================================================
           MOBILE - 24px
        ========================================================= */

        @media (max-width: 700px) {
          .msp-container,
          .msp-hero-inner {
            padding-left: 24px;
            padding-right: 24px;
          }

          .msp-resilience {
            padding-left: 24px;
            padding-right: 24px;
          }

          .msp-hero {
            padding-top: 45px;
            padding-bottom: 55px;
          }

          .msp-section-label {
            padding: 6px 9px;
            font-size: 8px;
            letter-spacing: 0.65px;
          }

          .msp-hero h1 {
            margin-top: 18px;
            font-size: 42px;
            line-height: 1;
            letter-spacing: -2px;
          }

          .msp-hero-subtitle {
            margin-bottom: 17px;
            font-size: 19px;
            line-height: 1.3;
            letter-spacing: -0.4px;
          }

          .msp-hero-description {
            font-size: 12.5px;
            line-height: 1.65;
          }

          .msp-hero-description.secondary {
            font-size: 12px;
          }

          .msp-primary-btn {
            width: 100%;
            margin-top: 22px;
            min-height: 43px;
          }

          .msp-hero-points {
            gap: 7px;
          }

          .msp-hero-point {
            font-size: 9px;
            padding: 6px 9px;
          }

          .msp-hero-image-wrapper {
            aspect-ratio: 1 / 0.92;
            border-radius: 13px;
          }

          .msp-health-badge {
            top: 11px;
            right: 11px;
            padding: 7px 10px;
            font-size: 8.5px;
          }

          .msp-hero-image-card {
            left: 12px;
            right: 12px;
            bottom: 12px;
            padding: 11px;
            gap: 9px;
          }

          .msp-image-card-icon {
            width: 34px;
            height: 34px;
          }

          .msp-image-card-title {
            font-size: 10px;
          }

          .msp-image-card-text {
            font-size: 8px;
          }

          .msp-image-card-shield {
            width: 27px;
            height: 27px;
          }

          .msp-resilience {
            padding-top: 62px;
            padding-bottom: 65px;
          }

          .msp-resilience-inner {
            gap: 38px;
          }

          .msp-resilience-image-frame {
            padding: 7px;
            border-radius: 13px;
          }

          .msp-embedded-badge {
            top: 16px;
            left: 16px;
            padding: 7px 9px;
            font-size: 8px;
          }

          .msp-resilience-content h2 {
            margin: 17px 0;
            font-size: 33px;
            line-height: 1.1;
            letter-spacing: -1.4px;
          }

          .msp-body-text {
            font-size: 12px;
            line-height: 1.68;
          }

          .msp-highlight {
            margin: 18px 0;
            padding: 15px 17px;
          }

          .msp-highlight p {
            font-size: 12.5px;
          }

          .msp-bottom-highlight {
            padding: 14px 15px;
          }

          .msp-bottom-highlight p {
            font-size: 11px;
          }

          .msp-services {
            padding-top: 58px;
            padding-bottom: 70px;
          }

          .msp-services-header {
            margin-bottom: 29px;
          }

          .msp-services-header h2 {
            font-size: 31px;
            letter-spacing: -1.2px;
          }

          .msp-services-header p {
            font-size: 12px;
            line-height: 1.6;
          }

          .msp-services-grid {
            grid-template-columns: 1fr;
            gap: 13px;
          }

          .msp-service-card {
            min-height: 300px;
            padding: 21px 19px 18px;
          }

          .msp-service-card h3 {
            font-size: 17px;
          }

          .msp-service-description {
            font-size: 12px;
            line-height: 1.62;
          }

          .msp-service-footer {
            left: 19px;
            right: 19px;
          }
        }

        /* =========================================================
           SMALL MOBILE - 16px
        ========================================================= */

        @media (max-width: 480px) {
          .msp-container,
          .msp-hero-inner {
            padding-left: 16px;
            padding-right: 16px;
          }

          .msp-resilience {
            padding-left: 16px;
            padding-right: 16px;
          }

          .msp-hero {
            padding-top: 38px;
            padding-bottom: 48px;
          }

          .msp-hero h1 {
            font-size: 36px;
            letter-spacing: -1.7px;
          }

          .msp-hero-subtitle {
            font-size: 17px;
          }

          .msp-hero-description {
            font-size: 12px;
          }

          .msp-hero-description.secondary {
            font-size: 11.5px;
          }

          .msp-hero-points {
            flex-direction: column;
            align-items: flex-start;
          }

          .msp-hero-point {
            width: fit-content;
          }

          .msp-hero-image-wrapper {
            aspect-ratio: 1 / 1;
          }

          .msp-health-badge {
            font-size: 8px;
          }

          .msp-image-card-title {
            font-size: 9px;
          }

          .msp-image-card-text {
            font-size: 7.5px;
          }

          .msp-resilience {
            padding-top: 52px;
            padding-bottom: 58px;
          }

          .msp-resilience-content h2 {
            font-size: 29px;
            letter-spacing: -1.1px;
          }

          .msp-body-text {
            font-size: 11.5px;
          }

          .msp-highlight p {
            font-size: 11.5px;
          }

          .msp-services {
            padding-top: 50px;
            padding-bottom: 60px;
          }

          .msp-services-header h2 {
            font-size: 28px;
          }

          .msp-services-header p {
            font-size: 11.5px;
          }

          .msp-service-card {
            min-height: 305px;
            padding-left: 17px;
            padding-right: 17px;
          }

          .msp-service-description {
            font-size: 11.5px;
          }

          .msp-service-footer {
            left: 17px;
            right: 17px;
          }
        }

        /* =========================================================
           EXTRA SMALL
        ========================================================= */

        @media (max-width: 360px) {
          .msp-hero h1 {
            font-size: 32px;
          }

          .msp-hero-subtitle {
            font-size: 16px;
          }

          .msp-resilience-content h2 {
            font-size: 27px;
          }

          .msp-services-header h2 {
            font-size: 26px;
          }

          .msp-service-card {
            min-height: 315px;
          }

          .msp-service-description {
            font-size: 11px;
          }
        }
      `}),e.jsxs("main",{className:"msp-page",children:[e.jsx("section",{className:"msp-hero",children:e.jsxs("div",{className:"msp-hero-inner",children:[e.jsxs("div",{className:"msp-hero-content",children:[e.jsx("div",{className:"msp-section-label",children:"IT Augmentation • Managed Services"}),e.jsx("h1",{children:"MSP Support"}),e.jsx("h2",{className:"msp-hero-subtitle",children:"Reliable IT Support for Business Continuity"}),e.jsx("p",{className:"msp-hero-description",children:"Your business depends on technology that works reliably, securely, and efficiently. TechTorch MSP Support provides structured IT assistance, proactive maintenance, and ongoing technical support to help organizations manage their technology environment with greater confidence."}),e.jsx("p",{className:"msp-hero-description secondary",children:"From infrastructure and software support to cloud and day-to-day technical assistance, we help keep your IT operations aligned with your business requirements."}),e.jsxs(n,{to:"/talk-to-expert",className:"msp-primary-btn",children:["Talk to Our Experts",e.jsx(a,{size:15})]}),e.jsx("div",{className:"msp-hero-line"}),e.jsxs("div",{className:"msp-hero-points",children:[e.jsx("div",{className:"msp-hero-point",children:"Proactive Maintenance"}),e.jsx("div",{className:"msp-hero-point",children:"24/7 Operations Coverage"}),e.jsx("div",{className:"msp-hero-point",children:"Enterprise SLA Support"})]})]}),e.jsx("div",{className:"msp-hero-image-area",children:e.jsxs("div",{className:"msp-hero-image-wrapper",children:[e.jsx("img",{loading:"lazy",decoding:"async",src:"/MSPSupport1.webp",alt:"MSP Support operations team"}),e.jsxs("div",{className:"msp-health-badge",children:[e.jsx("span",{className:"msp-health-dot"}),"99.98% Telemetry Health"]}),e.jsxs("div",{className:"msp-hero-image-card",children:[e.jsx("div",{className:"msp-image-card-icon",children:e.jsx(p,{size:20})}),e.jsxs("div",{className:"msp-image-card-content",children:[e.jsx("p",{className:"msp-image-card-title",children:"IT Operations & Infrastructure Reliability"}),e.jsx("p",{className:"msp-image-card-text",children:"Real-time Telemetry & Rapid Incident Triage"})]}),e.jsx("div",{className:"msp-image-card-shield",children:e.jsx(s,{size:16})})]})]})})]})}),e.jsx("section",{className:"msp-resilience",children:e.jsxs("div",{className:"msp-resilience-inner",children:[e.jsxs("div",{className:"msp-resilience-image",children:[e.jsx("div",{className:"msp-resilience-image-frame",children:e.jsx("img",{loading:"lazy",decoding:"async",src:"/MSPSupport2.webp",alt:"IT support team collaboration"})}),e.jsxs("div",{className:"msp-embedded-badge",children:[e.jsx(t,{size:13}),"EMBEDDED ENGINEERING"]})]}),e.jsxs("div",{className:"msp-resilience-content",children:[e.jsx("div",{className:"msp-section-label",children:"Operational Resilience"}),e.jsx("h2",{children:"Smarter IT Management. Dependable Support."}),e.jsx("p",{className:"msp-body-text",children:"As businesses become increasingly dependent on digital systems, managing IT effectively has become an important part of everyday operations. Technical issues, system maintenance, software requirements, infrastructure changes, and evolving business needs can all place additional pressure on internal teams."}),e.jsx("div",{className:"msp-highlight",children:e.jsx("p",{children:"TechTorch MSP Support delivers rigorous, proactive infrastructure governance tailored to high-availability enterprise environments."})}),e.jsx("p",{className:"msp-body-text",children:"Our services are designed to give businesses access to ongoing technical expertise without making IT management unnecessarily complicated. We work around your existing technology environment, understand your operational requirements, and provide support that is aligned with the way your organization works."}),e.jsx("p",{className:"msp-body-text",children:"Our focus extends beyond simply resolving technical problems. Through ongoing support and maintenance, we help businesses maintain their technology environment, address issues efficiently, and prepare their IT operations for changing requirements."}),e.jsx("div",{className:"msp-bottom-highlight",children:e.jsx("p",{children:"Whether your organization needs assistance with infrastructure, software, cloud environments, system maintenance, or technical troubleshooting, our MSP Support services provide a dependable foundation for everyday IT operations."})})]})]})}),e.jsx("section",{className:"msp-services",children:e.jsxs("div",{className:"msp-container",children:[e.jsxs("div",{className:"msp-services-header",children:[e.jsx("div",{className:"msp-section-label",children:"Service Capabilities"}),e.jsx("h2",{children:"Our MSP Support Services"}),e.jsx("p",{children:"Comprehensive, structured support components designed to preserve uptime, protect critical assets, and provide clear operational answers."})]}),e.jsx("div",{className:"msp-services-grid",children:r.map(i=>e.jsxs("article",{className:"msp-service-card",children:[e.jsxs("div",{className:"msp-service-top",children:[e.jsx("div",{className:"msp-service-icon",children:i.icon}),e.jsx("div",{className:"msp-service-number",children:i.number})]}),e.jsx("div",{className:"msp-service-category",children:i.category}),e.jsx("h3",{children:i.title}),e.jsx("p",{className:"msp-service-description",children:i.description}),e.jsxs("div",{className:"msp-service-footer",children:[e.jsx("div",{className:"msp-service-tag-primary",children:i.tag1}),e.jsx("div",{className:"msp-service-tag-secondary",children:i.tag2})]})]},i.number))})]})})]})]})};export{S as default};
