import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as a,L as v}from"./vendor-router-L4ZCoGSs.js";import{A as y}from"./arrow-up-right-DIePtCQ0.js";import{P as b}from"./phone-D3JbSBfc.js";import{t as E,K as w,I as T,r as I,A as C}from"./index-37hjU4u5.js";import{M as j}from"./mail-CbeZpzUl.js";import{C as S}from"./chevron-left-IInL7UPY.js";import{T as L}from"./target-BdO2Z0xV.js";import{B as W}from"./brain-circuit-BYwXIQof.js";import{C as z}from"./cloud-C7BQ_lpB.js";import{I as A}from"./id-card-C3-s-mU4.js";import{S as M}from"./settings-2-D0_FofoO.js";const k={name:"folder-kanban",size:24,node:[["path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z",key:"1fr9dc"}],["path",{d:"M8 10v4",key:"tgpxqk"}],["path",{d:"M12 10v2",key:"hh53o1"}],["path",{d:"M16 10v6",key:"1d6xys"}]]};k.node;const O=E(k);function R(){const[o,t]=a.useState(!1),d=a.useRef(null),s=a.useRef(null),c=()=>{s.current&&clearTimeout(s.current),t(!0)},x=()=>{s.current=setTimeout(()=>{t(!1)},400)};a.useEffect(()=>{const r=i=>{d.current&&!d.current.contains(i.target)&&t(!1)},l=i=>{i.key==="Escape"&&t(!1)};return document.addEventListener("mousedown",r),document.addEventListener("keydown",l),()=>{document.removeEventListener("mousedown",r),document.removeEventListener("keydown",l),s.current&&clearTimeout(s.current)}},[]);const p=[{label:"Call Us",Icon:b,href:"tel:+915813500381"},{label:"WhatsApp",Icon:w,href:"https://wa.me/91XXXXXXXXXX?text=Hi%2C%20I%27d%20like%20to%20know%20more%20about%20your%20technology%20solutions.",external:!0},{label:"Email Us",Icon:j,href:"https://mail.google.com/mail/?view=cm&fs=1&to=contact@techtorch.solutions&su=Technology%20Services%20Enquiry",external:!0}];return e.jsx("section",{className:"relative w-full overflow-hidden",children:e.jsxs("div",{className:`\r
          relative\r
          h-[330px]\r
          w-full\r
          sm:h-[360px]\r
          md:h-[390px]\r
          lg:h-[450px]\r
          xl:h-[480px]\r
        `,children:[e.jsx("img",{loading:"lazy",decoding:"async",src:"/Slide4.1.webp",alt:"Technology moving business forward",className:"absolute inset-0 h-full w-full object-cover object-center"}),e.jsx("div",{className:"absolute inset-0 bg-black/10"}),e.jsx("div",{className:`\r
            absolute inset-0 w-full\r
            px-4 sm:px-6 md:px-10 lg:px-[100px]\r
          `,children:e.jsxs("div",{className:`\r
              flex h-full max-w-[590px]\r
              flex-col justify-center\r
              -translate-y-3\r
              sm:-translate-y-4\r
              md:-translate-y-5\r
            `,children:[e.jsxs("h1",{className:`\r
                font-['Plus_Jakarta_Sans']\r
                text-[22px] font-medium\r
                leading-[1.08] tracking-[-0.7px] text-white\r
                min-[400px]:text-[24px]\r
                sm:text-[27px]\r
                md:text-[30px]\r
                lg:text-[34px]\r
                xl:text-[35px]\r
              `,children:["Technology That Moves Your",e.jsx("br",{className:"hidden sm:block"}),"Business Forward"]}),e.jsx("p",{className:`\r
                mt-2 max-w-[560px]\r
                font-['Inter'] text-[11px]\r
                font-light leading-[1.4] text-white\r
                sm:mt-3 sm:text-[12px]\r
                md:text-[13px] lg:text-[14px]\r
              `,children:"We help businesses use technology to work smarter, solve complex challenges and prepare for what comes next. From software and cloud to AI and cybersecurity, our solutions are built around your business needs."}),e.jsx("div",{className:"mt-5 sm:mt-6 md:mt-7 translate-y-2",children:e.jsxs("div",{ref:d,className:"relative inline-block",onMouseEnter:c,onMouseLeave:x,children:[e.jsxs(v,{to:"/talk-to-expert",className:`\r
                    group inline-flex items-center gap-2\r
                    rounded-[5px] border border-white\r
                    bg-transparent\r
                    !px-[12px] !py-[8px]\r
                    font-['Inter'] text-[12px]\r
                    font-medium leading-none text-white\r
                    transition-all duration-300\r
                    hover:bg-white hover:text-[#22091f]\r
                    sm:text-[13px]\r
                    md:!px-[14px] md:!py-[9px] md:text-[14px]\r
                  `,children:[e.jsx("span",{children:"Talk to Our Experts"}),e.jsx(y,{size:16,strokeWidth:1.8,className:`\r
                      shrink-0\r
                      transition-transform duration-300\r
                      group-hover:translate-x-1\r
                      group-hover:-translate-y-1\r
                    `})]}),e.jsx("div",{className:`
                    absolute
                    left-full
                    top-1/2
                    ml-2
                    flex
                    -translate-y-1/2
                    items-center
                    gap-2
                    transition-all
                    duration-300
                    ${o?"visible opacity-100":"invisible opacity-0 pointer-events-none"}
                  `,"aria-hidden":!o,children:p.map(({label:r,Icon:l,href:i,external:n})=>e.jsx("a",{href:i,title:r,"aria-label":r,target:n?"_blank":void 0,rel:n?"noopener noreferrer":void 0,tabIndex:o?0:-1,onClick:()=>t(!1),className:`\r
                          flex\r
                          h-10 w-10\r
                          sm:h-11 sm:w-11\r
                          shrink-0\r
                          items-center justify-center\r
                          rounded-full\r
                          border border-white/50\r
                          bg-black/80\r
                          text-white\r
                          backdrop-blur-md\r
                          transition-all duration-300\r
                          hover:scale-110\r
                          hover:border-[#730042]\r
                          hover:bg-[#730042]\r
                        `,children:e.jsx(l,{size:18})},r))})]})})]})})]})})}function X(){return e.jsx("section",{className:"w-full bg-[#faf9f4]",children:e.jsxs("div",{className:`\r
          w-full\r
\r
          px-4\r
          py-8\r
\r
          sm:px-6\r
          sm:py-9\r
\r
          md:px-10\r
          md:py-10\r
\r
          lg:px-[100px]\r
          lg:py-11\r
\r
          xl:py-12\r
        `,children:[e.jsxs("h2",{className:`\r
            max-w-[650px]\r
            font-['Plus_Jakarta_Sans']\r
            text-[28px]\r
            font-medium\r
            leading-[1.08]\r
            tracking-[-1.2px]\r
            text-[#111111]\r
\r
            min-[400px]:text-[30px]\r
\r
            sm:text-[34px]\r
            sm:tracking-[-1.3px]\r
\r
            md:text-[38px]\r
            md:tracking-[-1.5px]\r
\r
            lg:text-[42px]\r
            lg:tracking-[-1.7px]\r
\r
            xl:text-[34px]\r
          `,children:[e.jsx("span",{className:"text-[#730042]",children:"Technology"})," That Works",e.jsx("br",{}),"for Your Business"]}),e.jsxs("div",{className:`\r
            mt-8\r
            grid\r
            grid-cols-1\r
            gap-x-12\r
            gap-y-7\r
\r
            min-[400px]:gap-y-8\r
\r
            sm:mt-9\r
            sm:gap-y-8\r
\r
            md:mt-10\r
            md:gap-y-9\r
\r
            lg:grid-cols-2\r
            lg:gap-x-16\r
            lg:gap-y-10\r
\r
            xl:gap-x-20\r
          `,children:[e.jsxs("div",{className:`\r
              w-full\r
              max-w-[610px]\r
              font-['Inter']\r
              text-[15px]\r
              font-normal\r
              leading-[1.5]\r
              text-[#333333]\r
\r
              sm:text-[15px]\r
\r
              md:text-[16px]\r
\r
              lg:text-[15px]\r
              lg:leading-[1.5]\r
            `,children:[e.jsx("p",{children:"Technology is most effective when it solves a real business need."}),e.jsx("p",{className:"mt-6 sm:mt-7 lg:mt-8",children:"At TechTorch Solutions, we bring together technology expertise, engineering capabilities and business understanding to help organizations improve the way they operate, modernize their systems and respond to changing business needs."}),e.jsx("p",{className:"mt-6 sm:mt-7 lg:mt-8",children:"Our technology services cover the areas businesses rely on to build and maintain a modern digital environment—from IT consulting and AI to cloud infrastructure, cybersecurity and software engineering. We also provide software development and support, and skilled technology resources to help businesses strengthen both their technology and their teams."})]}),e.jsxs("div",{className:`\r
              w-full\r
              max-w-[560px]\r
\r
              lg:translate-x-12\r
              xl:translate-x-16\r
\r
              font-['Inter']\r
              text-[14px]\r
              font-normal\r
              leading-[1.5]\r
              text-[#333333]\r
\r
              sm:text-[15px]\r
\r
              md:text-[16px]\r
\r
              lg:text-[15px]\r
              lg:leading-[1.5]\r
            `,children:[e.jsx("p",{children:"Whether you are looking to improve an existing system, develop a new solution, move to the cloud or bring additional technical expertise into your organization, we focus on understanding your requirements first and then building a solution that is practical, reliable and ready to grow with your business."}),e.jsx("p",{className:"mt-10 sm:mt-11 lg:mt-12",children:"Our approach is simple: understand the challenge, find the right technology and build a solution that delivers lasting value. With the right combination of people, expertise and technology, we help businesses move forward with greater confidence."})]})]})]})})}const m="#7a1338",_="#f7f4ef",h=[{id:"it-consultancy",icon:L,title:"IT Consultancy",description:"We help you assess your technology, identify opportunities and create a clear direction aligned with your business goals.",cta:"Explore IT Consultancy"},{id:"ai",icon:W,title:"Artificial Intelligence",description:"We help businesses apply AI to automate processes, improve insights and create smarter ways of working.",cta:"Explore AI Services"},{id:"cloud",icon:z,title:"Cloud Infrastructure",description:"We build and modernize cloud environments that improve flexibility, reliability, performance and scalability.",cta:"Explore Cloud Services"},{id:"staffing",icon:A,title:"Resource & Staffing",description:"We provide skilled technology professionals and flexible resources to support projects and evolving business requirements.",cta:"Explore Staffing Services"},{id:"software-dev-support",icon:O,title:"Software Development & Support",description:"We develop, maintain and improve software to keep your systems reliable and ready for changing needs.",cta:"Explore Software Development"},{id:"software-engineering",icon:M,title:"Software Engineering",description:"We design and develop reliable software solutions around your business requirements.",cta:"Explore Software Engineering"},{id:"cybersecurity",icon:I,title:"Cybersecurity",description:"We help businesses strengthen security, reduce risk and protect critical systems and information.",cta:"Explore Cybersecurity"}],P=3,u=280,g=37,f=P*(u+g),B=h.length*u+(h.length-1)*g;function H(){const[o,t]=a.useState(0),[d,s]=a.useState(0),c=a.useRef(null);a.useEffect(()=>{const n=()=>{c.current&&s(c.current.offsetWidth)};return n(),window.addEventListener("resize",n),()=>window.removeEventListener("resize",n)},[]);const x=Math.max(0,B-d),p=x>0?Math.ceil(x/f):0,r=Math.min(o*f,x),l=()=>{t(n=>Math.max(0,n-1))},i=()=>{t(n=>Math.min(p,n+1))};return e.jsxs("section",{className:"technology-services-section",children:[e.jsxs("div",{className:"technology-services-container",children:[e.jsxs("div",{className:"services-header",children:[e.jsxs("div",{className:"services-header-content",children:[e.jsx("h2",{children:"OUR TECHNOLOGY SERVICES"}),e.jsx("p",{children:"We provide practical technology services that help businesses modernize, improve efficiency and solve complex challenges. From software and cloud to AI, cybersecurity and technical expertise, our solutions are built around your business needs."})]}),e.jsxs("div",{className:"slider-controls",children:[e.jsx("button",{onClick:l,disabled:o===0,className:"slider-control","aria-label":"Previous cards",children:e.jsx(S,{size:19})}),e.jsx("button",{onClick:i,disabled:o>=p,className:"slider-control","aria-label":"Next cards",children:e.jsx(T,{size:19})})]})]}),e.jsx("div",{className:"cards-viewport",ref:c,children:e.jsx("div",{className:"cards-track",style:{transform:`translateX(-${r}px)`},children:h.map(n=>{const N=n.icon;return e.jsxs("div",{className:"service-card",style:{flex:`0 0 ${u}px`},children:[e.jsx("div",{className:"service-icon",children:e.jsx(N,{size:23,color:"#ffffff",strokeWidth:1.8})}),e.jsx("h3",{children:n.title}),e.jsx("p",{children:n.description}),e.jsxs("a",{href:"#",children:[n.cta,e.jsx(C,{size:16})]})]},n.id)})})})]}),e.jsx("style",{children:`
        /* ================= SECTION ================= */

        .technology-services-section {
          position: relative;

          /* Vertical padding */
          padding-top: 60px;
          padding-bottom: 60px;

          /* Left/right padding same as Hero: 16 / 24 / 40 / 100 */
          padding-left: 16px;
          padding-right: 16px;

          background: ${m};

          background-image:
            repeating-linear-gradient(
              90deg,
              rgba(255,255,255,0.08) 0px,
              rgba(255,255,255,0.08) 1px,
              transparent 1px,
              transparent 90px
            );

          font-family: "Plus Jakarta Sans", sans-serif;

          overflow: hidden;
          box-sizing: border-box;
        }

        @media (min-width: 640px) {
          .technology-services-section {
            padding-left: 24px;
            padding-right: 24px;
          }
        }

        @media (min-width: 768px) {
          .technology-services-section {
            padding-left: 40px;
            padding-right: 40px;
          }
        }

        @media (min-width: 1024px) {
          .technology-services-section {
            padding-left: 100px;
            padding-right: 100px;
          }
        }

        /* ================= CONTAINER ================= */

        .technology-services-container {
          width: 100%;
        }

        /* ================= HEADER ================= */

        .services-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;

          gap: 30px;

          margin-bottom: 40px;
        }

        .services-header-content {
          max-width: 640px;
        }

        .services-header h2 {
          font-size: 24px;
          font-weight: 700;

          letter-spacing: 0.5px;

          color: #ffffff;

          margin: 0 0 16px;
        }

        .services-header p {
          font-size: 15px;
          line-height: 1.7;

          color: #e9d3dd;

          margin: 0;
        }

        /* ================= CONTROLS ================= */

        .slider-controls {
          display: flex;
          gap: 12px;

          flex-shrink: 0;
        }

        .slider-control {
          width: 40px;
          height: 40px;

          border-radius: 50%;
          border: none;

          background: #ffffff;
          color: ${m};

          display: flex;
          align-items: center;
          justify-content: center;

          cursor: pointer;

          transition:
            transform 0.2s ease,
            opacity 0.2s ease;
        }

        .slider-control:hover:not(:disabled) {
          transform: translateY(-2px);
        }

        .slider-control:disabled {
          opacity: 0.5;
          cursor: default;
        }

        /* ================= VIEWPORT ================= */

        .cards-viewport {
          width: 100%;
          overflow: hidden;
        }

        /* ================= TRACK ================= */

        .cards-track {
          display: flex;

          gap: ${g}px;

          /* No left padding, so first card aligns with heading */
          padding-left: 0;

          box-sizing: border-box;

          transition: transform 0.45s ease;

          will-change: transform;
        }

        /* ================= CARD ================= */

        .service-card {
          background: ${_};

          border: 1px solid #e6b8cf;
          border-radius: 14px;

          min-height: 330px;

          padding: 30px 28px;

          box-sizing: border-box;

          display: flex;
          flex-direction: column;

          flex-shrink: 0;
        }

        /* ================= ICON ================= */

        .service-icon {
          width: 50px;
          height: 50px;

          border-radius: 50%;

          background: ${m};

          display: flex;
          align-items: center;
          justify-content: center;

          margin-bottom: 22px;
        }

        /* ================= TITLE ================= */

        .service-card h3 {
          font-size: 18px;
          font-weight: 700;

          line-height: 1.3;

          color: #1a1a1a;

          margin: 0 0 13px;
        }

        /* ================= DESCRIPTION ================= */

        .service-card p {
          font-size: 14px;
          line-height: 1.65;

          color: #555555;

          margin: 0 0 22px;

          flex-grow: 1;
        }

        /* ================= LINK ================= */

        .service-card a {
          display: inline-flex;
          align-items: center;

          gap: 7px;

          font-size: 14px;
          font-weight: 700;

          color: #1a1a1a;

          text-decoration: none;

          transition: gap 0.2s ease;
        }

        .service-card a:hover {
          gap: 11px;
        }

        /* ================= TABLET ================= */

        @media (max-width: 900px) {
          .technology-services-section {
            padding-top: 55px;
            padding-bottom: 55px;
          }

          .services-header {
            gap: 25px;
          }

          .service-card {
            min-height: 320px;
          }
        }

        /* ================= MOBILE ================= */

        @media (max-width: 768px) {
          .technology-services-section {
            padding-top: 50px;
            padding-bottom: 50px;
          }

          .services-header {
            flex-direction: column;
          }

          .services-header-content {
            max-width: 100%;
          }

          .slider-controls {
            align-self: flex-start;
          }

          .services-header h2 {
            font-size: 22px;
          }

          .service-card {
            min-height: 310px;
          }
        }

        /* ================= SMALL MOBILE ================= */

        @media (max-width: 480px) {
          .technology-services-section {
            padding-top: 42px;
            padding-bottom: 42px;
          }

          .services-header {
            margin-bottom: 30px;
          }

          .services-header h2 {
            font-size: 20px;
          }

          .services-header p {
            font-size: 14px;
          }

          .service-card {
            min-height: 300px;
            padding: 26px 22px;
          }
        }
      `})]})}function D(){return e.jsx("section",{className:"relative block w-full bg-[#faf9f4] px-0",children:e.jsx("div",{className:`\r
          mx-auto\r
          w-full\r
          overflow-hidden\r
          bg-[#faf9f4]\r
        `,children:e.jsxs("div",{className:`\r
            grid\r
            w-full\r
            grid-cols-1\r
            md:grid-cols-2\r
            lg:grid-cols-[57%_43%]\r
            lg:h-[600px]\r
            xl:grid-cols-[57%_43%]\r
            xl:h-[570px]\r
          `,children:[e.jsxs("div",{className:`\r
              flex\r
              flex-col\r
              justify-center\r
\r
              pl-4\r
              pr-4\r
              py-10\r
\r
              sm:pl-6\r
              sm:pr-6\r
              sm:py-12\r
\r
              md:pl-10\r
              md:pr-8\r
              md:py-10\r
\r
              lg:pl-[100px]\r
              lg:pr-8\r
              lg:py-6\r
\r
              xl:py-6\r
            `,children:[e.jsx("p",{className:"mb-3 text-[16px] font-medium tracking-wide text-[#333]",children:"HOW WE WORK"}),e.jsxs("h2",{className:`\r
                text-[24px]\r
                font-['Plus_Jakarta_Sans']\r
                font-medium\r
                leading-[1.05]\r
                tracking-[-1px]\r
                text-[#111]\r
\r
                sm:text-[30px]\r
                md:text-[32px]\r
\r
                lg:text-[34px]\r
                xl:text-[34px]\r
              `,children:["A Clear Approach to",e.jsx("br",{}),e.jsx("span",{className:"text-[#8b0750]",children:"Better Technology"})]}),e.jsx("p",{className:`\r
                mt-5\r
                max-w-[600px]\r
                text-[14px]\r
                text-['Inter']\r
                leading-[1.55]\r
                sm:text-[15px]\r
                md:text-[14px]\r
                lg:text-[15px]\r
                xl:text-[15px]\r
              `,children:"Every business has its own goals, challenges and way of working. We believe technology should be built around those needs rather than forcing businesses to adapt to a fixed solution. That is why we take a clear and collaborative approach, starting with understanding your business and ending with solutions that can continue to evolve with it. We work closely with our clients throughout the process to understand what matters most, define the right direction and deliver technology that is practical, reliable and built for long-term use."}),e.jsx("h3",{className:`\r
                mt-5\r
                text-[16px]\r
                text-['Inter']\r
                font-semibold\r
\r
                sm:text-[17px]\r
                md:text-[17px]\r
\r
                lg:text-[18px]\r
              `,children:"From Understanding to Execution"}),e.jsxs("div",{className:"mt-4 flex flex-col gap-3",children:[e.jsxs("div",{className:"flex items-center gap-5",children:[e.jsx("div",{className:`\r
                    flex\r
                    h-[42px]\r
                    w-[42px]\r
                    shrink-0\r
                    items-center\r
                    justify-center\r
                    rounded-full\r
                    bg-[#8b0750]\r
                  `,children:e.jsxs("svg",{width:"20",height:"20",viewBox:"0 0 24 24",fill:"none",stroke:"white",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[e.jsx("circle",{cx:"11",cy:"11",r:"7"}),e.jsx("path",{d:"m20 20-4-4"})]})}),e.jsx("span",{className:`\r
                    text-[16px]\r
                    text-['Inter']\r
                    font-medium\r
\r
                    sm:text-[17px]\r
\r
                    md:text-[17px]\r
\r
                    lg:text-[17px]\r
                  `,children:"Understand"})]}),e.jsxs("div",{className:"flex items-center gap-5",children:[e.jsx("div",{className:`\r
                    flex\r
                    h-[42px]\r
                    w-[42px]\r
                    shrink-0\r
                    items-center\r
                    justify-center\r
                    rounded-full\r
                    bg-[#8b0750]\r
                  `,children:e.jsxs("svg",{width:"26",height:"26",viewBox:"0 0 24 24",fill:"none",stroke:"white",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[e.jsx("path",{d:"m8 9-3 3 3 3"}),e.jsx("path",{d:"m16 9 3 3-3 3"}),e.jsx("path",{d:"m14 5-4 14"})]})}),e.jsx("span",{className:`\r
                    text-[16px]\r
                    font-medium\r
                    text-['Inter']\r
\r
                    sm:text-[17px]\r
\r
                    md:text-[17px]\r
\r
                    lg:text-[17px]\r
                  `,children:"Build"})]}),e.jsxs("div",{className:"flex items-center gap-5",children:[e.jsx("div",{className:`\r
                    flex\r
                    h-[42px]\r
                    w-[42px]\r
                    shrink-0\r
                    items-center\r
                    justify-center\r
                    rounded-full\r
                    bg-[#8b0750]\r
                  `,children:e.jsxs("svg",{width:"20",height:"20",viewBox:"0 0 24 24",fill:"none",stroke:"white",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[e.jsx("path",{d:"M3 3v18h18"}),e.jsx("path",{d:"m7 15 4-4 3 3 6-7"}),e.jsx("path",{d:"M16 7h4v4"})]})}),e.jsx("span",{className:`\r
                    text-[16px]\r
                    font-medium\r
                    text-['Inter']\r
\r
                    sm:text-[17px]\r
\r
                    md:text-[17px]\r
\r
                    lg:text-[17px]\r
                  `,children:"Grow"})]})]})]}),e.jsx("div",{className:`\r
              relative\r
              flex\r
              h-auto\r
              w-full\r
              items-center\r
              justify-center\r
              overflow-hidden\r
              py-8\r
\r
              sm:py-10\r
\r
              md:h-full\r
              md:items-center\r
              md:justify-end\r
              md:py-0\r
\r
              lg:h-full\r
              lg:items-start\r
              lg:justify-end\r
              lg:py-0\r
\r
              xl:h-full\r
              xl:items-start\r
              xl:justify-end\r
              xl:py-0\r
            `,children:e.jsx("img",{loading:"lazy",decoding:"async",src:"/Slide4.2.webp",alt:"How we work",className:`\r
                block\r
                h-auto\r
                w-[82%]\r
                max-w-[500px]\r
                object-contain\r
\r
                sm:w-[80%]\r
\r
                md:h-full\r
                md:w-auto\r
                md:max-w-none\r
                md:object-contain\r
\r
                lg:h-full\r
                lg:w-auto\r
                lg:max-w-none\r
                lg:object-cover\r
\r
                xl:absolute\r
                xl:top-0\r
                xl:right-0\r
                xl:h-full\r
                xl:w-[80%]\r
                xl:max-w-none\r
                xl:object-cover\r
              `})})]})})})}function U(){const[o,t]=a.useState(!1),d=a.useRef(null),s=a.useRef(null),c=()=>{s.current&&clearTimeout(s.current),t(!0)},x=()=>{s.current=setTimeout(()=>{t(!1)},400)};a.useEffect(()=>{const r=i=>{d.current&&!d.current.contains(i.target)&&t(!1)},l=i=>{i.key==="Escape"&&t(!1)};return document.addEventListener("mousedown",r),document.addEventListener("keydown",l),()=>{document.removeEventListener("mousedown",r),document.removeEventListener("keydown",l),s.current&&clearTimeout(s.current)}},[]);const p=[{label:"Call Us",Icon:b,href:"tel:+915813500381"},{label:"WhatsApp",Icon:w,href:"https://wa.me/91XXXXXXXXXX?text=Hi%2C%20I%27d%20like%20to%20know%20more%20about%20your%20technology%20solutions.",external:!0},{label:"Email Us",Icon:j,href:"https://mail.google.com/mail/?view=cm&fs=1&to=contact@techtorch.solutions&su=Technology%20Services%20Enquiry",external:!0}];return e.jsxs("section",{className:`\r
        relative\r
        w-full\r
        overflow-hidden\r
        bg-[#170b17]\r
        h-[430px]\r
        sm:h-[460px]\r
        md:h-[500px]\r
        lg:h-[540px]\r
        xl:h-[570px]\r
      `,children:[e.jsx("img",{loading:"lazy",decoding:"async",src:"/Slide4.3.webp",alt:"Let's Connect",className:`\r
          absolute\r
          inset-0\r
          h-full\r
          w-full\r
          object-fill\r
        `}),e.jsx("div",{className:`\r
          absolute\r
          inset-0\r
          z-10\r
          flex\r
          items-center\r
        `,children:e.jsxs("div",{className:`\r
            w-[62%]\r
            pl-4\r
            pr-3\r
            sm:w-[61%]\r
            sm:pl-6\r
            sm:pr-4\r
            md:w-[60%]\r
            md:pl-10\r
            md:pr-5\r
            lg:w-[59%]\r
            lg:pl-[100px]\r
            lg:pr-6\r
            xl:w-[58%]\r
            xl:pr-8\r
          `,children:[e.jsx("p",{className:`\r
              -translate-y-8\r
              mb-5\r
              text-[13px]\r
              font-medium\r
              uppercase\r
              tracking-[0.01em]\r
              text-white\r
              sm:-translate-y-9\r
              sm:mb-6\r
              sm:text-[15px]\r
              md:-translate-y-10\r
              md:mb-7\r
              md:text-[17px]\r
              lg:-translate-y-11\r
              lg:mb-8\r
              lg:text-[18px]\r
              xl:-translate-y-[60px]\r
              xl:mb-9\r
              xl:text-[19px]\r
            `,children:"LET’S CONNECT"}),e.jsx("h2",{className:`\r
              -translate-y-6\r
              text-[25px]\r
              font-semibold\r
              font-['Plus_Jakarta_Sans']\r
              leading-[1.08]\r
              tracking-[-0.02em]\r
              text-white\r
              sm:-translate-y-7\r
              sm:text-[32px]\r
              md:-translate-y-8\r
              md:text-[34px]\r
              lg:-translate-y-9\r
              lg:text-[36px]\r
              xl:-translate-y-10\r
              xl:text-[36px]\r
            `,children:"LET'S BUILD WHAT'S NEXT"}),e.jsx("h2",{className:`\r
              -translate-y-5\r
              mt-4\r
              whitespace-nowrap\r
              text-[18px]\r
              font-medium\r
              font-['Inter']\r
              leading-[1.2]\r
              text-white\r
              sm:-translate-y-6\r
              sm:mt-5\r
              sm:text-[20px]\r
              md:-translate-y-7\r
              md:mt-6\r
              md:text-[24px]\r
              lg:-translate-y-8\r
              lg:mt-7\r
              lg:text-[26px]\r
              xl:-translate-y-9\r
              xl:mt-8\r
              xl:text-[26px]\r
            `,children:"Have a Technology Challenge?"}),e.jsxs("p",{className:`\r
              -translate-y-5\r
              mt-2\r
              max-w-[480px]\r
              text-[13px]\r
              font-['Inter']\r
              font-normal\r
              leading-[1.4]\r
              text-white\r
              sm:-translate-y-6\r
              sm:mt-3\r
              sm:text-[15px]\r
              md:-translate-y-7\r
              md:mt-3\r
              md:text-[16px]\r
              lg:-translate-y-8\r
              lg:mt-4\r
              lg:text-[17px]\r
              xl:-translate-y-9\r
              xl:mt-4\r
              xl:text-[17px]\r
            `,children:["Let's understand your requirements and",e.jsx("br",{className:"hidden sm:block"}),"find a practical way forward."]}),e.jsx("div",{className:`\r
              mt-6\r
              translate-y-5\r
              sm:mt-7\r
              sm:translate-y-6\r
              md:mt-8\r
              md:translate-y-7\r
              lg:mt-9\r
              lg:translate-y-8\r
            `,children:e.jsxs("div",{ref:d,className:"relative inline-block",onMouseEnter:c,onMouseLeave:x,children:[e.jsxs(v,{to:"/talk-to-expert",className:`\r
                  group\r
                  relative\r
                  inline-flex\r
                  items-center\r
                  gap-2\r
                  rounded-[5px]\r
                  border\r
                  border-white\r
                  bg-transparent\r
                  !px-[10px]\r
                  !py-[8px]\r
                  text-[13px]\r
                  font-medium\r
                  leading-none\r
                  text-white\r
                  transition-all\r
                  duration-300\r
                  hover:bg-white\r
                  hover:text-[#22091f]\r
                  sm:text-[15px]\r
                  md:text-[16px]\r
                  lg:text-[17px]\r
                `,children:[e.jsx("span",{children:"Talk to Our Experts"}),e.jsx(y,{size:18,strokeWidth:1.8,className:`\r
                    shrink-0\r
                    transition-transform\r
                    duration-300\r
                    group-hover:translate-x-1\r
                    group-hover:-translate-y-1\r
                  `})]}),e.jsx("div",{className:`
                  absolute
                  left-full
                  top-1/2
                  ml-2
                  flex
                  -translate-y-1/2
                  items-center
                  gap-2
                  transition-all
                  duration-300
                  ${o?"visible opacity-100":"invisible opacity-0 pointer-events-none"}
                `,"aria-hidden":!o,children:p.map(({label:r,Icon:l,href:i,external:n})=>e.jsx("a",{href:i,title:r,"aria-label":r,target:n?"_blank":void 0,rel:n?"noopener noreferrer":void 0,tabIndex:o?0:-1,onClick:()=>t(!1),className:`\r
                        flex\r
                        h-10\r
                        w-10\r
                        sm:h-11\r
                        sm:w-11\r
                        shrink-0\r
                        items-center\r
                        justify-center\r
                        rounded-full\r
                        border\r
                        border-white/50\r
                        bg-[#170b17]/90\r
                        text-white\r
                        backdrop-blur-md\r
                        transition-all\r
                        duration-300\r
                        hover:scale-110\r
                        hover:border-[#730042]\r
                        hover:bg-[#730042]\r
                      `,children:e.jsx(l,{size:18})},r))})]})})]})})]})}function re(){return e.jsxs(e.Fragment,{children:[e.jsx(R,{}),e.jsx(X,{}),e.jsx(H,{}),e.jsx(D,{}),e.jsx(U,{})]})}export{D as HowWeWork,U as LetsConnect,R as TechnologyMovesForward,H as TechnologyServicesSection,X as TechnologyThatWorks,re as default};
