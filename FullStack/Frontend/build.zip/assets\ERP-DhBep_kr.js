import{j as n}from"./vendor-query-PraSc8EQ.js";import{r as x,L as P,d as M}from"./vendor-router-L4ZCoGSs.js";import{g as f}from"./vendor-gsap-I1jVCVBc.js";import{S as T}from"./ScrollTrigger-DIOrBQLF.js";import{A as L}from"./arrow-up-right-DIePtCQ0.js";import{P as O}from"./phone-D3JbSBfc.js";import{t as v,K as S,s as C,W}from"./index-37hjU4u5.js";import{M as _}from"./mail-CbeZpzUl.js";import{S as B}from"./settings-2-D0_FofoO.js";import{C as D}from"./contact-Dp_d-NMy.js";const j={name:"indian-rupee",size:24,node:[["path",{d:"m14 20-8-8h4c5.333 0 5.333-8 0-8",key:"cvo5tb"}],["path",{d:"M6 4h12",key:"1x2ag7"}],["path",{d:"M6 8h12",key:"6g4wlu"}]]};j.node;const $=v(j);const k={name:"warehouse",size:24,node:[["path",{d:"M18 21V10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v11",key:"pb2vm6"}],["path",{d:"M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 1.132-1.803l7.95-3.974a2 2 0 0 1 1.837 0l7.948 3.974A2 2 0 0 1 22 8z",key:"doq5xv"}],["path",{d:"M6 13h12",key:"yf64js"}],["path",{d:"M6 17h12",key:"1jwigz"}]]};k.node;const F=v(k);f.registerPlugin(T);function H(){const[r,e]=x.useState(!1),t=x.useRef(null);x.useEffect(()=>{const i=s=>{t.current&&!t.current.contains(s.target)&&e(!1)},o=s=>{s.key==="Escape"&&e(!1)};return document.addEventListener("mousedown",i),document.addEventListener("keydown",o),()=>{document.removeEventListener("mousedown",i),document.removeEventListener("keydown",o)}},[]);const a=[{label:"Call Us",Icon:O,href:"tel:+915813500381"},{label:"WhatsApp",Icon:S,href:"https://wa.me/91XXXXXXXXXX?text=Hi%2C%20I%27d%20like%20to%20know%20more%20about%20your%20ERP%20solutions.",external:!0},{label:"Email Us",Icon:_,href:"https://mail.google.com/mail/?view=cm&fs=1&to=contact@techtorch.solutions&su=ERP%20Solutions%20Enquiry",external:!0}];return n.jsxs("section",{className:`\r
        relative\r
        w-full\r
        overflow-hidden\r
        bg-[#0c140c]\r
        font-['Plus_Jakarta_Sans']\r
        min-h-[500px]\r
        sm:min-h-[520px]\r
        md:min-h-[540px]\r
        lg:min-h-[560px]\r
        xl:min-h-[580px]\r
      `,children:[n.jsx("div",{className:`\r
          absolute\r
          inset-0\r
          bg-cover\r
          bg-center\r
          bg-no-repeat\r
        `,style:{backgroundImage:"url('/slide21.webp')"}}),n.jsx("div",{className:"absolute inset-0",style:{background:"linear-gradient(180deg, rgba(6,10,6,0.55) 0%, rgba(6,10,6,0.38) 45%, rgba(6,10,6,0.65) 100%)"}}),n.jsxs("div",{className:`\r
          relative\r
          z-10\r
          mx-auto\r
          flex\r
          min-h-[500px]\r
          sm:min-h-[520px]\r
          md:min-h-[540px]\r
          lg:min-h-[560px]\r
          xl:min-h-[580px]\r
          w-full\r
          max-w-6xl\r
          flex-col\r
          items-center\r
          justify-center\r
          px-5\r
          sm:px-8\r
          md:px-10\r
          lg:px-12\r
          py-14\r
          sm:py-16\r
          md:py-20\r
          lg:py-24\r
          text-center\r
        `,children:[n.jsx("p",{className:`\r
            mb-3\r
            sm:mb-4\r
            md:mb-5\r
            text-[10px]\r
            sm:text-xs\r
            md:text-sm\r
            font-bold\r
            tracking-[0.12em]\r
            sm:tracking-[0.15em]\r
            md:tracking-[0.18em]\r
            leading-tight\r
            text-white/90\r
          `,children:"ENTERPRISE RESOURCE PLANNING"}),n.jsx("h1",{className:`\r
            mb-4\r
            sm:mb-5\r
            md:mb-6\r
            w-full\r
            max-w-full\r
            sm:max-w-[520px]\r
            md:max-w-[700px]\r
            lg:max-w-[850px]\r
            text-[1.65rem]\r
            sm:text-[2rem]\r
            md:text-[2.5rem]\r
            lg:text-[3rem]\r
            xl:text-[3.25rem]\r
            font-semibold\r
            leading-[1.15]\r
            sm:leading-[1.15]\r
            md:leading-[1.12]\r
            text-white\r
          `,children:"Connect Your Business. Work Better Together."}),n.jsx("p",{className:`\r
            mb-6\r
            sm:mb-7\r
            md:mb-8\r
            lg:mb-9\r
            w-full\r
            max-w-full\r
            sm:max-w-[540px]\r
            md:max-w-[680px]\r
            lg:max-w-[800px]\r
            text-[13px]\r
            sm:text-sm\r
            md:text-base\r
            lg:text-[17px]\r
            leading-[1.6]\r
            md:leading-[1.65]\r
            text-white/90\r
          `,children:"Bring your finance, operations, people, inventory and customer processes together in one place. With a connected ERP system, your teams can spend less time managing information and more time getting work done."}),n.jsxs("div",{ref:t,className:`\r
            relative\r
            flex\r
            w-full\r
            items-center\r
            justify-center\r
          `,onMouseEnter:()=>e(!0),onMouseLeave:()=>e(!1),children:[n.jsxs(P,{to:"/talk-to-expert",className:`\r
              group\r
              relative\r
              z-10\r
              inline-flex\r
              shrink-0\r
              items-center\r
              justify-center\r
              gap-3\r
              border\r
              border-white/70\r
              bg-transparent\r
              text-white\r
              text-[11px]\r
              sm:text-xs\r
              md:text-sm\r
              font-medium\r
              tracking-wide\r
              px-5\r
              sm:px-6\r
              md:px-7\r
              py-2.5\r
              sm:py-3\r
              md:py-3.5\r
              whitespace-nowrap\r
              transition-colors\r
              duration-300\r
              ease-in-out\r
              hover:bg-white\r
              hover:text-[#0c140c]\r
              hover:border-white\r
              active:scale-95\r
            `,children:["Talk to Our Experts",n.jsx(L,{size:16,className:`\r
                shrink-0\r
                transition-transform\r
                duration-300\r
                group-hover:translate-x-1\r
                group-hover:-translate-y-1\r
              `})]}),n.jsx("div",{className:`
              absolute
              left-1/2
              top-1/2
              flex
              -translate-y-1/2
              items-center
              gap-2
              transition-all
              duration-300
              ${r?"visible opacity-100":"invisible opacity-0 pointer-events-none"}
            `,style:{marginLeft:"120px"},"aria-hidden":!r,children:a.map(({label:i,Icon:o,href:s,external:l})=>n.jsx("a",{href:s,title:i,"aria-label":i,target:l?"_blank":void 0,rel:l?"noopener noreferrer":void 0,tabIndex:r?0:-1,onClick:()=>e(!1),className:`\r
                    flex\r
                    h-10\r
                    w-10\r
                    sm:h-11\r
                    sm:w-11\r
                    shrink-0\r
                    items-center\r
                    justify-center\r
                    rounded-full\r
                    border\r
                    border-white/50\r
                    bg-[#0c140c]/80\r
                    text-white\r
                    backdrop-blur-md\r
                    transition-all\r
                    duration-300\r
                    hover:scale-110\r
                    hover:border-[#730042]\r
                    hover:bg-[#730042]\r
                  `,children:n.jsx(o,{size:18})},i))})]})]}),n.jsx("style",{children:`
        @keyframes contactReveal {
          from {
            opacity: 0;
            transform: translateX(-8px);
          }

          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @media (prefers-reduced-motion: reduce) {
          .animate-\\[contactReveal_250ms_ease-out\\] {
            animation: none;
          }
        }
      `})]})}function X(){return n.jsx("section",{className:`\r
        w-full\r
        min-h-[480px]\r
        overflow-hidden\r
        bg-[#F8F7F0]\r
        text-[#191919]\r
\r
        sm:min-h-[460px]\r
        md:min-h-[500px]\r
        lg:min-h-[520px]\r
      `,style:{backgroundColor:"#F8F7F0"},children:n.jsxs("div",{className:`\r
          w-full\r
          px-4\r
          py-6\r
\r
          sm:px-6\r
          sm:py-5\r
\r
          md:px-10\r
          md:py-6\r
\r
          lg:px-[100px]\r
          lg:py-8\r
        `,children:[n.jsx("p",{className:`\r
            font-['Plus_Jakarta_Sans']\r
            font-bold\r
            uppercase\r
            leading-none\r
            tracking-[0.01em]\r
            text-[#151515]\r
\r
            text-[13px]\r
            sm:text-[15px]\r
            md:text-[16px]\r
            lg:text-[16px]\r
          `,children:"OUR ERP APPROACH"}),n.jsxs("div",{className:`\r
            mt-5\r
            grid\r
            grid-cols-1\r
            gap-6\r
\r
            sm:mt-6\r
            sm:gap-7\r
\r
            md:mt-6\r
            md:grid-cols-2\r
            md:gap-7\r
\r
            lg:mt-7\r
            lg:gap-8\r
\r
            xl:gap-10\r
          `,children:[n.jsxs("div",{className:`\r
              order-1\r
              min-w-0\r
              md:order-1\r
            `,children:[n.jsxs("h2",{className:`\r
                font-['Plus_Jakarta_Sans']\r
                text-[26px]\r
                font-semibold\r
                leading-[1.1]\r
                tracking-[-0.03em]\r
\r
                xs:text-[24px]\r
                sm:text-[26px]\r
                md:text-[30px]\r
                lg:text-[30px]\r
                xl:text-[32px]\r
              `,children:["A Business That",n.jsx("br",{}),n.jsx("span",{className:"text-[#730042]",children:"Works as One"})]}),n.jsx("p",{className:`\r
                mt-4\r
                max-w-[550px]\r
                font-['Inter']\r
                text-[13px]\r
                font-normal\r
                leading-[1.55]\r
                text-[#303030]\r
\r
                sm:mt-5\r
                sm:text-[13px]\r
\r
                md:mt-5\r
                md:text-[15px]\r
\r
                lg:text-[15px]\r
              `,children:"As businesses grow, their operations become more connected — finance, inventory, HRMS, Engage, Pay and everyday processes all depend on each other. When these functions work across separate systems, teams can spend more time managing information than using it."}),n.jsx("p",{className:`\r
                mt-4\r
                max-w-[550px]\r
                font-['Inter']\r
                text-[13px]\r
                font-normal\r
                leading-[1.55]\r
                text-[#303030]\r
\r
                sm:mt-5\r
                sm:text-[13px]\r
\r
                md:mt-5\r
                md:text-[15px]\r
\r
                lg:text-[15px]\r
              `,children:"An ERP brings these essential business functions together in one connected environment. It gives teams better visibility, helps information move more efficiently across the organisation and creates a more consistent way of working."}),n.jsx("p",{className:`\r
                mt-4\r
                max-w-[550px]\r
                font-['Inter']\r
                text-[13px]\r
                font-normal\r
                leading-[1.55]\r
                text-[#303030]\r
\r
                sm:mt-5\r
                sm:text-[13px]\r
\r
                md:mt-5\r
                md:text-[15px]\r
\r
                lg:text-[15px]\r
              `,children:"At TechTorch, we take a practical approach to ERP. We first understand how your business operates, where processes can be improved and what your teams need to work more effectively. From there, we help shape a solution around your business priorities."})]}),n.jsxs("div",{className:`\r
              relative\r
              order-2\r
              flex\r
              w-full\r
              min-w-0\r
              flex-col\r
              items-center\r
\r
              md:order-2\r
              md:items-center\r
              md:translate-x-2\r
\r
              lg:translate-x-14\r
              lg:-translate-y-5\r
\r
              xl:translate-x-32\r
              xl:-translate-y-6\r
            `,children:[n.jsx("div",{className:`\r
                relative\r
                mx-auto\r
                flex\r
                w-full\r
                items-center\r
                justify-center\r
                overflow-hidden\r
\r
                max-w-[280px]\r
\r
                xs:max-w-[300px]\r
\r
                sm:max-w-[350px]\r
\r
                md:max-w-[450px]\r
\r
                lg:max-w-[425px]\r
\r
                xl:max-w-[445px]\r
              `,children:n.jsx("img",{loading:"lazy",decoding:"async",src:"/Hero02Slide02.webp",alt:"ERP Approach",className:`\r
                  block\r
                  h-auto\r
                  w-full\r
                  object-contain\r
                `})}),n.jsx("div",{className:`\r
                mt-4\r
                w-full\r
                max-w-[320px]\r
                rounded-[8px]\r
                bg-[#FCECF6]\r
                px-3\r
                py-2.5\r
\r
                sm:mt-4\r
                sm:max-w-[300px]\r
                sm:px-4\r
                sm:py-3\r
\r
                md:-mt-4\r
                md:max-w-[390px]\r
                md:px-5\r
                md:py-4\r
\r
                lg:-mt-1\r
                lg:max-w-[400px]\r
                lg:translate-x-6\r
\r
                xl:translate-x-0\r
              `,children:n.jsxs("p",{className:`\r
                  font-['Inter']\r
                  text-[11px]\r
                  font-semibold\r
                  leading-[1.4]\r
                  text-[#151515]\r
\r
                  sm:text-[13px]\r
                  md:text-[15px]\r
                  lg:text-[15px]\r
                `,children:["The goal is simple:",n.jsxs("span",{className:"font-normal",children:[" ","connect the business, simplify the way people work and create a stronger foundation for growth."]})]})})]})]})]})})}const b="#5c0e34",d=[{title:"Engage",desc:"Keep your employees connected and engaged by making communication, collaboration and everyday interactions easier across the organisation.",icon:C},{title:"Finance & Accounting",desc:"Keep your financial information organised and get a clearer view of your business performance.",icon:$},{title:"Inventory & Supply Chain",desc:"Keep track of stock, purchasing and movement so your teams know what is available and what needs attention.",icon:F},{title:"Payroll",desc:"Manage employee salaries, payments and payroll processes more efficiently, while keeping important payroll information organised and accessible.",icon:W},{title:"Operations",desc:"Bring everyday operational activities together and give your teams a clearer view of what is happening.",icon:B},{title:"HRMS",desc:"Keep employee information and important HR processes organized in one place.",icon:D}],h=360,N=150,u=260,E=80,G=120,z=150,U=60,g=z+u+90;function R(r){return E+r*(h+N)}function I(r){return r%2===0?z:U}function A(r){return{x:R(r)+h/2,y:I(r)+u/2}}function J(){return E+d.length*h+(d.length-1)*N+G}function Y(){const r=d.map((t,a)=>A(a));let e=`M ${r[0].x},${r[0].y}`;for(let t=0;t<r.length-1;t++){const a=r[t],i=r[t+1],o=(a.x+i.x)/2,s=Math.min(a.y,i.y)-45;e+=` Q ${o},${s} ${i.x},${i.y}`}return e}function K(){const r=x.useRef(null),e=x.useRef(null),t=x.useRef(null),[a,i]=x.useState(!1);x.useLayoutEffect(()=>{const l=window.matchMedia("(max-width: 1024px)");i(l.matches);const p=m=>i(m.matches);return l.addEventListener("change",p),()=>l.removeEventListener("change",p)},[]),x.useLayoutEffect(()=>{const l=f.context(()=>{if(a)return;const p=t.current,m=e.current;if(!p||!m)return;const w=()=>Math.max(p.scrollWidth-m.offsetWidth,0);f.to(p,{x:()=>-w(),ease:"none",scrollTrigger:{trigger:r.current,start:"top top",end:()=>"+="+w()*1.15,scrub:1,pin:!0,anticipatePin:1,invalidateOnRefresh:!0}})},r);return()=>l.revert()},[a]);const o=Y(),s=J();return n.jsxs("section",{ref:r,className:"one-platform-section",children:[n.jsxs("div",{className:"one-platform-container",children:[n.jsxs("div",{className:"one-platform-header",children:[n.jsx("h2",{className:"one-platform-heading",children:"One Platform for Your Everyday Business"}),n.jsx("p",{className:"one-platform-description",children:"An ERP system should make it easier for different parts of your business to work together. We help connect the functions that matter most to your day-to-day operations."})]}),n.jsx("div",{ref:e,className:"one-platform-viewport",children:n.jsxs("div",{ref:t,className:"one-platform-track",style:{width:a?void 0:`${s}px`,height:`${g}px`},children:[!a&&n.jsxs("svg",{viewBox:`0 0 ${s} ${g}`,width:s,height:g,className:"platform-connector",children:[n.jsx("path",{d:o,stroke:"#ffffff",strokeOpacity:"0.55",strokeWidth:"1.5",strokeDasharray:"3 6",fill:"none"}),d.map((l,p)=>{const m=A(p);return n.jsx("circle",{cx:m.x,cy:m.y,r:"4",fill:"#ffffff"},p)})]}),d.map((l,p)=>n.jsx(q,{card:l,style:a?void 0:{left:`${R(p)}px`,top:`${I(p)}px`,width:`${h}px`}},l.title))]})})]}),n.jsx("style",{children:`
        * { box-sizing: border-box; }

        .one-platform-section {
          width: 100%;
          min-height: 100vh;
          background: ${b};
          font-family: 'Plus Jakarta Sans', sans-serif;
          overflow: hidden;
          display: flex;
          align-items: center;
        }

        .one-platform-container {
          width: 100%;
          max-width: 1300px;
          margin: 0 auto;
          padding: 70px 40px;
        }

        .one-platform-header {
          margin-bottom: 30px;
          max-width: 700px;
        }

        .one-platform-heading {
          font-size: 32px;
          font-weight: 700;
          color: #ffffff;
          line-height: 1.2;
          margin: 0 0 14px 0;
        }

        .one-platform-description {
         font-family: "Inter", sans-serif;
          font-size: 15px;
          font-weight: 500;
          color: #f1d9e4;
          line-height: 1.6;
          margin: 0;
        }

        /* The viewport is what clips the horizontally-translating
           track — only what's inside this box is visible. */
        .one-platform-viewport {
          position: relative;
          width: 100%;
          overflow: hidden;
        }

        .one-platform-track {
          position: relative;
          will-change: transform;
        }

        .platform-connector {
          position: absolute;
          top: 0;
          left: 0;
          pointer-events: none;
          z-index: 1;
        }

        .platform-card {
          position: absolute;
          min-height: ${u}px;
          background: #ffffff;
          border-radius: 10px;
          padding: 30px 26px;
          z-index: 2;
          box-shadow: 0 15px 40px rgba(0, 0, 0, 0.18);
        }

        .card-icon {
          width: 48px;
          height: 48px;
          border-radius: 50%;
          background: ${b};
          display: flex;
          align-items: center;
          justify-content: center;
          color: #ffffff;
          margin-bottom: 18px;
        }

        .card-title {
        font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 16px;
          font-weight: 700;
          color: #141414;
          margin: 0 0 12px;
          line-height: 1.3;
        }

        .card-desc {
        font-family: "Inter", sans-serif;
          font-size: 13.5px;
          line-height: 1.5;
          color: #2f2f2f;
          margin: 0;
        }

        /* =========================================================
           TABLET + MOBILE (≤1024px) — GSAP pin is skipped in JS;
           fall back to a native, swipeable horizontal scroller with
           snap points and auto height, so nothing ever gets clipped.
        ========================================================= */
        @media (max-width: 1024px) {
          .one-platform-section {
            min-height: auto;
            padding: 0;
          }

          .one-platform-container {
            padding: 55px 30px;
          }

          .one-platform-viewport {
            overflow-x: auto;
            overflow-y: visible;
            scroll-snap-type: x mandatory;
            -webkit-overflow-scrolling: touch;
            margin: 0 -30px;
            padding: 0 30px;
          }

          .one-platform-track {
            display: flex;
            align-items: flex-start;
            gap: 20px;
            width: max-content !important;
            height: auto !important;
          }

          .platform-card {
            position: relative;
            width: 360px;
            min-height: 0;
            height: auto;
            scroll-snap-align: start;
            flex: 0 0 auto;
          }
        }

        /* Tablet portrait / small tablets get a narrower card so it
           doesn't feel oversized, and two can peek on screen at once. */
        @media (max-width: 900px) {
          .one-platform-heading {
            font-size: 27px;
          }

          .platform-card {
            width: 68vw;
          }
        }

        @media (max-width: 700px) {
          .one-platform-container {
            padding: 40px 20px;
          }

          .one-platform-heading {
            font-size: 24px;
          }

          .one-platform-description {
            font-size: 13.5px;
          }

          .one-platform-viewport {
            margin: 0 -20px;
            padding: 0 20px;
          }

          .platform-card {
            width: 80vw;
            padding: 24px 20px;
          }

          .card-icon {
            width: 44px;
            height: 44px;
            margin-bottom: 14px;
          }

          .card-title {
            font-size: 15px;
          }

          .card-desc {
            font-size: 13px;
          }
        }

        @media (max-width: 400px) {
          .platform-card {
            width: 86vw;
            padding: 20px 18px;
          }
        }
      `})]})}function q({card:r,style:e}){const t=r.icon;return n.jsxs("div",{className:"platform-card",style:e,children:[n.jsx("div",{className:"card-icon",children:n.jsx(t,{size:22,strokeWidth:2})}),n.jsx("h3",{className:"card-title",children:r.title}),n.jsx("p",{className:"card-desc",children:r.desc})]})}function V(){const r=[{number:"01",title:"Understand",description:"We learn about your business, your current systems and the challenges your teams are facing."},{number:"02",title:"Plan",description:"We identify the key priorities and create a clear plan based on your business goals."},{number:"03",title:"Connect",description:"We bring the right processes, information and teams together."},{number:"04",title:"Implement",description:"We put the solution in place through a structured and manageable implementation process."},{number:"05",title:"Improve",description:"Once the system is in place, we continue to look for ways to improve it as your business changes."}];return n.jsx("section",{id:"vxbl7s",className:"relative w-full overflow-hidden bg-white",children:n.jsxs("div",{className:`\r
          relative mx-auto\r
          w-full\r
          max-w-[1520px]\r
          overflow-hidden\r
          bg-white\r
\r
          min-h-[520px]\r
\r
          xs:min-h-[545px]\r
\r
          sm:min-h-[565px]\r
\r
          md:min-h-[585px]\r
\r
          lg:min-h-[615px]\r
\r
          xl:min-h-[600px]\r
\r
          2xl:min-h-[620px]\r
        `,children:[n.jsx("div",{id:"9k9mjj",className:`\r
            absolute\r
            right-5\r
            top-5\r
            z-40\r
\r
            flex\r
            h-[65px]\r
            w-[120px]\r
            items-center\r
            justify-center\r
\r
            bg-white\r
\r
            xs:right-6\r
            xs:top-6\r
            xs:h-[72px]\r
            xs:w-[135px]\r
\r
            sm:right-8\r
            sm:top-7\r
            sm:h-[85px]\r
            sm:w-[160px]\r
\r
            md:right-10\r
            md:top-8\r
            md:h-[100px]\r
            md:w-[190px]\r
\r
            lg:right-[50px]\r
            lg:top-[25px]\r
            lg:h-[125px]\r
            lg:w-[230px]\r
\r
            xl:right-[52px]\r
            xl:top-[25px]\r
            xl:h-[140px]\r
            xl:w-[250px]\r
\r
            2xl:right-[55px]\r
            2xl:top-[25px]\r
            2xl:h-[150px]\r
            2xl:w-[270px]\r
          `,children:n.jsx("img",{loading:"lazy",decoding:"async",src:"/TorchX Suite.webp",alt:"TorchX Suite",className:`\r
              block\r
              h-auto\r
              w-[82%]\r
              max-w-full\r
              object-contain\r
            `})}),n.jsxs("div",{className:`\r
            absolute\r
            right-0\r
            bottom-0\r
            z-0\r
\r
            flex\r
            items-end\r
            justify-end\r
\r
            w-[100%]\r
            h-[calc(100%-105px)]\r
\r
            xs:h-[calc(100%-115px)]\r
\r
            sm:h-[calc(100%-125px)]\r
\r
            md:h-[calc(100%-135px)]\r
\r
            lg:top-[145px]\r
            lg:h-auto\r
            lg:bottom-0\r
            lg:w-[76%]\r
\r
            xl:top-[160px]\r
            xl:h-auto\r
            xl:bottom-0\r
            xl:w-[76%]\r
\r
            2xl:top-[170px]\r
            2xl:h-auto\r
            2xl:bottom-0\r
            2xl:w-[74%]\r
          `,children:[n.jsx("img",{loading:"lazy",decoding:"async",id:"8f14dd",src:"/Slide2.2.webp",alt:"TorchX ERP platform",className:`\r
              block\r
              h-full\r
              w-full\r
              max-h-full\r
              max-w-full\r
              object-contain\r
              object-right-bottom\r
\r
              lg:h-auto\r
              lg:max-h-full\r
\r
              xl:h-auto\r
              xl:max-h-full\r
\r
              2xl:h-auto\r
              2xl:max-h-full\r
            `}),n.jsx("div",{className:`\r
              pointer-events-none\r
              absolute\r
              inset-y-0\r
              left-0\r
              z-10\r
\r
              w-[30%]\r
\r
              bg-gradient-to-r\r
              from-white\r
              via-white/85\r
              to-transparent\r
\r
              xs:w-[29%]\r
\r
              sm:w-[27%]\r
\r
              md:w-[25%]\r
\r
              lg:w-[27%]\r
\r
              xl:w-[25%]\r
            `})]}),n.jsxs("div",{className:`\r
            relative\r
            z-20\r
            w-full\r
\r
            px-5\r
            pt-7\r
\r
            xs:px-6\r
            xs:pt-8\r
\r
            sm:px-8\r
            sm:pt-9\r
\r
            md:px-10\r
            md:pt-9\r
\r
            lg:px-[50px]\r
            lg:pt-[30px]\r
            lg:translate-x-8\r
\r
            xl:px-[52px]\r
            xl:pt-[28px]\r
            xl:translate-x-12\r
          `,children:[n.jsxs("h2",{id:"41gxzm",className:`\r
              pr-[115px]\r
\r
              font-['Inter']\r
              text-[24px]\r
              font-medium\r
              leading-[1.1]\r
              tracking-[-0.035em]\r
              text-[#111111]\r
\r
              xs:pr-[125px]\r
              xs:text-[28px]\r
              xs:leading-[1.08]\r
\r
              sm:pr-[145px]\r
              sm:text-[31px]\r
\r
              md:pr-[170px]\r
              md:text-[35px]\r
\r
              lg:pr-0\r
              lg:text-[32px]\r
              lg:leading-[1.12]\r
              lg:tracking-[-0.03em]\r
\r
              xl:text-[32px]\r
\r
              2xl:text-[34px]\r
            `,children:["A Practical Path to"," ",n.jsx("span",{className:"text-[#850052]",children:"ERP"})]}),n.jsx("p",{id:"lql9x7",className:`\r
              mt-[13px]\r
              max-w-[100%]\r
              pr-[105px]\r
\r
              font-['Inter']\r
              text-[12px]\r
              font-medium\r
              leading-[1.35]\r
              text-[#1e1e1e]\r
\r
              xs:mt-[15px]\r
              xs:pr-[115px]\r
              xs:text-[13px]\r
              xs:leading-[1.32]\r
\r
              sm:mt-[16px]\r
              sm:max-w-[600px]\r
              sm:pr-[125px]\r
              sm:text-[14px]\r
\r
              md:mt-[17px]\r
              md:max-w-[620px]\r
              md:pr-[145px]\r
              md:text-[15px]\r
\r
              lg:mt-[12px]\r
              lg:max-w-[700px]\r
              lg:pr-0\r
              lg:text-[16px]\r
              lg:leading-[1.32]\r
\r
              xl:text-[15px]\r
\r
              2xl:max-w-[720px]\r
            `,children:"Every business is different, so there is no single ERP approach that works for everyone. We take the time to understand your business before deciding what needs to change."}),n.jsx("div",{id:"g9w64w",className:`\r
              mt-[28px]\r
              w-[72%]\r
              max-w-[390px]\r
\r
              xs:mt-[30px]\r
              xs:w-[70%]\r
\r
              sm:mt-[32px]\r
              sm:w-[64%]\r
              sm:max-w-[420px]\r
\r
              md:mt-[34px]\r
              md:w-[61%]\r
              md:max-w-[430px]\r
\r
              lg:mt-[45px]\r
              lg:w-[430px]\r
\r
              xl:w-[440px]\r
\r
              2xl:w-[450px]\r
            `,children:r.map((e,t)=>n.jsxs("div",{className:`
                  flex
                  items-start
                  gap-[8px]

                  xs:gap-[10px]

                  sm:gap-[12px]

                  ${t!==r.length-1?"mb-[12px] xs:mb-[16px] sm:mb-[18px] lg:mb-[21px]":""}
                `,children:[n.jsx("div",{className:`\r
                    flex\r
                    h-[34px]\r
                    w-[34px]\r
                    shrink-0\r
                    items-center\r
                    justify-center\r
                    rounded-full\r
                    bg-[#850052]\r
\r
                    font-['Inter']\r
                    text-[13px]\r
                    font-medium\r
                    text-white\r
\r
                    xs:h-[40px]\r
                    xs:w-[40px]\r
                    xs:text-[15px]\r
\r
                    sm:h-[43px]\r
                    sm:w-[43px]\r
                    sm:text-[16px]\r
\r
                    md:h-[44px]\r
                    md:w-[44px]\r
                    md:text-[17px]\r
\r
                    lg:h-[44px]\r
                    lg:w-[44px]\r
                    lg:text-[18px]\r
                  `,children:e.number}),n.jsxs("div",{className:"min-w-0 flex-1 pt-[1px]",children:[n.jsx("h3",{className:`\r
                      font-['Plus_Jakarta_Sans']\r
                      text-[15px]\r
                      font-semibold\r
                      leading-[1.2]\r
                      text-[#111111]\r
\r
                      xs:text-[17px]\r
\r
                      sm:text-[18px]\r
\r
                      md:text-[19px]\r
\r
                      lg:text-[18px]\r
                    `,children:e.title}),n.jsx("p",{className:`\r
                      mt-[3px]\r
                      max-w-[370px]\r
\r
                      font-['Inter']\r
                      text-[11px]\r
                      font-medium\r
                      leading-[1.3]\r
                      text-[#333333]\r
\r
                      xs:text-[12px]\r
\r
                      sm:text-[13px]\r
\r
                      md:text-[14px]\r
\r
                      lg:text-[14px]\r
                    `,children:e.description})]})]},e.number))})]})]})})}function Q(){const r=M();return n.jsxs("section",{className:`\r
        relative\r
        w-full\r
        overflow-hidden\r
        bg-[#0a1128]\r
        font-['Plus_Jakarta_Sans']\r
\r
        min-h-[430px]\r
        sm:min-h-[450px]\r
        md:min-h-[500px]\r
        lg:min-h-[580px]\r
        xl:min-h-[620px]\r
      `,children:[n.jsx("div",{className:`\r
          absolute\r
          inset-0\r
          bg-no-repeat\r
          bg-cover\r
          bg-center\r
        `,style:{backgroundImage:"url('/slide25.webp')"}}),n.jsx("div",{className:"absolute inset-0 bg-black/10"}),n.jsxs("div",{className:`\r
          relative\r
          z-10\r
\r
          flex\r
          flex-col\r
          justify-center\r
\r
          w-full\r
\r
          min-h-[430px]\r
          sm:min-h-[450px]\r
          md:min-h-[500px]\r
          lg:min-h-[580px]\r
          xl:min-h-[620px]\r
\r
          px-6\r
          sm:px-10\r
          md:px-16\r
          lg:px-20\r
          xl:px-24\r
\r
          box-border\r
        `,children:[n.jsxs("h2",{className:`\r
            text-white\r
            font-semibold\r
            leading-[1.15]\r
            tracking-tight\r
\r
            text-[1.65rem]\r
            sm:text-[1.9rem]\r
            md:text-[2.3rem]\r
            lg:text-[2.7rem]\r
            xl:text-[3rem]\r
\r
            max-w-[330px] max-w-full\r
            sm:max-w-[420px] max-w-full\r
            md:max-w-[520px] max-w-full\r
            lg:max-w-[600px] max-w-full\r
\r
            ml-2\r
            sm:ml-4\r
            md:ml-8\r
            lg:ml-12\r
            xl:ml-16\r
\r
            translate-y-0\r
          `,children:["Ready to Bring Your",n.jsx("br",{}),"Business Together?"]}),n.jsx("p",{className:`\r
            mt-6\r
            sm:mt-7\r
            md:mt-8\r
            lg:mt-10\r
\r
            text-white/90\r
\r
            text-[13px]\r
            sm:text-sm\r
            md:text-base\r
            lg:text-lg\r
\r
            leading-[1.6]\r
\r
            max-w-[300px] max-w-full\r
            sm:max-w-[380px] max-w-full\r
            md:max-w-[480px] max-w-full\r
            lg:max-w-[560px] max-w-full\r
\r
            ml-2\r
            sm:ml-4\r
            md:ml-8\r
            lg:ml-12\r
            xl:ml-16\r
          `,children:"Let's look at how the right ERP approach can simplify your processes, improve visibility and help your teams work better together."}),n.jsx("div",{className:`\r
            mt-8\r
            sm:mt-9\r
            md:mt-10\r
            lg:mt-14\r
\r
            ml-2\r
            sm:ml-4\r
            md:ml-8\r
            lg:ml-12\r
            xl:ml-16\r
          `,children:n.jsx("button",{type:"button",onClick:()=>r("/talk-to-expert"),className:`\r
              border\r
              border-white/70\r
\r
              bg-transparent\r
              text-white\r
\r
              text-[11px]\r
              sm:text-xs\r
              md:text-sm\r
\r
              font-medium\r
              tracking-wide\r
\r
              px-4\r
              sm:px-5\r
              md:px-6\r
\r
              py-2\r
              sm:py-2.5\r
              md:py-3\r
\r
              rounded-lg\r
\r
              whitespace-nowrap\r
\r
              hover:bg-white\r
              hover:text-[#0a1128]\r
\r
              transition-all\r
              duration-300\r
\r
              active:scale-95\r
            `,children:"Talk to Our ERP Experts"})})]}),n.jsx("style",{children:`

        /* ==========================================
           TABLET
        ========================================== */

        @media (max-width: 900px) {

          .tech-hero-content {
            padding-left: 40px;
            padding-right: 40px;
          }

        }


        /* ==========================================
           MOBILE
        ========================================== */

        @media (max-width: 640px) {

          section {
            background-color: #0a1128;
          }

        }


        /* ==========================================
           VERY SMALL MOBILE
        ========================================== */

        @media (max-width: 380px) {

          h1 {
            font-size: 1.5rem;
          }

        }

      `})]})}const y="#730042",c={automate:n.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"#ffffff",strokeWidth:"1.75",strokeLinecap:"round",strokeLinejoin:"round",width:"20",height:"20",children:[n.jsx("circle",{cx:"12",cy:"12",r:"3"}),n.jsx("path",{d:"M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"})]}),understand:n.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"#ffffff",strokeWidth:"1.75",strokeLinecap:"round",strokeLinejoin:"round",width:"20",height:"20",children:[n.jsx("rect",{x:"5",y:"2",width:"14",height:"20",rx:"2"}),n.jsx("path",{d:"M9 7h6M9 11l2 2 4-4"})]}),improve:n.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"#ffffff",strokeWidth:"1.75",strokeLinecap:"round",strokeLinejoin:"round",width:"20",height:"20",children:[n.jsx("polyline",{points:"3 17 9 11 13 15 21 6"}),n.jsx("polyline",{points:"15 6 21 6 21 12"})]}),support:n.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"#ffffff",strokeWidth:"1.75",strokeLinecap:"round",strokeLinejoin:"round",width:"20",height:"20",children:[n.jsx("path",{d:"M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"}),n.jsx("circle",{cx:"10",cy:"7",r:"4"}),n.jsx("path",{d:"M23 21v-2a4 4 0 0 0-3-3.87"}),n.jsx("path",{d:"M16 3.13a4 4 0 0 1 0 7.75"})]})},Z=[{icon:c.automate,title:"Automate",desc:"Reduce repetitive tasks and give your teams more time to focus on important work."},{icon:c.understand,title:"Understand",desc:"Use your business information to see what is working and where there is room to improve."},{icon:c.improve,title:"Improve",desc:"Find ways to make everyday processes faster and more efficient."},{icon:c.support,title:"Support",desc:"Give your teams access to the right information when they need it."}];function nn(){const r=x.useRef(null),[e,t]=x.useState(!1);return x.useEffect(()=>{const a=r.current;if(!a)return;const i=new IntersectionObserver(o=>{o[0].isIntersecting?(t(!1),requestAnimationFrame(()=>{requestAnimationFrame(()=>{t(!0)})})):t(!1)},{threshold:.25});return i.observe(a),()=>i.disconnect()},[]),n.jsxs("section",{ref:r,className:`erp-intelligence-section ${e?"is-visible":""}`,children:[n.jsxs("div",{className:"erp-intelligence-container",children:[n.jsxs("div",{className:"erp-header",children:[n.jsx("p",{className:"erp-label",children:"ERP & INTELLIGENCE"}),n.jsxs("h2",{className:"erp-heading",children:["Get More From"," ",n.jsx("span",{children:"Your Business Data"})]}),n.jsxs("p",{className:"erp-description",children:["Once your business processes and information are connected, you can do more with the data you already have.",n.jsx("br",{className:"desktop-break"}),"From automation and reporting to analytics and intelligent tools, a connected ERP system can help your teams work faster and make more informed decisions."]})]}),n.jsx("div",{className:"erp-intelligence-cards",children:Z.map(({icon:a,title:i,desc:o},s)=>n.jsxs("div",{className:"erp-card",children:[n.jsx("div",{className:"erp-icon",style:{"--icon-delay":`${s*.25}s`},children:a}),n.jsx("p",{className:"erp-card-title",children:i}),n.jsx("p",{className:"erp-card-description",children:o})]},i))})]}),n.jsx("style",{children:`

        /* =================================================
           BASE / DESKTOP
        ================================================= */

        .erp-intelligence-section {
          width: 100%;
          background: #f6f3ec;
          background-image:
            repeating-linear-gradient(
              90deg,
              rgba(0,0,0,0.05) 0px,
              rgba(0,0,0,0.05) 1px,
              transparent 1px,
              transparent 48px
            );
          font-family: "Plus Jakarta Sans", sans-serif;
          padding: 38px 0 48px;
          overflow: hidden;
          box-sizing: border-box;
        }

        /*
          EXACT SAME HORIZONTAL ALIGNMENT AS FOOTER

          Footer:
          px-4
          sm:px-6
          md:px-10
          lg:px-[100px]
        */

        .erp-intelligence-container {
          width: 100%;
          margin: 0;
          padding-left: 100px;
          padding-right: 100px;
          box-sizing: border-box;
          transform: none;
        }

        /* =================================================
           HEADER
        ================================================= */

        .erp-header {
          width: 100%;
          max-width: 950px;
          margin-left: 0;
          box-sizing: border-box;
        }

        .erp-label {
          font-size: 18px;
          font-weight: 700;
          color: #141414;
          letter-spacing: 0.02em;
          margin: -8px 0 12px;
          text-align: left;
        }

        .erp-heading {
          font-size: 32px;
          font-weight: 700;
          line-height: 1.15;
          color: #141414;
          margin: 0 0 16px;
          text-align: left;
        }

        .erp-heading span {
          color: ${y};
        }

        .erp-description {
          font-size: 15px;
          color: #2c2c2c;
          line-height: 1.6;
          margin: 0 0 32px;
          max-width: 820px;
          font-family: "Inter", sans-serif;
          text-align: left;
        }

        /* =================================================
           CARDS
        ================================================= */

        .erp-intelligence-cards {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 28px;
          width: 100%;
          margin-left: 0;
          box-sizing: border-box;
          transform: none;
        }

        .erp-card {
          width: 100%;
          min-width: 0;
          min-height: 250px;
          background: #ffffff;
          padding: 32px;
          box-sizing: border-box;
          display: flex;
          flex-direction: column;
          border-radius: 16px;
          box-shadow:
            0 10px 28px rgba(20, 20, 20, 0.05);
        }

        /* =================================================
           ICON
        ================================================= */

        .erp-icon {
          width: 50px;
          height: 50px;
          min-width: 50px;
          border-radius: 50%;
          background: ${y};
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 22px;

          opacity: 0;

          transform:
            translateY(35px)
            scale(0.65);

          transition:
            opacity 0.6s ease,
            transform 0.8s cubic-bezier(0.16, 1, 0.3, 1);

          transition-delay: var(--icon-delay);

          will-change:
            transform,
            opacity;
        }

        /* =================================================
           ICON ANIMATION
        ================================================= */

        .erp-intelligence-section.is-visible .erp-icon {
          opacity: 1;

          transform:
            translateY(0)
            scale(1);
        }

        /* =================================================
           CARD TITLE
        ================================================= */

        .erp-card-title {
          font-size: 20px;
          font-weight: 600;
          color: #141414;
          margin: 0 0 10px;
          line-height: 1.2;
        }

        /* =================================================
           CARD DESCRIPTION
        ================================================= */

        .erp-card-description {
          font-size: 13.5px;
          font-family: "Inter", sans-serif;
          color: #3a3a3a;
          line-height: 1.5;
          margin: 0;
        }

        /* =================================================
           LARGE TABLET
        ================================================= */

        @media (max-width: 1200px) {

          .erp-intelligence-container {
            padding-left: 70px;
            padding-right: 70px;
          }

          .erp-intelligence-cards {
            width: 100%;
            gap: 22px;
          }

          .erp-card {
            padding: 28px;
            min-height: 250px;
          }

          .erp-card-title {
            font-size: 20px;
          }

          .erp-card-description {
            font-size: 14px;
          }

          .erp-icon {
            width: 54px;
            height: 54px;
            min-width: 54px;
          }

          .erp-icon svg {
            width: 20px;
            height: 20px;
          }
        }

        /* =================================================
           TABLET
        ================================================= */

        @media (max-width: 900px) {

          .erp-intelligence-section {
            padding: 36px 0 44px !important;
          }

          /*
            Footer-style tablet spacing
            md = 40px
          */

          .erp-intelligence-container {
            padding-left: 40px;
            padding-right: 40px;
          }

          .erp-header {
            width: 100%;
            max-width: 800px;
            margin-left: 0;
          }

          .erp-label {
            font-size: 21px;
          }

          .erp-heading {
            font-size: 29px;
          }

          .erp-description {
            font-size: 15px;
            max-width: 700px;
          }

          .erp-intelligence-cards {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            width: 100%;
            gap: 20px;
            margin-left: 0;
          }

          .erp-card {
            min-height: 240px;
            padding: 26px 24px;
            border-radius: 14px;
          }

          .erp-icon {
            width: 54px;
            height: 54px;
            min-width: 54px;
            margin-bottom: 20px;
          }

          .erp-icon svg {
            width: 20px;
            height: 20px;
          }

          .erp-card-title {
            font-size: 20px;
          }

          .erp-card-description {
            font-size: 14px;
          }
        }

        /* =================================================
           SMALL TABLET
        ================================================= */

        @media (max-width: 768px) {

          .erp-intelligence-section {
            padding: 32px 0 40px !important;
          }

          .erp-intelligence-container {
            padding-left: 20px;
            padding-right: 20px;
          }

          .erp-header {
            max-width: 100%;
            margin-left: 0;
            margin-right: 0;
          }

          .erp-label {
            font-size: 20px;
            margin: 0 0 10px;
            text-align: left;
          }

          .erp-heading {
            font-size: 28px;
            line-height: 1.2;
            margin: 0 0 14px;
            text-align: left;
          }

          .erp-description {
            font-size: 15px;
            line-height: 1.55;
            margin: 0 0 28px;
            max-width: 100%;
          }

          .erp-intelligence-cards {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            width: 100%;
            gap: 18px;
            margin-left: 0;
          }

          .erp-card {
            min-height: 230px;
            padding: 25px 22px;
          }

          .erp-icon {
            width: 54px;
            height: 54px;
            min-width: 54px;
            margin-bottom: 18px;
          }

          .erp-icon svg {
            width: 20px;
            height: 20px;
          }

          .erp-card-title {
            font-size: 19px;
            margin-bottom: 8px;
          }

          .erp-card-description {
            font-size: 14px;
            line-height: 1.5;
          }
        }

        /* =================================================
           MOBILE
        ================================================= */

        @media (max-width: 600px) {

          .erp-intelligence-section {
            padding: 28px 0 36px !important;
          }

          /*
            EXACT FOOTER MOBILE ALIGNMENT
            Footer uses px-4 = 16px
          */

          .erp-intelligence-container {
            padding-left: 16px;
            padding-right: 16px;
          }

          .erp-header {
            width: 100%;
            margin: 0;
          }

          .erp-label {
            font-size: 18px;
            line-height: 1.3;
            margin: 0 0 9px;
          }

          .erp-heading {
            font-size: 25px;
            line-height: 1.2;
            margin: 0 0 13px;
          }

          .erp-description {
            font-size: 14px;
            line-height: 1.55;
            margin: 0 0 24px;
            max-width: 100%;
          }

          .desktop-break {
            display: none;
          }

          /* ONE CARD PER ROW */

          .erp-intelligence-cards {
            display: grid;
            grid-template-columns: 1fr;
            width: 100%;
            gap: 16px;
            margin-left: 0;
          }

          .erp-card {
            width: 100%;
            min-height: auto;
            padding: 24px 20px;
            border-radius: 14px;
          }

          .erp-icon {
            width: 54px;
            height: 54px;
            min-width: 54px;
            margin-bottom: 17px;
          }

          .erp-icon svg {
            width: 20px;
            height: 20px;
          }

          .erp-card-title {
            font-size: 19px;
            line-height: 1.2;
            margin-bottom: 8px;
          }

          .erp-card-description {
            font-size: 14px;
            line-height: 1.5;
          }
        }

        /* =================================================
           VERY SMALL MOBILE
        ================================================= */

        @media (max-width: 400px) {

          .erp-intelligence-container {
            padding-left: 14px;
            padding-right: 14px;
          }

          .erp-label {
            font-size: 17px;
          }

          .erp-heading {
            font-size: 23px;
          }

          .erp-description {
            font-size: 13.5px;
          }

          .erp-card {
            padding: 22px 18px;
          }

          .erp-icon {
            width: 54px;
            height: 54px;
            min-width: 54px;
          }

          .erp-icon svg {
            width: 19px;
            height: 19px;
          }

          .erp-card-title {
            font-size: 18px;
          }

          .erp-card-description {
            font-size: 13.5px;
          }
        }

        /* =================================================
           REDUCED MOTION
        ================================================= */

        @media (prefers-reduced-motion: reduce) {

          .erp-icon {
            transition: none !important;
            opacity: 1 !important;
            transform: none !important;
          }
        }

      `})]})}function dn(){return n.jsxs(n.Fragment,{children:[n.jsx(H,{}),n.jsx(X,{}),n.jsx(K,{}),n.jsx(V,{}),n.jsx(Q,{}),n.jsx(nn,{})]})}export{X as ERPApproach,H as ErpHero,nn as ErpIntelligence,K as OnePlatformSection,V as PracticalERPPath,Q as TechHero,dn as default};
