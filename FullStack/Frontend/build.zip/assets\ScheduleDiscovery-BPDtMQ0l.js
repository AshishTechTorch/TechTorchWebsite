import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as l}from"./vendor-router-L4ZCoGSs.js";import{F as C,s as z,a as D}from"./FormNotice-OE790tVc.js";import{a2 as v,A,r as T,Z as F}from"./index-37hjU4u5.js";function B(){const[s,r]=l.useState(""),[n,x]=l.useState(""),[u,b]=l.useState(""),[w,f]=l.useState(!1),[a,y]=l.useState({sis:!1,admissions:!1,academic:!1,campus:!1,tuition:!1,analytics:!1}),c=t=>{y(o=>({...o,[t]:!o[t]}))},[j,N]=l.useState(!1),[k,d]=l.useState(""),S=async t=>{if(t.preventDefault(),j)return;const o=t.currentTarget;if(!o.checkValidity()){const i=o.querySelector(":invalid");i&&(i.focus(),o.reportValidity(),setTimeout(()=>{i.blur()},43e3));return}if(!s){d("Please select your institution type.");return}if(!n){d("Please select your student count / scale.");return}if(!Object.values(a).some(Boolean)){d("Please select at least one area of interest.");return}if(!u){d("Please select your expected timeline.");return}const E=new FormData(o),p=i=>(E.get(i)||"").toString().trim(),I={sis:"Student Information System (SIS)",admissions:"Admissions & Enrollment Automation",academic:"Academic Management & Grading",campus:"Campus Operations & Attendance",tuition:"Tuition & Financial Operations",analytics:"Analytics & Institutional Reporting"};d(""),N(!0);try{await z("education",{institutionName:p("institutionName"),institutionType:s,studentScale:n,areasOfInterest:Object.keys(a).filter(i=>a[i]).map(i=>I[i]),fullName:p("fullName"),officialEmail:p("officialEmail"),designation:p("designation"),phone:p("phone"),expectedTimeline:u,additionalNotes:p("additionalNotes"),confidentialityConsent:E.get("consent")==="on"}),f(!0),setTimeout(()=>{f(!1)},3e3),o.reset(),r(""),x(""),b(""),y({sis:!1,admissions:!1,academic:!1,campus:!1,tuition:!1,analytics:!1})}catch(i){d(D(i))}finally{N(!1)}};return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`

        .discovery-page {
          min-height: 100vh;
          width: 100%;
          background: #F6F7F8;
          padding: 40px 100px;
          font-family: "Inter", sans-serif;
          overflow-x: hidden;
        }

        .discovery-wrapper {
          width: 100%;
          max-width: 900px;
          margin: 0 auto;
        }

        /* ================================
           SUCCESS DIALOG
        ================================= */

       .success-dialog {
  position: fixed;
  top: 24px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 9999;

  width: min(420px, calc(100% - 32px));

  display: flex;
  align-items: center;
  gap: 14px;

  padding: 16px 20px;

  background: #ffffff;
  border: 1px solid #E5D3DC;
  border-radius: 10px;

  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);

  font-family: "Inter", sans-serif;

  animation: successDialogIn 0.25s ease-out;
}

       .success-dialog-icon {
  width: 34px;
  height: 34px;
  flex-shrink: 0;

  display: flex;
  align-items: center;
  justify-content: center;

  border-radius: 50%;
  background: #ffffff;
  color: #22824D;

  border: none;
}

        .success-dialog-content {
          min-width: 0;
        }

        .success-dialog-title {
          margin: 0;

          color: #202022;
          font-family: "Inter", sans-serif;
          font-size: 14px;
          font-weight: 700;
          line-height: 1.4;
        }

        .success-dialog-text {
          margin: 2px 0 0;

          color: #65595E;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 400;
          line-height: 1.5;
        }
          .success-dialog-ok {
  width: 34px;
  height: 34px;

  margin-left: auto;
  flex-shrink: 0;

  display: flex;
  align-items: center;
  justify-content: center;

  padding: 0;

  border: none;
  border-radius: 50%;

  background: #730042;
  color: #ffffff;

  font-family: "Inter", sans-serif;
  font-size: 10px;
  font-weight: 600;

  cursor: pointer;

  transition: background 0.2s ease, transform 0.2s ease;
}

.success-dialog-ok:hover {
  background: #620038;
  transform: scale(1.05);
}

        @keyframes successDialogIn {
          from {
            opacity: 0;
            transform: translate(-50%, -12px);
          }

          to {
            opacity: 1;
            transform: translate(-50%, 0);
          }
        }

        /* ================================
           PAGE HEADER
        ================================= */

        .discovery-header {
          width: 100%;
          text-align: center;
          margin: 0 auto;
        }

        .discovery-eyebrow {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          border: 1px solid #E4D4DC;
          background: #F8F1F4;
          padding: 6px 14px;
          border-radius: 999px;
          color: #730042;
          font-family: "Inter", sans-serif;
          font-size: 10px;
          font-weight: 600;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          line-height: 1.4;
        }

        .discovery-eyebrow-dot {
          width: 7px;
          height: 7px;
          flex-shrink: 0;
          border-radius: 50%;
          background: #730042;
        }

        /*
          MAIN HEADING
          Plus Jakarta Sans
        */

        .discovery-heading {
          margin: 16px auto 0;
          max-width: 800px;
          color: #171719;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 36px;
          font-weight: 600;
          line-height: 1.12;
          letter-spacing: -0.04em;
        }

        /*
          SUBHEADING
          Plus Jakarta Sans
        */

        .discovery-subheading {
          margin: 10px auto 0;
          max-width: 700px;
          color: #65595E;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 14px;
          font-weight: 500;
          line-height: 1.6;
        }

        /* ================================
           FORM
        ================================= */

        .discovery-form {
          width: 100%;
          margin-top: 28px;
          padding: 36px 40px;
          background: #ffffff;
          border: 1px solid #DDE2E6;
          border-radius: 10px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
        }

        /* ================================
           SECTION HEADER
        ================================= */

        .form-section-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding-bottom: 10px;
          border-bottom: 1px solid #E2E5E7;
        }

        .form-section-left {
          display: flex;
          align-items: center;
          gap: 10px;
          min-width: 0;
        }

        .form-section-number {
          width: 28px;
          height: 28px;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          background: #FFDDE7;
          color: #730042;
          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 700;
        }

        /*
          SECTION HEADING
          Plus Jakarta Sans
        */

        .form-section-title {
          margin: 0;
          color: #202022;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 16px;
          font-weight: 600;
          line-height: 1.4;
        }

        .form-section-right {
          flex-shrink: 0;
          color: #64575D;
          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 600;
          text-align: right;
        }

        /* ================================
           FIELD
        ================================= */

        .form-field {
          margin-top: 20px;
        }

        .form-label {
          display: block;
          color: #29292B;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 600;
          line-height: 1.4;
          text-transform: uppercase;
          letter-spacing: 0.01em;
        }

        .form-label span {
          color: #730042;
        }

        .form-input,
        .form-textarea {
          width: 100%;
          border: 1px solid #E2E5E8;
          background: #ECEFF1;
          color: #29292B;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          outline: none;
          transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }

        .form-input {
          height: 40px;
          margin-top: 10px;
          padding: 0 14px;
          border-radius: 7px;
        }

        .form-textarea {
          height: 105px;
          margin-top: 10px;
          padding: 12px 16px;
          border-radius: 8px;
          resize: none;
          line-height: 1.7;
        }

        .form-input::placeholder,
        .form-textarea::placeholder {
          color: #A28F96;
        }

        .form-input:focus,
        .form-textarea:focus {
          border-color: #730042;
          box-shadow: 0 0 0 1px #E8D6DF;
        }

        /* ================================
           CHOICE GRID
        ================================= */

        .choice-grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 8px;
          margin-top: 10px;
        }

        .timeline-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 8px;
          margin-top: 10px;
        }

        .choice-button {
          min-height: 48px;
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 8px 10px;
          border-radius: 7px;
          border: 1px solid #E2E5E8;
          background: #ECEFF1;
          color: #29292B;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 500;
          line-height: 1.5;
          text-align: center;
          cursor: pointer;
          transition:
            border-color 0.15s ease,
            background 0.15s ease,
            color 0.15s ease;
        }

        .choice-button:hover {
          border-color: #730042;
          background: #F5E5ED;
        }

        .choice-button.selected {
          border-color: #730042;
          background: #F5E5ED;
          color: #730042;
          box-shadow: inset 0 0 0 1px #730042;
        }

        /* ================================
           INTEREST SECTION
        ================================= */

        .interest-section {
          margin-top: 28px;
        }

        .interest-grid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 8px;
          margin-top: 12px;
        }

        .interest-card {
          width: 100%;
          min-height: 57px;
          display: flex;
          align-items: flex-start;
          gap: 12px;
          padding: 10px 12px;
          border: 1px solid #E2E5E8;
          border-radius: 9px;
          background: #ECEFF1;
          color: #29292B;
          font-family: "Inter", sans-serif;
          text-align: left;
          cursor: pointer;
          transition:
            border-color 0.15s ease,
            background 0.15s ease;
        }

        .interest-card:hover {
          border-color: #D3D6D9;
          background: #E9EBED;
        }

        .interest-checkbox {
          width: 14px;
          height: 14px;
          flex-shrink: 0;
          margin-top: 2px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 2px;
          background: #ffffff;
        }

        .interest-checkbox.selected {
          background: #730042;
        }

        .interest-content {
          min-width: 0;
        }

        .interest-title {
          display: block;
          color: #262527;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.4;
        }

        .interest-description {
          display: block;
          margin-top: 2px;
          color: #65595E;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 400;
          line-height: 1.5;
        }

        /* ================================
           CONTACT SECTION
        ================================= */

        .contact-section {
          margin-top: 28px;
        }

        .contact-grid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 16px;
          margin-top: 16px;
        }

        /* ================================
           CONSENT
        ================================= */

        .consent-section {
          margin-top: 20px;
          padding-top: 16px;
          border-top: 1px solid #E4E6E8;
        }

        .consent-label {
          display: flex;
          align-items: flex-start;
          gap: 12px;
          cursor: pointer;
        }

        .consent-checkbox {
          width: 14px;
          height: 14px;
          flex-shrink: 0;
          margin-top: 4px;
          accent-color: #730042;
        }

        .consent-text {
          color: #65595E;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          line-height: 1.7;
        }

        /* ================================
           SUBMIT
        ================================= */

        .submit-button {
          width: 100%;
          height: 46px;
          margin-top: 20px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 12px;
          padding: 0 20px;
          border: none;
          border-radius: 9px;
          background: #730042;
          color: #ffffff;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 600;
          letter-spacing: 0.01em;
          text-transform: uppercase;
          cursor: pointer;
          box-shadow: 0 3px 8px rgba(115, 0, 66, 0.18);
          transition:
            background 0.2s ease,
            box-shadow 0.2s ease;
        }

        .submit-button:hover {
          background: #620038;
          box-shadow: 0 5px 12px rgba(115, 0, 66, 0.22);
        }

        .submit-arrow {
          transition: transform 0.2s ease;
        }

        .submit-button:hover .submit-arrow {
          transform: translateX(4px);
        }

        /* ================================
           TRUST INDICATORS
        ================================= */

        .trust-indicators {
          margin-top: 16px;
          display: flex;
          flex-wrap: wrap;
          align-items: center;
          justify-content: center;
          gap: 8px 20px;
          color: #564D51;
          font-family: "Inter", sans-serif;
          font-size: 9px;
          font-weight: 500;
        }

        .trust-item {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .trust-icon {
          color: #22824D;
        }

        .trust-dot {
          color: #C8A5B7;
        }

        /* ================================
           LARGE TABLET
        ================================= */

        @media (max-width: 1100px) {
          .discovery-page {
            padding: 40px 60px;
          }

          .discovery-heading {
            font-size: 34px;
          }

          .discovery-form {
            padding: 32px;
          }
        }

        /* ================================
           TABLET
        ================================= */

        @media (max-width: 900px) {
          .discovery-page {
            padding: 36px 40px;
          }

          .discovery-heading {
            font-size: 32px;
          }

          .discovery-form {
            margin-top: 24px;
            padding: 30px;
          }

          .choice-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .interest-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }
        }

        /* ================================
           MOBILE
        ================================= */

        @media (max-width: 640px) {
          .discovery-page {
            padding: 28px 20px 40px;
          }

          .success-dialog {
            top: 16px;
            width: calc(100% - 28px);
            padding: 14px 16px;
          }

          .success-dialog-title {
            font-size: 13px;
          }

          .success-dialog-text {
            font-size: 11px;
          }

          .discovery-eyebrow {
            max-width: 100%;
            padding: 6px 11px;
            font-size: 9px;
            letter-spacing: 0.08em;
          }

          .discovery-heading {
            margin-top: 14px;
            font-size: 28px;
            line-height: 1.16;
          }

          .discovery-subheading {
            margin-top: 9px;
            font-size: 13px;
            line-height: 1.65;
          }

          .discovery-form {
            margin-top: 22px;
            padding: 24px 18px;
            border-radius: 9px;
          }

          .form-section-header {
            align-items: flex-start;
          }

          .form-section-title {
            font-size: 15px;
          }

          .form-section-right {
            font-size: 9px;
          }

          .form-field {
            margin-top: 18px;
          }

          .form-label {
            font-size: 11px;
          }

          .choice-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .choice-button {
            min-height: 46px;
            font-size: 10px;
            padding: 7px 8px;
          }

          .interest-grid {
            grid-template-columns: 1fr;
          }

          .contact-grid {
            grid-template-columns: 1fr;
            gap: 14px;
          }

          .timeline-grid {
            grid-template-columns: 1fr;
          }

          .consent-text {
            font-size: 11px;
            line-height: 1.65;
          }

          .trust-indicators {
            gap: 8px 14px;
            font-size: 8px;
          }
        }

        /* ================================
           SMALL MOBILE
        ================================= */

        @media (max-width: 400px) {
          .discovery-page {
            padding: 24px 14px 32px;
          }

          .discovery-eyebrow {
            font-size: 8px;
          }

          .discovery-heading {
            font-size: 24px;
            letter-spacing: -0.035em;
          }

          .discovery-subheading {
            font-size: 12px;
          }

          .discovery-form {
            padding: 20px 14px;
          }

          .form-section-left {
            gap: 8px;
          }

          .form-section-number {
            width: 26px;
            height: 26px;
            font-size: 10px;
          }

          .form-section-title {
            font-size: 14px;
          }

          .form-section-right {
            font-size: 8px;
          }

          .choice-button {
            min-height: 44px;
            font-size: 9px;
          }

          .interest-card {
            padding: 9px 10px;
          }

          .interest-title {
            font-size: 11px;
          }

          .interest-description {
            font-size: 9px;
          }

          .submit-button {
            height: 44px;
            font-size: 10px;
          }

          .trust-indicators {
            flex-direction: column;
            gap: 7px;
          }

          .trust-dot {
            display: none;
          }
        }

        /* ================================
           REDUCED MOTION
        ================================= */

        @media (prefers-reduced-motion: reduce) {
          .form-input,
          .form-textarea,
          .choice-button,
          .interest-card,
          .submit-button,
          .submit-arrow,
          .success-dialog {
            transition: none;
            animation: none;
          }
        }
      `}),e.jsxs("main",{className:"discovery-page",children:[w&&e.jsxs("div",{className:"success-dialog",role:"alert","aria-live":"polite",tabIndex:-1,onKeyDown:t=>{t.key==="Enter"&&(t.preventDefault(),f(!1))},children:[e.jsx("div",{className:"success-dialog-icon",children:e.jsx(v,{size:21})}),e.jsxs("div",{className:"success-dialog-content",children:[e.jsx("p",{className:"success-dialog-title",children:"Request Submitted"}),e.jsx("p",{className:"success-dialog-text",children:"Your consultation request has been submitted successfully."})]}),e.jsx("button",{type:"button",className:"success-dialog-ok",onClick:()=>f(!1),autoFocus:!0,"aria-label":"Close",children:"OK"})]}),e.jsxs("div",{className:"discovery-wrapper",children:[e.jsxs("div",{className:"discovery-header",children:[e.jsxs("div",{className:"discovery-eyebrow",children:[e.jsx("span",{className:"discovery-eyebrow-dot"}),e.jsx("span",{children:"TechTorch Education · Consultation Request"})]}),e.jsx("h1",{className:"discovery-heading",children:"Schedule Education Discovery Session"}),e.jsx("p",{className:"discovery-subheading",children:"Connect with our education technology architects to evaluate your institution's digital ecosystem and roadmap."})]}),e.jsxs("form",{onSubmit:S,className:"discovery-form",children:[e.jsx(h,{number:"01",title:"Institution Details",rightText:"PROFILE & SCALE"}),e.jsxs("div",{className:"form-field",children:[e.jsxs("label",{className:"form-label",children:["Institution Name ",e.jsx("span",{children:"*"})]}),e.jsx("input",{type:"text",name:"institutionName",placeholder:"e.g. Cambridge Global University",required:!0,className:"form-input"})]}),e.jsxs("div",{className:"form-field",children:[e.jsxs("label",{className:"form-label",children:["Institution Type ",e.jsx("span",{children:"*"})]}),e.jsx("div",{className:"choice-grid",children:["Higher Ed / University","College / Institute","Multi-Campus Network","K-12 Academy"].map(t=>e.jsx(g,{selected:s===t,onClick:()=>r(t),children:t},t))})]}),e.jsxs("div",{className:"form-field",children:[e.jsxs("label",{className:"form-label",children:["Current Student Count / Scale ",e.jsx("span",{children:"*"})]}),e.jsx("div",{className:"choice-grid",children:["Under 2,000","2,000 - 10,000","10,000 - 25,000","25,000+"].map(t=>e.jsx(g,{selected:n===t,onClick:()=>x(t),children:t},t))})]}),e.jsxs("div",{className:"interest-section",children:[e.jsx(h,{number:"02",title:"Areas of Interest / Scope",rightText:"SELECT PRIORITIES"}),e.jsxs("div",{className:"interest-grid",children:[e.jsx(m,{selected:a.sis,onClick:()=>c("sis"),title:"Student Information System (SIS)",description:"Centralized records, enrollment logs, student portals"}),e.jsx(m,{selected:a.admissions,onClick:()=>c("admissions"),title:"Admissions & Enrollment Automation",description:"Applicant intake pipelines, fee collection, verification"}),e.jsx(m,{selected:a.academic,onClick:()=>c("academic"),title:"Academic Management & Grading",description:"Course scheduling, grading matrices, LMS integration"}),e.jsx(m,{selected:a.campus,onClick:()=>c("campus"),title:"Campus Operations & Attendance",description:"Smart attendance tracking, biometric & card IoT check-ins"}),e.jsx(m,{selected:a.tuition,onClick:()=>c("tuition"),title:"Tuition & Financial Operations",description:"Tuition billing, financial aid reconciliation, ERP connections"}),e.jsx(m,{selected:a.analytics,onClick:()=>c("analytics"),title:"Analytics & Institutional Reporting",description:"Retention alerts, health dashboards, audit trails"})]})]}),e.jsxs("div",{className:"contact-section",children:[e.jsx(h,{number:"03",title:"Contact Person Details",rightText:"STAKEHOLDER PROFILE"}),e.jsxs("div",{className:"contact-grid",children:[e.jsxs("div",{children:[e.jsxs("label",{className:"form-label",children:["Full Name ",e.jsx("span",{children:"*"})]}),e.jsx("input",{type:"text",name:"fullName",placeholder:"Dr. Sarah Jenkins",required:!0,className:"form-input"})]}),e.jsxs("div",{children:[e.jsxs("label",{className:"form-label",children:["Official / Institutional Email ",e.jsx("span",{children:"*"})]}),e.jsx("input",{type:"email",name:"officialEmail",placeholder:"sjenkins@institution.edu",required:!0,className:"form-input"})]}),e.jsxs("div",{children:[e.jsxs("label",{className:"form-label",children:["Designation / Role ",e.jsx("span",{children:"*"})]}),e.jsx("input",{type:"text",name:"designation",placeholder:"e.g. Provost, CIO, Registrar, Dean, Director of IT",required:!0,className:"form-input"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"form-label",children:"Phone / WhatsApp Number"}),e.jsx("input",{type:"tel",name:"phone",placeholder:"+1 (555) 382-9011",className:"form-input"})]})]}),e.jsxs("div",{className:"form-field",children:[e.jsxs("label",{className:"form-label",children:["Expected Timeline ",e.jsx("span",{children:"*"})]}),e.jsx("div",{className:"timeline-grid",children:["Immediate / Within 1 Month","1 - 3 Months","Exploratory / Budget Planning"].map(t=>e.jsx(g,{selected:u===t,onClick:()=>b(t),children:t},t))})]}),e.jsxs("div",{className:"form-field",children:[e.jsx("label",{className:"form-label",children:"Additional Notes / Challenges (Optional)"}),e.jsx("textarea",{rows:3,name:"additionalNotes",placeholder:"Share any key friction points, current tech stack challenges, or specific deployment goals...",className:"form-textarea"})]})]}),e.jsx("div",{className:"consent-section",children:e.jsxs("label",{className:"consent-label",children:[e.jsx("input",{type:"checkbox",name:"consent",required:!0,className:"consent-checkbox"}),e.jsx("span",{className:"consent-text",children:"I confirm this request is made on behalf of an educational institution. I agree to bilateral non-disclosure terms and confidentiality assurance for all shared architecture data."})]})}),e.jsx(C,{error:k}),e.jsxs("button",{type:"submit",disabled:j,className:"submit-button",children:["Submit Consultation Request",e.jsx(A,{size:17,className:"submit-arrow"})]}),e.jsxs("div",{className:"trust-indicators",children:[e.jsxs("span",{className:"trust-item",children:[e.jsx(T,{size:12,className:"trust-icon"}),"Strict NDA Protected"]}),e.jsx("span",{className:"trust-dot",children:"•"}),e.jsxs("span",{className:"trust-item",children:[e.jsx(F,{size:12,className:"trust-icon"}),"24h Architect Response"]}),e.jsx("span",{className:"trust-dot",children:"•"}),e.jsxs("span",{className:"trust-item",children:[e.jsx(v,{size:12,className:"trust-icon"}),"Zero Obligation Evaluation"]})]})]})]})]})]})}function h({number:s,title:r,rightText:n}){return e.jsxs("div",{className:"form-section-header",children:[e.jsxs("div",{className:"form-section-left",children:[e.jsx("div",{className:"form-section-number",children:s}),e.jsx("h2",{className:"form-section-title",children:r})]}),e.jsx("span",{className:"form-section-right",children:n})]})}function g({children:s,selected:r,onClick:n}){return e.jsx("button",{type:"button",onClick:n,className:`choice-button ${r?"selected":""}`,children:s})}function m({selected:s,onClick:r,title:n,description:x}){return e.jsxs("button",{type:"button",onClick:r,className:"interest-card",children:[e.jsx("span",{className:`interest-checkbox ${s?"selected":""}`,children:s&&e.jsx("svg",{viewBox:"0 0 20 20",className:"h-2.5 w-2.5 text-white",fill:"currentColor",children:e.jsx("path",{fillRule:"evenodd",d:"M16.704 5.296a1 1 0 010 1.414l-7.5 7.5a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8.5 12.086l6.793-6.79a1 1 0 011.411 0z",clipRule:"evenodd"})})}),e.jsxs("span",{className:"interest-content",children:[e.jsx("span",{className:"interest-title",children:n}),e.jsx("span",{className:"interest-description",children:x})]})]})}export{B as default};
