import{j as e}from"./vendor-query-PraSc8EQ.js";import{d as T,r as m}from"./vendor-router-L4ZCoGSs.js";import{t as z,A as y,a8 as E}from"./index-37hjU4u5.js";import{U as A}from"./user-BusR5MVP.js";import{B as P}from"./briefcase-business-D4kLSYLp.js";import{C as I}from"./calendar-days-CqohBNRW.js";import{M as D}from"./mail-CbeZpzUl.js";import{P as O}from"./phone-D3JbSBfc.js";import{M}from"./map-pin-B0tD-pH2.js";import{C as R}from"./clock-3-BIKamG4f.js";const w={name:"message-circle-question-mark",size:24,node:[["path",{d:"M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",key:"1sd12s"}],["path",{d:"M9 9.5a3 2.5 0 016 0c0 2-2 2-3 3.5",key:"1awbb0"}],["path",{d:"M12 17h.01",key:"p32p05"}]],aliases:["message-circle-question"]};w.node;const B=z(w);function _(){const k=T(),[u,g]=m.useState("email"),b={fullName:"",email:"",company:"",phone:"",service:"",requirement:"",stage:"",timeline:"",nda:!1},[s,v]=m.useState(b),[a,x]=m.useState({}),[h,j]=m.useState(!1),[l,d]=m.useState({type:"",message:""}),N={"Software Development":"Software Development","Digital Transformation":"Digital Transformation","ERP Solutions":"ERP & Business Processes","AI & Cloud Solutions":"Cloud Solutions",Cybersecurity:"Technology Support","IT Consulting":"Technology Consulting"},S={email:"Email",phone:"Phone Call",video:"Online Meeting"},q=n=>{const i={},t=n.fullName.trim();t?/^[A-Za-zÀ-ÖØ-öø-ÿ .'-]+$/.test(t)||(i.fullName="Enter a valid name."):i.fullName="Full name is required.";const o=n.email.trim();o?/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(o)||(i.email="Please enter a valid email address."):i.email="Work email is required.";const c=n.phone.trim();c&&!/^[6-9]\d{9}$/.test(c)&&(i.phone="Enter a valid 10-digit mobile number."),n.service||(i.service="Please select a service.");const p=n.requirement.trim();return p?p.length>500&&(i.requirement="Requirement must be 500 characters or fewer."):i.requirement="Please describe your requirement.",i},r=n=>{const{name:i,value:t,type:o,checked:c}=n.target;let p=o==="checkbox"?c:t;i==="phone"&&(p=t.replace(/\D/g,"").slice(0,10)),v(f=>({...f,[i]:p})),a[i]&&x(f=>({...f,[i]:""})),l.message&&d({type:"",message:""})},C=async n=>{if(n.preventDefault(),h)return;const i=q(s);if(x(i),Object.keys(i).length){d({type:"error",message:"Please fix the highlighted fields and try again."});return}const t=s.service;let o=s.requirement.trim();N[t]!==t&&(o=`Service of interest: ${t}

${o}`),s.nda&&(o+=`

NDA: Please share a draft Bilateral Mutual NDA prior to technical architecture discussion.`),j(!0),d({type:"",message:""});try{await E.general({fullName:s.fullName.trim(),businessEmail:s.email.trim(),phoneNumber:s.phone.trim(),companyOrganization:s.company.trim()||"Not specified",areaOfInterest:N[t]||t,requirement:o,projectStage:s.stage,timeline:s.timeline,preferredContactMethod:S[u],contactConsent:!0}),v(b),x({}),g("email"),d({type:"success",message:"Thank you! Your enquiry has been sent. Our team will get back to you shortly."})}catch(c){d({type:"error",message:c.message||"Could not send your enquiry. Please try again."})}finally{j(!1)}};return e.jsxs("div",{className:"conversation-page",children:[e.jsx("style",{children:`

        * {
          box-sizing: border-box;
        }

        .conversation-page {
          width: 100%;
          min-height: 100vh;
          overflow-x: hidden;
          background: #ffffff;
          color: #151b2b;
          font-family: "Inter", sans-serif;
        }

        .conversation-container {
          width: min(1200px, calc(100% - 50px));
          margin: 0 auto;
        }

        /* HEADINGS - PLUS JAKARTA SANS */

        .conversation-heading,
        .conversation-eyebrow,
        .form-section-title h3,
        .steps-title,
        .step-title,
        .quick-title,
        .channels-title,
        .office-title {
          font-family: "Plus Jakarta Sans", sans-serif;
        }

        /* BODY / BUTTONS - INTER */

        .conversation-page,
        .conversation-text,
        button,
        input,
        select,
        textarea,
        .form-label,
        .connect-option,
        .nda-label,
        .privacy-note,
        .conversation-submit,
        .quick-button,
        .channel-name,
        .channel-value,
        .channel-subvalue,
        .office-address,
        .business-hours {
          font-family: "Inter", sans-serif;
        }

        .conversation-heading {
          margin: 0;
          color: #151b2b;
          font-weight: 700;
          letter-spacing: -0.65px;
        }

        .conversation-text {
          margin: 0;
          color: #687184;
          line-height: 1.6;
        }

        .conversation-eyebrow {
          margin: 0 0 9px;
          color: #730042;
          font-size: 12px;
          font-weight: 700;
          letter-spacing: 0.5px;
          text-transform: uppercase;
        }

        /* INTRO */

        .conversation-intro {
          padding: 52px 0 42px;
          background: #ffffff;
        }

        .conversation-main-title {
         font-size: 38px;
          line-height: 1.08;
        }

        .conversation-main-description {
          max-width: 900px;
          margin-top: 16px;
          color: #5e6a7e;
          font-size: 15px;
          line-height: 1.65;
        }

        /* MAIN */

        .conversation-content {
          display: grid;
          grid-template-columns: minmax(0, 1.35fr) minmax(320px, 0.8fr);
          align-items: start;
          gap: 44px;
          padding: 8px 0 72px;
        }

        /* FORM CARD */

        .conversation-form-card {
          padding: 30px;
          border: 1px solid #e3e7ed;
          border-radius: 17px;
          background: #ffffff;
          box-shadow: 0 4px 14px rgba(20, 30, 45, 0.035);
        }

        .form-card-title {
          margin-top: 3px;
          font-size: 25px;
          line-height: 1.2;
        }

        .form-card-description {
          max-width: 720px;
          margin-top: 5px;
          font-size: 14px;
          line-height: 1.55;
        }

        .form-separator {
          width: 100%;
          height: 1px;
          margin: 18px 0 23px;
          background: #edf0f3;
        }

        /* SECTION TITLES */

        .form-section-title {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 14px;
        }

        .form-section-icon {
          width: 29px;
          height: 29px;
          border-radius: 7px;
          background: #f9edf4;
          color: #730042;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .form-section-icon svg {
          width: 15px;
          height: 15px;
        }

        .form-section-title h3 {
          margin: 0;
          color: #1c2434;
          font-size: 14px;
          font-weight: 700;
        }

        /* FORM */

        .details-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 17px 16px;
        }

        .form-field {
          min-width: 0;
        }

        .form-label {
          display: block;
          margin-bottom: 7px;
          color: #374153;
          font-size: 13px;
          line-height: 1.4;
          font-weight: 600;
        }

        .required {
          color: #730042;
        }

        .conversation-input,
        .conversation-select,
        .conversation-textarea {
          width: 100%;
          border: 1px solid #d6dfe9;
          border-radius: 7px;
          outline: none;
          background: #ffffff;
          color: #313b4d;
          font-size: 13px;
          transition: 0.2s ease;
        }

        .conversation-input,
        .conversation-select {
          height: 39px;
          padding: 0 12px;
        }

        .conversation-textarea {
          min-height: 94px;
          padding: 11px 12px;
          resize: vertical;
        }

        .conversation-input::placeholder,
        .conversation-textarea::placeholder {
          color: #a5b2c3;
        }

        .conversation-input:focus,
        .conversation-select:focus,
        .conversation-textarea:focus {
          border-color: #730042;
          box-shadow: 0 0 0 3px rgba(115, 0, 66, 0.07);
        }

        /* REQUIREMENT */

        .requirement-section,
        .project-section {
          margin-top: 25px;
        }

        .requirement-counter {
          display: flex;
          justify-content: flex-end;
          margin-top: 4px;
          color: #9aa8b9;
          font-size: 10px;
        }

        /* PROJECT */

        .project-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 17px 16px;
        }

        /* CONNECT */

        .connect-section {
          margin-top: 17px;
        }

        .connect-title {
          margin: 0 0 9px;
          color: #374153;
          font-size: 12px;
          font-weight: 600;
        }

        .connect-options {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 10px;
        }

        .connect-option {
          min-height: 37px;
          padding: 0 10px;
          border: 1px solid #e0e5eb;
          border-radius: 7px;
          background: #ffffff;
          color: #4b5566;
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 12px;
          font-weight: 500;
          cursor: pointer;
        }

        .connect-option.active {
          border-color: rgba(115, 0, 66, 0.28);
        }

        .custom-radio {
          width: 15px;
          height: 15px;
          flex-shrink: 0;
          border: 1.5px solid #adb7c4;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .connect-option.active .custom-radio {
          border-color: #730042;
        }

        .connect-option.active .custom-radio::after {
          content: "";
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: #730042;
        }

        /* NDA */

        .nda-row {
          display: flex;
          align-items: flex-start;
          gap: 9px;
          margin-top: 19px;
        }

        .nda-checkbox {
          width: 15px;
          height: 15px;
          margin-top: 1px;
          accent-color: #730042;
          cursor: pointer;
        }

        .nda-label {
          color: #718095;
          font-size: 13px;
          line-height: 1.5;
        }

        /* BUTTON */

        .submit-area {
          margin-top: 24px;
        }

        .conversation-submit {
          min-height: 47px;
          padding: 0 27px;
          border: none;
          border-radius: 7px;
          background: #730042;
          color: #ffffff;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          font-size: 12px;
          font-weight: 600;
          box-shadow: 0 5px 12px rgba(115, 0, 66, 0.16);
          transition: 0.2s ease;
        }

        .conversation-submit:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 18px rgba(115, 0, 66, 0.22);
        }

        .privacy-note {
          max-width: 700px;
          margin-top: 10px;
          color: #8592a5;
          font-size: 11px;
          line-height: 1.5;
        }

        /* SIDEBAR */

        .conversation-sidebar {
          display: flex;
          flex-direction: column;
          gap: 14px;
        }

        .steps-card,
        .channels-card {
          padding: 27px;
          border: 1px solid #e2e6ec;
          border-radius: 16px;
          background: #ffffff;
        }

        .steps-eyebrow,
        .channels-title {
          margin: 0 0 7px;
          color: #a2afbf;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.45px;
          text-transform: uppercase;
        }

        .steps-title {
          font-size: 18px;
          line-height: 1.2;
        }

        .steps-divider {
          height: 1px;
          margin: 18px 0 19px;
          background: #edf0f3;
        }

        .step-item {
          display: grid;
          grid-template-columns: 38px 1fr;
          gap: 11px;
          margin-bottom: 20px;
        }

        .step-item:last-child {
          margin-bottom: 0;
        }

        .step-number {
          width: 34px;
          height: 34px;
          border-radius: 50%;
          background: #730042;
          color: #ffffff;
          display: flex;
          align-items: center;
          justify-content: center;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 12px;
          font-weight: 700;
          box-shadow: 0 0 0 4px #f9edf4;
        }

        .step-title {
          margin: 0;
          color: #293243;
          font-size: 13px;
          font-weight: 700;
        }

        .step-description {
          margin-top: 4px;
          color: #738095;
          font-size: 13px;
          line-height: 1.55;
        }

        /* QUICK CARD */

        .quick-answer-card {
          min-height: 205px;
          padding: 25px;
          border-radius: 16px;
          background: #730042;
          color: #ffffff;
          position: relative;
          overflow: hidden;
        }

        .quick-badge {
          display: inline-flex;
          padding: 5px 10px;
          border: 1px solid rgba(255,255,255,0.24);
          border-radius: 20px;
          background: rgba(255,255,255,0.1);
          color: #ffffff;
          font-size: 10px;
          font-weight: 600;
        }

        .quick-title {
          margin-top: 17px;
          color: #ffffff;
          font-size: 18px;
          font-weight: 700;
        }

        .quick-description {
          max-width: 330px;
          margin-top: 8px;
          color: rgba(255,255,255,0.84);
          font-size: 12px;
          line-height: 1.55;
        }

        .quick-button {
          min-height: 35px;
          margin-top: 14px;
          padding: 0 15px;
          border: 1px solid rgba(255,255,255,0.3);
          border-radius: 20px;
          background: rgba(255,255,255,0.15);
          color: #ffffff;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 11px;
          font-weight: 600;
        }

        .quick-icon {
          position: absolute;
          right: 22px;
          bottom: 21px;
          width: 58px;
          height: 58px;
          border-radius: 50%;
          background: #f7eaf1;
          color: #730042;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        /* CHANNELS */

        .channels-title {
          margin-bottom: 18px;
        }

        .channel-item {
          display: flex;
          align-items: flex-start;
          gap: 11px;
          margin-bottom: 16px;
        }

        .channel-icon {
          width: 27px;
          height: 27px;
          flex-shrink: 0;
          border-radius: 7px;
          background: #f9edf4;
          color: #730042;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .channel-icon svg {
          width: 14px;
        }

        .channel-name {
          margin: 0;
          color: #374153;
          font-size: 12px;
          font-weight: 600;
        }

        .channel-value {
          margin-top: 2px;
          color: #730042;
          font-size: 12px;
          font-weight: 600;
        }

        .channel-subvalue {
          margin-top: 2px;
          color: #758195;
          font-size: 12px;
          line-height: 1.45;
        }

        /* CONTACT */

        .contact-section {
          padding: 42px 0 80px;
          border-top: 1px solid #e7eaf0;
        }

        .contact-heading {
          font-size: 27px;
          line-height: 1.2;
        }

        .contact-description {
          margin-top: 5px;
          font-size: 13px;
        }

        .contact-card {
          display: grid;
          grid-template-columns: 1.15fr 0.85fr;
          gap: 35px;
          margin-top: 31px;
          padding: 32px;
          border: 1px solid #e2e6ec;
          border-radius: 17px;
          background: #ffffff;
        }

        .offices-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 25px;
        }

        .office-item {
          position: relative;
          padding-left: 12px;
        }

        .office-item::before {
          content: "";
          position: absolute;
          top: 5px;
          left: 0;
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #730042;
        }

        .office-title {
          margin: 0;
          color: #293243;
          font-size: 14px;
          line-height: 1.4;
          font-weight: 600;
        }

        .office-address {
          margin-top: 5px;
          color: #6f7d91;
          font-size: 13px;
          line-height: 1.6;
        }

        .business-hours {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-top: 29px;
          padding-top: 17px;
          border-top: 1px solid #edf0f3;
          color: #4d596b;
          font-size: 12px;
          font-weight: 600;
        }

        .business-hours svg {
          color: #730042;
        }

        /* MAP */

        .map-wrapper {
          min-height: 260px;
          padding: 10px;
          border-radius: 13px;
          background: #f5f8fb;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .map-image {
          display: block;
          width: 100%;
          height: 100%;
          min-height: 240px;
          object-fit: contain;
          border-radius: 7px;
        }

        /* =====================================================
           RESPONSIVE
        ===================================================== */

        @media (max-width: 1100px) {

          .conversation-container {
            width: min(960px, calc(100% - 40px));
          }

          .conversation-content {
            grid-template-columns: minmax(0, 1.2fr) minmax(290px, 0.8fr);
            gap: 28px;
          }

          .conversation-form-card {
            padding: 27px;
          }

        }

        @media (max-width: 900px) {

          .conversation-content {
            grid-template-columns: 1fr;
            gap: 25px;
          }

          .conversation-sidebar {
            display: grid;
            grid-template-columns: 1fr 1fr;
          }

          .steps-card {
            grid-column: 1 / -1;
          }

          .contact-card {
            grid-template-columns: 1fr;
          }

        }

        @media (max-width: 700px) {

          .conversation-container {
            width: calc(100% - 30px);
          }

          .conversation-intro {
            padding: 40px 0 32px;
          }

          .conversation-main-title {
            font-size: 35px;
          }

          .conversation-main-description {
            font-size: 14px;
          }

          .conversation-form-card {
            padding: 21px 17px;
          }

          .details-grid,
          .project-grid {
            grid-template-columns: 1fr;
          }

          .connect-options {
            grid-template-columns: 1fr;
          }

          .conversation-submit {
            width: 100%;
          }

          .conversation-sidebar {
            display: flex;
            flex-direction: column;
          }

          .contact-card {
            padding: 21px 17px;
          }

          .offices-grid {
            grid-template-columns: 1fr;
          }

        }

        @media (max-width: 420px) {

          .conversation-container {
            width: calc(100% - 24px);
          }

          .conversation-main-title {
            font-size: 30px;
          }

          .conversation-main-description {
            font-size: 13px;
          }

          .conversation-form-card {
            padding: 18px 14px;
          }

          .form-card-title {
            font-size: 20px;
          }

          .conversation-input,
          .conversation-select {
            height: 42px;
            font-size: 11px;
          }

          .conversation-textarea {
            min-height: 100px;
          }

          .steps-card,
          .quick-answer-card,
          .channels-card {
            padding: 20px;
          }

          .contact-heading {
            font-size: 23px;
          }

          .map-wrapper {
            min-height: 180px;
          }

          .map-image {
            min-height: 170px;
          }

        }


        /* FORM FEEDBACK */

        .field-error {
          margin: 5px 0 0;
          color: #c62828;
          font-size: 12px;
          line-height: 1.4;
        }

        .form-alert {
          margin: 0 0 14px;
          padding: 11px 14px;
          border-radius: 8px;
          font-size: 13.5px;
          line-height: 1.5;
        }

        .form-alert.success {
          background: #edf7ee;
          border: 1px solid #c9e6cf;
          color: #1e6b34;
        }

        .form-alert.error {
          background: #fdecec;
          border: 1px solid #f5c6c6;
          color: #a12020;
        }

        .conversation-submit:disabled {
          opacity: 0.65;
          cursor: not-allowed;
        }

      `}),e.jsx("section",{className:"conversation-intro",children:e.jsxs("div",{className:"conversation-container",children:[e.jsx("p",{className:"conversation-eyebrow",children:"LET'S START A CONVERSATION"}),e.jsx("h1",{className:"conversation-heading conversation-main-title",children:"Let’s Discuss What Your Business Needs"}),e.jsx("p",{className:"conversation-main-description",children:"Technology requirement clear ho ya abhi sirf idea stage par ho, our team can help you explore the right direction. Tell us about your business challenge, project, or technology requirement and we’ll connect with you to discuss the possibilities."})]})}),e.jsx("section",{children:e.jsxs("div",{className:"conversation-container conversation-content",children:[e.jsxs("form",{className:"conversation-form-card",onSubmit:C,noValidate:!0,children:[e.jsx("p",{className:"conversation-eyebrow",children:"GET IN TOUCH"}),e.jsx("h2",{className:"conversation-heading form-card-title",children:"Let’s Understand Your Needs"}),e.jsx("p",{className:"conversation-text form-card-description",children:"Tell us a little about your business, project, or technology requirement. The more we understand, the better we can discuss the right approach for your needs."}),e.jsx("div",{className:"form-separator"}),e.jsxs("div",{className:"form-section-title",children:[e.jsx("span",{className:"form-section-icon",children:e.jsx(A,{})}),e.jsx("h3",{children:"Your Details"})]}),e.jsxs("div",{className:"details-grid",children:[e.jsxs("div",{className:"form-field",children:[e.jsxs("label",{className:"form-label",children:["Full Name ",e.jsx("span",{className:"required",children:"*"})]}),e.jsx("input",{type:"text",className:"conversation-input",name:"fullName",value:s.fullName,onChange:r,placeholder:"Enter your full name",required:!0}),a.fullName&&e.jsx("p",{className:"field-error",children:a.fullName})]}),e.jsxs("div",{className:"form-field",children:[e.jsxs("label",{className:"form-label",children:["Work Email ",e.jsx("span",{className:"required",children:"*"})]}),e.jsx("input",{type:"email",className:"conversation-input",name:"email",value:s.email,onChange:r,placeholder:"Enter your business email",required:!0}),a.email&&e.jsx("p",{className:"field-error",children:a.email})]}),e.jsxs("div",{className:"form-field",children:[e.jsx("label",{className:"form-label",children:"Company Name"}),e.jsx("input",{type:"text",className:"conversation-input",name:"company",value:s.company,onChange:r,placeholder:"Enter your company name"}),a.company&&e.jsx("p",{className:"field-error",children:a.company})]}),e.jsxs("div",{className:"form-field",children:[e.jsx("label",{className:"form-label",children:"Phone Number"}),e.jsx("input",{type:"tel",className:"conversation-input",name:"phone",value:s.phone,onChange:r,placeholder:"Enter your phone number"}),a.phone&&e.jsx("p",{className:"field-error",children:a.phone})]})]}),e.jsxs("div",{className:"requirement-section",children:[e.jsxs("div",{className:"form-section-title",children:[e.jsx("span",{className:"form-section-icon",children:e.jsx(P,{})}),e.jsx("h3",{children:"Your Requirement"})]}),e.jsxs("label",{className:"form-label",children:["What can we help you with? ",e.jsx("span",{className:"required",children:"*"})]}),e.jsxs("select",{className:"conversation-select",name:"service",value:s.service,onChange:r,required:!0,children:[e.jsx("option",{value:"",disabled:!0,children:"Select a service"}),e.jsx("option",{children:"Software Development"}),e.jsx("option",{children:"Digital Transformation"}),e.jsx("option",{children:"ERP Solutions"}),e.jsx("option",{children:"AI & Cloud Solutions"}),e.jsx("option",{children:"Cybersecurity"}),e.jsx("option",{children:"IT Consulting"})]}),a.service&&e.jsx("p",{className:"field-error",children:a.service}),e.jsxs("div",{className:"form-field",style:{marginTop:"15px"},children:[e.jsxs("label",{className:"form-label",children:["Tell us about your requirement"," ",e.jsx("span",{className:"required",children:"*"})]}),e.jsx("textarea",{className:"conversation-textarea",name:"requirement",value:s.requirement,onChange:r,maxLength:500,placeholder:"Briefly describe your project, business challenge or technology requirement...",required:!0}),a.requirement&&e.jsx("p",{className:"field-error",children:a.requirement}),e.jsxs("div",{className:"requirement-counter",children:[s.requirement.length,"/500"]})]})]}),e.jsxs("div",{className:"project-section",children:[e.jsxs("div",{className:"form-section-title",children:[e.jsx("span",{className:"form-section-icon",children:e.jsx(I,{})}),e.jsx("h3",{children:"Project Information"})]}),e.jsxs("div",{className:"project-grid",children:[e.jsxs("div",{className:"form-field",children:[e.jsx("label",{className:"form-label",children:"Current Stage"}),e.jsxs("select",{className:"conversation-select",name:"stage",value:s.stage,onChange:r,children:[e.jsx("option",{value:"",disabled:!0,children:"Select current stage"}),e.jsx("option",{children:"Idea Stage"}),e.jsx("option",{children:"Planning"}),e.jsx("option",{children:"Development"}),e.jsx("option",{children:"Implementation"})]})]}),e.jsxs("div",{className:"form-field",children:[e.jsx("label",{className:"form-label",children:"Expected Timeline"}),e.jsxs("select",{className:"conversation-select",name:"timeline",value:s.timeline,onChange:r,children:[e.jsx("option",{value:"",disabled:!0,children:"Select timeline"}),e.jsx("option",{children:"Immediate"}),e.jsx("option",{children:"Within 1 Month"}),e.jsx("option",{children:"1–3 Months"}),e.jsx("option",{children:"3–6 Months"})]})]})]}),e.jsxs("div",{className:"connect-section",children:[e.jsx("p",{className:"connect-title",children:"Preferred Way to Connect"}),e.jsx("div",{className:"connect-options",children:[["email","Email"],["phone","Phone Call"],["video","Online Video Meeting"]].map(([n,i])=>e.jsxs("label",{className:`connect-option ${u===n?"active":""}`,onClick:()=>g(n),children:[e.jsx("span",{className:"custom-radio"}),i]},n))})]}),e.jsxs("div",{className:"nda-row",children:[e.jsx("input",{id:"nda",name:"nda",type:"checkbox",className:"nda-checkbox",checked:s.nda,onChange:r}),e.jsx("label",{className:"nda-label",htmlFor:"nda",children:"Please share a draft Bilateral Mutual NDA prior to technical architecture discussion."})]}),e.jsxs("div",{className:"submit-area",children:[l.message&&e.jsx("div",{className:`form-alert ${l.type}`,role:l.type==="error"?"alert":"status",children:l.message}),e.jsxs("button",{type:"submit",className:"conversation-submit",disabled:h,children:[h?"Sending…":"Send Enquiry & Start Conversation",!h&&e.jsx(y,{size:16})]}),e.jsx("p",{className:"privacy-note",children:"By submitting this form, you agree to be contacted by TechTorch Solutions regarding your enquiry. Your data is protected by strict bilateral confidentiality."})]})]})]}),e.jsxs("div",{className:"conversation-sidebar",children:[e.jsxs("div",{className:"steps-card",children:[e.jsx("p",{className:"steps-eyebrow",children:"STEP-BY-STEP DISCOVERY"}),e.jsx("h2",{className:"conversation-heading steps-title",children:"What Happens Next?"}),e.jsx("div",{className:"steps-divider"}),[["01","Share Your Requirement","Tell us about your business needs, project, existing system, or technology challenge."],["02","We Understand Your Needs","Our team reviews your requirement and understands the business and technical context."],["03","Explore the Right Approach","We discuss relevant solutions, technologies, and possible ways to move your initiative forward."],["04","Take the Next Step","Once the requirement is clear, we can discuss the scope, engagement approach, and next steps."]].map(([n,i,t])=>e.jsxs("div",{className:"step-item",children:[e.jsx("div",{className:"step-number",children:n}),e.jsxs("div",{children:[e.jsx("h3",{className:"step-title",children:i}),e.jsx("p",{className:"step-description",children:t})]})]},n))]}),e.jsxs("div",{className:"quick-answer-card",children:[e.jsx("span",{className:"quick-badge",children:"FAQ & Quick Assistance"}),e.jsx("h2",{className:"quick-title",children:"Need a Quick Answer?"}),e.jsx("p",{className:"quick-description",children:"Have a question about our services, solutions, or products? Browse immediate answers."}),e.jsxs("button",{type:"button",className:"quick-button",onClick:()=>k("/explore-questions"),children:["Ask a Question",e.jsx(y,{size:13})]}),e.jsx("div",{className:"quick-icon",children:e.jsx(B,{})})]}),e.jsxs("div",{className:"channels-card",children:[e.jsx("h3",{className:"channels-title",children:"DIRECT ADVISORY CHANNELS"}),e.jsxs("div",{className:"channel-item",children:[e.jsx("div",{className:"channel-icon",children:e.jsx(D,{})}),e.jsxs("div",{children:[e.jsx("p",{className:"channel-name",children:"Direct Email"}),e.jsx("p",{className:"channel-value",children:"contact@techtorch.solutions"})]})]}),e.jsxs("div",{className:"channel-item",children:[e.jsx("div",{className:"channel-icon",children:e.jsx(O,{})}),e.jsxs("div",{children:[e.jsx("p",{className:"channel-name",children:"Direct Phone Inquiries"}),e.jsx("p",{className:"channel-subvalue",children:"+91 581 3500381 | +91 7251090147"})]})]}),e.jsxs("div",{className:"channel-item",children:[e.jsx("div",{className:"channel-icon",children:e.jsx(M,{})}),e.jsxs("div",{children:[e.jsx("p",{className:"channel-name",children:"Global Presence"}),e.jsx("p",{className:"channel-subvalue",children:"Noida, Uttar Pradesh • Bareilly HQ • Florida, USA"})]})]})]})]})]})}),e.jsx("section",{className:"contact-section",children:e.jsxs("div",{className:"conversation-container",children:[e.jsx("p",{className:"conversation-eyebrow",children:"CONTACT & DELIVERY HUBS"}),e.jsx("h2",{className:"conversation-heading contact-heading",children:"Connect With TechTorch"}),e.jsx("p",{className:"conversation-text contact-description",children:"For technology solutions, services, products, and dedicated enterprise pods."}),e.jsxs("div",{className:"contact-card",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"offices-grid",children:[e.jsxs("div",{className:"office-item",children:[e.jsx("h3",{className:"office-title",children:"Noida Office"}),e.jsxs("p",{className:"office-address",children:["Suite G/11, B-8 Sector-2,",e.jsx("br",{}),"Near Sector-15 Metro Station,",e.jsx("br",{}),"Noida, Uttar Pradesh – 201301,",e.jsx("br",{}),"India"]})]}),e.jsxs("div",{className:"office-item",children:[e.jsx("h3",{className:"office-title",children:"Corporate HQ"}),e.jsxs("p",{className:"office-address",children:["M-1 Vrindavan Colony,",e.jsx("br",{}),"IVRI Road, Near Izatnagar",e.jsx("br",{}),"Police Station, Bareilly,",e.jsx("br",{}),"Uttar Pradesh – 243122, India"]})]}),e.jsxs("div",{className:"office-item",children:[e.jsx("h3",{className:"office-title",children:"Overseas Office"}),e.jsxs("p",{className:"office-address",children:["Global Delivery Desk",e.jsx("br",{}),"Florida, USA"]})]})]}),e.jsxs("div",{className:"business-hours",children:[e.jsx(R,{size:15}),"Business Hours: Monday – Friday | 10:00 AM – 7:00 PM (IST)"]})]}),e.jsx("div",{className:"map-wrapper",children:e.jsx("img",{loading:"lazy",decoding:"async",src:"/GlobalPresenceMap.webp",alt:"TechTorch Global Presence",className:"map-image"})})]})]})})]})}export{_ as default};
