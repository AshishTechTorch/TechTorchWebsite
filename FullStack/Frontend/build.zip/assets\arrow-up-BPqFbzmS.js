import{t as a}from"./index-37hjU4u5.js";const o={name:"arrow-up",size:24,node:[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]]};o.node;const r=a(o);export{r as A};
