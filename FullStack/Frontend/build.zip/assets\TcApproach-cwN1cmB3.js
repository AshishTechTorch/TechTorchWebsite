import{j as a}from"./vendor-query-PraSc8EQ.js";import{d as f,r as s}from"./vendor-router-L4ZCoGSs.js";import{t as g,X as u,s as b,A as y,r as N}from"./index-37hjU4u5.js";import{R as A}from"./rocket-B8Wt4fTK.js";const m={name:"ruler",size:24,node:[["path",{d:"M21.3 15.3a2.4 2.4 0 0 1 0 3.4l-2.6 2.6a2.4 2.4 0 0 1-3.4 0L2.7 8.7a2.41 2.41 0 0 1 0-3.4l2.6-2.6a2.41 2.41 0 0 1 3.4 0Z",key:"icamh8"}],["path",{d:"m14.5 12.5 2-2",key:"inckbg"}],["path",{d:"m11.5 9.5 2-2",key:"fmmyf7"}],["path",{d:"m8.5 6.5 2-2",key:"vc6u1g"}],["path",{d:"m17.5 15.5 2-2",key:"wo5hmg"}]]};m.node;const j=g(m),c="#7A1F3D",w="#1B1B2A",l="#5b5a63",I=[{num:"01",icon:u,title:"Understand",body:"Understand your business and technology requirements.",footer:"DISCOVERY & SCOPING"},{num:"02",icon:j,title:"Develop",body:"Design and develop the required solution.",footer:"AGILE ENGINEERING"},{num:"03",icon:A,title:"Test & Deploy",body:"Test and prepare the solution for implementation.",footer:"RELEASE VALIDATION"},{num:"04",icon:b,title:"Support",body:"Provide ongoing maintenance and support.",footer:"CONTINUITY SLA"}];function R(){const h=f(),d=s.useRef(null),i=s.useRef([]);return s.useEffect(()=>{const n=d.current;if(!n)return;const t=()=>{i.current.forEach(r=>{r&&(r.style.opacity="0",r.style.transform="translateY(45px)")})},p=()=>{i.current.forEach((r,e)=>{r&&setTimeout(()=>{r.style.opacity="1",r.style.transform="translateY(0)"},e*180)})};t();const o=new IntersectionObserver(r=>{r.forEach(e=>{e.isIntersecting?(t(),setTimeout(()=>{p()},100)):t()})},{threshold:.2});return o.observe(n),()=>{o.disconnect()}},[]),a.jsxs(a.Fragment,{children:[a.jsx("style",{children:`

          * {
            box-sizing: border-box;
          }

          .approach-section {
            width: 100%;
            font-family: "Inter", Arial, sans-serif;
            overflow: hidden;
          }

          /* =========================================
             TYPOGRAPHY
          ========================================= */

          .approach-heading,
          .approach-subheading,
          .approach-card-title,
          .approach-cta-heading {
            font-family: "Plus Jakarta Sans", Arial, sans-serif;
          }

          .approach-description,
          .approach-card-body,
          .approach-cta-description,
          .approach-cta-actions,
          .approach-card-footer {
            font-family: "Inter", Arial, sans-serif;
          }

          /* =========================================
             MAIN CONTAINER
             Desktop: 100px
             Tablet: 40px
             Mobile: 24px
             Small Mobile: 16px
          ========================================= */

          .approach-container {
            width: 100%;
            max-width: 1440px;
            margin: 0 auto;
            padding: 80px 100px;
          }

          /* =========================================
             APPROACH CARD ANIMATION
          ========================================= */

          .approach-card {
            opacity: 0;
            transform: translateY(45px);

            transition:
              opacity 0.7s ease,
              transform 0.7s cubic-bezier(0.22, 1, 0.36, 1),
              box-shadow 0.3s ease;

            will-change: opacity, transform;
          }

          .approach-card:hover {
            transform: translateY(-5px) !important;
            box-shadow: 0 12px 30px rgba(27, 27, 42, 0.08);
          }

          .approach-card-icon {
            transition: transform 0.3s ease;
          }

          .approach-card:hover .approach-card-icon {
            transform: scale(1.12);
          }

          /* =========================================
             CTA BUTTON
          ========================================= */

          .cta-button {
            transition:
              transform 0.3s ease,
              box-shadow 0.3s ease;
          }

          .cta-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 22px rgba(0, 0, 0, 0.15);
          }

          /* =========================================
             LARGE TABLET
          ========================================= */

          @media (max-width: 1200px) {
            .approach-container {
              padding: 70px 40px;
            }

            .approach-heading {
              font-size: 1.95rem;
            }

            .approach-cards {
              gap: 16px !important;
            }
          }

          /* =========================================
             TABLET
          ========================================= */

          @media (max-width: 900px) {
            .approach-container {
              padding: 60px 40px;
            }

            .approach-heading {
              font-size: 1.8rem !important;
            }

            .approach-cards {
              grid-template-columns: repeat(
                2,
                minmax(0, 1fr)
              ) !important;

              gap: 16px !important;
            }

            .approach-card {
              padding: 21px !important;
            }

            .approach-cta {
              padding: 44px 34px !important;
            }
          }

          /* =========================================
             MOBILE
          ========================================= */

          @media (max-width: 700px) {
            .approach-container {
              padding: 45px 24px 60px !important;
            }

            .approach-heading {
              font-size: 1.65rem !important;
              line-height: 1.28 !important;
            }

            .approach-description {
              font-size: 13px !important;
              line-height: 1.7 !important;
              margin-bottom: 32px !important;
            }

            .approach-cards {
              grid-template-columns: 1fr !important;
              gap: 13px !important;
              margin-bottom: 44px !important;
            }

            .approach-card {
              padding: 19px !important;
            }

            .approach-card-body {
              margin-bottom: 22px !important;
            }

            .approach-cta {
              padding: 36px 24px !important;
              border-radius: 22px !important;
            }

            .approach-cta-heading {
              font-size: 1.55rem !important;
            }

            .approach-cta-description {
              font-size: 13px !important;
              line-height: 1.7 !important;
            }

            .approach-cta-actions {
              flex-direction: column;
              align-items: flex-start !important;
              gap: 18px !important;
            }
          }

          /* =========================================
             SMALL MOBILE
          ========================================= */

          @media (max-width: 480px) {
            .approach-container {
              padding: 36px 16px 52px !important;
            }

            .approach-heading {
              font-size: 1.5rem !important;
            }

            .approach-description {
              font-size: 12.5px !important;
            }

            .approach-card {
              padding: 18px !important;
            }

            .approach-cta {
              padding: 31px 19px !important;
              border-radius: 20px !important;
            }

            .approach-cta-heading {
              font-size: 1.4rem !important;
            }

            .approach-cta-description {
              font-size: 12.5px !important;
            }

            .approach-card-footer {
              font-size: 8.5px !important;
            }
          }

          /* =========================================
             VERY SMALL MOBILE
          ========================================= */

          @media (max-width: 360px) {
            .approach-container {
              padding-left: 16px !important;
              padding-right: 16px !important;
            }

            .approach-heading {
              font-size: 1.4rem !important;
            }

            .approach-cta {
              padding: 28px 17px !important;
            }

            .approach-cta-heading {
              font-size: 1.3rem !important;
            }

            .approach-cta-description {
              font-size: 12px !important;
            }
          }

          /* =========================================
             REDUCED MOTION
          ========================================= */

          @media (prefers-reduced-motion: reduce) {
            .approach-card {
              opacity: 1 !important;
              transform: none !important;
              transition: none !important;
            }

            .approach-card:hover {
              transform: none !important;
            }

            .cta-button {
              transition: none !important;
            }
          }
        `}),a.jsx("section",{ref:d,className:"approach-section w-full bg-white",style:{color:w},children:a.jsxs("div",{className:"approach-container",children:[a.jsx("p",{className:`\r
              text-xs\r
              font-semibold\r
              tracking-wide\r
              mb-3\r
            `,style:{color:c,fontFamily:"Inter, Arial, sans-serif"},children:"OUR APPROACH"}),a.jsx("h2",{className:`\r
              approach-heading\r
              text-2xl\r
              font-bold\r
              tracking-tight\r
              mb-2\r
            `,children:"From Requirement to Support"}),a.jsx("p",{className:`\r
              approach-description\r
              text-sm\r
              leading-relaxed\r
              mb-10\r
            `,style:{color:l},children:"A disciplined, progressive engineering lifecycle tailored for operational continuity."}),a.jsx("div",{className:`\r
              approach-cards\r
              grid\r
              sm:grid-cols-2\r
              md:grid-cols-4\r
              gap-4\r
              mb-14\r
            `,children:I.map(({num:n,icon:t,title:p,body:o,footer:r},e)=>a.jsxs("div",{ref:x=>{i.current[e]=x},className:`\r
                    approach-card\r
                    rounded-xl\r
                    p-5\r
                    flex\r
                    flex-col\r
                  `,style:{background:"#f6f7fa"},children:[a.jsxs("div",{className:"flex items-center justify-between mb-5",children:[a.jsx("span",{className:`\r
                        text-xl\r
                        font-bold\r
                      `,style:{color:c,fontFamily:"Plus Jakarta Sans, Arial, sans-serif"},children:n}),a.jsx(t,{className:"approach-card-icon",size:18,strokeWidth:1.8,style:{color:"#a9a6b0"}})]}),a.jsx("h3",{className:`\r
                      approach-card-title\r
                      text-sm\r
                      font-semibold\r
                      mb-1.5\r
                    `,children:p}),a.jsx("p",{className:`\r
                      approach-card-body\r
                      text-xs\r
                      leading-relaxed\r
                      mb-6\r
                    `,style:{color:l},children:o}),a.jsx("p",{className:`\r
                      approach-card-footer\r
                      mt-auto\r
                      text-[9px]\r
                      font-semibold\r
                      tracking-wide\r
                    `,style:{color:"#a9a6b0"},children:r})]},n))}),a.jsxs("div",{className:`\r
              approach-cta\r
              relative\r
              overflow-hidden\r
              rounded-3xl\r
              px-8\r
              py-12\r
            `,style:{background:"linear-gradient(135deg, #3d0d28 0%, #5c1730 60%, #4a1230 100%)"},children:[a.jsx("div",{className:"absolute inset-0 pointer-events-none",style:{background:"radial-gradient(circle at 20% 30%, rgba(255,255,255,0.08) 0%, transparent 55%)"}}),a.jsxs("div",{className:"relative max-w-xl",children:[a.jsxs("span",{className:`\r
                  inline-flex\r
                  items-center\r
                  gap-1.5\r
                  text-[10px]\r
                  font-semibold\r
                  tracking-wide\r
                  px-3\r
                  py-1.5\r
                  rounded-full\r
                  mb-6\r
                `,style:{background:"rgba(255,255,255,0.12)",color:"#f3d9e2",fontFamily:"Inter, Arial, sans-serif"},children:[a.jsx("span",{className:"w-1.5 h-1.5 rounded-full bg-white"}),"GET IN TOUCH"]}),a.jsxs("h2",{className:`\r
                  approach-heading\r
                  approach-cta-heading\r
                  text-2xl\r
                  md:text-[1.75rem]\r
                  leading-[1.25]\r
                  font-bold\r
                  tracking-tight\r
                  text-white\r
                  mb-5\r
                `,children:["Let's Build Technology",a.jsx("br",{}),"Around Your Business"]}),a.jsx("p",{className:`\r
                  approach-cta-description\r
                  text-sm\r
                  leading-relaxed\r
                  mb-8\r
                `,style:{color:"#e3c3cf"},children:"Discuss your telecommunications technology requirements with the TechTorch team."}),a.jsxs("div",{className:`\r
                  approach-cta-actions\r
                  flex\r
                  flex-wrap\r
                  items-center\r
                  gap-4\r
                `,children:[a.jsxs("button",{type:"button",onClick:()=>h("/telecommunication-get-in-touch"),className:`\r
                    cta-button\r
                    inline-flex\r
                    items-center\r
                    gap-2\r
                    px-5\r
                    py-3\r
                    rounded-[6px]\r
                    bg-white\r
                    text-sm\r
                    font-medium\r
                  `,style:{color:c,fontFamily:"Inter, Arial, sans-serif"},children:["Get in Touch",a.jsx(y,{size:15})]}),a.jsxs("div",{className:"flex items-center gap-1.5",children:[a.jsx(N,{size:13,style:{color:"#e3c3cf"}}),a.jsx("span",{className:"text-xs",style:{color:"#e3c3cf",fontFamily:"Inter, Arial, sans-serif"},children:"Confidential Consultation & Scoping"})]})]})]})]})]})})]})}export{R as default};
