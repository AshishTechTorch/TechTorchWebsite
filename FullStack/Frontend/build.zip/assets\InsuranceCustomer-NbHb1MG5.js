import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as m}from"./vendor-router-L4ZCoGSs.js";import{S as b}from"./smartphone-CoEIwl-3.js";import{t as w,r as y,Q as j,X as N}from"./index-37hjU4u5.js";import{L as z}from"./link-2-DwassH_y.js";import{M as k}from"./maximize-2-DWV0BG6T.js";import{C as E}from"./clipboard-list-ivKQuMBl.js";import{C}from"./code-xml-CIX-EOu2.js";import{C as $}from"./check-BpCzgOHM.js";import{G as L}from"./globe-DIvA-9_v.js";const v={name:"undo-2",size:24,node:[["path",{d:"M9 14 4 9l5-5",key:"102s5s"}],["path",{d:"M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11",key:"f3b9sd"}]]};v.node;const P=w(v),o="#7A1F3D",l="#1B1B2A",c="#5b5a63",h="#fbeef1",R=[{icon:P,title:"Accessible",body:"Make digital information and services easier to access."},{icon:z,title:"Connected",body:"Bring relevant customer and business information together."},{icon:b,title:"Responsive",body:"Develop applications that provide consistent experiences across devices."},{icon:k,title:"Scalable",body:"Create digital platforms that can evolve with business requirements."}],D=[{icon:N,phase:"01 · DISCOVERY",title:"Understand",body:"Analyze business requirements, existing processes and challenges.",footer:"Phase 01"},{icon:E,phase:"02 · BLUEPRINT",title:"Plan",body:"Define the solution architecture and implementation approach.",footer:"Phase 02"},{icon:C,phase:"03 · BUILD",title:"Develop",body:"Build, configure and integrate the required solutions and systems.",footer:"Phase 03"},{icon:$,phase:"04 · RELEASE",title:"Deploy",body:"Test and implement the solution with a focus on reliability and stability.",footer:"Phase 04"},{icon:L,phase:"05 · LIFECYCLE",title:"Support",body:"Provide ongoing maintenance and technical assistance.",footer:"Phase 05"}];function f({children:p}){return e.jsxs("span",{className:"digital-pill",children:[e.jsx("span",{className:"digital-pill-dot"}),p]})}function u(){const p=m.useRef(null);return m.useEffect(()=>{const r=p.current;if(!r)return;const n=Array.from(r.querySelectorAll(".digital-card-reveal")),i=window.matchMedia("(prefers-reduced-motion: reduce)");let a;function d(){a?.disconnect(),r.classList.remove("reveal-enabled"),n.forEach(s=>{s.classList.remove("is-visible")}),!(i.matches||!("IntersectionObserver"in window))&&(r.classList.add("reveal-enabled"),a=new IntersectionObserver(s=>{s.filter(t=>t.isIntersecting).sort((t,g)=>Number(t.target.dataset.index)-Number(g.target.dataset.index)).forEach((t,g)=>{t.target.style.setProperty("--reveal-delay",`${g*180}ms`),t.target.classList.add("is-visible")}),s.forEach(t=>{t.isIntersecting||t.target.classList.remove("is-visible")})},{threshold:0}),n.forEach(s=>a.observe(s)))}return d(),i.addEventListener("change",d),()=>{a?.disconnect(),i.removeEventListener("change",d),r.classList.remove("reveal-enabled")}},[]),p}function W(){const p=u(),r=u();return e.jsxs("section",{className:"digital-experience-section",children:[e.jsx("style",{children:`

        .digital-experience-section {
          width: 100%;
          background: #ffffff;
          color: ${l};
          font-family: "Inter", sans-serif;
          overflow: hidden;
        }

        .digital-experience-section,
        .digital-experience-section *,
        .digital-experience-section *::before,
        .digital-experience-section *::after {
          box-sizing: border-box;
        }

        .digital-main-container {
          width: 100%;
          max-width: 1440px;
          margin: 0 auto;
          padding: 75px 100px 85px;
        }

        .digital-experience-grid {
          display: grid;
          grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
          gap: 58px;
          align-items: center;
        }

        .digital-image-area {
          position: relative;
          width: 100%;
          min-width: 0;
          padding: 0 24px 22px 0;
        }

        .digital-main-image {
          width: 100%;
          height: 390px;
          display: block;
          object-fit: cover;
          object-position: center;
          border-radius: 18px;
          background: #e2e5e7;
        }

        .digital-icon-stack {
          position: absolute;
          top: 25px;
          left: 25px;
          display: flex;
          flex-direction: column;
          gap: 8px;
          padding: 9px;
          border-radius: 12px;
          background: #ffffff;
          box-shadow: 0 10px 28px rgba(0, 0, 0, 0.1);
          z-index: 2;
        }

        .digital-icon-box {
          width: 34px;
          height: 34px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 8px;
          background: ${h};
          color: ${o};
        }

        .digital-content {
          min-width: 0;
          width: 100%;
        }

        .digital-pill {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          max-width: 100%;
          margin-bottom: 18px;
          padding: 6px 11px;
          border-radius: 999px;
          background: ${h};
          color: ${o};
          font-size: 9px;
          line-height: 1.3;
          font-weight: 700;
          letter-spacing: 0.06em;
        }

        .digital-pill-dot {
          width: 6px;
          height: 6px;
          flex-shrink: 0;
          border-radius: 50%;
          background: ${o};
        }

        .digital-heading {
          max-width: 600px;
          margin: 0 0 18px;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 36px;
          line-height: 1.16;
          font-weight: 700;
          letter-spacing: -0.8px;
          color: ${l};
        }

        .digital-heading-highlight,
        .approach-heading-highlight {
          color: ${o};
        }

        .digital-description {
          max-width: 590px;
          margin: 0 0 13px;
          font-size: 14px;
          line-height: 1.72;
          font-weight: 400;
          color: ${c};
        }

        .digital-description:last-of-type {
          margin-bottom: 30px;
        }

        .digital-features-grid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          column-gap: 28px;
          row-gap: 24px;
        }

        .digital-feature {
          display: flex;
          align-items: flex-start;
          gap: 11px;
          width: 100%;
          min-width: 0;
        }

        .digital-feature-icon {
          width: 36px;
          height: 36px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          border-radius: 50%;
          background: ${o};
          color: #ffffff;
        }

        .digital-feature-content {
          min-width: 0;
        }

        .digital-feature-title {
          margin: 0 0 5px;
          font-size: 13px;
          line-height: 1.45;
          font-weight: 700;
          color: ${l};
        }

        .digital-feature-body {
          margin: 0;
          font-size: 11px;
          line-height: 1.65;
          color: ${c};
        }

        .approach-section {
          margin-top: 10px;
        }

        .approach-header {
          display: grid;
          grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
          gap: 48px;
          align-items: start;
          margin-bottom: 45px;
        }

        .approach-header-left,
        .approach-header-right {
          min-width: 0;
        }

        .approach-header-right {
          padding-top: 7px;
        }

        .approach-heading {
          max-width: 580px;
          margin: 0;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 36px;
          line-height: 1.16;
          font-weight: 700;
          letter-spacing: -0.8px;
          color: ${l};
        }

        .approach-description {
          max-width: 560px;
          margin: 0;
          font-size: 14px;
          line-height: 1.72;
          font-weight: 400;
          color: ${c};
        }

        .phases-grid {
          display: grid;
          grid-template-columns: repeat(5, minmax(0, 1fr));
          gap: 16px;
        }

        /* Reveal wrapper keeps entrance and hover independent. */
        .digital-card-reveal {
          display: flex;
          min-width: 0;
        }

        .digital-experience-section .reveal-enabled
        > .digital-card-reveal {
          opacity: 0;
        }

        .digital-experience-section .reveal-enabled
        > .digital-card-reveal.is-visible {
          animation: digital-card-enter
            650ms
            cubic-bezier(0.22, 1, 0.36, 1)
            var(--reveal-delay, 0ms)
            both;
        }

        @keyframes digital-card-enter {
          from {
            opacity: 0;
            transform: translateY(28px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .phase-card {
          width: 100%;
          min-width: 0;
          min-height: 245px;
          display: flex;
          flex-direction: column;
          padding: 19px;
          border: 1px solid #ece9e4;
          border-radius: 12px;

          /* Same background as the phase icon */
          background: #ffffff;

          transition:
            transform 0.25s ease,
            box-shadow 0.25s ease,
            border-color 0.25s ease;
        }

        .phase-card:hover {
        background: #fbeef1;
          transform: translateY(-3px);
          border-color: #e2d8dc;
          box-shadow: 0 10px 25px rgba(0, 0, 0, 0.06);
        }

        .phase-top {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 20px;
          min-width: 0;
        }

        .phase-icon {
          width: 32px;
          height: 32px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          border-radius: 8px;
          background: ${h};
          color: ${o};
        }

        .phase-label {
          min-width: 0;
          white-space: normal;
          overflow-wrap: anywhere;
          font-size: 9px;
          line-height: 1.4;
          font-weight: 700;
          letter-spacing: 0.04em;
          color: ${o};
        }

        .phase-title {
          margin: 0 0 8px;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 15px;
          line-height: 1.4;
          font-weight: 700;
          color: ${l};
        }

        .phase-body {
          margin: 0;
          font-size: 11px;
          line-height: 1.65;
          color: ${c};
        }

        .phase-footer {
          margin-top: auto;
          padding-top: 13px;
          border-top: 1px solid #ece9e4;
          font-size: 10px;
          line-height: 1.4;
          font-weight: 500;
          color: #a29b8f;
        }

        @media (max-width: 1199px) {
          .digital-main-container {
            padding-left: 40px;
            padding-right: 40px;
          }

          .digital-experience-grid {
            gap: 45px;
          }

          .digital-main-image {
            height: 350px;
          }

          .digital-heading,
          .approach-heading {
            font-size: 33px;
          }

          .phases-grid {
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 17px;
          }

          .phase-card {
            min-height: 225px;
          }
        }

        @media (max-width: 900px) {
          .digital-main-container {
            padding-top: 60px;
            padding-bottom: 70px;
          }

          .digital-experience-grid {
            grid-template-columns: 1fr;
            gap: 50px;
          }

          .digital-image-area {
            max-width: 700px;
            margin: 0 auto;
            padding-right: 25px;
          }

          .digital-main-image {
            height: 390px;
          }

          .digital-content {
            max-width: 700px;
            margin: 0 auto;
          }

          .digital-heading,
          .approach-heading {
            font-size: 34px;
          }

          .digital-description,
          .approach-description {
            max-width: 700px;
          }

          .approach-header {
            grid-template-columns: 1fr;
            gap: 20px;
            margin-bottom: 38px;
          }

          .approach-header-right {
            padding-top: 0;
          }

          .phases-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 17px;
          }
        }

        @media (max-width: 767px) {
          .digital-main-container {
            padding: 50px 24px 58px;
          }

          .digital-experience-grid {
            gap: 45px;
          }

          .digital-image-area {
            padding: 0 16px 18px 0;
          }

          .digital-main-image {
            height: 300px;
            border-radius: 15px;
          }

          .digital-icon-stack {
            top: 18px;
            left: 18px;
            gap: 6px;
            padding: 7px;
            border-radius: 10px;
          }

          .digital-icon-box {
            width: 30px;
            height: 30px;
            border-radius: 7px;
          }

          .digital-icon-box svg {
            width: 13px;
            height: 13px;
          }

          .digital-pill {
            margin-bottom: 14px;
            padding: 5px 10px;
            font-size: 8px;
          }

          .digital-pill-dot {
            width: 5px;
            height: 5px;
          }

          .digital-heading {
            margin-bottom: 16px;
            font-size: 29px;
            line-height: 1.18;
            letter-spacing: -0.5px;
          }

          .digital-description {
            font-size: 13px;
            line-height: 1.7;
          }

          .digital-description:last-of-type {
            margin-bottom: 25px;
          }

          .digital-features-grid {
            grid-template-columns: minmax(0, 1fr);
            gap: 20px;
          }

          .digital-feature {
            gap: 10px;
          }

          .digital-feature-icon {
            width: 34px;
            height: 34px;
          }

          .digital-feature-icon svg {
            width: 15px;
            height: 15px;
          }

          .digital-feature-title {
            font-size: 13px;
          }

          .digital-feature-body {
            font-size: 11.5px;
            line-height: 1.65;
          }

          .approach-section {
            margin-top: 0;
          }

          .approach-header {
            gap: 17px;
            margin-bottom: 30px;
          }

          .approach-heading {
            font-size: 29px;
            line-height: 1.18;
            letter-spacing: -0.5px;
          }

          .approach-description {
            font-size: 13px;
            line-height: 1.7;
          }

          .phases-grid {
            grid-template-columns: minmax(0, 1fr);
            gap: 14px;
          }

          .phase-card {
            min-height: auto;
            padding: 20px;
            border-radius: 11px;
          }

          .phase-top {
            margin-bottom: 17px;
          }

          .phase-title {
            font-size: 15px;
          }

          .phase-body {
            font-size: 11.5px;
            line-height: 1.65;
          }
        }

        @media (max-width: 480px) {
          .digital-main-container {
            padding: 42px 16px 50px;
          }

          .digital-image-area {
            padding-right: 10px;
          }

          .digital-main-image {
            height: 260px;
          }

          .digital-icon-stack {
            top: 14px;
            left: 14px;
          }

          .digital-heading {
            font-size: 26px;
            line-height: 1.18;
          }

          .digital-description {
            font-size: 12px;
            line-height: 1.68;
          }

          .digital-feature-body {
            font-size: 11px;
          }

          .approach-heading {
            font-size: 26px;
          }

          .approach-description {
            font-size: 12px;
          }

          .phase-card {
            padding: 18px;
          }

          .phase-title {
            font-size: 14px;
          }

          .phase-body {
            font-size: 11px;
          }
        }

        @media (max-width: 340px) {
          .digital-main-image {
            height: 235px;
          }

          .digital-heading,
          .approach-heading {
            font-size: 24px;
          }
        }

        @media (prefers-reduced-motion: reduce) {
          .digital-experience-section .reveal-enabled
          > .digital-card-reveal,
          .digital-experience-section .reveal-enabled
          > .digital-card-reveal.is-visible {
            animation: none;
            opacity: 1;
            transform: none;
          }

          .phase-card {
            transition: none;
          }

          .phase-card:hover {
            transform: none;
          }
        }
      `}),e.jsxs("div",{className:"digital-main-container",children:[e.jsxs("div",{className:"digital-experience-grid",children:[e.jsxs("div",{className:"digital-image-area",children:[e.jsx("img",{loading:"lazy",decoding:"async",src:"/DevelopmentTeam.webp",alt:"Digital customer experience",className:"digital-main-image"}),e.jsx("div",{className:"digital-icon-stack",children:[b,y,j].map((n,i)=>e.jsx("span",{className:"digital-icon-box",children:e.jsx(n,{size:15,strokeWidth:1.8})},i))})]}),e.jsxs("div",{className:"digital-content",children:[e.jsx(f,{children:"DIGITAL CUSTOMER EXPERIENCE"}),e.jsxs("h2",{className:"digital-heading",children:["Create Consistent"," ",e.jsx("span",{className:"digital-heading-highlight",children:"Digital Experiences"})]}),e.jsx("p",{className:"digital-description",children:"Customers increasingly interact with businesses through digital channels. These interactions need to be supported by reliable applications, accessible information and well-connected systems."}),e.jsx("p",{className:"digital-description",children:"TechTorch helps organizations develop digital platforms and applications that support both customer-facing experiences and internal business operations."}),e.jsx("div",{ref:p,className:"digital-features-grid",children:R.map(({icon:n,title:i,body:a},d)=>e.jsx("div",{"data-index":d,className:"digital-card-reveal",children:e.jsxs("div",{className:"digital-feature",children:[e.jsx("span",{className:"digital-feature-icon",children:e.jsx(n,{size:16,strokeWidth:1.8})}),e.jsxs("div",{className:"digital-feature-content",children:[e.jsx("h3",{className:"digital-feature-title",children:i}),e.jsx("p",{className:"digital-feature-body",children:a})]})]})},i))})]})]}),e.jsxs("div",{className:"approach-section",children:[e.jsxs("div",{className:"approach-header",children:[e.jsxs("div",{className:"approach-header-left",children:[e.jsx(f,{children:"OUR APPROACH"}),e.jsxs("h2",{className:"approach-heading",children:["From Business Requirements",e.jsx("br",{}),e.jsx("span",{className:"approach-heading-highlight",children:"to Technology"})]})]}),e.jsx("div",{className:"approach-header-right",children:e.jsx("p",{className:"approach-description",children:"We start with your business requirements and build the technology approach around them."})})]}),e.jsx("div",{ref:r,className:"phases-grid",children:D.map(({icon:n,phase:i,title:a,body:d,footer:s},x)=>e.jsx("div",{"data-index":x,className:"digital-card-reveal",children:e.jsxs("div",{className:"phase-card",children:[e.jsxs("div",{className:"phase-top",children:[e.jsx("span",{className:"phase-icon",children:e.jsx(n,{size:15,strokeWidth:1.8})}),e.jsx("span",{className:"phase-label",children:i})]}),e.jsx("h3",{className:"phase-title",children:a}),e.jsx("p",{className:"phase-body",children:d}),e.jsx("p",{className:"phase-footer",children:s})]})},a))})]})]})]})}export{W as default};
