import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as o}from"./vendor-router-L4ZCoGSs.js";import{U as h}from"./user-check-B8dkNk1t.js";import{y as f,G as g,R as b}from"./index-37hjU4u5.js";const n="#7A1F3D",m="#1B1B2A",s="#5b5a63",u=[{num:"01",icon:h,phase:"PHASE 01 • DISCOVERY",title:"Understand",body:"Understand your business requirements and e-commerce objectives."},{num:"02",icon:f,phase:"PHASE 02 • BUILD",title:"Implement",body:"Configure and implement the solution around your requirements."},{num:"03",icon:g,phase:"PHASE 03 • ENABLEMENT",title:"Train",body:"Provide training to help teams work with the e-commerce environment."},{num:"04",icon:b,phase:"PHASE 04 • EVOLUTION",title:"Maintain & Update",body:"Continue with maintenance and updates as your requirements evolve."}];function N(){const p=o.useRef(null),[r,l]=o.useState(!1);return o.useEffect(()=>{const i=p.current;if(!i)return;const t=new IntersectionObserver(([a])=>{a.isIntersecting&&(l(!0),t.unobserve(i))},{threshold:.15});return t.observe(i),()=>t.disconnect()},[]),e.jsxs("section",{ref:p,className:"implementation-section",children:[e.jsx("style",{children:`

        .implementation-section {
          width: 100%;
          overflow: hidden;
          background: #f7f5f2;
          color: ${m};
          font-family: "Inter", sans-serif;
        }

        /* =========================================
           MAIN WRAPPER
        ========================================= */

        .implementation-wrapper {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;
          padding-left: 100px;
          padding-right: 100px;
          padding-top: 80px;
          padding-bottom: 80px;
          box-sizing: border-box;
        }

        /* =========================================
           HEADER
        ========================================= */

        .implementation-header {
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          gap: 32px;
          margin-bottom: 48px;
        }

        .implementation-header-content {
          max-width: 760px;
        }

        .implementation-label {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 7px 13px;
          margin-bottom: 16px;
          border-radius: 999px;
          background: #fbeef1;
          color: ${n};
          font-family: "Inter", sans-serif;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.08em;
          line-height: 1;
        }

        .implementation-label-dot {
          width: 6px;
          height: 6px;
          flex-shrink: 0;
          border-radius: 50%;
          background: ${n};
        }

        .implementation-heading {
          margin: 0;
          color: ${m};
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 38px;
          font-weight: 700;
          line-height: 1.2;
          letter-spacing: -0.025em;
        }

        .implementation-subtitle {
          max-width: 430px;
          margin: 0;
          color: ${s};
          font-family: "Inter", sans-serif;
          font-size: 15px;
          font-weight: 400;
          line-height: 1.7;
        }

        /* =========================================
           STEPS GRID
        ========================================= */

        .implementation-grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 20px;
        }

        /* =========================================
           CARD
        ========================================= */

        .implementation-card {
          position: relative;
          display: flex;
          flex-direction: column;
          min-height: 280px;
          padding: 24px;
          box-sizing: border-box;
          background: #ffffff;
          border-radius: 16px;
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.05);

          opacity: 0;
          transform: translateY(32px);

          transition:
            opacity 700ms ease,
            transform 700ms cubic-bezier(0.22, 1, 0.36, 1),
            box-shadow 350ms ease;
        }

        .implementation-card.is-visible {
          opacity: 1;
          transform: translateY(0);
        }

        .implementation-card:hover {
          transform: translateY(-8px);
          box-shadow: 0 18px 40px rgba(122, 31, 61, 0.12);
        }

        /* =========================================
           TOP ROW
        ========================================= */

        .implementation-card-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 22px;
        }

        .implementation-number {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 40px;
          height: 40px;
          flex-shrink: 0;
          border-radius: 9px;
          background: #fbeef1;
          color: ${n};
          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 700;
        }

        .implementation-icon {
          color: ${n};
        }

        /* =========================================
           CARD CONTENT
        ========================================= */

        .implementation-phase {
          margin: 0 0 9px;
          color: #a9a6b0;
          font-family: "Inter", sans-serif;
          font-size: 9px;
          font-weight: 700;
          line-height: 1.4;
          letter-spacing: 0.08em;
        }

        .implementation-card-title {
          margin: 0 0 9px;
          color: ${m};
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 17px;
          font-weight: 700;
          line-height: 1.35;
        }

        .implementation-card-body {
          margin: 0;
          color: ${s};
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 400;
          line-height: 1.7;
        }


        /* =========================================
           TABLET
        ========================================= */

        @media (max-width: 1200px) {
          .implementation-wrapper {
            padding-left: 40px;
            padding-right: 40px;
            padding-top: 70px;
            padding-bottom: 70px;
          }

          .implementation-header {
            margin-bottom: 40px;
          }

          .implementation-heading {
            font-size: 34px;
          }

          .implementation-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
          }

          .implementation-card {
            min-height: 270px;
          }
        }

        /* =========================================
           SMALL TABLET / LARGE MOBILE
        ========================================= */

        @media (max-width: 900px) {
          .implementation-header {
            align-items: flex-start;
            flex-direction: column;
            gap: 18px;
          }

          .implementation-header-content {
            max-width: 100%;
          }

          .implementation-subtitle {
            max-width: 650px;
          }

          .implementation-heading {
            font-size: 32px;
          }
        }

        /* =========================================
           MOBILE
        ========================================= */

        @media (max-width: 700px) {
          .implementation-wrapper {
            padding-left: 24px;
            padding-right: 24px;
            padding-top: 56px;
            padding-bottom: 56px;
          }

          .implementation-header {
            gap: 16px;
            margin-bottom: 30px;
          }

          .implementation-label {
            padding: 7px 12px;
            margin-bottom: 13px;
            font-size: 9px;
          }

          .implementation-heading {
            font-size: 28px;
            line-height: 1.22;
          }

          .implementation-subtitle {
            font-size: 13px;
            line-height: 1.65;
          }

          .implementation-grid {
            grid-template-columns: 1fr;
            gap: 15px;
          }

          .implementation-card {
            min-height: 250px;
            padding: 21px;
            border-radius: 14px;
          }

          .implementation-card-top {
            margin-bottom: 20px;
          }

          .implementation-number {
            width: 38px;
            height: 38px;
            font-size: 11px;
          }

          .implementation-phase {
            font-size: 8.5px;
          }

          .implementation-card-title {
            font-size: 16px;
          }

          .implementation-card-body {
            font-size: 12.5px;
            line-height: 1.65;
          }
        }

        /* =========================================
           SMALL MOBILE
        ========================================= */

        @media (max-width: 480px) {
          .implementation-wrapper {
            padding-left: 16px;
            padding-right: 16px;
            padding-top: 48px;
            padding-bottom: 48px;
          }

          .implementation-heading {
            font-size: 24px;
          }

          .implementation-subtitle {
            font-size: 12.5px;
          }

          .implementation-grid {
            gap: 13px;
          }

          .implementation-card {
            min-height: 235px;
            padding: 19px;
          }

          .implementation-card-title {
            font-size: 15px;
          }

          .implementation-card-body {
            font-size: 12px;
          }

          .implementation-footer-text {
            font-size: 10.5px;
          }
        }

        /* =========================================
           REDUCED MOTION
        ========================================= */

        @media (prefers-reduced-motion: reduce) {
          .implementation-card {
            opacity: 1;
            transform: none;
            transition: none;
          }

          .implementation-card:hover {
            transform: none;
          }

          .implementation-arrow {
            transition: none;
          }
        }
      `}),e.jsxs("div",{className:"implementation-wrapper",children:[e.jsxs("div",{className:"implementation-header",children:[e.jsxs("div",{className:"implementation-header-content",children:[e.jsxs("span",{className:"implementation-label",children:[e.jsx("span",{className:"implementation-label-dot"}),"OUR APPROACH"]}),e.jsx("h2",{className:"implementation-heading",children:"From Implementation to Ongoing Support"})]}),e.jsx("p",{className:"implementation-subtitle",children:"A structured, disciplined delivery lifecycle built to minimize disruption and maximize long-term operational velocity."})]}),e.jsx("div",{className:"implementation-grid",children:u.map(({num:i,icon:t,phase:a,title:d,body:x},c)=>e.jsxs("div",{className:`implementation-card ${r?"is-visible":""}`,style:{transitionDelay:r?`${c*150}ms`:"0ms"},children:[e.jsxs("div",{className:"implementation-card-top",children:[e.jsx("span",{className:"implementation-number",children:i}),e.jsx(t,{className:"implementation-icon",size:18,strokeWidth:1.8,"aria-hidden":"true"})]}),e.jsx("p",{className:"implementation-phase",children:a}),e.jsx("h3",{className:"implementation-card-title",children:d}),e.jsx("p",{className:"implementation-card-body",children:x})]},i))})]})]})}export{N as default};
