import{t as c}from"./index-37hjU4u5.js";const e={name:"check",size:24,node:[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]};e.node;const t=c(e);export{t as C};
