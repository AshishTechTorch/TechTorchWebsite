import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as a}from"./vendor-router-L4ZCoGSs.js";import{B as f}from"./badge-check-CJFSwGzB.js";import{r as p,T as g}from"./index-37hjU4u5.js";const b=[{height:90,color:"#e9c3d6"},{height:140,color:"#d99cba"},{height:180,color:"#c07a9e"}];function v(){const i=a.useRef(null),[o,l]=a.useState(!1),[m,c]=a.useState(0),r=a.useRef(!1);return a.useEffect(()=>{const s=()=>{if(!i.current)return;const t=i.current.getBoundingClientRect(),n=window.innerHeight,d=t.bottom<=n*.95&&t.bottom>=n*.15,x=t.bottom<-100||t.top>n+100;d&&!r.current&&(r.current=!0,c(h=>h+1),l(!0)),x&&r.current&&(r.current=!1,l(!1))};return s(),window.addEventListener("scroll",s,{passive:!0}),window.addEventListener("resize",s),()=>{window.removeEventListener("scroll",s),window.removeEventListener("resize",s)}},[]),e.jsxs("section",{ref:i,className:"w-full overflow-hidden px-4 py-10 font-inter sm:px-6 sm:py-12 md:px-10 md:py-14 lg:px-[100px] lg:py-16 xl:py-20",style:{background:"linear-gradient(135deg, #6e0f3e 0%, #8f1249 55%, #6e0f3e 100%)"},children:[e.jsx("style",{children:`
        @keyframes growBar1 {
          from { height: 0px; }
          to { height: 90px; }
        }

        @keyframes growBar2 {
          from { height: 0px; }
          to { height: 140px; }
        }

        @keyframes growBar3 {
          from { height: 0px; }
          to { height: 180px; }
        }

        .bar-fill {
          height: 0px;
          animation-fill-mode: forwards;
          animation-timing-function: cubic-bezier(0.22, 1, 0.36, 1);
        }

        .animate-bars .bar-fill-1 {
          animation: growBar1 1.2s cubic-bezier(0.22, 1, 0.36, 1) forwards;
          animation-delay: 0s;
        }

        .animate-bars .bar-fill-2 {
          animation: growBar2 1.2s cubic-bezier(0.22, 1, 0.36, 1) forwards;
          animation-delay: 0.35s;
        }

        .animate-bars .bar-fill-3 {
          animation: growBar3 1.2s cubic-bezier(0.22, 1, 0.36, 1) forwards;
          animation-delay: 0.7s;
        }
      `}),e.jsxs("div",{className:"grid w-full grid-cols-1 items-center gap-12 lg:grid-cols-2 lg:gap-14",children:[e.jsxs("div",{className:"w-full",children:[e.jsx("p",{className:"mb-3 text-[11px] font-semibold tracking-[0.14em] text-rose-200 sm:mb-4 sm:text-[12px]",children:"METHODOLOGY"}),e.jsx("h2",{className:"mb-5 text-3xl font-bold leading-tight text-white sm:mb-6 sm:text-4xl md:text-[42px]",style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Scale at Speed"}),e.jsx("p",{className:"mb-8 max-w-md text-sm leading-relaxed text-rose-100/80 sm:mb-10 sm:text-base",children:"The TechTorch Philosophy balances the necessity for rapid innovation with the absolute requirement for structural invulnerability."}),e.jsxs("div",{className:"space-y-6 sm:space-y-7",children:[e.jsxs("div",{className:"flex gap-3 sm:gap-4",children:[e.jsx(f,{size:20,className:"mt-0.5 flex-shrink-0 text-white"}),e.jsxs("div",{children:[e.jsx("h3",{className:"mb-1 text-base font-semibold text-white sm:text-[17px]",children:"Rapid Iteration"}),e.jsx("p",{className:"max-w-md text-sm leading-relaxed text-rose-100/70",children:"Deploying critical infrastructure enhancements in weeks, not quarters."})]})]}),e.jsxs("div",{className:"flex gap-3 sm:gap-4",children:[e.jsx(p,{size:20,className:"mt-0.5 flex-shrink-0 text-white"}),e.jsxs("div",{children:[e.jsx("h3",{className:"mb-1 text-base font-semibold text-white sm:text-[17px]",children:"Structural Invulnerability"}),e.jsx("p",{className:"max-w-md text-sm leading-relaxed text-rose-100/70",children:"Architecting zero-trust, high-availability systems from day one."})]})]})]})]}),e.jsxs("div",{className:`w-full rounded-xl p-5 sm:p-7 md:p-8 ${o?"animate-bars":""}`,style:{background:"linear-gradient(160deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02))",border:"1px solid rgba(255,255,255,0.15)"},children:[e.jsx("div",{className:"mb-5 flex h-40 items-end justify-center gap-3 border-l border-white/20 pl-4 sm:mb-6 sm:h-44 sm:gap-5 sm:pl-6 md:gap-6",children:b.map((s,t)=>e.jsx("div",{className:"flex h-[180px] w-10 items-end sm:w-12 md:w-14",children:e.jsx("div",{className:`bar-fill bar-fill-${t+1} w-full rounded-t-sm`,style:{backgroundColor:s.color}})},t))}),e.jsxs("div",{className:"flex items-center justify-between gap-4 border-t border-white/15 pt-4",children:[e.jsx("span",{className:"text-xs text-rose-100/80 sm:text-sm",children:"Innovation Velocity"}),e.jsx(g,{size:18,className:"flex-shrink-0 text-rose-200"})]})]},m)]})]})}export{v as default};
