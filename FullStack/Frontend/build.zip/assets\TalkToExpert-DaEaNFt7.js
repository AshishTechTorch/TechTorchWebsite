import{j as e,d as j}from"./vendor-query-PraSc8EQ.js";import{p as w}from"./index-37hjU4u5.js";import{d as v,r as o}from"./vendor-router-L4ZCoGSs.js";const p={phone:"+91 72510 90147",email:"contact@techtorch.solutions",whatsapp:"+91 72510 90147"},N=w,k=/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,z=/^[6-9]\d{9}$/,g={fullName:"",email:"",phone:"",company:"",preferredTime:"",details:""};function C(){v();const[t,m]=o.useState(g),[r,l]=o.useState({}),[x,s]=o.useState({type:"",message:""}),[d,h]=o.useState(!1),i=a=>{const{name:n,value:f}=a.target,y=n==="phone"?f.replace(/\D/g,"").slice(0,10):f;m(c=>({...c,[n]:y})),l(c=>({...c,[n]:""})),s({type:"",message:""})},u=()=>{const a={};return t.fullName.trim()||(a.fullName="Please enter your full name."),t.email.trim()?k.test(t.email.trim())||(a.email="Please enter a valid email address."):a.email="Please enter your email address.",t.phone.trim()?z.test(t.phone)||(a.phone="Please enter a valid 10-digit mobile number."):a.phone="Please enter your phone number.",t.details.trim()||(a.details="Please tell us how we can help."),l(a),Object.keys(a).length===0},b=async a=>{if(a.preventDefault(),s({type:"",message:""}),!!u()){h(!0);try{await j.post(`${N}/api/expert-queries`,{fullName:t.fullName.trim(),email:t.email.trim(),phone:t.phone,company:t.company.trim(),preferredTime:t.preferredTime,details:t.details.trim()}),s({type:"success",message:"Thank you! Your request has been submitted successfully."}),m(g),l({})}catch(n){s({type:"error",message:n.response?.data?.message||"We couldn't submit your request. Please try again or contact us directly."})}finally{h(!1)}}};return e.jsxs("section",{className:"expert-section",children:[e.jsxs("div",{className:"expert-layout",children:[e.jsxs("div",{className:"expert-left",children:[e.jsx("span",{className:"expert-eyebrow",children:"LET'S TALK"}),e.jsxs("h1",{className:"expert-main-heading",children:["Talk to Our ",e.jsx("span",{children:"Experts"})]}),e.jsx("p",{className:"expert-description",children:"Have a business challenge or an idea you want to bring to life? Our team is here to understand your needs and help you find the right technology solutions."}),e.jsxs("div",{className:"expert-contact-list",children:[e.jsxs("a",{href:"tel:+917251090147",className:"expert-contact-item",children:[e.jsx("span",{className:"expert-contact-icon","aria-hidden":"true",children:e.jsx("svg",{viewBox:"0 0 24 24",children:e.jsx("path",{d:"M22 16.92v3a2 2 0 0 1-2.18 2A19.8 19.8 0 0 1 11.19 18a19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.09 3.18 2 2 0 0 1 4.08 1h3a2 2 0 0 1 2 1.72c.12.96.36 1.9.7 2.8a2 2 0 0 1-.45 2.11L8.06 8.9a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.84.58 2.8.7a2 2 0 0 1 1.76 2.04Z"})})}),e.jsxs("span",{className:"expert-contact-copy",children:[e.jsx("span",{className:"expert-contact-label",children:"Call Us"}),e.jsx("strong",{children:p.phone})]})]}),e.jsxs("a",{href:`https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(p.email)}`,target:"_blank",rel:"noopener noreferrer",className:"expert-contact-item",children:[e.jsx("span",{className:"expert-contact-icon","aria-hidden":"true",children:e.jsxs("svg",{viewBox:"0 0 24 24",children:[e.jsx("rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"}),e.jsx("path",{d:"m22 7-10 7L2 7"})]})}),e.jsxs("span",{className:"expert-contact-copy",children:[e.jsx("span",{className:"expert-contact-label",children:"Email Us"}),e.jsx("strong",{children:p.email})]})]}),e.jsxs("a",{href:`https://wa.me/${p.whatsapp.replace(/\D/g,"")}`,target:"_blank",rel:"noopener noreferrer",className:"expert-contact-item",children:[e.jsx("span",{className:"expert-contact-icon","aria-hidden":"true",children:e.jsxs("svg",{viewBox:"0 0 24 24",children:[e.jsx("path",{d:"M21 11.5a8.4 8.4 0 0 1-12.4 7.4L3 20l1.2-5.3A8.4 8.4 0 1 1 21 11.5Z"}),e.jsx("path",{d:"M8.5 8.5c.4 2.2 2.1 3.9 4.3 4.3"})]})}),e.jsxs("span",{className:"expert-contact-copy",children:[e.jsx("span",{className:"expert-contact-label",children:"WhatsApp"}),e.jsx("strong",{children:"Chat with our team"})]})]})]}),e.jsxs("div",{className:"expert-note",children:[e.jsx("span",{className:"expert-note-dot"}),e.jsx("p",{children:"Let's work together to turn your ideas into impact."})]})]}),e.jsxs("div",{className:"expert-form-card",children:[e.jsxs("div",{className:"expert-form-heading",children:[e.jsx("span",{className:"expert-eyebrow",children:"GET IN TOUCH"}),e.jsx("h2",{children:"Let's Start a Conversation"}),e.jsx("p",{children:"Share a few details about your requirements. Our team will get back to you."})]}),e.jsxs("form",{onSubmit:b,noValidate:!0,children:[e.jsxs("div",{className:"expert-form-grid",children:[e.jsxs("div",{className:"expert-field",children:[e.jsxs("label",{htmlFor:"fullName",children:["Full Name ",e.jsx("span",{children:"*"})]}),e.jsx("input",{id:"fullName",name:"fullName",type:"text",placeholder:"Enter your full name",value:t.fullName,onChange:i,"aria-invalid":!!r.fullName}),r.fullName&&e.jsx("small",{className:"expert-error",children:r.fullName})]}),e.jsxs("div",{className:"expert-field",children:[e.jsxs("label",{htmlFor:"email",children:["Email Address ",e.jsx("span",{children:"*"})]}),e.jsx("input",{id:"email",name:"email",type:"email",placeholder:"you@company.com",value:t.email,onChange:i,"aria-invalid":!!r.email}),r.email&&e.jsx("small",{className:"expert-error",children:r.email})]}),e.jsxs("div",{className:"expert-field",children:[e.jsxs("label",{htmlFor:"phone",children:["Phone Number ",e.jsx("span",{children:"*"})]}),e.jsx("input",{id:"phone",name:"phone",type:"tel",inputMode:"numeric",placeholder:"10-digit mobile number",value:t.phone,onChange:i,"aria-invalid":!!r.phone}),r.phone&&e.jsx("small",{className:"expert-error",children:r.phone})]}),e.jsxs("div",{className:"expert-field",children:[e.jsx("label",{htmlFor:"company",children:"Company Name"}),e.jsx("input",{id:"company",name:"company",type:"text",placeholder:"Your company (optional)",value:t.company,onChange:i})]}),e.jsxs("div",{className:"expert-field expert-field-full",children:[e.jsx("label",{htmlFor:"preferredTime",children:"Preferred Time to Connect"}),e.jsxs("select",{id:"preferredTime",name:"preferredTime",value:t.preferredTime,onChange:i,children:[e.jsx("option",{value:"",children:"Select a convenient time"}),e.jsx("option",{value:"Morning",children:"Morning (9 AM – 12 PM)"}),e.jsx("option",{value:"Afternoon",children:"Afternoon (12 PM – 4 PM)"}),e.jsx("option",{value:"Evening",children:"Evening (4 PM – 7 PM)"})]})]}),e.jsxs("div",{className:"expert-field expert-field-full",children:[e.jsxs("label",{htmlFor:"details",children:["How Can We Help You? ",e.jsx("span",{children:"*"})]}),e.jsx("textarea",{id:"details",name:"details",rows:"4",placeholder:"Tell us about your project, goals, or requirements...",value:t.details,onChange:i,"aria-invalid":!!r.details}),r.details&&e.jsx("small",{className:"expert-error",children:r.details})]})]}),x.message&&e.jsx("div",{className:`expert-status expert-status-${x.type}`,role:"status",children:x.message}),e.jsxs("button",{type:"submit",className:"expert-submit-btn",disabled:d,children:[d?"Submitting...":"Submit Your Request",!d&&e.jsx("span",{"aria-hidden":"true",children:"→"})]}),e.jsx("p",{className:"expert-privacy-note",children:"Your information will only be used to respond to your enquiry."})]})]})]}),e.jsx("style",{children:`

        .expert-section,
        .expert-section * {
          box-sizing: border-box;
        }

        .expert-section {
          width: 100%;
          padding: 35px 0 70px;
          background: #efefef;
          color: #1b1b2a;
          font-family: 'Inter', sans-serif;
        }

        .expert-section h1,
        .expert-section h2 {
          font-family: 'Plus Jakarta Sans', sans-serif;
        }

        .expert-section p,
        .expert-section a,
        .expert-section label,
        .expert-section input,
        .expert-section select,
        .expert-section textarea,
        .expert-section button,
        .expert-section small,
        .expert-section strong,
        .expert-section .expert-eyebrow,
        .expert-section .expert-contact-label {
          font-family: 'Inter', sans-serif;
        }

        .expert-back-home {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          margin: 0 100px 28px;
          padding: 11px 17px;
          border: 1px solid #730042;
          border-radius: 8px;
          background: #ffffff;
          color: #730042;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: background 0.25s ease, color 0.25s ease;
        }

        .expert-back-home:hover {
          background: #730042;
          color: #ffffff;
        }

        .expert-back-home svg {
          flex-shrink: 0;
        }

        .expert-layout {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;
          padding: 0 100px;
          display: grid;
          grid-template-columns: minmax(0, 1fr) minmax(380px, 460px);
          gap: 65px;
          align-items: start;
        }

        .expert-left {
          padding-top: 22px;
          min-width: 0;
        }

        .expert-eyebrow {
          display: inline-block;
          color: #730042;
          font-size: 12px;
          font-weight: 700;
          letter-spacing: 2px;
          margin-bottom: 17px;
        }

        .expert-main-heading {
          margin: 0 0 22px;
          max-width: 650px;
          font-size: clamp(36px, 4vw, 58px);
          line-height: 1.12;
          letter-spacing: -1.8px;
          font-weight: 700;
        }

        .expert-main-heading span {
          color: #730042;
        }

        .expert-description {
          max-width: 570px;
          margin: 0;
          color: #5b5a63;
          font-size: 16px;
          line-height: 1.9;
        }

        .expert-contact-list {
          display: grid;
          gap: 16px;
          margin-top: 38px;
          max-width: 500px;
        }

        .expert-contact-item {
          display: flex;
          align-items: center;
          gap: 17px;
          min-width: 0;
          padding: 16px;
          border: 1px solid #e0dce0;
          border-radius: 12px;
          background: rgba(255, 255, 255, 0.65);
          color: #1b1b2a;
          text-decoration: none;
          transition: border-color 0.25s ease, transform 0.25s ease,
            background 0.25s ease;
        }

        .expert-contact-item:hover {
          border-color: #730042;
          background: #fff;
          transform: translateY(-2px);
        }

        .expert-contact-icon {
          width: 48px;
          height: 48px;
          flex: 0 0 48px;
          display: grid;
          place-items: center;
          border-radius: 10px;
          background: #f4e8ef;
          color: #730042;
        }

        .expert-contact-icon svg {
          width: 22px;
          height: 22px;
          fill: none;
          stroke: currentColor;
          stroke-width: 1.7;
          stroke-linecap: round;
          stroke-linejoin: round;
        }

        .expert-contact-copy {
          display: flex;
          flex-direction: column;
          gap: 6px;
          min-width: 0;
        }

        .expert-contact-label {
          color: #77717b;
          font-size: 12px;
          font-weight: 500;
        }

        .expert-contact-copy strong {
          overflow-wrap: anywhere;
          font-size: 15px;
          font-weight: 600;
        }

        .expert-note {
          display: flex;
          align-items: center;
          gap: 11px;
          margin-top: 30px;
          color: #5b5a63;
          font-size: 13px;
          line-height: 1.7;
        }

        .expert-note p {
          margin: 0;
        }

        .expert-note-dot {
          width: 8px;
          height: 8px;
          flex: 0 0 8px;
          border-radius: 50%;
          background: #730042;
        }

        .expert-form-card {
          min-width: 0;
          padding: 32px;
          border: 1px solid #e7e3e7;
          border-radius: 18px;
          background: #fff;
          box-shadow: 0 15px 45px rgba(27, 27, 42, 0.06);
        }

        .expert-form-heading {
          margin-bottom: 26px;
        }

        .expert-form-heading .expert-eyebrow {
          margin-bottom: 11px;
        }

        .expert-form-heading h2 {
          margin: 0 0 11px;
          font-size: clamp(23px, 2vw, 30px);
          line-height: 1.3;
          letter-spacing: -0.7px;
          font-weight: 700;
        }

        .expert-form-heading p {
          margin: 0;
          color: #77717b;
          font-size: 13px;
          line-height: 1.8;
        }

        .expert-form-grid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 19px 15px;
        }

        .expert-field {
          display: flex;
          flex-direction: column;
          min-width: 0;
        }

        .expert-field-full {
          grid-column: 1 / -1;
        }

        .expert-field label {
          margin-bottom: 8px;
          color: #292633;
          font-size: 12px;
          font-weight: 600;
          line-height: 1.5;
        }

        .expert-field label span {
          color: #730042;
        }

        .expert-field input,
        .expert-field select,
        .expert-field textarea {
          width: 100%;
          min-width: 0;
          border: 1px solid #dedbe1;
          border-radius: 8px;
          outline: none;
          background: #fff;
          color: #1b1b2a;
          font-size: 13px;
          transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }

        .expert-field input,
        .expert-field select {
          height: 46px;
          padding: 0 12px;
        }

        .expert-field textarea {
          min-height: 110px;
          padding: 12px;
          resize: vertical;
          line-height: 1.7;
        }

        .expert-field input::placeholder,
        .expert-field textarea::placeholder {
          color: #aaa5ae;
        }

        .expert-field input:focus,
        .expert-field select:focus,
        .expert-field textarea:focus {
          border-color: #730042;
          box-shadow: 0 0 0 3px rgba(115, 0, 66, 0.08);
        }

        .expert-field input[aria-invalid="true"],
        .expert-field textarea[aria-invalid="true"] {
          border-color: #c62828;
        }

        .expert-error {
          margin-top: 6px;
          color: #c62828;
          font-size: 11px;
          line-height: 1.5;
        }

        .expert-status {
          margin-top: 18px;
          padding: 12px 14px;
          border-radius: 8px;
          font-size: 12px;
          line-height: 1.7;
        }

        .expert-status-success {
          color: #17653a;
          border: 1px solid #b9e2c8;
          background: #effaf2;
        }

        .expert-status-error {
          color: #a52222;
          border: 1px solid #f0c7c7;
          background: #fff3f3;
        }

        .expert-submit-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 12px;
          width: 100%;
          min-height: 50px;
          margin-top: 22px;
          padding: 13px 18px;
          border: 1px solid #730042;
          border-radius: 8px;
          background: #730042;
          color: #fff;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: background 0.25s ease, color 0.25s ease,
            border-color 0.25s ease;
        }

        .expert-submit-btn:hover:not(:disabled) {
          background: #fff;
          color: #730042;
        }

        .expert-submit-btn:disabled {
          opacity: 0.65;
          cursor: not-allowed;
        }

        .expert-submit-btn span {
          font-size: 20px;
          line-height: 1;
        }

        .expert-privacy-note {
          margin: 13px 0 0;
          color: #8b8690;
          font-size: 11px;
          line-height: 1.7;
          text-align: center;
        }

        @media (max-width: 1100px) {
          .expert-layout {
            padding: 0 40px;
            grid-template-columns: minmax(0, 1fr) minmax(340px, 430px);
            gap: 35px;
          }

          .expert-back-home {
            margin-left: 40px;
            margin-right: 40px;
          }

          .expert-form-card {
            padding: 26px;
          }

          .expert-main-heading {
            font-size: clamp(34px, 4.5vw, 48px);
          }
        }

        @media (max-width: 850px) {
          .expert-section {
            padding: 30px 0 55px;
          }

          .expert-layout {
            grid-template-columns: minmax(0, 1fr);
            gap: 35px;
          }

          .expert-left {
            padding-top: 0;
          }

          .expert-description {
            max-width: 680px;
          }

          .expert-contact-list {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            max-width: none;
          }

          .expert-form-card {
            width: 100%;
            max-width: 650px;
          }
        }

        @media (max-width: 600px) {
          .expert-section {
            padding: 25px 0 42px;
          }

          .expert-back-home {
            margin-left: 24px;
            margin-right: 24px;
            margin-bottom: 22px;
          }

          .expert-layout {
            padding: 0 24px;
            gap: 28px;
          }

          .expert-main-heading {
            font-size: clamp(33px, 8vw, 43px);
            letter-spacing: -1.2px;
          }

          .expert-description {
            font-size: 14px;
            line-height: 1.85;
          }

          .expert-contact-list {
            grid-template-columns: minmax(0, 1fr);
            gap: 12px;
            margin-top: 26px;
          }

          .expert-contact-item {
            padding: 13px;
          }

          .expert-form-card {
            padding: 23px 19px;
            border-radius: 14px;
          }

          .expert-form-grid {
            grid-template-columns: minmax(0, 1fr);
            gap: 17px;
          }

          .expert-field-full {
            grid-column: auto;
          }

          .expert-form-heading h2 {
            font-size: 25px;
          }
        }

        @media (max-width: 380px) {
          .expert-back-home {
            margin-left: 16px;
            margin-right: 16px;
          }

          .expert-layout {
            padding: 0 16px;
          }

          .expert-section {
            padding: 22px 0 35px;
          }

          .expert-main-heading {
            font-size: 31px;
          }

          .expert-form-card {
            padding: 20px 15px;
          }

          .expert-contact-icon {
            width: 42px;
            height: 42px;
            flex-basis: 42px;
          }

          .expert-contact-copy strong {
            font-size: 13px;
          }
        }
      `})]})}export{C as default};
