import{j as e}from"./vendor-query-PraSc8EQ.js";import{L as o}from"./vendor-router-L4ZCoGSs.js";import{t as d,Z as g,A as r,s as x,r as b,R as c,X as m,a2 as p,a6 as h}from"./index-37hjU4u5.js";import{U as f}from"./user-cog-DR4rZ0mg.js";import{A as u}from"./arrow-left-right-arVRAjz_.js";import{C as w}from"./code-xml-CIX-EOu2.js";import{S as y}from"./smartphone-CoEIwl-3.js";import{C as j}from"./chart-column-CdCTLONG.js";import{W as v}from"./workflow-4I6MIdFw.js";import{R as N}from"./rocket-B8Wt4fTK.js";import{T as k}from"./target-BdO2Z0xV.js";import{L as z}from"./layers-GER1Kp3Z.js";import{A as S}from"./award-Cg1W0rjp.js";const l={name:"check-check",size:24,node:[["path",{d:"M18 6 7 17l-5-5",key:"116fxf"}],["path",{d:"m22 10-7.5 7.5L13 16",key:"ke71qq"}]]};l.node;const T=d(l),i="#730024",A=["Skilled Resources","Flexible Staffing","Technology Support"],R=[{icon:f,number:"01",title:"Skill-Aligned Resources",description:"Identify technical professionals based on the skills, experience, technology environment, and responsibilities required for your project.",tags:["Technical Skills","Relevant Expertise","Project Requirements"]},{icon:u,number:"02",title:"Flexible Team Support",description:"Add technical capacity when your workload or project requirements change, while complementing the capabilities of your existing team.",tags:["Flexible Staffing","Team Support","Technical Capacity"]},{icon:x,number:"03",title:"Project-Focused Collaboration",description:"Enable resources to work within your existing project structure, processes, technologies, and team environment.",tags:["Project Collaboration","Team Integration","Technical Support"]}],E=[{icon:w,number:"01",title:"Custom Software Development",description:"Develop software solutions around specific business processes, requirements, and operational needs.",tag:"Enterprise Aligned"},{icon:y,number:"02",title:"Web & Mobile Application Development",description:"Create practical and responsive applications designed for modern web and mobile environments.",tag:"Full-Stack & Native"},{icon:j,number:"03",title:"Enterprise Software Solutions",description:"Support core business functions through technology solutions that integrate with existing business processes.",tag:"ERP & Core Systems"},{icon:v,number:"04",title:"API Development & System Integration",description:"Connect applications and platforms through reliable APIs and structured system integration.",tag:"Secure REST & Microservices"},{icon:b,number:"05",title:"Quality Assurance & Testing",description:"Support software quality through functional, performance, security, and usability testing.",tag:"Functional & Automated QA"},{icon:c,number:"06",title:"Software Modernization",description:"Modernize existing applications and technology environments to meet changing business and technical requirements.",tag:"Legacy to Cloud & Modern Stack"}],s=[{icon:m,dot:"1",label:"Discovery",tag:"01 / PHASE 1",title:"Understand & Scoping",description:"We begin by understanding your project objectives, technology environment, required skills, and resource needs.",keyActivities:["Objective Scoping","Tech Stack Matrix","Skill Profile Audit"],footLabel:"Detailed Blueprint",footRight:"Step 01"},{icon:p,dot:"2",label:"Alignment",tag:"02 / PHASE 2",title:"Identify & Select",description:"Technical resources are mapped to the capabilities needed for your project with rigorous vetting.",keyActivities:["Skill & Seniority Match","Architecture Validation","Culture & Team Fit"],footLabel:"Verified Talent Profiles",footRight:"Step 02"},{icon:h,dot:"3",label:"Integration",tag:"03 / PHASE 3",title:"Align & Onboard",description:"Relevant technology resources are aligned with your project, workflows, and existing team structure.",keyActivities:["Workflow Synchronization","Toolchain & Access Setup","Sprint Alignment"],footLabel:"Team Embedding",footRight:"Step 03"},{icon:N,dot:"4",label:"Momentum",tag:"04 / PHASE 4",title:"Support & Scale",description:"Resources continue to contribute with ongoing technical governance as project priorities and requirements evolve.",keyActivities:["Performance Monitoring","Dynamic Capacity Scaling","Knowledge Retention"],footLabel:"Delivery Velocity",footRight:"Step 04"}],C=[{icon:k,title:"Relevant Technical Expertise",description:"Access technology capabilities aligned with your project requirements."},{icon:z,title:"Flexible Resource Support",description:"Support your existing team with additional technical capacity when needed."},{icon:h,title:"Project-Focused Approach",description:"Keep resource requirements connected to your actual project goals and technology environment."},{icon:S,title:"Broad Technology Capabilities",description:"Benefit from expertise spanning software development, integration, testing, modernization, and support."}],I=["Skilled Resources","Flexible Staffing","Technology Support"];function U(){return e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"bench-page",children:[e.jsx("section",{className:"bench-hero",children:e.jsx("div",{className:"bench-container bench-hero-container",children:e.jsxs("div",{className:"bench-hero-grid",children:[e.jsxs("div",{className:"bench-hero-content",children:[e.jsxs("div",{className:"bench-hero-badge",children:[e.jsx(g,{className:"bench-hero-badge-icon"}),e.jsx("span",{children:"IT AUGMENTATION • BENCH HIRING"})]}),e.jsx("h1",{className:"bench-hero-heading",children:"Build Your Technology Team with the Right Resources"}),e.jsx("p",{className:"bench-hero-subheading",children:"Access skilled technology professionals to support your projects, strengthen your existing teams, and respond to changing business and technology requirements."}),e.jsxs(o,{to:"/talk-to-expert",className:"bench-primary-button",children:["Talk to Our Experts",e.jsx(r,{})]}),e.jsx("div",{className:"bench-hero-tags",children:A.map(n=>e.jsxs("span",{className:"bench-tag",children:[e.jsx("span",{className:"bench-tag-dot"}),n]},n))})]}),e.jsx("div",{className:"bench-hero-image-card",children:e.jsxs("div",{className:"bench-hero-image",children:[e.jsx("div",{className:"bench-hero-image-overlay"}),e.jsxs("div",{className:"bench-hero-image-footer",children:[e.jsxs("span",{children:[e.jsx("span",{className:"bench-status-dot"}),"Enterprise Ready Bench"]}),e.jsx("span",{children:"Verified Technical Talent"})]})]})})]})})}),e.jsx("section",{className:"bench-content-section",children:e.jsxs("div",{className:"bench-container",children:[e.jsxs("div",{className:"bench-centered-content",children:[e.jsxs("div",{className:"bench-section-label",children:[e.jsx("span",{}),"STRATEGIC RESOURCING"]}),e.jsx("h2",{className:"bench-section-heading",children:"Flexible Technology Resources for Growing Business Needs"}),e.jsxs("div",{className:"bench-prose",children:[e.jsx("p",{children:"Technology projects do not always require the same level of expertise or team capacity. As business priorities change, organizations may need additional technical resources to support ongoing projects, new initiatives, or specific technology requirements."}),e.jsx("p",{children:"TechTorch provides Resource and Staffing solutions that help businesses access skilled professionals and flexible workforce support. Our approach focuses on understanding your project requirements and aligning the right technical capabilities with your existing teams and working environment."}),e.jsx("p",{children:"From software development and application engineering to system integration, testing, modernization, and technical support, the right resources can help businesses manage changing workloads while keeping their technology initiatives moving forward."})]})]}),e.jsxs("blockquote",{className:"bench-pull-quote",children:[e.jsx("p",{children:'"The right people, the right technical capabilities, and the right support for your business requirements."'}),e.jsx("span",{children:"— TECHTORCH RESOURCING FRAMEWORK"})]}),e.jsxs("div",{className:"bench-centered-content bench-secondary-content",children:[e.jsx("h3",{className:"bench-secondary-heading",children:"Technology Expertise That Supports Your Projects"}),e.jsxs("div",{className:"bench-prose",children:[e.jsx("p",{children:"TechTorch's software engineering capabilities cover a broad range of technology requirements, including custom software development, web and mobile application development, enterprise software solutions, API development and system integration, quality assurance and testing, software modernization, and ongoing maintenance and support."}),e.jsx("p",{children:"This allows businesses to align technical resources with the nature of their projects, existing technology environment, and operational requirements."})]})]})]})}),e.jsx("section",{className:"bench-section",children:e.jsxs("div",{className:"bench-container",children:[e.jsx("div",{className:"bench-section-eyebrow",children:"BENCH HIRING SUPPORT"}),e.jsx("h2",{className:"bench-section-title",children:"Structured Approach to Engineering Continuity"}),e.jsx("div",{className:"bench-approach-grid",children:R.map(n=>{const t=n.icon;return e.jsxs("div",{className:"bench-card",children:[e.jsxs("div",{className:"bench-card-top",children:[e.jsx("div",{className:"bench-icon-box",children:e.jsx(t,{})}),e.jsx("span",{className:"bench-card-number",children:n.number})]}),e.jsx("h3",{children:n.title}),e.jsx("p",{children:n.description}),e.jsx("div",{className:"bench-card-tags",children:n.tags.map(a=>e.jsx("span",{children:a},a))})]},n.number)})})]})}),e.jsx("section",{className:"bench-section",children:e.jsxs("div",{className:"bench-container",children:[e.jsx("div",{className:"bench-section-eyebrow",children:"TECHNOLOGY CAPABILITIES"}),e.jsx("h2",{className:"bench-section-title",children:"Support Across Your Technology Requirements"}),e.jsx("p",{className:"bench-section-description",children:"Bench hiring can support a range of technology activities depending on the requirements of your project."}),e.jsx("div",{className:"bench-capability-grid",children:E.map(n=>{const t=n.icon;return e.jsxs("div",{className:"bench-card",children:[e.jsxs("div",{className:"bench-card-top",children:[e.jsx("div",{className:"bench-icon-box",children:e.jsx(t,{})}),e.jsxs("span",{className:"bench-capability-number",children:["CAPABILITY ",n.number]})]}),e.jsx("h3",{children:n.title}),e.jsx("p",{children:n.description}),e.jsx("span",{className:"bench-capability-tag",children:n.tag})]},n.number)})}),e.jsxs("div",{className:"bench-maintenance-card",children:[e.jsxs("div",{className:"bench-maintenance-left",children:[e.jsx("div",{className:"bench-icon-box",children:e.jsx(c,{})}),e.jsxs("div",{children:[e.jsx("div",{className:"bench-maintenance-label",children:"CAPABILITY 07"}),e.jsx("h3",{children:"Ongoing Maintenance & Support"}),e.jsx("p",{children:"Provide continued technical assistance, updates, improvements, and support throughout the software lifecycle."})]})]}),e.jsxs("div",{className:"bench-maintenance-right",children:[e.jsx("span",{children:"SLA & Continuous Health"}),e.jsx("strong",{children:"Specialized Support →"})]})]})]})}),e.jsx("section",{className:"bench-section",children:e.jsxs("div",{className:"bench-container",children:[e.jsxs("div",{className:"bench-workflow-header",children:[e.jsxs("div",{className:"bench-section-label",children:[e.jsx("span",{}),"DELIVERY WORKFLOW • 4-PHASE DEPLOYMENT"]}),e.jsxs("div",{className:"bench-sla-label",children:[e.jsx("span",{}),"SLA-GOVERNED EXECUTION"]})]}),e.jsx("h2",{className:"bench-section-title",children:"From Requirement to Resource Alignment"}),e.jsx("p",{className:"bench-section-description",children:"A systematic four-stage methodology engineered to maintain project velocity, smooth onboarding, and uninterrupted operational continuity."}),e.jsxs("div",{className:"bench-phase-tracker",children:[e.jsx("div",{className:"bench-phase-line"}),s.map(n=>e.jsxs("div",{className:"bench-phase-point",children:[e.jsx("div",{className:"bench-phase-number",children:n.dot}),e.jsx("span",{children:n.label})]},n.dot))]}),e.jsx("div",{className:"bench-phase-grid",children:s.map(n=>{const t=n.icon;return e.jsxs("div",{className:"bench-phase-card",children:[e.jsxs("div",{className:"bench-phase-card-top",children:[e.jsx("div",{className:"bench-icon-box",children:e.jsx(t,{})}),e.jsx("span",{children:n.tag})]}),e.jsx("h3",{children:n.title}),e.jsx("p",{children:n.description}),e.jsx("div",{className:"bench-activities-label",children:"KEY ACTIVITIES"}),e.jsx("ul",{children:n.keyActivities.map(a=>e.jsxs("li",{children:[e.jsx("span",{}),a]},a))}),e.jsxs("div",{className:"bench-phase-footer",children:[e.jsx("strong",{children:n.footLabel}),e.jsx("span",{children:n.footRight})]})]},n.tag)})}),e.jsxs("div",{className:"bench-guarantee",children:[e.jsxs("div",{className:"bench-guarantee-content",children:[e.jsx(T,{}),e.jsxs("p",{children:[e.jsx("strong",{children:"Enterprise Deployment Guarantee:"})," ","Dedicated account management, structured weekly velocity checkpoints, and zero operational disruption throughout every engagement."]})]}),e.jsx("span",{children:"ZERO DISRUPTION"})]})]})}),e.jsx("section",{className:"bench-why-section",children:e.jsx("div",{className:"bench-container",children:e.jsxs("div",{className:"bench-why-box",children:[e.jsxs("span",{className:"bench-why-label",children:[e.jsx("span",{}),"WHY TECHTORCH"]}),e.jsx("h2",{children:"Technology Support Built Around Your Requirements"}),e.jsx("p",{children:"Flexible resourcing engineered to integrate seamlessly with your teams, methodologies, and enterprise goals."}),e.jsx("div",{className:"bench-why-grid",children:C.map(n=>{const t=n.icon;return e.jsxs("div",{className:"bench-why-card",children:[e.jsx("div",{className:"bench-why-icon",children:e.jsx(t,{})}),e.jsx("h3",{children:n.title}),e.jsx("p",{children:n.description})]},n.title)})})]})})}),e.jsx("section",{className:"bench-final-section",children:e.jsx("div",{className:"bench-container",children:e.jsxs("div",{className:"bench-final-card",children:[e.jsxs("div",{className:"bench-final-label",children:[e.jsx("span",{}),"STRENGTHEN YOUR TEAM"]}),e.jsx("h2",{children:"Strengthen Your Technology Team with the Right Resources"}),e.jsx("p",{children:"Whether you need additional technical capacity for an ongoing project or support for a new technology initiative, TechTorch can help you explore resource and staffing solutions aligned with your requirements."}),e.jsxs(o,{to:"/talk-to-expert",className:"bench-primary-button",children:["Talk to Our Experts",e.jsx(r,{})]}),e.jsx("div",{className:"bench-final-tags",children:I.map(n=>e.jsxs("span",{children:[e.jsx(p,{}),n]},n))}),e.jsx("div",{className:"bench-final-bottom",children:"Enterprise Grade Governance & Rapid SLA Deployment"})]})})})]}),e.jsx("style",{children:`

        /* =====================================================
           BASE
        ===================================================== */

        .bench-page {
          width: 100%;
          overflow: hidden;
          background: #f8f9fa;
          color: #1c1c1c;
          font-family: Inter, sans-serif;
        }

        .bench-container {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;
          padding-left: 100px;
          padding-right: 100px;
        }

        .bench-page h1,
        .bench-page h2,
        .bench-page h3 {
          font-family: "Plus Jakarta Sans", sans-serif;
        }

        button {
          font-family: Inter, sans-serif;
        }

        /* =====================================================
           HERO
        ===================================================== */

        .bench-hero {
          width: 100%;
          padding-top: 64px;
          padding-bottom: 56px;
          background: #f8f9fa;
        }

        .bench-hero-container {
          display: flex;
          align-items: center;
        }

        .bench-hero-grid {
          width: 100%;
          display: grid;
          grid-template-columns: minmax(0, 1fr) minmax(340px, 430px);
          align-items: center;
          gap: 70px;
        }

        .bench-hero-content {
          display: flex;
          flex-direction: column;
          align-items: flex-start;
          text-align: left;
        }

        .bench-hero-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          margin-bottom: 22px;
          padding: 8px 13px;
          border-radius: 999px;
          background: rgba(115, 0, 36, 0.05);
          border: 1px solid rgba(115, 0, 36, 0.1);
          color: ${i};
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.06em;
        }

        .bench-hero-badge-icon {
          width: 13px;
          height: 13px;
        }

        .bench-hero-heading {
          max-width: 720px;
          margin: 0 0 18px;
          color: #161620;
          font-size: clamp(34px, 3.4vw, 50px);
          line-height: 1.12;
          font-weight: 700;
          letter-spacing: -0.035em;
        }

        .bench-hero-subheading {
          max-width: 650px;
          margin: 0 0 25px;
          color: #737373;
          font-size: 14px;
          line-height: 1.7;
          font-weight: 500;
        }

        .bench-primary-button {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          width: fit-content;
          border: 0;
          border-radius: 7px;
          padding: 12px 20px;
          background: ${i};
          color: #ffffff;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          transition:
            transform 0.3s ease,
            background 0.3s ease,
            box-shadow 0.3s ease;
        }

        .bench-primary-button:hover {
          transform: translateY(-2px);
          background: #5c0035;
          box-shadow: 0 10px 24px rgba(115, 0, 36, 0.18);
        }

        .bench-primary-button svg {
          width: 15px;
          height: 15px;
        }

        .bench-hero-tags {
          display: flex;
          flex-wrap: wrap;
          align-items: center;
          gap: 8px;
        }

        .bench-tag {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          padding: 6px 9px;
          border: 1px solid #e5e5e5;
          border-radius: 4px;
          background: #ffffff;
          color: #5f5f5f;
          font-size: 9px;
          font-weight: 500;
        }

        .bench-tag-dot {
          width: 4px;
          height: 4px;
          border-radius: 50%;
          background: ${i};
        }

        .bench-hero-image-card {
          width: 100%;
          max-width: 430px;
          margin: 0 auto;
          overflow: hidden;
          border: 1px solid #e5e5e5;
          border-radius: 16px;
          background: #ffffff;
          box-shadow: 0 15px 40px rgba(0, 0, 0, 0.06);
        }

        .bench-hero-image {
          position: relative;
          width: 100%;
          height: 340px;
          background-image: url("/benchhiring.webp");
          background-size: cover;
          background-position: center;
        }

        .bench-hero-image-overlay {
          position: absolute;
          inset: 0;
          background: linear-gradient(
            180deg,
            transparent 45%,
            rgba(0, 0, 0, 0.68) 100%
          );
        }

        .bench-hero-image-footer {
          position: absolute;
          left: 18px;
          right: 18px;
          bottom: 17px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          color: #ffffff;
          font-size: 9px;
          font-weight: 500;
        }

        .bench-hero-image-footer span:first-child {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .bench-status-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #34d399;
        }

        /* =====================================================
           CONTENT
        ===================================================== */

        .bench-content-section {
          width: 100%;
          padding-top: 65px;
          padding-bottom: 70px;
          background: #ffffff;
        }

        .bench-centered-content {
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
        }

        .bench-section-label,
        .bench-section-eyebrow {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          color: ${i};
          font-size: 9px;
          font-weight: 700;
          letter-spacing: 0.08em;
        }

        .bench-section-label {
          padding: 7px 11px;
          border-radius: 999px;
          background: rgba(115, 0, 36, 0.05);
          border: 1px solid rgba(115, 0, 36, 0.1);
        }

        .bench-section-label span,
        .bench-final-label span {
          width: 4px;
          height: 4px;
          border-radius: 50%;
          background: ${i};
        }

        .bench-section-heading {
          max-width: 760px;
          margin: 17px 0 25px;
          color: #161620;
          font-size: clamp(28px, 3vw, 39px);
          line-height: 1.2;
          font-weight: 700;
          letter-spacing: -0.025em;
        }

        .bench-prose {
          width: 100%;
          max-width: 780px;
          display: flex;
          flex-direction: column;
          gap: 18px;
          color: #626262;
          font-size: 13px;
          line-height: 1.8;
        }

        .bench-prose p {
          margin: 0;
        }

        .bench-pull-quote {
          width: 100%;
          max-width: 780px;
          margin: 38px auto;
          padding: 19px 22px;
          border-left: 3px solid ${i};
          background: rgba(115, 0, 36, 0.05);
          text-align: left;
        }

        .bench-pull-quote p {
          margin: 0 0 9px;
          color: #454545;
          font-size: 12px;
          line-height: 1.7;
          font-style: italic;
        }

        .bench-pull-quote span {
          color: ${i};
          font-size: 8px;
          font-weight: 700;
          letter-spacing: 0.08em;
        }

        .bench-secondary-content {
          margin-top: 5px;
        }

        .bench-secondary-heading {
          margin: 0 0 15px;
          color: #161620;
          font-size: 22px;
          line-height: 1.3;
          font-weight: 700;
        }

        /* =====================================================
           GENERAL SECTION
        ===================================================== */

        .bench-section {
          width: 100%;
          padding-top: 65px;
          padding-bottom: 65px;
          background: #f8f9fa;
        }

        .bench-section-title {
          max-width: 700px;
          margin: 13px 0 11px;
          color: #161620;
          font-size: clamp(26px, 2.8vw, 37px);
          line-height: 1.2;
          font-weight: 700;
          letter-spacing: -0.025em;
        }

        .bench-section-description {
          max-width: 650px;
          margin: 0 0 28px;
          color: #747474;
          font-size: 12px;
          line-height: 1.7;
        }

        /* =====================================================
           CARDS
        ===================================================== */

        .bench-approach-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 18px;
        }

        .bench-capability-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 18px;
          margin-bottom: 18px;
        }

        .bench-card {
          position: relative;
          min-width: 0;
          padding: 23px;
          border: 1px solid #e5e5e5;
          border-radius: 11px;
          background: #ffffff;
          transition:
            transform 0.3s ease,
            box-shadow 0.3s ease,
            border-color 0.3s ease;
        }

        .bench-card:hover {
          transform: translateY(-4px);
          border-color: rgba(115, 0, 36, 0.2);
          box-shadow: 0 14px 32px rgba(115, 0, 36, 0.07);
        }

        .bench-card-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          margin-bottom: 19px;
        }

        .bench-icon-box {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 34px;
          height: 34px;
          flex-shrink: 0;
          border-radius: 8px;
          background: rgba(115, 0, 36, 0.06);
          color: ${i};
        }

        .bench-icon-box svg {
          width: 16px;
          height: 16px;
        }

        .bench-card-number,
        .bench-capability-number {
          color: #d2d2d2;
          font-size: 9px;
          font-weight: 700;
          letter-spacing: 0.04em;
        }

        .bench-card h3 {
          margin: 0 0 9px;
          color: #161620;
          font-size: 15px;
          line-height: 1.35;
          font-weight: 700;
        }

        .bench-card p {
          margin: 0 0 17px;
          color: #707070;
          font-size: 11px;
          line-height: 1.65;
        }

        .bench-card-tags {
          display: flex;
          flex-wrap: wrap;
          gap: 5px;
        }

        .bench-card-tags span,
        .bench-capability-tag {
          display: inline-flex;
          width: fit-content;
          padding: 5px 7px;
          border-radius: 4px;
          background: #f1f1f1;
          color: #606060;
          font-size: 8px;
          font-weight: 500;
        }

        .bench-capability-tag {
          margin-top: 2px;
        }

        /* =====================================================
           MAINTENANCE
        ===================================================== */

        .bench-maintenance-card {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 25px;
          padding: 20px 23px;
          border: 1px solid #e5e5e5;
          border-radius: 11px;
          background: #ffffff;
        }

        .bench-maintenance-left {
          display: flex;
          align-items: center;
          gap: 14px;
          min-width: 0;
        }

        .bench-maintenance-label {
          margin-bottom: 5px;
          color: ${i};
          font-size: 8px;
          font-weight: 700;
          letter-spacing: 0.07em;
        }

        .bench-maintenance-left h3 {
          margin: 0 0 5px;
          color: #161620;
          font-size: 14px;
          font-weight: 700;
        }

        .bench-maintenance-left p {
          max-width: 700px;
          margin: 0;
          color: #707070;
          font-size: 10px;
          line-height: 1.6;
        }

        .bench-maintenance-right {
          display: flex;
          align-items: center;
          gap: 12px;
          flex-shrink: 0;
        }

        .bench-maintenance-right span {
          padding: 5px 7px;
          border-radius: 4px;
          background: #f1f1f1;
          color: #606060;
          font-size: 8px;
          white-space: nowrap;
        }

        .bench-maintenance-right strong {
          color: ${i};
          font-size: 9px;
          white-space: nowrap;
        }

        /* =====================================================
           WORKFLOW
        ===================================================== */

        .bench-workflow-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 20px;
          margin-bottom: 5px;
        }

        .bench-sla-label {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 7px 11px;
          border-radius: 999px;
          background: #eeeeee;
          color: #646464;
          font-size: 8px;
          font-weight: 700;
          letter-spacing: 0.06em;
        }

        .bench-sla-label span {
          width: 4px;
          height: 4px;
          border-radius: 50%;
          background: ${i};
        }

        .bench-phase-tracker {
          position: relative;
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          margin: 38px 0 32px;
        }

        .bench-phase-line {
          position: absolute;
          top: 13px;
          left: 8%;
          right: 8%;
          height: 1px;
          background: rgba(115, 0, 36, 0.2);
        }

        .bench-phase-point {
          position: relative;
          z-index: 2;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
        }

        .bench-phase-number {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 27px;
          height: 27px;
          border-radius: 50%;
          background: ${i};
          color: #ffffff;
          font-size: 9px;
          font-weight: 700;
        }

        .bench-phase-point span {
          color: #626262;
          font-size: 9px;
          font-weight: 500;
        }

        .bench-phase-grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 15px;
          margin-bottom: 17px;
        }

        .bench-phase-card {
          min-width: 0;
          padding: 19px;
          border: 1px solid #e5e5e5;
          border-radius: 11px;
          background: #ffffff;
          transition:
            transform 0.3s ease,
            box-shadow 0.3s ease;
        }

        .bench-phase-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 13px 30px rgba(115, 0, 36, 0.06);
        }

        .bench-phase-card-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
          margin-bottom: 16px;
        }

        .bench-phase-card-top > span {
          color: #999999;
          font-size: 7px;
          font-weight: 700;
        }

        .bench-phase-card h3 {
          margin: 0 0 9px;
          color: #161620;
          font-size: 13px;
          line-height: 1.35;
          font-weight: 700;
        }

        .bench-phase-card > p {
          margin: 0 0 15px;
          color: #707070;
          font-size: 10px;
          line-height: 1.65;
        }

        .bench-activities-label {
          margin-bottom: 8px;
          color: #999999;
          font-size: 7px;
          font-weight: 700;
          letter-spacing: 0.08em;
        }

        .bench-phase-card ul {
          display: flex;
          flex-direction: column;
          gap: 6px;
          margin: 0 0 15px;
          padding: 0;
          list-style: none;
        }

        .bench-phase-card li {
          display: flex;
          align-items: flex-start;
          gap: 7px;
          color: #686868;
          font-size: 8px;
          line-height: 1.45;
        }

        .bench-phase-card li span {
          width: 4px;
          height: 4px;
          flex-shrink: 0;
          margin-top: 4px;
          border-radius: 50%;
          background: ${i};
        }

        .bench-phase-footer {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          padding-top: 11px;
          border-top: 1px solid #eeeeee;
        }

        .bench-phase-footer strong {
          color: ${i};
          font-size: 8px;
        }

        .bench-phase-footer span {
          color: #999999;
          font-size: 8px;
        }

        .bench-guarantee {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 20px;
          padding: 14px 18px;
          border: 1px solid #e5e5e5;
          border-radius: 10px;
          background: #ffffff;
        }

        .bench-guarantee-content {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .bench-guarantee-content svg {
          width: 16px;
          height: 16px;
          flex-shrink: 0;
          color: ${i};
        }

        .bench-guarantee p {
          margin: 0;
          color: #626262;
          font-size: 8.5px;
          line-height: 1.55;
        }

        .bench-guarantee p strong {
          color: #161620;
        }

        .bench-guarantee > span {
          color: ${i};
          font-size: 7.5px;
          font-weight: 700;
          white-space: nowrap;
        }

        /* =====================================================
           WHY TECHTORCH
        ===================================================== */

        .bench-why-section {
          width: 100%;
          padding-top: 45px;
          padding-bottom: 45px;
          background: #f8f9fa;
        }

        .bench-why-box {
          padding: 42px;
          border-radius: 17px;
          background: ${i};
        }

        .bench-why-label {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          margin-bottom: 15px;
          padding: 7px 11px;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 999px;
          background: rgba(255, 255, 255, 0.1);
          color: rgba(255, 255, 255, 0.9);
          font-size: 8px;
          font-weight: 700;
          letter-spacing: 0.08em;
        }

        .bench-why-label span {
          width: 4px;
          height: 4px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.8);
        }

        .bench-why-box > h2 {
          max-width: 700px;
          margin: 0 0 10px;
          color: #ffffff;
          font-size: clamp(28px, 3vw, 39px);
          line-height: 1.18;
          font-weight: 700;
          letter-spacing: -0.025em;
        }

        .bench-why-box > p {
          max-width: 700px;
          margin: 0 0 28px;
          color: rgba(255, 255, 255, 0.72);
          font-size: 11px;
          line-height: 1.65;
        }

        .bench-why-grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 14px;
        }

        .bench-why-card {
          min-height: 175px;
          padding: 20px;
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 10px;
          background: #811a55;
          transition:
            transform 0.3s ease,
            background 0.3s ease;
        }

        .bench-why-card:hover {
          transform: translateY(-4px);
          background: #8b215d;
        }

        .bench-why-icon {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 32px;
          height: 32px;
          margin-bottom: 17px;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 7px;
          background: rgba(255, 255, 255, 0.15);
          color: #ffffff;
        }

        .bench-why-icon svg {
          width: 15px;
          height: 15px;
        }

        .bench-why-card h3 {
          margin: 0 0 7px;
          color: #ffffff;
          font-size: 11px;
          line-height: 1.4;
          font-weight: 700;
        }

        .bench-why-card p {
          margin: 0;
          color: rgba(255, 255, 255, 0.7);
          font-size: 9px;
          line-height: 1.55;
        }

        /* =====================================================
           FINAL CTA
        ===================================================== */

        .bench-final-section {
          width: 100%;
          padding-top: 65px;
          padding-bottom: 75px;
          background: #f8f9fa;
        }

        .bench-final-card {
          max-width: 950px;
          margin: 0 auto;
          padding: 55px 60px;
          border: 1px solid rgba(115, 0, 36, 0.1);
          border-radius: 17px;
          background: rgba(115, 0, 36, 0.035);
          text-align: center;
        }

        .bench-final-label {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          margin-bottom: 16px;
          padding: 7px 11px;
          border: 1px solid rgba(115, 0, 36, 0.1);
          border-radius: 999px;
          background: #ffffff;
          color: ${i};
          font-size: 8px;
          font-weight: 700;
          letter-spacing: 0.08em;
        }

        .bench-final-card h2 {
          max-width: 800px;
          margin: 0 auto 13px;
          color: #161620;
          font-size: clamp(28px, 3vw, 39px);
          line-height: 1.2;
          font-weight: 700;
          letter-spacing: -0.025em;
        }

        .bench-final-card > p {
          max-width: 700px;
          margin: 0 auto 25px;
          color: #707070;
          font-size: 12px;
          line-height: 1.7;
        }

        .bench-final-card .bench-primary-button {
          margin-bottom: 25px;
        }

        .bench-final-tags {
          display: flex;
          flex-wrap: wrap;
          align-items: center;
          justify-content: center;
          gap: 20px;
          margin-bottom: 17px;
        }

        .bench-final-tags span {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          color: #606060;
          font-size: 9px;
          font-weight: 500;
        }

        .bench-final-tags svg {
          width: 12px;
          height: 12px;
          color: ${i};
        }

        .bench-final-bottom {
          color: #aaaaaa;
          font-size: 8px;
          font-weight: 500;
        }

        /* =====================================================
           TABLET
        ===================================================== */

        @media (max-width: 1200px) {
          .bench-container {
            padding-left: 40px;
            padding-right: 40px;
          }

          .bench-hero {
            padding-top: 55px;
          }

          .bench-hero-grid {
            gap: 45px;
            grid-template-columns: minmax(0, 1fr) 390px;
          }

          .bench-hero-image {
            height: 315px;
          }

          .bench-why-box {
            padding: 35px;
          }
        }

        /* =====================================================
           TABLET / SMALL LAPTOP
        ===================================================== */

        @media (max-width: 900px) {
          .bench-container {
            padding-left: 40px;
            padding-right: 40px;
          }

          .bench-hero-grid {
            grid-template-columns: 1fr;
            gap: 40px;
          }

          .bench-hero-content {
            align-items: center;
            text-align: center;
          }

          .bench-hero-heading {
            max-width: 750px;
          }

          .bench-hero-subheading {
            max-width: 650px;
          }

          .bench-hero-tags {
            justify-content: center;
          }

          .bench-hero-image-card {
            max-width: 600px;
          }

          .bench-hero-image {
            height: 350px;
          }

          .bench-approach-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .bench-capability-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .bench-phase-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .bench-why-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .bench-maintenance-card {
            align-items: flex-start;
            flex-direction: column;
          }

          .bench-maintenance-right {
            padding-left: 48px;
          }

          .bench-final-card {
            padding: 48px 40px;
          }
        }

        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 700px) {
          .bench-container {
            padding-left: 24px;
            padding-right: 24px;
          }

          .bench-hero {
            padding-top: 42px;
            padding-bottom: 42px;
          }

          .bench-hero-grid {
            gap: 32px;
          }

          .bench-hero-heading {
            font-size: 32px;
          }

          .bench-hero-subheading {
            font-size: 12px;
          }

          .bench-hero-image {
            height: 290px;
          }

          .bench-content-section,
          .bench-section {
            padding-top: 48px;
            padding-bottom: 48px;
          }

          .bench-section-heading,
          .bench-section-title {
            font-size: 28px;
          }

          .bench-prose {
            font-size: 12px;
          }

          .bench-approach-grid,
          .bench-capability-grid,
          .bench-phase-grid,
          .bench-why-grid {
            grid-template-columns: 1fr;
          }

          .bench-phase-tracker {
            grid-template-columns: 1fr;
            gap: 14px;
            margin: 28px 0;
          }

          .bench-phase-line {
            top: 13px;
            bottom: 13px;
            left: 13px;
            right: auto;
            width: 1px;
            height: auto;
          }

          .bench-phase-point {
            flex-direction: row;
            justify-content: flex-start;
            gap: 12px;
          }

          .bench-phase-point span {
            text-align: left;
          }

          .bench-why-box {
            padding: 28px 24px;
          }

          .bench-final-card {
            padding: 40px 24px;
          }

          .bench-maintenance-right {
            padding-left: 0;
            flex-wrap: wrap;
          }
        }

        /* =====================================================
           SMALL MOBILE
        ===================================================== */

        @media (max-width: 480px) {
          .bench-container {
            padding-left: 16px;
            padding-right: 16px;
          }

          .bench-hero {
            padding-top: 35px;
            padding-bottom: 35px;
          }

          .bench-hero-badge {
            font-size: 8px;
            padding: 7px 10px;
          }

          .bench-hero-heading {
            font-size: 27px;
          }

          .bench-hero-subheading {
            font-size: 11px;
          }

          .bench-primary-button {
            width: 100%;
            max-width: 250px;
            padding: 11px 18px;
            font-size: 11px;
          }

          .bench-hero-tags {
            gap: 5px;
          }

          .bench-tag {
            font-size: 8px;
            padding: 5px 7px;
          }

          .bench-hero-image {
            height: 240px;
          }

          .bench-hero-image-footer {
            left: 12px;
            right: 12px;
            bottom: 12px;
            font-size: 7px;
          }

          .bench-content-section,
          .bench-section {
            padding-top: 40px;
            padding-bottom: 40px;
          }

          .bench-section-heading,
          .bench-section-title {
            font-size: 24px;
          }

          .bench-prose {
            font-size: 11px;
          }

          .bench-pull-quote {
            padding: 16px 15px;
            margin: 28px auto;
          }

          .bench-pull-quote p {
            font-size: 10.5px;
          }

          .bench-card {
            padding: 18px;
          }

          .bench-maintenance-card {
            padding: 18px;
          }

          .bench-maintenance-left {
            align-items: flex-start;
          }

          .bench-maintenance-right {
            gap: 8px;
          }

          .bench-workflow-header {
            align-items: flex-start;
            flex-direction: column;
          }

          .bench-sla-label {
            font-size: 7px;
          }

          .bench-phase-card {
            padding: 17px;
          }

          .bench-guarantee {
            align-items: flex-start;
            flex-direction: column;
          }

          .bench-guarantee-content {
            align-items: flex-start;
          }

          .bench-guarantee > span {
            padding-left: 26px;
          }

          .bench-why-box {
            padding: 25px 18px;
            border-radius: 13px;
          }

          .bench-why-box > h2 {
            font-size: 25px;
          }

          .bench-final-section {
            padding-top: 40px;
            padding-bottom: 50px;
          }

          .bench-final-card {
            padding: 32px 18px;
            border-radius: 13px;
          }

          .bench-final-card h2 {
            font-size: 25px;
          }

          .bench-final-card > p {
            font-size: 10.5px;
          }

          .bench-final-tags {
            flex-direction: column;
            gap: 10px;
          }
        }

        /* =====================================================
           EXTRA SMALL
        ===================================================== */

        @media (max-width: 360px) {
          .bench-hero-heading {
            font-size: 24px;
          }

          .bench-section-heading,
          .bench-section-title {
            font-size: 22px;
          }

          .bench-card h3 {
            font-size: 13px;
          }

          .bench-card p {
            font-size: 10px;
          }

          .bench-why-box > h2,
          .bench-final-card h2 {
            font-size: 22px;
          }
        }

      `})]})}export{U as default};
