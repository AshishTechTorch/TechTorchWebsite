import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as n}from"./vendor-router-L4ZCoGSs.js";import{F as w,s as N,a as z}from"./FormNotice-OE790tVc.js";import"./index-37hjU4u5.js";function C(){const[s,d]=n.useState(""),[t,m]=n.useState({email:"",name:"",organization:"",industry:"",challenge:"",context:""}),[i,l]=n.useState({}),o=a=>{const{name:r,value:c}=a.target;m(p=>({...p,[r]:c})),l(p=>({...p,[r]:""}))},u=a=>{d(a),l(r=>({...r,timeline:""}))},[x,f]=n.useState(!1),[b,h]=n.useState(""),[y,g]=n.useState(!1),v=async a=>{if(a.preventDefault(),x)return;const r={};if(t.name.trim()||(r.name="Enter your full name"),t.email.trim()?/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(t.email)||(r.email="Enter a valid company email"):r.email="Enter your company email",t.organization.trim()||(r.organization="Enter your organization name"),t.industry.trim()||(r.industry="Select an industry"),t.challenge.trim()||(r.challenge="Enter your critical challenge"),s||(r.timeline="Select a deployment timeline"),t.context.trim()||(r.context="Tell us about your objectives"),l(r),!(Object.keys(r).length>0)){h(""),g(!1),f(!0);try{await N("secure",{executiveFullName:t.name.trim(),corporateWorkEmail:t.email.trim(),organizationName:t.organization.trim(),industryVertical:t.industry,currentCriticalChallenge:t.challenge.trim(),targetTimeline:s,infrastructureNotes:t.context.trim()}),g(!0),m({email:"",name:"",organization:"",industry:"",challenge:"",context:""}),d("")}catch(c){h(z(c))}finally{f(!1)}}},j=[{icon:"⚯",title:"Peer Threat Vector Benchmark",description:"Real-time risk scoring calibrated against current adversary activity in your specific industry vertical."},{icon:"♙",title:"Vector Squad Blueprint",description:"A bespoke operational schema detailing exact specialist deployment without burdening internal engineering teams."},{icon:"▣",title:"Executive 30-60-90 Day Playbook",description:"Synthesized governance summary, board-ready impact analysis, and step-by-step remediation timeline."}];return e.jsxs(e.Fragment,{children:[e.jsx("section",{className:"advisory-section",children:e.jsxs("div",{className:"advisory-container",children:[e.jsxs("div",{className:"advisory-left",children:[e.jsx("div",{className:"advisory-eyebrow",children:"ADVISORY FRAMEWORK"}),e.jsxs("h1",{children:["What to Anticipate During Your",e.jsx("br",{}),"Consultation"]}),e.jsx("p",{className:"advisory-intro",children:"TechTorch eliminates bureaucratic overhead. Your session is led exclusively by Senior Advisory Partners and Principal Systems Architects."}),j.map((a,r)=>e.jsxs("div",{className:"advisory-feature",children:[e.jsx("div",{className:"advisory-feature-icon",children:a.icon}),e.jsxs("div",{children:[e.jsx("h3",{children:a.title}),e.jsx("p",{children:a.description})]})]},r)),e.jsxs("div",{className:"advisory-image-wrapper",children:[e.jsx("img",{loading:"lazy",decoding:"async",src:"/AdvisoryFramework.webp",alt:"TechTorch Security Operations Center",className:"advisory-image"}),e.jsxs("div",{className:"advisory-image-caption",children:[e.jsx("span",{children:"TechTorch Continuous SOC Integration"}),e.jsx("span",{className:"caption-shield",children:"♢"})]})]}),e.jsxs("div",{className:"advisory-quote",children:[e.jsx("p",{children:"“Modern adversaries do not attack perimeter firewalls; they manipulate the trust boundaries between internal systems, unmonitored APIs, and human identity. Our advisory process targets resilience at the operational core.”"}),e.jsxs("div",{className:"advisor-profile",children:[e.jsx("div",{className:"advisor-avatar",children:"👩🏻"}),e.jsxs("div",{children:[e.jsx("strong",{children:"Dr. Evelyn Vance"}),e.jsx("span",{children:"Principal Director & Chief Cyber Architect"})]})]})]})]}),e.jsxs("form",{className:"advisory-form-card",onSubmit:v,noValidate:!0,children:[e.jsxs("div",{className:"form-header",children:[e.jsxs("div",{children:[e.jsx("span",{className:"form-eyebrow",children:"CONFIDENTIAL DISPATCH"}),e.jsx("h2",{children:"Executive Assessment Intake"})]}),e.jsx("div",{className:"form-lock",children:"♙"})]}),e.jsxs("div",{className:"form-row",children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Executive Full Name *"}),e.jsx("input",{type:"text",name:"name",value:t.name,onChange:o,placeholder:"e.g., Katherine Montgomery",className:i.name?"input-error":""}),i.name&&e.jsx("span",{className:"form-error",children:i.name})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Corporate Work Email *"}),e.jsx("input",{type:"email",name:"email",value:t.email,onChange:o,placeholder:"executive@enterprise.com",className:i.email?"input-error":""}),i.email&&e.jsx("span",{className:"form-error",children:i.email})]})]}),e.jsxs("div",{className:"form-row",children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Organization Name *"}),e.jsx("input",{type:"text",name:"organization",value:t.organization,onChange:o,placeholder:"Enterprise Corp / Holdings",className:i.organization?"input-error":""}),i.organization&&e.jsx("span",{className:"form-error",children:i.organization})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{children:"Industry Vertical *"}),e.jsxs("select",{name:"industry",value:t.industry,onChange:o,className:i.industry?"input-error":"",children:[e.jsx("option",{value:"",children:"Select an industry..."}),e.jsx("option",{value:"Financial Services & Banking",children:"Financial Services & Banking"}),e.jsx("option",{value:"Healthcare",children:"Healthcare"}),e.jsx("option",{value:"Technology",children:"Technology"}),e.jsx("option",{value:"Manufacturing",children:"Manufacturing"}),e.jsx("option",{value:"Government",children:"Government"}),e.jsx("option",{value:"Retail & E-Commerce",children:"Retail & E-Commerce"})]}),i.industry&&e.jsx("span",{className:"form-error",children:i.industry})]})]}),e.jsxs("div",{className:"form-group full-width",children:[e.jsx("label",{children:"Current Critical Challenge *"}),e.jsx("input",{type:"text",name:"challenge",value:t.challenge,onChange:o,placeholder:"e.g. Multi-Cloud Migration & Perimeter Hardening",className:i.challenge?"input-error":""}),i.challenge&&e.jsx("span",{className:"form-error",children:i.challenge})]}),e.jsxs("div",{className:"form-group full-width",children:[e.jsx("label",{children:"Target Timeline for Deployment *"}),e.jsx("div",{className:i.timeline?"timeline-options timeline-options-error":"timeline-options",children:["Immediate (48h)","Next 30 Days","Strategic Q2/Q3"].map(a=>e.jsx("button",{type:"button",className:s===a?"timeline-option active":"timeline-option",onClick:()=>u(a),children:a},a))}),i.timeline&&e.jsx("span",{className:"form-error",children:i.timeline})]}),e.jsxs("div",{className:"form-group full-width",children:[e.jsx("label",{children:"Brief Context or Infrastructure Notes *"}),e.jsx("textarea",{name:"context",value:t.context,onChange:o,placeholder:"Share specific regulatory constraints, cloud environments, or architecture priorities...",className:i.context?"input-error":""}),i.context&&e.jsx("span",{className:"form-error",children:i.context})]}),e.jsxs("div",{className:"security-note",children:[e.jsxs("div",{className:"security-note-left",children:[e.jsx("span",{className:"security-symbol",children:"⚙"}),e.jsx("span",{children:"Protected Under TechTorch Master Mutual Non-Disclosure Agreement"})]}),e.jsxs("strong",{children:["256-Bit",e.jsx("br",{}),"TLS"]})]}),e.jsx(w,{error:b,success:y}),e.jsxs("button",{type:"submit",disabled:x,className:"advisory-submit",children:["DEPLOY SECURITY ADVISORY BRIEFING",e.jsx("span",{children:"→"})]}),e.jsxs("div",{className:"form-contact",children:[e.jsxs("div",{className:"contact-item",children:[e.jsx("span",{className:"contact-icon",children:"♧"}),e.jsxs("div",{children:[e.jsx("small",{children:"Priority C-Suite Dispatch:"}),e.jsx("strong",{children:e.jsx("a",{href:"tel:+917251090147",children:"+91 72510 90147"})})]})]}),e.jsxs("div",{className:"contact-item",children:[e.jsx("span",{className:"contact-icon",children:"✉"}),e.jsxs("div",{children:[e.jsx("small",{children:"Direct Advisory Desk:"}),e.jsx("strong",{children:e.jsx("a",{href:"https://www.techtorch.solutions",target:"_blank",rel:"noopener noreferrer",children:"www.techtorch.solutions"})})]})]})]})]})]})}),e.jsx("section",{className:"advisory-bottom-features",children:e.jsxs("div",{className:"bottom-features-container",children:[e.jsxs("div",{className:"bottom-feature",children:[e.jsx("div",{className:"bottom-feature-icon",children:"♧"}),e.jsx("h3",{children:"Zero Data Ingestion"}),e.jsxs("p",{children:["Read-only non-intrusive",e.jsx("br",{}),"diagnostic probes"]})]}),e.jsxs("div",{className:"bottom-feature",children:[e.jsx("div",{className:"bottom-feature-icon",children:"♙"}),e.jsx("h3",{children:"CISSP & CISM Leadership"}),e.jsxs("p",{children:["Direct oversight by senior",e.jsx("br",{}),"practitioners"]})]}),e.jsxs("div",{className:"bottom-feature",children:[e.jsx("div",{className:"bottom-feature-icon",children:"⚡"}),e.jsx("h3",{children:"Scale at Speed™"}),e.jsxs("p",{children:["Proven engineering",e.jsx("br",{}),"mobilization methodology"]})]}),e.jsxs("div",{className:"bottom-feature",children:[e.jsx("div",{className:"bottom-feature-icon",children:"⚖"}),e.jsx("h3",{children:"Institutional Compliance"}),e.jsxs("p",{children:["ISO 27001, SOC 2 Type II,",e.jsx("br",{}),"FedRAMP alignment"]})]})]})}),e.jsx("style",{children:`

        * {
          box-sizing: border-box;
        }


        /* =========================================================
           ADVISORY FRAMEWORK
        ========================================================= */

        .advisory-section {
          width: 100%;
          background: #f3f4f6;
          font-family: "Inter", sans-serif;
          color: #262a32;
          overflow: hidden;
        }


        .advisory-container {
          width: 100%;
          max-width: 1180px;
          margin: 0 auto;
          padding: 44px 28px 55px;

          display: grid;

          grid-template-columns:
            minmax(0, 0.9fr)
            minmax(470px, 1.05fr);

          gap: 36px;
          align-items: start;
        }


        /* ================= LEFT ================= */

        .advisory-left {
          min-width: 0;
        }


        .advisory-eyebrow {
          margin-bottom: 10px;
          color: #74123f;
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 0.9px;
        }


        .advisory-left h1 {
          margin: 0;
          color: #20242b;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 25px;
          line-height: 1.18;
          font-weight: 600;
          letter-spacing: -1px;
        }


        .advisory-intro {
          margin: 12px 0 24px;
          color: #6b6870;
          font-size: 13px;
          line-height: 1.55;
        }


        /* ================= FEATURES ================= */

        .advisory-feature {
          display: grid;
          grid-template-columns: 25px 1fr;
          gap: 10px;
          margin-bottom: 15px;
        }


        .advisory-feature-icon {
          color: #74123f;
          font-size: 18px;
          line-height: 1.2;
          text-align: center;
        }


        .advisory-feature h3 {
          margin: 0 0 4px;
          color: #292d35;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 15px;
          line-height: 1.3;
          font-weight: 750;
        }


        .advisory-feature p {
          margin: 0;
          color: #706c73;
          font-size: 11.5px;
          line-height: 1.5;
        }


        /* ================= IMAGE ================= */

        .advisory-image-wrapper {
          position: relative;
          width: 100%;
          height: 144px;
          margin-top: 24px;

          border-radius: 8px;
          overflow: hidden;
          background: #1c2230;
        }


        .advisory-image {
          width: 100%;
          height: 100%;
          display: block;
          object-fit: cover;
          object-position: center;
        }


        .advisory-image-caption {
          position: absolute;

          left: 12px;
          right: 12px;
          bottom: 10px;

          height: 29px;

          display: flex;
          align-items: center;
          justify-content: space-between;

          padding: 0 11px;

          border-radius: 5px;
          background: rgba(255, 255, 255, 0.94);

          color: #70133f;
          font-size: 9px;
          font-weight: 800;
          letter-spacing: 1.2px;
        }


        .caption-shield {
          font-size: 16px;
        }


        /* ================= QUOTE ================= */

        .advisory-quote {
          margin-top: 18px;
          padding: 17px 18px;

          border-radius: 10px;
          background: #ffffff;

          box-shadow:
            0 3px 12px rgba(30, 35, 45, 0.04);
        }


        .advisory-quote > p {
          margin: 0;
          color: #646773;
          font-size: 13px;
          line-height: 1.55;
          font-style: italic;
        }


        .advisor-profile {
          display: flex;
          align-items: center;
          gap: 9px;
          margin-top: 12px;
        }


        .advisor-avatar {
          width: 27px;
          height: 27px;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 50%;
          background: #eee;
          font-size: 15px;
        }


        .advisor-profile strong {
          display: block;
          color: #343842;
          font-size: 13px;
          line-height: 1.3;
        }


        .advisor-profile span {
          display: block;
          color: #756c73;
          font-size: 11px;
          letter-spacing: 0.8px;
        }


        /* =========================================================
           FORM CARD
        ========================================================= */

        .advisory-form-card {
          width: 100%;
          padding: 30px 29px 25px;

          background: #ffffff;
          border-radius: 11px;

          box-shadow:
            0 5px 18px rgba(30, 35, 45, 0.08);
        }


        /* ================= FORM HEADER ================= */

        .form-header {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          margin-bottom: 25px;
        }


        .form-eyebrow {
          display: block;
          margin-bottom: 4px;

          color: #74123f;
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 0.8px;
        }


        .form-header h2 {
          margin: 0;
          color: #252932;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 17px;
          font-weight: 700;
        }


        .form-lock {
          color: #74123f;
          font-size: 21px;
        }


        /* ================= FORM ROW ================= */

        .form-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 14px;
          margin-bottom: 13px;
        }


        .form-group {
          min-width: 0;
          margin-bottom: 13px;
        }


        .form-group label {
          display: block;
          margin-bottom: 6px;

          color: #3b3e44;
          font-size: 12px;
          font-weight: 700;
        }


        .form-group input,
        .form-group select,
        .form-group textarea {
          width: 100%;

          border: 1px solid #edf0f3;
          border-radius: 5px;
          outline: none;

          background: #f8f9fa;
          color: #363b44;

          font-family: "Inter", sans-serif;
          font-size: 11px;

          transition:
            border-color 0.2s ease,
            box-shadow 0.2s ease;
        }


        .form-group input,
        .form-group select {
          height: 34px;
          padding: 0 11px;
        }


        .form-group textarea {
          height: 70px;
          padding: 10px 11px;
          resize: none;
        }


        .form-group input::placeholder,
        .form-group textarea::placeholder {
          color: #b4bac2;
        }


        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
          border-color: #cfa0b6;

          box-shadow:
            0 0 0 2px rgba(116, 18, 63, 0.06);
        }


        /* ================= VALIDATION ================= */

        .form-error {
          display: block;
          margin-top: 5px;

          color: #ff3b3b;
          font-size: 9px;
          line-height: 1.3;
          font-weight: 500;
        }


        .input-error {
          border-color: #ff4b4b !important;
          background: #fffafa !important;
        }


        .input-error:focus {
          border-color: #ff4b4b !important;
          box-shadow: none !important;
        }


        .timeline-options-error .timeline-option {
          border-color: #ff4b4b;
        }


        /* ================= TIMELINE ================= */

        .timeline-options {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 7px;
        }


        .timeline-option {
          height: 31px;

          border: 1px solid #eef0f2;
          border-radius: 5px;

          background: #f7f8f9;
          color: #4f535a;

          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 700;

          cursor: pointer;

          transition:
            background 0.2s ease,
            color 0.2s ease,
            border-color 0.2s ease;
        }


        .timeline-option.active {
          border-color: #f0e3e9;
          background: #fff7fa;
          color: #74123f;
        }


        /* ================= SECURITY ================= */

        .security-note {
          min-height: 46px;

          display: flex;
          align-items: center;
          justify-content: space-between;

          gap: 15px;
          padding: 0 12px;
          margin-top: 3px;

          border-radius: 6px;
          background: #f6f7f8;
        }


        .security-note-left {
          display: flex;
          align-items: center;
          gap: 8px;

          color: #77747a;
          font-size: 11px;
          line-height: 1.35;
          font-weight: 600;
          letter-spacing: 0.4px;
        }


        .security-symbol {
          color: #74123f;
          font-size: 13px;
        }


        .security-note > strong {
          color: #416044;

          font-family: monospace;
          font-size: 11px;
          line-height: 1.25;
          letter-spacing: 1px;
          text-align: right;
        }


        /* ================= SUBMIT ================= */

        .advisory-submit {
          width: 100%;
          height: 37px;

          margin-top: 13px;

          border: none;
          border-radius: 5px;

          background: #74123f;
          color: #ffffff;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 800;
          letter-spacing: 0.8px;

          cursor: pointer;

          transition:
            background 0.25s ease,
            transform 0.25s ease,
            box-shadow 0.25s ease;
        }


        .advisory-submit span {
          margin-left: 6px;
          font-size: 14px;
        }


        .advisory-submit:hover {
          background: #8b1b50;
          transform: translateY(-1px);

          box-shadow:
            0 6px 14px rgba(116, 18, 63, 0.18);
        }


        /* ================= CONTACT ================= */

        .form-contact {
          display: flex;
          align-items: center;
          justify-content: space-between;

          gap: 20px;
          margin-top: 24px;
        }


        .contact-item {
          display: flex;
          align-items: center;
          gap: 7px;
          min-width: 0;
        }


        .contact-icon {
          color: #74123f;
          font-size: 15px;
          flex-shrink: 0;
        }


        .contact-item small {
          display: block;

          color: #777078;

          font-family: monospace;
          font-size: 12px;
          font-weight: 700;
          letter-spacing: 1px;
        }


        .contact-item strong {
          display: block;

          color: #74123f;
          font-size: 11px;
          font-weight: 700;

          overflow-wrap: anywhere;
        }

        /* CLICKABLE CONTACT LINKS ONLY */

        .contact-item strong a {
          color: inherit;
          text-decoration: none;
        }

        .contact-item strong a:hover {
          text-decoration: underline;
        }


        /* =========================================================
           BOTTOM FEATURES
        ========================================================= */

        .advisory-bottom-features {
          width: 100%;
          background: #ffffff;
          border-top: 1px solid #eeeeee;
          font-family: "Inter", sans-serif;
        }


        /*
          IMPORTANT:
          Same content width and alignment as advisory container.
        */

        .bottom-features-container {
          width: 100%;
          max-width: 1180px;

          margin: 0 auto;

          padding: 40px 28px 38px;

          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));

          gap: 36px;

          align-items: start;
        }


        .bottom-feature {
          min-width: 0;

          text-align: center;

          transition:
            transform 0.3s ease;
        }


        .bottom-feature:hover {
          transform: translateY(-3px);
        }


        .bottom-feature-icon {
          width: 28px;
          height: 28px;

          margin: 0 auto 9px;

          display: flex;
          align-items: center;
          justify-content: center;

          color: #74123f;
          font-size: 21px;
          line-height: 1;

          transition: color 0.3s ease;
        }


        .bottom-feature:hover .bottom-feature-icon {
          color: #970052;
        }


        .bottom-feature h3 {
          margin: 0 0 7px;

          color: #282b32;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 14px;
          line-height: 1.25;
          font-weight: 700;
        }


        .bottom-feature p {
          margin: 0;

          color: #756c72;

          font-size: 10px;
          line-height: 1.5;
          font-weight: 600;
          letter-spacing: 1.35px;
        }


        /* =========================================================
           LARGE DESKTOP
        ========================================================= */

        @media (min-width: 1400px) {

          .advisory-container {
            max-width: 1240px;
            gap: 42px;
            padding-top: 55px;
          }


          .advisory-left h1 {
            font-size: 30px;
          }


          .advisory-image-wrapper {
            height: 155px;
          }


          .advisory-form-card {
            padding: 32px;
          }


          .bottom-features-container {
            max-width: 1240px;
            padding: 42px 28px 40px;
            gap: 42px;
          }
        }


        /* =========================================================
           LAPTOP
        ========================================================= */

        @media (max-width: 1100px) {

          .advisory-container {
            max-width: 1000px;

            grid-template-columns:
              minmax(0, 0.88fr)
              minmax(440px, 1fr);

            gap: 28px;

            padding-left: 22px;
            padding-right: 22px;
          }


          .advisory-form-card {
            padding: 26px 24px 23px;
          }


          .bottom-features-container {
            max-width: 1000px;
            padding: 38px 22px;
            gap: 28px;
          }


          .bottom-feature h3 {
            font-size: 13px;
          }


          .bottom-feature p {
            font-size: 9px;
            letter-spacing: 1.1px;
          }
        }


        /* =========================================================
           TABLET
        ========================================================= */

        @media (max-width: 850px) {

          .advisory-container {
            grid-template-columns: 1fr;

            max-width: 650px;

            gap: 30px;

            padding: 38px 20px 45px;
          }


          .advisory-image-wrapper {
            height: 220px;
          }


          .advisory-form-card {
            padding: 27px 24px;
          }


          .bottom-features-container {
            max-width: 650px;

            grid-template-columns:
              repeat(2, minmax(0, 1fr));

            gap: 30px 28px;

            padding: 34px 20px;
          }


          .bottom-feature h3 {
            font-size: 13px;
          }


          .bottom-feature p {
            font-size: 8px;
            letter-spacing: 1px;
          }
        }


        /* =========================================================
           MOBILE
        ========================================================= */

        @media (max-width: 600px) {

          .advisory-container {
            width: 100%;
            max-width: 100%;

            padding: 30px 14px 35px;

            gap: 25px;
          }


          .advisory-left h1 {
            font-size: 24px;
            line-height: 1.2;
          }


          .advisory-intro {
            font-size: 12px;
            margin-bottom: 20px;
          }


          .advisory-feature {
            grid-template-columns: 22px 1fr;
            gap: 7px;
            margin-bottom: 13px;
          }


          .advisory-feature h3 {
            font-size: 14px;
          }


          .advisory-feature p {
            font-size: 10.5px;
            line-height: 1.5;
          }


          .advisory-image-wrapper {
            height: 185px;
            margin-top: 20px;
          }


          .advisory-image-caption {
            left: 8px;
            right: 8px;
            bottom: 8px;

            height: 27px;

            padding: 0 9px;

            font-size: 7px;
          }


          .advisory-quote {
            padding: 14px;
            margin-top: 14px;
          }


          .advisory-quote > p {
            font-size: 10px;
          }


          .advisory-form-card {
            padding: 23px 17px 20px;
            border-radius: 9px;
          }


          .form-header {
            margin-bottom: 20px;
          }


          .form-header h2 {
            font-size: 16px;
          }


          .form-row {
            grid-template-columns: 1fr;
            gap: 0;
            margin-bottom: 0;
          }


          .form-group input,
          .form-group select {
            height: 36px;
          }


          .timeline-options {
            grid-template-columns: 1fr;
            gap: 6px;
          }


          .timeline-option {
            height: 34px;
          }


          .security-note {
            padding: 8px 10px;
          }


          .security-note-left {
            font-size: 7px;
          }


          .form-contact {
            flex-direction: column;
            align-items: flex-start;
            gap: 12px;
          }


          /* ================= BOTTOM FEATURES ================= */

          .bottom-features-container {
            width: 100%;
            max-width: 100%;

            grid-template-columns:
              repeat(2, minmax(0, 1fr));

            gap: 26px 14px;

            padding: 30px 14px;
          }


          .bottom-feature-icon {
            width: 25px;
            height: 25px;

            margin-bottom: 8px;

            font-size: 18px;
          }


          .bottom-feature h3 {
            font-size: 11px;
            line-height: 1.3;
          }


          .bottom-feature p {
            font-size: 7px;
            line-height: 1.45;
            letter-spacing: 0.8px;
          }
        }


        /* =========================================================
           SMALL MOBILE
        ========================================================= */

        @media (max-width: 380px) {

          .advisory-container {
            padding-left: 11px;
            padding-right: 11px;
          }


          .advisory-left h1 {
            font-size: 22px;
          }


          .advisory-image-wrapper {
            height: 165px;
          }


          .advisory-form-card {
            padding-left: 14px;
            padding-right: 14px;
          }


          .form-header h2 {
            font-size: 15px;
          }


          .advisory-submit {
            font-size: 8px;
          }


          /* ================= BOTTOM FEATURES ================= */

          .bottom-features-container {
            grid-template-columns: 1fr;

            gap: 23px;

            padding: 28px 15px;
          }


          .bottom-feature h3 {
            font-size: 12px;
          }


          .bottom-feature p {
            font-size: 8px;
          }
        }

      `})]})}export{C as default};
