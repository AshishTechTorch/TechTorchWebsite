import{j as i}from"./vendor-query-PraSc8EQ.js";import{L as e}from"./vendor-router-L4ZCoGSs.js";import{I as o,A as t}from"./index-37hjU4u5.js";const n="#7A1F3D";function s(){return i.jsxs("section",{className:"build-online-cta-section",children:[i.jsx("style",{children:`

        /* =========================================
           SECTION
        ========================================= */

        .build-online-cta-section {
          position: relative;
          width: 100%;
          overflow: hidden;

          color: #ffffff;
          font-family: "Inter", sans-serif;
        }

        /* =========================================
           BACKGROUND
        ========================================= */

        .build-online-bg {
          position: absolute;
          inset: 0;
          width: 100%;
          height: 100%;
        }

        .build-online-bg img {
          width: 100%;
          height: 100%;
          display: block;
          object-fit: cover;
          transform: scale(1.02);
        }

        /* =========================================
           DARK OVERLAY
        ========================================= */

        .build-online-overlay {
          position: absolute;
          inset: 0;

          background:
            linear-gradient(
              115deg,
              rgba(20, 22, 28, 0.88) 0%,
              rgba(26, 28, 36, 0.78) 45%,
              rgba(20, 22, 28, 0.88) 100%
            );
        }

        /* =========================================
           CONTENT WRAPPER
           Universal spacing:
           Desktop: 100px
           Tablet: 40px
           Mobile: 24px
           Small mobile: 16px
        ========================================= */

        .build-online-wrapper {
          position: relative;
          z-index: 2;

          width: 100%;
          max-width: 1600px;
          margin: 0 auto;

          padding: 96px 100px;

          box-sizing: border-box;

          text-align: center;
        }

        /* =========================================
           INNER CONTENT
        ========================================= */

        .build-online-content {
          width: 100%;
          max-width: 900px;
          margin: 0 auto;
        }

        /* =========================================
           BADGE
        ========================================= */

        .build-online-badge {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 6px;

          margin: 0 0 20px;
          padding: 7px 12px;

          border-radius: 999px;

          background: ${n};
          color: #ffffff;

          font-family: "Inter", sans-serif;
          font-size: 9px;
          font-weight: 700;
          line-height: 1.2;
          letter-spacing: 0.08em;

          transition:
            transform 300ms ease,
            box-shadow 300ms ease;
        }

        .build-online-badge:hover {
          transform: scale(1.05);
          box-shadow: 0 8px 20px rgba(122, 31, 61, 0.25);
        }

        /* =========================================
           HEADING
        ========================================= */

        .build-online-heading {
          margin: 0 0 17px;

          color: #ffffff;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 38px;
          font-weight: 700;
          line-height: 1.2;
          letter-spacing: -0.025em;
        }

        .build-online-heading-break {
          display: block;
        }

        /* =========================================
           DESCRIPTION
        ========================================= */

        .build-online-description {
          max-width: 720px;
          margin: 0 auto 30px;

          color: #c9c6cc;

          font-family: "Inter", sans-serif;
          font-size: 15px;
          font-weight: 400;
          line-height: 1.75;
        }

        /* =========================================
           BUTTONS
        ========================================= */

        .build-online-actions {
          width: 100%;

          display: flex;
          align-items: center;
          justify-content: center;
          gap: 14px;
        }

        .build-online-button {
          min-height: 46px;
          padding: 0 27px;

          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;

          border-radius: 7px;

          font-family: "Inter", sans-serif;
          font-size: 14px;
          font-weight: 600;
          line-height: 1;

          cursor: pointer;

          transition:
            transform 300ms ease,
            box-shadow 300ms ease,
            background 300ms ease,
            border-color 300ms ease;
        }

        /* Primary */

        .build-online-primary {
          border: 1px solid ${n};
          background: ${n};
          color: #ffffff;
        }

        .build-online-primary:hover {
          transform: translateY(-3px);
          box-shadow:
            0 10px 25px rgba(122, 31, 61, 0.35);
        }

        /* Secondary */

        .build-online-secondary {
          border: 1px solid rgba(255, 255, 255, 0.12);
          background: #ffffff;
          color: #730042;
        }

        .build-online-secondary:hover {
          transform: translateY(-3px);
          
        }

        /* =========================================
           ARROW
        ========================================= */

        .build-online-arrow {
          transition: transform 300ms ease;
        }

        .build-online-primary:hover .build-online-arrow {
          transform: translateX(4px);
        }

        /* =========================================
           TABLET
        ========================================= */

        @media (max-width: 1200px) {
          .build-online-wrapper {
            padding-left: 40px;
            padding-right: 40px;
            padding-top: 80px;
            padding-bottom: 80px;
          }

          .build-online-heading {
            font-size: 35px;
          }
        }

        /* =========================================
           MOBILE
        ========================================= */

        @media (max-width: 700px) {
          .build-online-wrapper {
            padding-left: 24px;
            padding-right: 24px;
            padding-top: 64px;
            padding-bottom: 64px;
          }

          .build-online-badge {
            margin-bottom: 17px;
          }

          .build-online-heading {
            margin-bottom: 15px;
            font-size: 29px;
            line-height: 1.22;
          }

          .build-online-description {
            margin-bottom: 25px;
            font-size: 13px;
            line-height: 1.7;
          }

          .build-online-actions {
            flex-direction: column;
            align-items: stretch;
            gap: 11px;
          }

          .build-online-button {
            width: 100%;
            min-height: 45px;
          }
        }

        /* =========================================
           SMALL MOBILE
        ========================================= */

        @media (max-width: 480px) {
          .build-online-wrapper {
            padding-left: 16px;
            padding-right: 16px;
            padding-top: 52px;
            padding-bottom: 52px;
          }

          .build-online-heading {
            font-size: 25px;
            line-height: 1.24;
          }

          .build-online-description {
            font-size: 12.5px;
            line-height: 1.65;
          }

          .build-online-button {
            font-size: 13px;
          }
        }

        /* =========================================
           VERY SMALL MOBILE
        ========================================= */

        @media (max-width: 360px) {
          .build-online-heading {
            font-size: 23px;
          }

          .build-online-description {
            font-size: 12px;
          }
        }

        /* =========================================
           TOUCH DEVICES
        ========================================= */

        @media (hover: none) {
          .build-online-badge:hover {
            transform: none;
            box-shadow: none;
          }

          .build-online-primary:hover,
          .build-online-secondary:hover {
            transform: none;
            box-shadow: none;
          }

          .build-online-primary:hover .build-online-arrow {
            transform: none;
          }
        }

        /* =========================================
           REDUCED MOTION
        ========================================= */

        @media (prefers-reduced-motion: reduce) {
          .build-online-badge,
          .build-online-button,
          .build-online-arrow {
            transition: none !important;
          }
        }
      `}),i.jsx("div",{className:"build-online-bg",children:i.jsx("img",{loading:"lazy",decoding:"async",src:"/ecommerce3.webp",alt:"Building online business with technology"})}),i.jsx("div",{className:"build-online-overlay"}),i.jsx("div",{className:"build-online-wrapper",children:i.jsxs("div",{className:"build-online-content",children:[i.jsxs("span",{className:"build-online-badge",children:[i.jsx(o,{size:11,strokeWidth:3}),"NEXT PHASE"]}),i.jsxs("h2",{className:"build-online-heading",children:["Build Your Online Business With the",i.jsx("span",{className:"build-online-heading-break",children:"Right Technology"})]}),i.jsx("p",{className:"build-online-description",children:"Bring your products, customers and e-commerce operations together with technology designed around your business requirements."}),i.jsxs("div",{className:"build-online-actions",children:[i.jsxs(e,{to:"/talk-to-expert",className:`\r
    build-online-button\r
    build-online-primary\r
  `,children:["Talk to Our Experts",i.jsx(t,{size:15,strokeWidth:1.8,className:"build-online-arrow"})]}),i.jsx("button",{type:"button",className:`\r
                build-online-button\r
                build-online-secondary\r
              `,children:"Get in Touch"})]})]})})]})}export{s as default};
