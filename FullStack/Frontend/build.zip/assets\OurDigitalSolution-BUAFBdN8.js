import{j as t}from"./vendor-query-PraSc8EQ.js";import{r as n}from"./vendor-router-L4ZCoGSs.js";import{t as z,v as k,s as N,w as C,z as E,F as A,x as I,I as S}from"./index-37hjU4u5.js";import{S as M}from"./settings-BNjID7h6.js";import{A as P}from"./arrow-left-right-arVRAjz_.js";import{P as L}from"./plane-v6NNEqmb.js";import{C as T}from"./contact-Dp_d-NMy.js";import{C as R}from"./clipboard-list-ivKQuMBl.js";import{C as O}from"./chevron-left-IInL7UPY.js";const m={name:"file-chart-column",size:24,node:[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M8 18v-1",key:"zg0ygc"}],["path",{d:"M12 18v-6",key:"17g6i2"}],["path",{d:"M16 18v-3",key:"j5jt4h"}]],aliases:["file-bar-chart-2"]};m.node;const D=z(m),r=[{number:"01",icon:k,title:"Enterprise Resource Planning (ERP)",description:"Connect essential functions such as finance, inventory, human resources, and customer relationships within a synchronized system."},{number:"02",icon:M,title:"Operations Management",description:"Efficient operations depend on clear workflows. Help businesses organize tasks, monitor activity, improve visibility, and eliminate bottlenecks."},{number:"03",icon:P,title:"Supply Chain Management",description:"From procurement and inventory to logistics and distribution, achieve total clarity and intelligent orchestration across channels."},{number:"04",icon:L,title:"Aviation Management",description:"Aviation demands exact precision, coordination, and strict compliance. Solutions built to enhance operational efficiency, safety, and flight crew dispatch."},{number:"05",icon:N,title:"People Resources",description:"People are at the center of every organization. Modernize talent lifecycle, performance, payroll, and daily HR communication seamlessly."},{number:"06",icon:C,title:"Web Portals",description:"Build secure, fast, and user-friendly digital portals for customers, external vendors, partners, and employees around designated workflows."},{number:"07",icon:D,title:"Financial Management",description:"Ensure financial figures are accurate, auditable, and easily digestible. Streamline financial processes, reporting, and statutory compliance."},{number:"08",icon:E,title:"Payment Management",description:"Deliver seamless payment gateways, automated multi-currency settlement engines, and bank-grade reconciliation capabilities."},{number:"09",icon:A,title:"Healthcare & Hospital Management",description:"Empower clinics and multi-specialty hospitals with structured patient records, staff scheduling, bed management, and unified clinical data."},{number:"10",icon:T,title:"Customer Relationship Management",description:"Consolidate interactions, automate lead nurturing, orchestrate customer support tickets, and maintain single-pane-of-glass customer records."},{number:"11",icon:I,title:"E-Commerce Platforms",description:"Modern digital sales go beyond simple store layouts. Connect inventory, payments, multi-channel listings, and post-purchase loyalty workflows."},{number:"12",icon:R,title:"Project Management",description:"Successful deliverables need accountability and timeline visibility. Organize tasks, manage dependencies, and track delivery deadlines accurately."}],V=2500,u=600;function G(){const a=r.length,h=[...r,...r,...r],[g,l]=n.useState(4),[o,s]=n.useState(a),[d,x]=n.useState(!0),p=n.useRef(null);n.useEffect(()=>{function e(){const i=window.innerWidth;i<=640?l(1):i<=1024?l(2):l(4)}return e(),window.addEventListener("resize",e),()=>{window.removeEventListener("resize",e)}},[]);function c(){clearInterval(p.current),p.current=setInterval(()=>{s(e=>e+1)},V)}n.useEffect(()=>(c(),()=>{clearInterval(p.current)}),[]),n.useEffect(()=>{if(o>=a*2||o<a){const e=setTimeout(()=>{x(!1),s(i=>i>=a*2?i-a:i+a)},u);return()=>clearTimeout(e)}},[o,a]),n.useEffect(()=>{if(!d){const e=requestAnimationFrame(()=>{x(!0)});return()=>cancelAnimationFrame(e)}},[d]);function f(){s(e=>e+1),c()}function b(){s(e=>e-1),c()}const w=o*100/g;return t.jsxs(t.Fragment,{children:[t.jsx("section",{className:"digital-solutions-section",children:t.jsxs("div",{className:"digital-solutions-container",children:[t.jsxs("div",{className:"digital-solutions-header",children:[t.jsxs("div",{className:"digital-solutions-label",children:[t.jsx("span",{className:"label-line"}),t.jsx("span",{className:"label-text",children:"Our Digital Solutions"}),t.jsx("span",{className:"label-line"})]}),t.jsxs("div",{className:"carousel-navigation",children:[t.jsx("button",{type:"button",onClick:b,"aria-label":"Previous solutions",className:"carousel-button",children:t.jsx(O,{size:17,strokeWidth:2})}),t.jsx("button",{type:"button",onClick:f,"aria-label":"Next solutions",className:"carousel-button",children:t.jsx(S,{size:17,strokeWidth:2})})]})]}),t.jsx("div",{className:"carousel-wrapper",children:t.jsx("div",{className:"carousel-track",style:{transform:`translateX(-${w}%)`,transition:d?`transform ${u}ms ease`:"none"},children:h.map(({number:e,icon:i,title:y,description:v},j)=>t.jsx("div",{className:"carousel-item",style:{width:`${100/g}%`},children:t.jsxs("div",{className:"solution-card",children:[t.jsx("span",{className:"card-accent"}),t.jsxs("div",{className:"card-top",children:[t.jsx("div",{className:"icon-box",children:t.jsx(i,{size:17,strokeWidth:2})}),t.jsx("span",{className:"solution-number",children:e})]}),t.jsx("h3",{className:"solution-title",children:y}),t.jsx("p",{className:"solution-description",children:v})]})},`${e}-${j}`))})})]})}),t.jsx("style",{children:`
        /* =================================================
           MAIN SECTION
        ================================================= */

        .digital-solutions-section {
          width: 100%;
          overflow: hidden;
          background: #f6f4ee;

          padding-top: 64px;
          padding-bottom: 64px;

          padding-left: 100px;
          padding-right: 100px;

          box-sizing: border-box;
        }

        .digital-solutions-container {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;
        }

        /* =================================================
           HEADER
        ================================================= */

        .digital-solutions-header {
          position: relative;

          width: 100%;

          display: flex;
          align-items: center;
          justify-content: center;

          margin-bottom: 42px;
        }

        .digital-solutions-label {
          display: flex;
          align-items: center;
          justify-content: center;

          gap: 12px;
        }

        .label-line {
          width: 40px;
          height: 1px;
          flex-shrink: 0;

          background: #730024;
        }

        .label-text {
          font-family: "Inter", sans-serif;

          font-size: 12px;
          font-weight: 700;

          line-height: 1.2;

          letter-spacing: 0.15em;
          text-transform: uppercase;

          color: #730024;

          white-space: nowrap;
        }

        /* =================================================
           NAVIGATION
        ================================================= */

        .carousel-navigation {
          position: absolute;

          right: 0;
          top: 50%;

          transform: translateY(-50%);

          display: flex;
          align-items: center;

          gap: 8px;
        }

        .carousel-button {
          width: 38px;
          height: 38px;

          border: none;
          border-radius: 50%;

          display: flex;
          align-items: center;
          justify-content: center;

          padding: 0;

          background: #730024;
          color: #ffffff;

          cursor: pointer;

          transition:
            transform 0.3s ease,
            opacity 0.3s ease,
            box-shadow 0.3s ease;
        }

        .carousel-button:hover {
          opacity: 0.9;

          transform: scale(1.06);

          box-shadow:
            0 8px 18px rgba(115, 0, 36, 0.18);
        }

        .carousel-button:active {
          transform: scale(0.96);
        }

        /* =================================================
           CAROUSEL
        ================================================= */

        .carousel-wrapper {
          width: 100%;
          overflow: hidden;
        }

        .carousel-track {
          display: flex;
          width: 100%;

          will-change: transform;
        }

        .carousel-item {
          flex-shrink: 0;

          padding-left: 8px;
          padding-right: 8px;

          box-sizing: border-box;
        }

        /* =================================================
           CARD
        ================================================= */

        .solution-card {
          position: relative;

          width: 100%;
          height: 100%;
          min-height: 225px;

          overflow: hidden;

          box-sizing: border-box;

          border-radius: 14px;

          background: #ffffff;

          padding-top: 24px;
          padding-bottom: 24px;
          padding-left: 24px;
          padding-right: 20px;

          box-shadow:
            0 4px 16px rgba(20, 20, 20, 0.045);

          transition:
            transform 0.3s ease,
            box-shadow 0.3s ease;
        }

        .solution-card:hover {
          transform: translateY(-4px);

          box-shadow:
            0 12px 28px rgba(20, 20, 20, 0.08);
        }

        /* =================================================
           CARD ACCENT
        ================================================= */

        .card-accent {
          position: absolute;

          left: 0;
          top: 0;

          width: 5px;
          height: 100%;

          background: #730024;
        }

        /* =================================================
           CARD TOP
        ================================================= */

        .card-top {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;

          margin-bottom: 18px;
        }

        .icon-box {
          width: 40px;
          height: 40px;

          flex-shrink: 0;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 9px;

          background: #fdeef4;

          color: #730024;
        }

        .solution-number {
          margin-top: 3px;

          font-family: "Inter", sans-serif;

          font-size: 11px;
          font-weight: 600;

          line-height: 1;

          color: #94a3b8;
        }

        /* =================================================
           TITLE
        ================================================= */

        .solution-title {
          margin: 0 0 10px;

          font-family: "Plus Jakarta Sans", sans-serif;

          font-size: 15px;
          font-weight: 700;

          line-height: 1.45;

          color: #0f172a;
        }

        /* =================================================
           DESCRIPTION
        ================================================= */

        .solution-description {
          margin: 0;

          font-family: "Inter", sans-serif;

          font-size: 12.5px;
          font-weight: 400;

          line-height: 1.7;

          color: #64748b;
        }

        /* =================================================
           TABLET
        ================================================= */

        @media (max-width: 1200px) {
          .digital-solutions-section {
            padding-left: 40px;
            padding-right: 40px;

            padding-top: 60px;
            padding-bottom: 60px;
          }

          .digital-solutions-container {
            max-width: 100%;
          }

          .solution-card {
            min-height: 225px;
          }
        }

        /* =================================================
           TABLET / SMALL LAPTOP
        ================================================= */

        @media (max-width: 900px) {
          .digital-solutions-section {
            padding-left: 40px;
            padding-right: 40px;

            padding-top: 54px;
            padding-bottom: 54px;
          }

          .digital-solutions-header {
            margin-bottom: 34px;
          }

          .carousel-item {
            padding-left: 7px;
            padding-right: 7px;
          }

          .solution-card {
            min-height: 230px;

            padding-top: 22px;
            padding-bottom: 22px;
            padding-left: 22px;
            padding-right: 18px;
          }

          .solution-title {
            font-size: 15px;
          }

          .solution-description {
            font-size: 12.5px;
          }
        }

        /* =================================================
           MOBILE
        ================================================= */

        @media (max-width: 640px) {
          .digital-solutions-section {
            padding-left: 24px;
            padding-right: 24px;

            padding-top: 48px;
            padding-bottom: 48px;
          }

          .digital-solutions-header {
            justify-content: flex-start;

            margin-bottom: 28px;

            padding-right: 92px;
          }

          .digital-solutions-label {
            gap: 9px;
          }

          .label-line {
            width: 22px;
          }

          .label-text {
            font-size: 10px;
            letter-spacing: 0.11em;

            white-space: normal;
          }

          .carousel-navigation {
            right: 0;

            gap: 6px;
          }

          .carousel-button {
            width: 34px;
            height: 34px;
          }

          .carousel-item {
            padding-left: 5px;
            padding-right: 5px;
          }

          .solution-card {
            min-height: 215px;

            border-radius: 13px;

            padding-top: 21px;
            padding-bottom: 21px;
            padding-left: 21px;
            padding-right: 18px;
          }

          .card-top {
            margin-bottom: 16px;
          }

          .icon-box {
            width: 38px;
            height: 38px;
          }

          .solution-title {
            font-size: 15px;
            line-height: 1.4;
          }

          .solution-description {
            font-size: 12.5px;
            line-height: 1.65;
          }
        }

        /* =================================================
           SMALL MOBILE
        ================================================= */

        @media (max-width: 480px) {
          .digital-solutions-section {
            padding-left: 16px;
            padding-right: 16px;

            padding-top: 42px;
            padding-bottom: 42px;
          }

          .digital-solutions-header {
            margin-bottom: 25px;

            padding-right: 82px;
          }

          .digital-solutions-label {
            gap: 7px;
          }

          .label-line {
            width: 16px;
          }

          .label-text {
            font-size: 9px;
            letter-spacing: 0.09em;
          }

          .carousel-navigation {
            gap: 5px;
          }

          .carousel-button {
            width: 32px;
            height: 32px;
          }

          .carousel-item {
            padding-left: 4px;
            padding-right: 4px;
          }

          .solution-card {
            min-height: 205px;

            padding-top: 19px;
            padding-bottom: 19px;
            padding-left: 20px;
            padding-right: 16px;

            border-radius: 12px;
          }

          .card-accent {
            width: 4px;
          }

          .icon-box {
            width: 36px;
            height: 36px;

            border-radius: 8px;
          }

          .solution-number {
            font-size: 10px;
          }

          .solution-title {
            margin-bottom: 8px;

            font-size: 14px;
          }

          .solution-description {
            font-size: 12px;
            line-height: 1.6;
          }
        }

        /* =================================================
           VERY SMALL DEVICES
        ================================================= */

        @media (max-width: 360px) {
          .digital-solutions-section {
            padding-left: 16px;
            padding-right: 16px;
          }

          .digital-solutions-header {
            padding-right: 76px;
          }

          .label-text {
            font-size: 8.5px;
          }

          .carousel-button {
            width: 30px;
            height: 30px;
          }

          .solution-card {
            min-height: 200px;

            padding-left: 18px;
            padding-right: 15px;
          }

          .solution-title {
            font-size: 13.5px;
          }

          .solution-description {
            font-size: 11.5px;
          }
        }
      `})]})}export{G as default};
