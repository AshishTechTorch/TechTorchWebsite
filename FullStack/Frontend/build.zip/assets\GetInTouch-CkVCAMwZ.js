import{j as e}from"./vendor-query-PraSc8EQ.js";import{r}from"./vendor-router-L4ZCoGSs.js";import{F as v,s as k,a as I}from"./FormNotice-OE790tVc.js";import{a2 as A,Q as E,Z as C,A as S}from"./index-37hjU4u5.js";import{L as z}from"./lock-keyhole-iBzDZ1RM.js";const T=[["Policy Administration & Lifecycle","PAS"],["Claims Processing & Smart FNOL","Claims"],["Broker & Client Digital Portals","Portals"],["Actuarial & Financial (IFRS 17)","Finance"],["Core Legacy Modernization & APIs","Migration"],["Cloud Infrastructure & Cyber","Cloud"],["Dedicated Engineering Pods","Staffing"],["Custom Enterprise Software","Custom"]],D=["< 30 Days (Urgent)","1–3 Months (Q2)","3–6 Months Roadmap","Exploratory"];function F(){const[l,p]=r.useState([]),[d,x]=r.useState(""),[h,o]=r.useState(!1),[n,f]=r.useState({fullName:"",email:"",organization:"",phone:"",objectives:"",nda:!1,briefing:!1}),g=i=>{p(a=>a.includes(i)?a.filter(t=>t!==i):[...a,i])},s=i=>{const{name:a,value:t,type:j,checked:w}=i.target;f(N=>({...N,[a]:j==="checkbox"?w:t}))},[u,m]=r.useState(!1),[b,c]=r.useState(""),y=async i=>{if(i.preventDefault(),u)return;const a=i.currentTarget;if(!a.checkValidity()){const t=a.querySelector(":invalid");t&&(t.focus(),a.reportValidity(),setTimeout(()=>{t.blur()},4e3));return}if(l.length===0){c("Please select at least one insurance capability.");return}if(!d){c("Please select your target timeline.");return}c(""),m(!0);try{await k("insurance",{fullName:n.fullName.trim(),corporateWorkEmail:n.email.trim(),organizationName:n.organization.trim(),phone:n.phone.trim(),insuranceCapabilities:l,targetTimeline:d,technicalObjectives:n.objectives.trim(),mutualNda:!!n.nda,architectureBriefing:!!n.briefing}),o(!0),setTimeout(()=>{o(!1)},3e3),f({fullName:"",email:"",organization:"",phone:"",objectives:"",nda:!1,briefing:!1}),p([]),x("")}catch(t){c(I(t))}finally{m(!1)}};return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`

        * {
          box-sizing: border-box;
        }

        /* ================================
           SUCCESS DIALOG
        ================================= */

        .insurance-success-dialog {
          position: fixed;
          top: 24px;
          left: 50%;
          transform: translateX(-50%);
          z-index: 9999;
          width: min(420px, calc(100% - 32px));
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 16px 20px;
          background: #ffffff;
          border: 1px solid #E5D3DC;
          border-radius: 10px;
          box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
          font-family: "Inter", sans-serif;
          animation: insuranceSuccessDialogIn 0.25s ease-out;
        }

        .insurance-success-dialog-icon {
          width: 44px;
          height: 44px;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          background: #ffffff;
          color: #22824D;
          border: none;
        }

        .insurance-success-dialog-content { min-width: 0; }

        .insurance-success-dialog-title {
          margin: 0;
          color: #202022;
          font-family: "Inter", sans-serif;
          font-size: 14px;
          font-weight: 700;
          line-height: 1.4;
        }

        .insurance-success-dialog-text {
          margin: 2px 0 0;
          color: #65595E;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 400;
          line-height: 1.5;
        }

        .insurance-success-dialog-ok {
          width: 34px;
          height: 34px;
          margin-left: auto;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 0;
          border: none;
          border-radius: 50%;
          background: #730042;
          color: #ffffff;
          font-family: "Inter", sans-serif;
          font-size: 10px;
          font-weight: 600;
          cursor: pointer;
          transition: background 0.2s ease, transform 0.2s ease;
        }

        .insurance-success-dialog-ok:hover {
          background: #620038;
          transform: scale(1.05);
        }

        @keyframes insuranceSuccessDialogIn {
          from { opacity: 0; transform: translate(-50%, -12px); }
          to { opacity: 1; transform: translate(-50%, 0); }
        }

        /* ================================
           MAIN PAGE
        ================================= */

        .insurance-page {
          width: 100%;
          min-height: 100vh;
          background: #f8fafc;
          padding: 40px 32px;
          font-family: "Inter", Arial, sans-serif;
          color: #17213a;
          overflow: hidden;
        }

        .insurance-container {
          width: 100%;
          max-width: 1280px;
          margin: 0 auto;
          display: grid;
          grid-template-columns: minmax(0, 0.9fr) minmax(0, 1.25fr);
          gap: 38px;
          align-items: start;
        }

        /* ================================
           LEFT SIDE
        ================================= */

        .insurance-left {
          padding-top: 2px;
          min-width: 0;
        }

        .insurance-badge {
          display: inline-flex;
          align-items: center;
          flex-wrap: wrap;
          gap: 8px;
          padding: 7px 13px;
          background: #f1f5f9;
          border: 1px solid #dce3eb;
          border-radius: 22px;
          font-family: "Inter", Arial, sans-serif;
          font-size: 12px;
          font-weight: 700;
          color: #3b4a63;
          box-shadow: 0 2px 5px rgba(0, 0, 0, 0.04);
        }

        .badge-dot {
          width: 8px;
          height: 8px;
          flex-shrink: 0;
          border-radius: 50%;
          background: #12b981;
        }

        .badge-separator {
          color: #9ba8bb;
        }

        .sla-text {
          color: #86004a;
        }

        /* MAIN HEADING
           Plus Jakarta Sans
        */

        .insurance-left h1 {
          margin: 34px 0 15px;
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 36px;
          line-height: 1.08;
          letter-spacing: -1.5px;
          font-weight: 600;
          color: #121a31;
        }

        /* SUBHEADING
           Plus Jakarta Sans
        */

        .insurance-description {
          max-width: 500px;
          margin: 0 0 31px;
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          color: #52647f;
          font-size: 15px;
          line-height: 1.7;
          font-weight: 500;
        }

        /* ================================
           INFO CARDS
        ================================= */

        .insurance-info-card {
          display: flex;
          gap: 14px;
          padding: 17px 16px;
          margin-bottom: 14px;
          background: #ffffff;
          border: 1px solid #e0e6ee;
          border-radius: 13px;
          box-shadow: 0 2px 5px rgba(22, 35, 55, 0.04);
        }

        .info-icon {
          flex-shrink: 0;
          width: 40px;
          height: 40px;
          border-radius: 8px;
          background: #fff0f7;
          color: #90004f;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .insurance-info-card h3 {
          margin: 1px 0 5px;
          font-family: "Inter", Arial, sans-serif;
          font-size: 14px;
          font-weight: 700;
          color: #18233b;
        }

        .insurance-info-card p {
          margin: 0;
          font-family: "Inter", Arial, sans-serif;
          color: #52627b;
          font-size: 13px;
          line-height: 1.5;
          font-weight: 400;
        }

        /* ================================
           CONTACT CARD
        ================================= */

        .insurance-contact-info {
          margin-top: 31px;
          padding: 20px;
          border-radius: 15px;
          border: 1px solid #dce4ed;
          background: #f1f5f9;
        }

        .contact-top {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 20px;
          padding-bottom: 15px;
          border-bottom: 1px solid #e2e8f0;
        }

        .contact-top span,
        .governance-title {
          display: block;
          font-family: "Inter", Arial, sans-serif;
          color: #8292aa;
          font-size: 11px;
          margin-bottom: 3px;
        }

        .contact-top strong {
          display: block;
          font-family: "Inter", Arial, sans-serif;
          color: #85004a;
          font-size: 12px;
          font-weight: 700;
          word-break: break-word;
        }

        .contact-top > div:last-child strong {
          color: #28364e;
        }

        .governance {
          padding-top: 17px;
        }

        .governance-tags {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          margin-top: 8px;
        }

        .governance-tags div {
          display: flex;
          align-items: center;
          gap: 7px;
          padding: 6px 9px;
          border: 1px solid #cad5e2;
          background: #ffffff;
          border-radius: 4px;
          font-family: "Inter", Arial, sans-serif;
          font-size: 10px;
          font-weight: 600;
          color: #34435b;
        }

        .governance-tags i {
          width: 6px;
          height: 6px;
          flex-shrink: 0;
          border-radius: 50%;
          background: #12b981;
        }

        /* ================================
           FORM CARD
        ================================= */

        .insurance-form-card {
          width: 100%;
          background: #ffffff;
          border: 1px solid #dce4ed;
          border-radius: 17px;
          padding: 32px;
          box-shadow: 0 8px 25px rgba(31, 45, 65, 0.05);
          min-width: 0;
        }

        .form-heading {
          padding-bottom: 20px;
          border-bottom: 1px solid #e6ebf1;
          margin-bottom: 26px;
        }

        /* FORM HEADING
           Plus Jakarta Sans
        */

        .form-heading h2 {
          margin: 0 0 7px;
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 21px;
          line-height: 1.35;
          font-weight: 700;
          color: #172139;
        }

        /* FORM SUBHEADING
           Plus Jakarta Sans
        */

        .form-heading p {
          margin: 0;
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 13px;
          line-height: 1.6;
          font-weight: 500;
          color: #63748e;
        }

        /* ================================
           FORM SECTIONS
        ================================= */

        .form-section {
          margin-bottom: 25px;
        }

        .section-title {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 13px;
          font-family: "Inter", Arial, sans-serif;
          color: #94a4bb;
          font-size: 12px;
          line-height: 1.4;
          font-weight: 800;
        }

        .section-number {
          width: 16px;
          height: 16px;
          flex-shrink: 0;
          border-radius: 50%;
          background: #182139;
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          font-family: "Inter", Arial, sans-serif;
          font-size: 9px;
          font-weight: 700;
        }

        /* ================================
           INPUTS
        ================================= */

        .form-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 14px;
        }

        .input-group {
          min-width: 0;
        }

        .input-group label {
          display: block;
          margin-bottom: 5px;
          font-family: "Inter", Arial, sans-serif;
          font-size: 13px;
          font-weight: 500;
          color: #263650;
        }

        .input-group input {
          width: 100%;
          height: 39px;
          padding: 0 12px;
          border: 1px solid #cbd6e4;
          border-radius: 7px;
          outline: none;
          font-family: "Inter", Arial, sans-serif;
          font-size: 13px;
          color: #263650;
          background: #ffffff;
          transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }

        .input-group input::placeholder {
          color: #9aabc1;
        }

        .input-group input:focus,
        .insurance-textarea:focus {
          border-color: #8b0050;
          box-shadow: 0 0 0 2px rgba(139, 0, 80, 0.08);
        }

        /* ================================
           CAPABILITIES
        ================================= */

        .capability-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 15px;
          margin-bottom: 13px;
        }

        .capability-header-left {
          display: flex;
          align-items: center;
          gap: 8px;
          min-width: 0;
        }

        .capability-header-left .section-title {
          white-space: normal;
        }

        .capability-header > small {
          flex-shrink: 0;
          color: #9ba9bd;
          font-family: "Inter", Arial, sans-serif;
          font-size: 10px;
          font-weight: 500;
        }

        .capability-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 7px;
        }

        .capability-button {
          min-height: 39px;
          padding: 7px 10px;
          border: 1px solid #d8e0e9;
          border-radius: 8px;
          background: white;
          color: #263650;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          text-align: left;
          cursor: pointer;
          font-family: "Inter", Arial, sans-serif;
          font-size: 12px;
          font-weight: 500;
          transition: all 0.2s ease;
        }

        .capability-button:hover {
          border-color: #8b0050;
          transform: translateY(-1px);
        }

        .capability-button small {
          flex-shrink: 0;
          color: #61708a;
          font-family: "Inter", Arial, sans-serif;
          font-size: 10px;
        }

        .capability-button.selected {
          background: #8b0050;
          border-color: #8b0050;
          color: white;
        }

        .capability-button.selected small {
          color: #f7c9df;
        }

        /* ================================
           TIMELINE
        ================================= */

        .timeline-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 8px;
        }

        .timeline-button {
          min-height: 36px;
          padding: 7px 8px;
          border: 1px solid #d8e0e9;
          border-radius: 8px;
          background: white;
          color: #263650;
          cursor: pointer;
          font-family: "Inter", Arial, sans-serif;
          font-size: 12px;
          font-weight: 500;
          line-height: 1.3;
          transition: all 0.2s ease;
        }

        .timeline-button:hover {
          border-color: #8b0050;
          transform: translateY(-1px);
        }

        .timeline-button.selected {
          background: #8b0050;
          color: white;
          border-color: #8b0050;
        }

        /* ================================
           TEXTAREA
        ================================= */

        .optional-title {
          display: flex;
          align-items: center;
          width: 100%;
        }

        .optional-text {
          margin-left: auto;
          font-family: "Inter", Arial, sans-serif;
          font-size: 10px;
          font-weight: 500;
          color: #94a4bb;
        }

        .insurance-textarea {
          width: 100%;
          height: 84px;
          resize: vertical;
          min-height: 84px;
          max-height: 180px;
          padding: 11px 12px;
          border: 1px solid #cbd6e4;
          border-radius: 7px;
          outline: none;
          font-family: "Inter", Arial, sans-serif;
          font-size: 13px;
          line-height: 1.5;
          color: #263650;
          background: #ffffff;
          transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }

        .insurance-textarea::placeholder {
          color: #94a5bd;
        }

        /* ================================
           CHECKBOXES
        ================================= */

        .checkbox-section {
          border-top: 1px solid #e5eaf0;
          padding-top: 8px;
          margin-bottom: 25px;
        }

        .checkbox-row {
          position: relative;
          display: flex;
          align-items: flex-start;
          gap: 9px;
          margin: 8px 0;
          color: #3c4c65;
          font-family: "Inter", Arial, sans-serif;
          font-size: 12px;
          line-height: 1.5;
          cursor: pointer;
        }

        .checkbox-row input {
          position: absolute;
          opacity: 0;
          pointer-events: none;
        }

        .custom-checkbox {
  width: 18px;
  height: 18px;
  flex-shrink: 0;
  margin-top: 1px;

  display: flex;
  align-items: center;
  justify-content: center;

  border: 1px solid #E5D3DC;
  border-radius: 4px;

  background: #ffffff;
  color: transparent;

  font-family: "Inter", Arial, sans-serif;
  font-size: 12px;
  font-weight: 700;

  transition: background 0.2s ease, border-color 0.2s ease;
}

/* CHECKED = BEETROOT + WHITE TICK */
.checkbox-row input:checked + .custom-checkbox {
  background: #730042 !important;
  border-color: #730042 !important;
  color: #ffffff !important;
}
         

        /* ================================
           SUBMIT
        ================================= */

        .insurance-submit-button {
          width: 100%;
          min-height: 49px;
          padding: 10px 16px;
          border: none;
          border-radius: 11px;
          background: #8b0050;
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          font-family: "Inter", Arial, sans-serif;
          font-size: 13px;
          font-weight: 600;
          line-height: 1.4;
          text-align: center;
          cursor: pointer;
          box-shadow: 0 4px 9px rgba(139, 0, 80, 0.18);
          transition: all 0.2s ease;
        }

        .insurance-submit-button:hover {
          background: #730042;
          transform: translateY(-1px);
        }

        .insurance-submit-button:active {
          transform: translateY(0);
        }

        .form-footer {
          margin: 16px 0 0;
          text-align: center;
          font-family: "Inter", Arial, sans-serif;
          font-size: 10px;
          line-height: 1.5;
          color: #60718b;
        }

        /* ================================
           LARGE TABLET
        ================================= */

        @media (max-width: 1100px) {
          .insurance-page {
            padding: 36px 24px;
          }

          .insurance-container {
            grid-template-columns: minmax(0, 0.85fr) minmax(0, 1.15fr);
            gap: 26px;
          }

          .insurance-left h1 {
            font-size: 34px;
          }

          .insurance-form-card {
            padding: 26px;
          }

          .timeline-grid {
            grid-template-columns: 1fr 1fr;
          }
        }

        /* ================================
           TABLET
        ================================= */

        @media (max-width: 900px) {
          .insurance-page {
            padding: 32px 22px;
          }

          .insurance-container {
            grid-template-columns: 1fr;
            gap: 28px;
            max-width: 760px;
          }

          .insurance-left {
            width: 100%;
            max-width: 760px;
            margin: 0 auto;
          }

          .insurance-description {
            max-width: 650px;
          }

          .insurance-form-card {
            width: 100%;
            max-width: 760px;
            margin: 0 auto;
          }

          .insurance-left h1 {
            font-size: 38px;
          }

          .capability-grid {
            grid-template-columns: 1fr 1fr;
          }

          .timeline-grid {
            grid-template-columns: repeat(4, 1fr);
          }
        }

        /* ================================
           MOBILE
        ================================= */

        @media (max-width: 650px) {
          .insurance-success-dialog {
            top: 16px;
            width: calc(100% - 28px);
            padding: 14px 16px;
          }

          .insurance-success-dialog-title { font-size: 13px; }
          .insurance-success-dialog-text { font-size: 11px; }
          .insurance-success-dialog-icon { width: 40px; height: 40px; }
          .insurance-success-dialog-icon svg { width: 28px; height: 28px; }

          .insurance-page {
            padding: 26px 16px;
          }

          .insurance-container {
            gap: 22px;
          }

          .insurance-badge {
            max-width: 100%;
            padding: 7px 10px;
            font-size: 9px;
            line-height: 1.4;
          }

          .insurance-left h1 {
            margin-top: 25px;
            font-size: 31px;
            line-height: 1.12;
            letter-spacing: -1px;
          }

          .insurance-description {
            margin-bottom: 24px;
            font-size: 14px;
            line-height: 1.65;
          }

          .insurance-info-card {
            gap: 11px;
            padding: 14px;
            margin-bottom: 11px;
          }

          .info-icon {
            width: 36px;
            height: 36px;
          }

          .insurance-info-card h3 {
            font-size: 13px;
          }

          .insurance-info-card p {
            font-size: 12px;
          }

          .insurance-contact-info {
            margin-top: 24px;
            padding: 16px;
          }

          .contact-top {
            grid-template-columns: 1fr;
            gap: 13px;
          }

          .governance {
            padding-top: 14px;
          }

          .governance-tags {
            gap: 6px;
          }

          .governance-tags div {
            font-size: 9px;
            padding: 5px 7px;
          }

          .insurance-form-card {
            padding: 20px 16px;
            border-radius: 14px;
          }

          .form-heading {
            padding-bottom: 17px;
            margin-bottom: 22px;
          }

          .form-heading h2 {
            font-size: 19px;
            line-height: 1.35;
          }

          .form-heading p {
            font-size: 12px;
            line-height: 1.55;
          }

          .form-grid {
            grid-template-columns: 1fr;
            gap: 12px;
          }

          .capability-grid {
            grid-template-columns: 1fr;
          }

          .capability-header {
            align-items: flex-start;
          }

          .capability-header > small {
            display: none;
          }

          .capability-button {
            min-height: 42px;
          }

          .timeline-grid {
            grid-template-columns: 1fr 1fr;
            gap: 7px;
          }

          .timeline-button {
            min-height: 40px;
            font-size: 10px;
          }

          .form-section {
            margin-bottom: 22px;
          }

          .section-title {
            font-size: 11px;
          }

          .insurance-textarea {
            min-height: 100px;
          }

          .optional-title {
            align-items: center;
          }

          .checkbox-section {
            margin-bottom: 21px;
          }

          .checkbox-row {
            font-size: 10px;
          }

          .insurance-submit-button {
            min-height: 48px;
            padding: 10px 13px;
            font-size: 12px;
          }
        }

        /* ================================
           SMALL MOBILE
        ================================= */

        @media (max-width: 420px) {
          .insurance-page {
            padding: 22px 12px;
          }

          .insurance-left h1 {
            font-size: 27px;
            line-height: 1.15;
          }

          .insurance-description {
            font-size: 13px;
          }

          .insurance-form-card {
            padding: 17px 13px;
          }

          .form-heading h2 {
            font-size: 17px;
          }

          .form-heading p {
            font-size: 11px;
          }

          .timeline-grid {
            grid-template-columns: 1fr;
          }

          .timeline-button {
            min-height: 38px;
          }

          .capability-button {
            font-size: 11px;
          }

          .capability-button small {
            font-size: 8px;
          }

          .insurance-submit-button {
            font-size: 11px;
          }

          .insurance-submit-button svg {
            width: 16px;
            height: 16px;
          }

          .form-footer {
            font-size: 9px;
          }
        }

        /* ================================
           VERY SMALL DEVICES
        ================================= */

        @media (max-width: 340px) {
          .insurance-page {
            padding-left: 10px;
            padding-right: 10px;
          }

          .insurance-badge {
            font-size: 8px;
          }

          .insurance-left h1 {
            font-size: 24px;
          }

          .insurance-form-card {
            padding: 15px 11px;
          }

          .section-title {
            font-size: 10px;
          }

          .insurance-submit-button {
            font-size: 10px;
          }
        }

        /* ================================
           REDUCED MOTION
        ================================= */

        @media (prefers-reduced-motion: reduce) {
          .capability-button,
          .timeline-button,
          .insurance-submit-button {
            transition: none;
          }

          .capability-button:hover,
          .timeline-button:hover,
          .insurance-submit-button:hover {
            transform: none;
          }
        }
      `}),e.jsxs("section",{className:"insurance-page",children:[h&&e.jsxs("div",{className:"insurance-success-dialog",role:"alert","aria-live":"polite",tabIndex:-1,onKeyDown:i=>{i.key==="Enter"&&(i.preventDefault(),o(!1))},children:[e.jsx("div",{className:"insurance-success-dialog-icon",children:e.jsx(A,{size:30,strokeWidth:2.5})}),e.jsxs("div",{className:"insurance-success-dialog-content",children:[e.jsx("p",{className:"insurance-success-dialog-title",children:"Request Submitted"}),e.jsx("p",{className:"insurance-success-dialog-text",children:"Your intake request has been submitted successfully."})]}),e.jsx("button",{type:"button",className:"insurance-success-dialog-ok",onClick:()=>o(!1),autoFocus:!0,"aria-label":"Close",children:"OK"})]}),e.jsxs("div",{className:"insurance-container",children:[e.jsxs("div",{className:"insurance-left",children:[e.jsxs("div",{className:"insurance-badge",children:[e.jsx("span",{className:"badge-dot"}),"TECHTORCH INSURANCE PRACTICE • DIRECT INTAKE",e.jsx("span",{className:"badge-separator",children:"•"}),e.jsx("span",{className:"sla-text",children:"<24h SLA"})]}),e.jsxs("h1",{children:["Connect with Principal",e.jsx("br",{}),"Insurance Solutions",e.jsx("br",{}),"Architects"]}),e.jsx("p",{className:"insurance-description",children:"Insurance businesses depend on connected operational foundations. Share your requirements across policy administration, claims automation, broker portals, or enterprise systems integration to discuss tailored architectural execution."}),e.jsxs("div",{className:"insurance-info-card",children:[e.jsx("div",{className:"info-icon",children:e.jsx(E,{size:19})}),e.jsxs("div",{children:[e.jsx("h3",{children:"Direct Architectural Review"}),e.jsx("p",{children:"30-min discovery session with an insurance tech lead to analyze workflows, legacy constraints, and target outcomes."})]})]}),e.jsxs("div",{className:"insurance-info-card",children:[e.jsx("div",{className:"info-icon",children:e.jsx(z,{size:19})}),e.jsxs("div",{children:[e.jsx("h3",{children:"Bilateral NDA Protected"}),e.jsx("p",{children:"Full mutual confidentiality and 100% intellectual property ownership explicitly preserved and respected from day one."})]})]}),e.jsxs("div",{className:"insurance-info-card",children:[e.jsx("div",{className:"info-icon",children:e.jsx(C,{size:19})}),e.jsxs("div",{children:[e.jsx("h3",{children:"Production-Grade Roadmap"}),e.jsx("p",{children:"Actionable technical scoping: stack recommendations, risk containment, and realistic delivery phases with clear SLAs."})]})]}),e.jsxs("div",{className:"insurance-contact-info",children:[e.jsxs("div",{className:"contact-top",children:[e.jsxs("div",{children:[e.jsx("span",{children:"Direct Advisory Inbox"}),e.jsx("strong",{children:"experts@techtorch.solutions"})]}),e.jsxs("div",{children:[e.jsx("span",{children:"Engineering Pods"}),e.jsx("strong",{children:"Bareilly HQ & Global Hybrid"})]})]}),e.jsxs("div",{className:"governance",children:[e.jsx("span",{className:"governance-title",children:"ENTERPRISE GOVERNANCE & STANDARDS"}),e.jsxs("div",{className:"governance-tags",children:[e.jsxs("div",{children:[e.jsx("i",{}),"SOC 2 Type II"]}),e.jsxs("div",{children:[e.jsx("i",{}),"ISO/IEC 27001"]}),e.jsxs("div",{children:[e.jsx("i",{}),"IFRS 17 Aligned"]})]})]})]})]}),e.jsxs("div",{className:"insurance-form-card",children:[e.jsxs("div",{className:"form-heading",children:[e.jsx("h2",{children:"Insurance Technology Scoping Console"}),e.jsx("p",{children:"Complete this technical intake to establish scope and route directly to a principal architect."})]}),e.jsxs("form",{onSubmit:y,children:[e.jsxs("div",{className:"form-section",children:[e.jsxs("div",{className:"section-title",children:[e.jsx("span",{className:"section-number",children:"1"}),"ORGANIZATION & PRIMARY CONTACT"]}),e.jsxs("div",{className:"form-grid",children:[e.jsxs("div",{className:"input-group",children:[e.jsx("label",{children:"Full Name *"}),e.jsx("input",{type:"text",name:"fullName",value:n.fullName,onChange:s,placeholder:"e.g. Alistair Vance",required:!0})]}),e.jsxs("div",{className:"input-group",children:[e.jsx("label",{children:"Corporate Work Email *"}),e.jsx("input",{type:"email",name:"email",value:n.email,onChange:s,placeholder:"e.g. a.vance@carriergroup.com",required:!0})]}),e.jsxs("div",{className:"input-group",children:[e.jsx("label",{children:"Organization / Carrier Name *"}),e.jsx("input",{type:"text",name:"organization",value:n.organization,onChange:s,placeholder:"e.g. Sovereign Mutual Assurance",required:!0})]}),e.jsxs("div",{className:"input-group",children:[e.jsx("label",{children:"Direct Phone / WhatsApp"}),e.jsx("input",{type:"tel",name:"phone",value:n.phone,onChange:s,placeholder:"e.g. +1 (555) 019-2834"})]})]})]}),e.jsxs("div",{className:"form-section",children:[e.jsxs("div",{className:"capability-header",children:[e.jsxs("div",{className:"capability-header-left",children:[e.jsx("span",{className:"section-number",children:"2"}),e.jsx("span",{className:"section-title",style:{margin:0},children:"SELECT INSURANCE CAPABILITIES (MULTI-SELECT)"})]}),e.jsx("small",{children:"CHOOSE ALL RELEVANT"})]}),e.jsx("div",{className:"capability-grid",children:T.map(([i,a])=>{const t=l.includes(i);return e.jsxs("button",{type:"button",className:`capability-button ${t?"selected":""}`,onClick:()=>g(i),children:[e.jsx("span",{children:i}),e.jsx("small",{children:a})]},i)})})]}),e.jsxs("div",{className:"form-section",children:[e.jsxs("div",{className:"section-title",children:[e.jsx("span",{className:"section-number",children:"3"}),"TARGET TIMELINE & SCALE"]}),e.jsx("div",{className:"timeline-grid",children:D.map(i=>e.jsx("button",{type:"button",className:`timeline-button ${d===i?"selected":""}`,onClick:()=>x(i),children:i},i))})]}),e.jsxs("div",{className:"form-section",children:[e.jsxs("div",{className:"section-title optional-title",children:[e.jsx("span",{className:"section-number",children:"4"}),"TECHNICAL OBJECTIVES & ENVIRONMENT",e.jsx("span",{className:"optional-text",children:"OPTIONAL"})]}),e.jsx("textarea",{className:"insurance-textarea",name:"objectives",value:n.objectives,onChange:s,placeholder:"Outline your core requirements, existing legacy systems (e.g. Guidewire, AS400, bespoke web portals), API expectations, or architectural roadblocks..."})]}),e.jsxs("div",{className:"checkbox-section",children:[e.jsxs("label",{className:"checkbox-row",children:[e.jsx("input",{type:"checkbox",name:"nda",checked:n.nda,onChange:s}),e.jsx("span",{className:"custom-checkbox",children:n.nda?"✓":""}),e.jsx("span",{children:"Execute Mutual Bilateral NDA prior to deep-dive architecture discussion"})]}),e.jsxs("label",{className:"checkbox-row",children:[e.jsx("input",{type:"checkbox",name:"briefing",checked:n.briefing,onChange:s}),e.jsx("span",{className:"custom-checkbox",children:n.briefing?"✓":""}),e.jsx("span",{children:"Request preliminary architecture consultation briefing document"})]})]}),e.jsx(v,{error:b}),e.jsxs("button",{type:"submit",disabled:u,className:"insurance-submit-button",children:["Submit Intake & Connect with Architects",e.jsx(S,{size:18})]}),e.jsx("p",{className:"form-footer",children:"Zero spam guarantee • 100% Client Code & IP Ownership • Enterprise SLA"})]})]})]})]})]})}export{F as default};
