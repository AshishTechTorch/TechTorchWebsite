import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as n}from"./vendor-router-L4ZCoGSs.js";import{F as C,s as q,a as A}from"./FormNotice-DRy7EQ_d.js";import{t as E,a2 as T,a3 as R,v as D,A as O,r as L}from"./index-BThRNyH6.js";import{U as H}from"./user-BaVexer9.js";import{M}from"./mail-3Flp59qD.js";import{P}from"./phone-B3rJcDGo.js";import{C as F}from"./clock-3-D3KlVi6Z.js";import{L as B}from"./lock-keyhole-qgr5czx6.js";import{S as U}from"./scale-OZoywk_6.js";const j={name:"timer",size:24,node:[["line",{x1:"10",x2:"14",y1:"2",y2:"2",key:"14vaq8"}],["line",{x1:"12",x2:"15",y1:"14",y2:"11",key:"17fdiu"}],["circle",{cx:"12",cy:"14",r:"8",key:"1e1u0o"}]]};j.node;const G=E(j),W=[{title:"Hospital & Clinic Operations",description:"EMR/EHR optimization, scheduling & clinical flows"},{title:"Diagnostic & Lab Systems",description:"LIS, PACS, imaging pipelines & specimen tracking"},{title:"Patient Portals & Experience",description:"Teleconsults, appointments & record access"},{title:"HealthTech Analytics & AI",description:"Bed occupancy, IoMT telemetry & triage predictive models"},{title:"Interoperability & Standards",description:"HL7 FHIR, ABDM, DICOM & HIPAA-aligned gateways"},{title:"Custom Cloud Infrastructure",description:"Scalable microservices, edge devices & secure data lakes"}],V=["< 500 / day","500 – 2,500","2.5k - 10k","10,000+"],Y=[{title:"Morning (09:00 - 12:00)"},{title:"Afternoon (13:00 - 17:00)"},{title:"Global / Flexible Zone"}];function ie(){const[p,h]=n.useState([]),[x,m]=n.useState(""),[l,u]=n.useState(""),[d,f]=n.useState(""),[w,c]=n.useState(!1),[r,g]=n.useState({name:"",email:"",organization:"",phone:"",challenge:"",nda:!1}),N=a=>{h(t=>t.includes(a)?t.filter(i=>i!==a):[...t,a])},s=a=>{const{name:t,value:i,type:z,checked:I}=a.target;g(S=>({...S,[t]:z==="checkbox"?I:i}))},[b,y]=n.useState(!1),[v,o]=n.useState(""),k=async a=>{if(a.preventDefault(),b)return;const t=a.currentTarget;if(!t.checkValidity()){const i=t.querySelector(":invalid");i&&(i.focus(),t.reportValidity(),setTimeout(()=>{i.blur()},4e3));return}if(!l){const i=t.querySelector(".patient-volume-required");i&&(i.focus(),i.reportValidity(),setTimeout(()=>{i.blur()},4e3));return}if(p.length===0){o("Please select at least one healthcare requirement.");return}if(!d){o("Please choose a preferred consultation window.");return}if(!r.phone.trim()){o("Phone / WhatsApp number is required.");return}o(""),y(!0);try{await q("healthcare",{healthcareRequirements:p,facilityType:x,patientVolume:l,fullNameDesignation:r.name.trim(),workEmail:r.email.trim(),organizationName:r.organization.trim(),phone:r.phone.trim(),consultationWindow:d,challengeScope:r.challenge.trim(),healthcareNdaRequested:!!r.nda}),c(!0),setTimeout(()=>{c(!1)},3e3),g({name:"",email:"",organization:"",phone:"",challenge:"",nda:!1}),h([]),m(""),u(""),f("")}catch(i){o(A(i))}finally{y(!1)}};return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`
        /* =====================================================
           GOOGLE FONTS
        ===================================================== */

        @import url(
          'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap'
        );


        /* =====================================================
           GLOBAL
        ===================================================== */

        * {
          box-sizing: border-box;
        }


        .healthcare-page {
          min-height: 100vh;

          width: 100%;

          background: #f7f9fb;

          padding: 70px 30px;

          font-family: "Inter", Arial, sans-serif;

          color: #172036;

          overflow: hidden;
        }


        /* =====================================================
           SUCCESS DIALOG
        ===================================================== */

        .success-dialog {
          position: fixed;
          top: 24px;
          left: 50%;
          transform: translateX(-50%);
          z-index: 9999;

          width: min(420px, calc(100% - 32px));

          display: flex;
          align-items: center;
          gap: 14px;

          padding: 16px 20px;

          background: #ffffff;
          border: 1px solid #E5D3DC;
          border-radius: 10px;

          box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);

          font-family: "Inter", sans-serif;

          animation: successDialogIn 0.25s ease-out;
        }

        .success-dialog-icon {
          width: 34px;
          height: 34px;
          flex-shrink: 0;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 50%;
          background: #ffffff;
          color: #22824D;

          border: none;
        }

        .success-dialog-content {
          min-width: 0;
        }

        .success-dialog-title {
          margin: 0;

          color: #202022;
          font-family: "Inter", sans-serif;
          font-size: 14px;
          font-weight: 700;
          line-height: 1.4;
        }

        .success-dialog-text {
          margin: 2px 0 0;

          color: #65595E;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 400;
          line-height: 1.5;
        }

        .success-dialog-ok {
          width: 34px;
          height: 34px;

          margin-left: auto;
          flex-shrink: 0;

          display: flex;
          align-items: center;
          justify-content: center;

          padding: 0;

          border: none;
          border-radius: 50%;

          background: #730042;
          color: #ffffff;

          font-family: "Inter", sans-serif;
          font-size: 10px;
          font-weight: 600;

          cursor: pointer;

          transition: background 0.2s ease, transform 0.2s ease;
        }

        .success-dialog-ok:hover {
          background: #620038;
          transform: scale(1.05);
        }

        @keyframes successDialogIn {
          from {
            opacity: 0;
            transform: translate(-50%, -12px);
          }

          to {
            opacity: 1;
            transform: translate(-50%, 0);
          }
        }


        /* =====================================================
           MAIN WRAPPER
        ===================================================== */

        .healthcare-wrapper {
          width: 100%;

          max-width: 1080px;

          margin: 0 auto;

          background: #ffffff;

          border: 1px solid #dce4ed;

          border-radius: 22px;

          padding: 44px 46px 38px;

          box-shadow:
            0 15px 35px rgba(27, 44, 70, 0.07);
        }


        /* =====================================================
           HEADER
        ===================================================== */

        .healthcare-header {
          text-align: center;

          margin-bottom: 40px;
        }


        /* =====================================================
           BADGE
           INTER
        ===================================================== */

        .healthcare-badge {
          display: inline-flex;

          align-items: center;

          justify-content: center;

          gap: 8px;

          padding: 6px 13px;

          border-radius: 20px;

          background: #f5f6f9;

          border: 1px solid #e0e5ec;

          color: #85004c;

          font-family: "Inter", sans-serif;

          font-size: 10px;

          font-weight: 700;

          letter-spacing: 0.3px;
        }


        .healthcare-badge-dot {
          width: 7px;

          height: 7px;

          flex-shrink: 0;

          border-radius: 50%;

          background: #85004c;
        }


        /* =====================================================
           MAIN HEADING
           PLUS JAKARTA SANS
        ===================================================== */

        .healthcare-header h1 {
          margin: 18px auto 12px;

          max-width: 760px;

          font-family:
            "Plus Jakarta Sans",
            sans-serif;

          font-size: 34px;

          line-height: 1.15;

          letter-spacing: -0.8px;

          font-weight: 700;

          color: #141c31;
        }


        /* =====================================================
           SUBHEADING
           PLUS JAKARTA SANS
        ===================================================== */

        .healthcare-header p {
          max-width: 720px;

          margin: 0 auto;

          font-family:
            "Plus Jakarta Sans",
            sans-serif;

          color: #596982;

          font-size: 13px;

          line-height: 1.7;

          font-weight: 500;
        }


        /* =====================================================
           FORM SECTIONS
        ===================================================== */

        .healthcare-section {
          margin-top: 32px;
        }


        .healthcare-section-heading {
          display: flex;

          align-items: center;

          flex-wrap: wrap;

          gap: 7px;

          margin-bottom: 14px;
        }


        .healthcare-section-number {
          color: #8a0050;

          font-family: "Inter", sans-serif;

          font-size: 13px;

          font-weight: 700;
        }


        .healthcare-section-heading h2 {
          margin: 0;

          font-family: "Inter", sans-serif;

          font-size: 14px;

          font-weight: 500;

          color: #171e31;
        }


        .healthcare-section-heading span:last-child {
          color: #a1adbd;

          font-family: "Inter", sans-serif;

          font-size: 11px;

          font-weight: 400;
        }


        /* =====================================================
           REQUIREMENTS
        ===================================================== */

        .healthcare-requirement-grid {
          display: grid;

          grid-template-columns:
            repeat(3, minmax(0, 1fr));

          gap: 11px;
        }


        .healthcare-requirement {
          width: 100%;

          min-height: 84px;

          padding: 14px;

          border: 1px solid #dce4ed;

          border-radius: 10px;

          background: #fbfcfd;

          text-align: left;

          cursor: pointer;

          font-family: "Inter", sans-serif;

          transition:
            border-color 0.2s ease,
            background 0.2s ease,
            transform 0.2s ease;
        }


        .healthcare-requirement:hover {
          border-color: #b6c2d1;

          transform: translateY(-1px);
        }


        .healthcare-requirement.selected {
          border-color: #8a0050;

          background: #fff7fa;
        }


        .requirement-top {
          display: flex;

          align-items: flex-start;

          gap: 10px;
        }


        .requirement-checkbox {
          width: 14px;

          height: 14px;

          margin-top: 1px;

          flex-shrink: 0;

          border: 1px solid #8f969e;

          border-radius: 3px;

          display: flex;

          align-items: center;

          justify-content: center;

          color: white;

          background: white;

          font-family: "Inter", sans-serif;

          font-size: 9px;

          font-weight: 700;
        }


        .healthcare-requirement.selected
        .requirement-checkbox {
          background: #8a0050;

          border-color: #8a0050;
        }


        .requirement-title {
          color: #273047;

          font-family: "Inter", sans-serif;

          font-size: 13px;

          line-height: 1.4;

          font-weight: 600;
        }


        .requirement-description {
          margin: 6px 0 0 24px;

          color: #718097;

          font-family: "Inter", sans-serif;

          font-size: 12px;

          line-height: 1.5;
        }


        /* =====================================================
           FACILITY
        ===================================================== */

        .facility-row {
          display: grid;

          grid-template-columns:
            minmax(0, 1fr)
            minmax(0, 1fr);

          gap: 20px;

          align-items: end;
        }


        .field-label {
          display: block;

          margin-bottom: 7px;

          color: #344157;

          font-family: "Inter", sans-serif;

          font-size: 13px;

          font-weight: 600;
        }


        .required-star {
          color: #8a0050;
        }


        .select-wrapper {
          position: relative;
        }


        .facility-select {
          width: 100%;

          height: 41px;

          padding: 0 38px 0 13px;

          border: 1px solid #dce4ed;

          border-radius: 8px;

          background: #fbfcfd;

          color: #39465c;

          outline: none;

          font-family: "Inter", sans-serif;

          font-size: 12px;

          appearance: none;

          cursor: pointer;
        }


        .facility-select:focus {
          border-color: #8a0050;

          box-shadow:
            0 0 0 2px rgba(138, 0, 80, 0.08);
        }


        .select-arrow {
          position: absolute;

          right: 12px;

          top: 50%;

          transform: translateY(-50%);

          color: #8794a7;

          pointer-events: none;
        }


        .volume-grid {
          display: grid;

          grid-template-columns:
            repeat(4, minmax(0, 1fr));

          gap: 7px;
        }


        .volume-button {
          height: 50px;

          padding: 5px;

          border: 1px solid #dce4ed;

          border-radius: 9px;

          background: #fbfcfd;

          color: #344157;

          font-family: "Inter", sans-serif;

          font-size: 12px;

          font-weight: 500;

          cursor: pointer;

          transition:
            border-color 0.2s ease,
            background 0.2s ease;
        }


        .volume-button:hover {
          border-color: #b9c4d2;
        }


        .volume-button.selected {
          color: white;

          background: #8a0050;

          border-color: #8a0050;
        }


        /* =====================================================
           CONTACT
        ===================================================== */

        .contact-grid {
          display: grid;

          grid-template-columns:
            repeat(2, minmax(0, 1fr));

          gap: 15px;
        }


        .healthcare-input-group {
          position: relative;

          min-width: 0;
        }


        .healthcare-input-group.full {
          grid-column: 1 / -1;
        }


        .healthcare-input-group label {
          display: block;

          margin-bottom: 7px;

          color: #344157;

          font-family: "Inter", sans-serif;

          font-size: 13px;

          font-weight: 600;
        }


        .healthcare-input-wrapper {
          position: relative;
        }


        .healthcare-input-wrapper svg {
          position: absolute;

          left: 12px;

          top: 50%;

          transform: translateY(-50%);

          width: 14px;

          height: 14px;

          color: #93a1b3;

          pointer-events: none;
        }


        .healthcare-input {
          width: 100%;

          height: 41px;

          padding: 0 12px 0 36px;

          border: 1px solid #dce4ed;

          border-radius: 8px;

          background: #fbfcfd;

          color: #344157;

          outline: none;

          font-family: "Inter", sans-serif;

          font-size: 13px;
        }


        .healthcare-input::placeholder {
          color: #9aa8ba;
        }


        .healthcare-input:focus,
        .healthcare-textarea:focus {
          border-color: #8a0050;

          box-shadow:
            0 0 0 2px rgba(138, 0, 80, 0.08);
        }


        /* =====================================================
           CONSULTATION
        ===================================================== */

        .consultation-label {
          margin: 18px 0 8px;

          color: #344157;

          font-family: "Inter", sans-serif;

          font-size: 12px;

          font-weight: 600;
        }


        .consultation-grid {
          display: grid;

          grid-template-columns:
            repeat(3, minmax(0, 1fr));

          gap: 9px;
        }


        .consultation-button {
          min-height: 39px;

          display: flex;

          align-items: center;

          gap: 7px;

          padding: 7px 12px;

          border: 1px solid #dce4ed;

          border-radius: 8px;

          background: #fbfcfd;

          color: #46536a;

          text-align: left;

          font-family: "Inter", sans-serif;

          font-size: 12px;

          font-weight: 600;

          cursor: pointer;

          transition:
            border-color 0.2s ease,
            background 0.2s ease;
        }


        .consultation-button:hover {
          border-color: #b9c4d2;
        }


        .consultation-button.selected {
          background: #fff1f7;

          border-color: #8a0050;

          color: #85004c;
        }


        .radio-circle {
          width: 12px;

          height: 12px;

          border: 1px solid #8c969f;

          border-radius: 50%;

          display: flex;

          align-items: center;

          justify-content: center;

          flex-shrink: 0;
        }


        .radio-circle::after {
          content: "";

          width: 6px;

          height: 6px;

          border-radius: 50%;

          background: transparent;
        }


        .consultation-button.selected
        .radio-circle {
          border-color: #8a0050;
        }


        .consultation-button.selected
        .radio-circle::after {
          background: #8a0050;
        }


        .consultation-clock {
          color: #8d9aac;

          flex-shrink: 0;
        }


        /* =====================================================
           TEXTAREA
        ===================================================== */

        .challenge-label {
          margin: 18px 0 8px;

          color: #344157;

          font-family: "Inter", sans-serif;

          font-size: 12px;

          font-weight: 600;
        }


        .optional {
          color: #9aa6b6;

          font-weight: 400;
        }


        .healthcare-textarea {
          width: 100%;

          height: 85px;

          padding: 12px;

          resize: vertical;

          min-height: 70px;

          max-height: 180px;

          border: 1px solid #dce4ed;

          border-radius: 9px;

          background: #fbfcfd;

          outline: none;

          color: #344157;

          font-family: "Inter", sans-serif;

          font-size: 13px;

          line-height: 1.5;
        }


        .healthcare-textarea::placeholder {
          color: #9aa8ba;
        }


        /* =====================================================
           NDA
        ===================================================== */

        .nda-box {
          margin-top: 29px;

          padding: 14px;

          display: flex;

          align-items: flex-start;

          gap: 10px;

          border: 1px solid #dce4ed;

          border-radius: 9px;

          background: #fbfcfd;

          cursor: pointer;

          font-family: "Inter", sans-serif;
        }


        .nda-box input {
          position: absolute;

          opacity: 0;

          pointer-events: none;
        }


        .nda-checkbox {
          width: 15px;

          height: 15px;

          flex-shrink: 0;

          margin-top: 1px;

          border: 1px solid #8b929b;

          border-radius: 3px;

          display: flex;

          align-items: center;

          justify-content: center;

          background: white;

          color: white;

          font-size: 9px;

          font-weight: 700;
        }


        .nda-box.checked .nda-checkbox {
          background: #8a0050;

          border-color: #8a0050;
        }


        .nda-content {
          min-width: 0;
        }


        .nda-content strong {
          display: flex;

          align-items: center;

          margin-bottom: 3px;

          color: #273047;

          font-family: "Inter", sans-serif;

          font-size: 13px;

          line-height: 1.4;

          font-weight: 600;
        }


        .nda-content p {
          margin: 0;

          color: #718097;

          font-family: "Inter", sans-serif;

          font-size: 11px;

          line-height: 1.5;
        }


        /* =====================================================
           SUBMIT
        ===================================================== */

        .healthcare-submit {
          width: 100%;

          min-height: 49px;

          margin-top: 28px;

          padding: 10px 18px;

          border: none;

          border-radius: 10px;

          background: #8a0050;

          color: white;

          display: flex;

          align-items: center;

          justify-content: center;

          gap: 9px;

          font-family: "Inter", sans-serif;

          font-size: 13px;

          font-weight: 700;

          cursor: pointer;

          box-shadow:
            0 5px 12px rgba(138, 0, 80, 0.17);

          transition:
            background 0.2s ease,
            transform 0.2s ease;
        }


        .healthcare-submit:hover {
          background: #710041;

          transform: translateY(-1px);
        }


        /* =====================================================
           FOOTER NOTE
        ===================================================== */

        .healthcare-bottom-note {
          display: flex;

          justify-content: center;

          align-items: center;

          flex-wrap: wrap;

          gap: 10px;

          margin-top: 15px;

          color: #68778d;

          font-family: "Inter", sans-serif;

          font-size: 10px;

          line-height: 1.5;
        }


        .healthcare-bottom-note span {
          display: flex;

          align-items: center;

          gap: 5px;
        }


        .healthcare-bottom-note svg {
          width: 11px;

          height: 11px;
        }


        .green-icon {
          color: #129b72;
        }


        .blue-icon {
          color: #4772cf;
        }


        .pink-icon {
          color: #8a0050;
        }


        .note-divider {
          color: #cbd2dc;
        }


        /* =====================================================
           LARGE TABLET
        ===================================================== */

        @media (max-width: 1050px) {

          .healthcare-page {
            padding: 55px 24px;
          }


          .healthcare-wrapper {
            max-width: 950px;

            padding: 38px 34px 34px;
          }


          .healthcare-header h1 {
            font-size: 31px;
          }


          .healthcare-requirement-grid {
            gap: 9px;
          }

        }


        /* =====================================================
           TABLET
        ===================================================== */

        @media (max-width: 850px) {

          .healthcare-page {
            padding: 45px 20px;
          }


          .healthcare-wrapper {
            padding: 34px 28px 32px;

            border-radius: 18px;
          }


          .healthcare-header {
            margin-bottom: 34px;
          }


          .healthcare-header h1 {
            font-size: 29px;

            line-height: 1.18;
          }


          .healthcare-header p {
            max-width: 620px;

            font-size: 12px;
          }


          .healthcare-requirement-grid {
            grid-template-columns:
              repeat(2, minmax(0, 1fr));
          }


          .facility-row {
            grid-template-columns: 1fr;

            gap: 17px;
          }


          .consultation-grid {
            grid-template-columns:
              repeat(3, minmax(0, 1fr));
          }

        }


        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 650px) {

          .healthcare-page {
            padding: 25px 14px 35px;
          }


          .healthcare-wrapper {
            padding: 28px 17px 25px;

            border-radius: 15px;

            box-shadow:
              0 10px 25px rgba(27, 44, 70, 0.06);
          }


          .healthcare-header {
            margin-bottom: 30px;
          }


          .healthcare-badge {
            padding: 5px 10px;

            font-size: 8.5px;
          }


          .healthcare-badge-dot {
            width: 6px;

            height: 6px;
          }


          /* Main heading */

          .healthcare-header h1 {
            margin-top: 15px;

            font-size: 25px;

            line-height: 1.2;

            letter-spacing: -0.5px;
          }


          /* Subheading */

          .healthcare-header p {
            margin-top: 4px;

            font-size: 11px;

            line-height: 1.7;
          }


          .healthcare-section {
            margin-top: 27px;
          }


          .healthcare-section-heading {
            gap: 6px;

            margin-bottom: 12px;
          }


          .healthcare-section-heading h2 {
            font-size: 11.5px;
          }


          .healthcare-section-heading span:last-child {
            font-size: 9px;
          }


          .healthcare-requirement-grid {
            grid-template-columns: 1fr;

            gap: 9px;
          }


          .healthcare-requirement {
            min-height: auto;

            padding: 13px;
          }


          .requirement-title {
            font-size: 11px;
          }


          .requirement-description {
            font-size: 9px;

            margin-top: 5px;
          }


          .facility-row {
            gap: 15px;
          }


          .volume-grid {
            grid-template-columns:
              repeat(2, minmax(0, 1fr));

            gap: 7px;
          }


          .volume-button {
            height: 45px;

            font-size: 9.5px;
          }


          .contact-grid {
            grid-template-columns: 1fr;

            gap: 13px;
          }


          .healthcare-input-group.full {
            grid-column: auto;
          }


          .healthcare-input {
            height: 40px;

            font-size: 10.5px;
          }


          .consultation-grid {
            grid-template-columns: 1fr;

            gap: 8px;
          }


          .consultation-button {
            min-height: 40px;

            font-size: 10px;
          }


          .healthcare-textarea {
            height: 95px;

            font-size: 10.5px;
          }


          .nda-box {
            margin-top: 25px;

            padding: 12px;
          }


          .nda-content strong {
            font-size: 10px;
          }


          .nda-content p {
            font-size: 9px;
          }


          .healthcare-submit {
            min-height: 47px;

            margin-top: 24px;

            font-size: 12px;
          }


          .healthcare-bottom-note {
            flex-direction: column;

            gap: 7px;

            font-size: 9px;

            text-align: center;
          }


          .note-divider {
            display: none;
          }

        }


        /* =====================================================
           SMALL MOBILE
        ===================================================== */

        @media (max-width: 400px) {

          .healthcare-page {
            padding: 20px 10px 30px;
          }


          .healthcare-wrapper {
            padding: 24px 14px 22px;

            border-radius: 13px;
          }


          .healthcare-header h1 {
            font-size: 22px;

            line-height: 1.22;
          }


          .healthcare-header p {
            font-size: 10px;

            line-height: 1.65;
          }


          .healthcare-section-heading h2 {
            font-size: 11px;
          }


          .healthcare-section-heading span:last-child {
            font-size: 8.5px;
          }


          .healthcare-requirement {
            padding: 12px;
          }


          .requirement-title {
            font-size: 10.5px;
          }


          .requirement-description {
            font-size: 8.5px;
          }


          .field-label,
          .healthcare-input-group label,
          .consultation-label,
          .challenge-label {
            font-size: 10px;
          }


          .facility-select {
            height: 39px;

            font-size: 10px;
          }


          .volume-button {
            font-size: 9px;
          }


          .healthcare-input {
            font-size: 10px;
          }


          .consultation-button {
            font-size: 9.5px;
          }


          .healthcare-textarea {
            font-size: 10px;
          }


          .healthcare-submit {
            min-height: 45px;

            font-size: 11px;
          }


          .healthcare-bottom-note {
            font-size: 8.5px;
          }

        }


        /* =====================================================
           VERY SMALL MOBILE
        ===================================================== */

        @media (max-width: 340px) {

          .healthcare-page {
            padding: 16px 8px 25px;
          }


          .healthcare-wrapper {
            padding: 21px 12px 20px;
          }


          .healthcare-badge {
            font-size: 7.5px;

            padding: 5px 8px;
          }


          .healthcare-header h1 {
            font-size: 20px;
          }


          .healthcare-header p {
            font-size: 9.5px;
          }


          .healthcare-section-heading h2 {
            font-size: 10.5px;
          }


          .healthcare-submit {
            font-size: 10.5px;
          }

        }


        /* =====================================================
           REDUCED MOTION
        ===================================================== */

        @media (prefers-reduced-motion: reduce) {

          .healthcare-requirement,
          .volume-button,
          .consultation-button,
          .healthcare-submit,
          .success-dialog {
            transition: none;
            animation: none;
          }


          .healthcare-requirement:hover,
          .healthcare-submit:hover {
            transform: none;
          }

        }

      `}),e.jsxs("section",{className:"healthcare-page",children:[w&&e.jsxs("div",{className:"success-dialog",role:"alert","aria-live":"polite",tabIndex:-1,onKeyDown:a=>{a.key==="Enter"&&(a.preventDefault(),c(!1))},children:[e.jsx("div",{className:"success-dialog-icon",children:e.jsx(T,{size:21})}),e.jsxs("div",{className:"success-dialog-content",children:[e.jsx("p",{className:"success-dialog-title",children:"Request Submitted"}),e.jsx("p",{className:"success-dialog-text",children:"Your consultation request has been submitted successfully."})]}),e.jsx("button",{type:"button",className:"success-dialog-ok",onClick:()=>c(!1),autoFocus:!0,"aria-label":"Close",children:"OK"})]}),e.jsxs("div",{className:"healthcare-wrapper",children:[e.jsxs("header",{className:"healthcare-header",children:[e.jsxs("div",{className:"healthcare-badge",children:[e.jsx("span",{className:"healthcare-badge-dot"}),"HEALTHCARE TECHNOLOGY CONSULTATION"]}),e.jsxs("h1",{children:["Get in Touch with TechTorch Healthcare",e.jsx("br",{}),"Experts"]}),e.jsx("p",{children:"Connect directly with our healthcare solutions team to discuss clinical workflows, diagnostic systems, patient portals, or operational integrations."})]}),e.jsxs("form",{onSubmit:k,children:[e.jsxs("div",{className:"healthcare-section",children:[e.jsxs("div",{className:"healthcare-section-heading",children:[e.jsx("span",{className:"healthcare-section-number",children:"01"}),e.jsx("h2",{children:"Primary Healthcare Requirement"}),e.jsx("span",{children:"(Select all applicable)"})]}),e.jsx("div",{className:"healthcare-requirement-grid",children:W.map(a=>{const t=p.includes(a.title);return e.jsxs("button",{type:"button",className:`healthcare-requirement ${t?"selected":""}`,onClick:()=>N(a.title),children:[e.jsxs("div",{className:"requirement-top",children:[e.jsx("span",{className:"requirement-checkbox",children:t&&e.jsx("span",{children:"✓"})}),e.jsx("span",{className:"requirement-title",children:a.title})]}),e.jsx("p",{className:"requirement-description",children:a.description})]},a.title)})})]}),e.jsxs("div",{className:"healthcare-section",children:[e.jsxs("div",{className:"healthcare-section-heading",children:[e.jsx("span",{className:"healthcare-section-number",children:"02"}),e.jsx("h2",{children:"Facility Type & Scale Tier"})]}),e.jsxs("div",{className:"facility-row",children:[e.jsxs("div",{children:[e.jsxs("label",{className:"field-label",children:["Facility Type"," ",e.jsx("span",{className:"required-star",children:"*"})]}),e.jsxs("div",{className:"select-wrapper",children:[e.jsxs("select",{className:"facility-select",value:x,onChange:a=>m(a.target.value),required:!0,children:[e.jsx("option",{value:"",disabled:!0,children:"Select facility type..."}),e.jsx("option",{value:"Hospital",children:"Hospital"}),e.jsx("option",{value:"Clinic",children:"Clinic"}),e.jsx("option",{value:"Diagnostic Center",children:"Diagnostic Center"}),e.jsx("option",{value:"Medical College",children:"Medical College"}),e.jsx("option",{value:"Healthcare Network",children:"Healthcare Network"}),e.jsx("option",{value:"Other",children:"Other"})]}),e.jsx(R,{className:"select-arrow",size:15})]})]}),e.jsxs("div",{children:[e.jsxs("label",{className:"field-label",children:["Daily Patient / Transaction Volume"," ",e.jsx("span",{className:"required-star",children:"*"})]}),e.jsx("input",{className:"patient-volume-required",type:"text",value:l,onChange:()=>{},required:!0,tabIndex:-1,"aria-hidden":"true",style:{position:"absolute",width:"1px",height:"1px",padding:0,margin:"-1px",overflow:"hidden",clip:"rect(0, 0, 0, 0)",whiteSpace:"nowrap",border:0}}),e.jsx("div",{className:"volume-grid",children:V.map(a=>e.jsx("button",{type:"button",className:`volume-button ${l===a?"selected":""}`,onClick:()=>u(t=>t===a?"":a),children:a},a))})]})]})]}),e.jsxs("div",{className:"healthcare-section",children:[e.jsxs("div",{className:"healthcare-section-heading",children:[e.jsx("span",{className:"healthcare-section-number",children:"03"}),e.jsx("h2",{children:"Contact & Integration Scope"})]}),e.jsxs("div",{className:"contact-grid",children:[e.jsxs("div",{className:"healthcare-input-group",children:[e.jsxs("label",{children:["Full Name & Designation"," ",e.jsx("span",{className:"required-star",children:"*"})]}),e.jsxs("div",{className:"healthcare-input-wrapper",children:[e.jsx(H,{}),e.jsx("input",{className:"healthcare-input",type:"text",name:"name",value:r.name,onChange:s,placeholder:"e.g. Dr. Rajesh Sharma, CMO",required:!0})]})]}),e.jsxs("div",{className:"healthcare-input-group",children:[e.jsxs("label",{children:["Work / Institutional Email"," ",e.jsx("span",{className:"required-star",children:"*"})]}),e.jsxs("div",{className:"healthcare-input-wrapper",children:[e.jsx(M,{}),e.jsx("input",{className:"healthcare-input",type:"email",name:"email",value:r.email,onChange:s,placeholder:"r.sharma@apollohospitals.com",required:!0})]})]}),e.jsxs("div",{className:"healthcare-input-group",children:[e.jsxs("label",{children:["Organization / Hospital Name"," ",e.jsx("span",{className:"required-star",children:"*"})]}),e.jsxs("div",{className:"healthcare-input-wrapper",children:[e.jsx(D,{}),e.jsx("input",{className:"healthcare-input",type:"text",name:"organization",value:r.organization,onChange:s,placeholder:"e.g. Apollo Hospitals Group",required:!0})]})]}),e.jsxs("div",{className:"healthcare-input-group",children:[e.jsxs("label",{children:["Phone / WhatsApp Number"," ",e.jsx("span",{className:"required-star",children:"*"})]}),e.jsxs("div",{className:"healthcare-input-wrapper",children:[e.jsx(P,{}),e.jsx("input",{className:"healthcare-input",type:"tel",name:"phone",value:r.phone,onChange:s,placeholder:"+91 98765 43210",required:!0})]})]})]}),e.jsx("div",{className:"consultation-label",children:"Preferred Consultation Window"}),e.jsx("div",{className:"consultation-grid",children:Y.map(a=>{const t=d===a.title;return e.jsxs("button",{type:"button",className:`consultation-button ${t?"selected":""}`,onClick:()=>f(i=>i===a.title?"":a.title),children:[e.jsx("span",{className:"radio-circle"}),e.jsx(F,{size:13,className:"consultation-clock"}),e.jsx("span",{children:a.title})]},a.title)})}),e.jsxs("div",{className:"challenge-label",children:["Brief Challenge or Integration Scope"," ",e.jsx("span",{className:"optional",children:"(Optional)"})]}),e.jsx("textarea",{className:"healthcare-textarea",name:"challenge",value:r.challenge,onChange:s,placeholder:"Tell us about your existing systems, interfaces (HL7 FHIR, DICOM, LIS/PACS), integration scope, target milestones, or security protocols..."})]}),e.jsxs("label",{className:`nda-box ${r.nda?"checked":""}`,children:[e.jsx("input",{type:"checkbox",name:"nda",checked:r.nda,onChange:s}),e.jsx("span",{className:"nda-checkbox",children:r.nda&&"✓"}),e.jsxs("span",{className:"nda-content",children:[e.jsxs("strong",{children:[e.jsx(B,{size:10,style:{display:"inline",marginRight:"5px",flexShrink:0}}),"Request standard Healthcare Non-Disclosure Agreement (NDA)"]}),e.jsx("p",{children:"A mutual NDA executed under enterprise standards will be delivered prior to technical architecture discussion."})]})]}),e.jsx(C,{error:v}),e.jsxs("button",{type:"submit",disabled:b,className:"healthcare-submit",children:["Submit Consultation Request",e.jsx(O,{size:17})]}),e.jsxs("div",{className:"healthcare-bottom-note",children:[e.jsxs("span",{children:[e.jsx(L,{className:"green-icon"}),"Strict Confidentiality"]}),e.jsx("span",{className:"note-divider",children:"•"}),e.jsxs("span",{children:[e.jsx(U,{className:"blue-icon"}),"Bilateral NDA Compliant"]}),e.jsx("span",{className:"note-divider",children:"•"}),e.jsxs("span",{children:[e.jsx(G,{className:"pink-icon"}),"Guaranteed 24h Architect Response"]})]})]})]})]})]})}export{ie as default};
