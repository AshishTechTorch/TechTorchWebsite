import{j as e}from"./vendor-query-PraSc8EQ.js";import{L as m}from"./vendor-router-L4ZCoGSs.js";import{t as p,A as d,r as c,Z as b,z as u,W as x,D as h,R as w,x as j,F as v,s as k}from"./index-BThRNyH6.js";import{C as l}from"./check-Cj2_y9Sm.js";import{C as N}from"./calendar-days-u_cmp8dG.js";import{C as z}from"./chart-line-B_0B5Rbj.js";import{S}from"./shopping-bag-D6A6VFV7.js";import{S as $}from"./settings-Dm05DpDI.js";import{E as M}from"./eye-BWH2ZhD-.js";import{S as P}from"./share-2-Ceim1j9X.js";import{H as C}from"./headphones-BBpbbgVA.js";import{C as I}from"./cloud-DZemR4H4.js";const g={name:"circle-dot",size:24,node:[["circle",{cx:"12",cy:"12",r:"1",key:"41hilf"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]};g.node;const A=p(g);const f={name:"concierge-bell",size:24,node:[["path",{d:"M3 20a1 1 0 0 1-1-1v-1a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1Z",key:"1pvr1r"}],["path",{d:"M20 16a8 8 0 1 0-16 0",key:"1pa543"}],["path",{d:"M12 4v4",key:"1bq03y"}],["path",{d:"M10 4h4",key:"1xpv9s"}]]};f.node;const E=p(f);const y={name:"qr-code",size:24,node:[["rect",{width:"5",height:"5",x:"3",y:"3",rx:"1",key:"1tu5fj"}],["rect",{width:"5",height:"5",x:"16",y:"3",rx:"1",key:"1v8r4q"}],["rect",{width:"5",height:"5",x:"3",y:"16",rx:"1",key:"1x03jg"}],["path",{d:"M21 16h-3a2 2 0 0 0-2 2v3",key:"177gqh"}],["path",{d:"M21 21v.01",key:"ents32"}],["path",{d:"M12 7v3a2 2 0 0 1-2 2H7",key:"8crl2c"}],["path",{d:"M3 12h.01",key:"nlz23k"}],["path",{d:"M12 3h.01",key:"n36tog"}],["path",{d:"M12 16v.01",key:"133mhm"}],["path",{d:"M16 12h1",key:"1slzba"}],["path",{d:"M21 12v.01",key:"1lwtk9"}],["path",{d:"M12 21v-1",key:"1880an"}]]};y.node;const D=p(y),s="#730042",i="#14193a",r="#5f6677",T=[{icon:u,label:"Card"},{icon:x,label:"Wallet"},{icon:h,label:"Bank Transfer"},{icon:D,label:"UPI"}],W=[{icon:x,title:"Multi-Channel Payment Processing",body:"Support multiple payment methods based on business needs and available integrations."},{icon:w,title:"Automated Reconciliation",body:"Match payment transactions with financial records and identify discrepancies more efficiently."},{icon:c,title:"Payment Security and Fraud Monitoring",body:"Support secure payment operations through appropriate security controls and fraud-monitoring processes."},{icon:N,title:"Recurring Billing Management",body:"Organize subscription billing and scheduled payments for recurring services."},{icon:z,title:"Reporting and Analytics",body:"Review transaction activity and payment trends to support better business decisions."}],B=[{image:"/PaymentIndustry1.webp",icon:j,title:"E-Commerce",body:"Support convenient online transactions."},{image:"/PaymentIndustry2.webp",icon:S,title:"Retail",body:"Organize payment processing across sales channels."},{image:"/PaymentIndustry3.webp",icon:E,title:"Hospitality",body:"Manage payments related to bookings and customer services."},{image:"/PaymentIndustry4.webp",icon:v,title:"Healthcare",body:"Support payment records and related workflows."},{image:"/PaymentIndustry5.webp",icon:h,title:"Financial Services",body:"Organize transaction information and reporting."}],F=[{icon:$,title:"Efficient Workflows",body:"Simplify routine payment activities."},{icon:M,title:"Transaction Visibility",body:"Make payment records easier to monitor and review."},{icon:P,title:"Flexible Integration",body:"Connect compatible payment tools and business systems."},{icon:k,title:"Implementation and Training",body:"Support teams during adoption and setup."},{icon:C,title:"Ongoing Support",body:"Adapt payment workflows as business needs evolve."}];function V(){return e.jsxs("div",{className:"pm-page",children:[e.jsx("style",{children:`

        .pm-page {
          width: 100%;
          overflow: hidden;
          background: #ffffff;
          color: ${i};
          font-family: "Inter", Arial, sans-serif;
        }

        .pm-page *,
        .pm-page *::before,
        .pm-page *::after {
          box-sizing: border-box;
        }

        .pm-container {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;
          padding-left: 24px;
          padding-right: 24px;
        }

        /* ---------- shared ---------- */

        .pm-eyebrow {
          display: flex;
          align-items: center;
          gap: 10px;
          margin: 0 0 14px;
          color: ${s};
          font-size: 10.5px;
          line-height: 1.4;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
        }

        .pm-eyebrow::before {
          content: "";
          width: 28px;
          height: 2px;
          flex-shrink: 0;
          background: ${s};
        }

        .pm-h1,
        .pm-h2,
        .pm-card-title {
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
        }

        .pm-h2 {
          margin: 0 0 18px;
          color: ${i};
          font-size: 32px;
          line-height: 1.2;
          font-weight: 700;
          letter-spacing: -0.035em;
        }

        .pm-text {
          margin: 0;
          color: ${r};
          font-size: 15px;
          line-height: 1.7;
        }

        .pm-icon {
          width: 40px;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          border-radius: 10px;
          background: #fbeef1;
          color: ${s};
        }

        /* ---------- 1. hero ---------- */

        .pm-hero {
          background:
            radial-gradient(circle at 85% 0%, rgba(255, 228, 238, 0.7), transparent 45%),
            #ffffff;
        }

        .pm-hero-grid {
          display: grid;
          grid-template-columns: minmax(0, 1fr) minmax(0, 0.98fr);
          gap: 48px;
          align-items: center;
          padding-top: 72px;
          padding-bottom: 72px;
        }

        .pm-h1 {
          margin: 0 0 22px;
          color: ${i};
          font-size: 44px;
          line-height: 1.04;
          font-weight: 800;
          letter-spacing: -0.045em;
        }

        .pm-hero-text {
          max-width: 540px;
          margin: 0 0 30px;
          color: ${r};
          font-size: 16px;
          line-height: 1.7;
        }

        .pm-btn {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          min-height: 46px;
          padding: 0 26px;
          border-radius: 999px;
          background: ${s};
          color: #ffffff;
          font-size: 13px;
          font-weight: 600;
          text-decoration: none;
          box-shadow: 0 8px 20px rgba(115, 0, 66, 0.25);
          transition: transform 0.25s ease, box-shadow 0.25s ease;
        }

        .pm-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 12px 26px rgba(115, 0, 66, 0.32);
        }

        .pm-hero-frame {
          position: relative;
          padding: 22px;
          border-radius: 26px;
          background: #fbf3f6;
          box-shadow: 0 18px 44px rgba(115, 0, 66, 0.1);
        }

        .pm-hero-photo {
          display: block;
          width: 100%;
          aspect-ratio: 1.7 / 1;
          object-fit: cover;
          border-radius: 14px;
          background: #1c2433;
        }

        .pm-float {
          position: absolute;
          background: #ffffff;
          border-radius: 12px;
          box-shadow: 0 14px 34px rgba(20, 25, 58, 0.16);
        }

        .pm-badges {
          top: 24px;
          right: 24px;
          display: flex;
          flex-direction: column;
          gap: 12px;
          padding: 14px 18px 14px 14px;
        }

        .pm-badge-row {
          display: flex;
          align-items: center;
          gap: 10px;
          color: ${i};
          font-size: 12px;
          font-weight: 500;
          line-height: 1;
        }

        .pm-badge-row svg {
          color: ${s};
        }

        .pm-paid {
          right: 4px;
          bottom: -26px;
          width: 170px;
          padding: 14px;
          text-align: center;
        }

        .pm-paid-inner {
          padding: 12px 10px;
          border-radius: 10px;
          background: #f8f9fb;
        }

        .pm-paid-icon {
          width: 28px;
          height: 28px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 8px;
          border-radius: 50%;
          background: #dff5e8;
          color: #1d8a52;
        }

        .pm-paid strong {
          display: block;
          color: ${i};
          font-size: 11.5px;
          line-height: 1.4;
          font-weight: 700;
        }

        .pm-paid small {
          display: block;
          color: #9aa1b2;
          font-size: 9.5px;
          line-height: 1.4;
        }

        /* ---------- 2. smarter payments ---------- */

        .pm-smart {
          background: #f8f6f1;
        }

        .pm-smart-grid {
          display: grid;
          grid-template-columns: minmax(0, 0.95fr) minmax(0, 1fr);
          gap: 64px;
          align-items: center;
          padding-top: 80px;
          padding-bottom: 88px;
        }

        .pm-smart-media {
          position: relative;
        }

        .pm-smart-photo {
          display: block;
          width: 100%;
          aspect-ratio: 1.5 / 1;
          object-fit: cover;
          border-radius: 18px;
          box-shadow: 0 18px 42px rgba(20, 25, 58, 0.16);
          background: #e9ecf3;
        }

        .pm-methods {
          top: 22px;
          right: 22px;
          display: flex;
          flex-direction: column;
          gap: 11px;
          padding: 16px 40px 16px 18px;
        }

        .pm-method {
          display: flex;
          align-items: center;
          gap: 12px;
          color: ${i};
          font-size: 11.5px;
          line-height: 1;
        }

        .pm-method svg {
          color: ${s};
        }

        .pm-pill {
          left: 50%;
          bottom: 22px;
          transform: translateX(-6%);
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 8px 18px 8px 10px;
          border-radius: 999px;
          color: ${i};
          font-size: 11.5px;
          font-weight: 500;
          white-space: nowrap;
        }

        .pm-pill-check {
          width: 22px;
          height: 22px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          background: #1d8a52;
          color: #ffffff;
        }

        .pm-smart .pm-h2 {
          max-width: 520px;
          font-size: 36px;
        }

        .pm-smart .pm-eyebrow {
          margin-bottom: 22px;
        }

        .pm-smart .pm-eyebrow::before {
          width: 28px;
        }

        .pm-smart .pm-text {
          font-size: 16px;
          line-height: 1.75;
        }

        /* ---------- 3. key features ---------- */

        .pm-features {
          background: ${s};
        }

        .pm-features-wrap {
          padding-top: 76px;
          padding-bottom: 84px;
        }

        .pm-features .pm-eyebrow {
          color: #f4d6e3;
        }

        .pm-features .pm-eyebrow::before {
          background: #f4d6e3;
        }

        .pm-features .pm-h2 {
          color: #ffffff;
          margin-bottom: 40px;
        }

        .pm-feature-grid {
          display: grid;
          grid-template-columns: repeat(5, minmax(0, 1fr));
          gap: 20px;
        }

        .pm-feature {
          min-width: 0;
          padding: 24px 20px 26px;
          border-radius: 14px;
          background: #ffffff;
          transition: transform 0.28s ease, box-shadow 0.28s ease;
        }

        .pm-feature:hover {
          transform: translateY(-5px);
          box-shadow: 0 18px 36px rgba(0, 0, 0, 0.22);
        }

        .pm-feature .pm-icon {
          width: 42px;
          height: 42px;
        }

        .pm-num {
          display: block;
          margin: 16px 0 10px;
          color: #9aa1b2;
          font-size: 10.5px;
          font-weight: 500;
        }

        .pm-card-title {
          margin: 0 0 10px;
          color: ${i};
          font-size: 14.5px;
          line-height: 1.35;
          font-weight: 700;
          letter-spacing: -0.01em;
        }

        .pm-card-text {
          margin: 0;
          color: ${r};
          font-size: 13.5px;
          line-height: 1.65;
        }

        /* ---------- 4. industries ---------- */

        .pm-industries-grid {
          display: grid;
          grid-template-columns: minmax(0, 0.85fr) minmax(0, 2fr);
          gap: 28px;
          align-items: start;
          padding-top: 72px;
          padding-bottom: 80px;
        }

        .pm-industries-copy .pm-h2 {
          margin-top: 6px;
          font-size: 30px;
        }

        .pm-industries-copy .pm-text {
          font-size: 15px;
          margin-bottom: 26px;
        }

        .pm-link {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          color: ${s};
          font-size: 12.5px;
          font-weight: 700;
          text-decoration: none;
        }

        .pm-link:hover {
          text-decoration: underline;
        }

        .pm-industry-grid {
          display: grid;
          grid-template-columns: repeat(5, minmax(0, 1fr));
          gap: 16px;
        }

        .pm-industry {
          min-width: 0;
          overflow: hidden;
          border: 1px solid #ece9e4;
          border-radius: 12px;
          background: #ffffff;
          box-shadow: 0 1px 4px rgba(20, 25, 58, 0.05);
          transition: transform 0.28s ease, box-shadow 0.28s ease;
        }

        .pm-industry:hover {
          transform: translateY(-5px);
          box-shadow: 0 14px 30px rgba(20, 25, 58, 0.12);
        }

        .pm-industry img {
          display: block;
          width: 100%;
          height: 102px;
          object-fit: cover;
          background: #e9ecf3;
        }

        .pm-industry-body {
          padding: 16px 14px 18px;
        }

        .pm-industry .pm-icon {
          width: 26px;
          height: 26px;
          border-radius: 7px;
          margin-bottom: 8px;
        }

        .pm-industry h3 {
          margin: 0 0 8px;
          color: ${i};
          font-family: "Inter", Arial, sans-serif;
          font-size: 12px;
          line-height: 1.3;
          font-weight: 700;
        }

        .pm-industry p {
          margin: 0;
          color: ${r};
          font-size: 12.5px;
          line-height: 1.6;
        }

        /* ---------- 5. why choose ---------- */

        .pm-why {
          background: #f8f6f1;
        }

        .pm-why-wrap {
          padding-top: 72px;
          padding-bottom: 80px;
        }

        .pm-why .pm-h2 {
          margin-bottom: 40px;
        }

        .pm-why-grid {
          display: grid;
          grid-template-columns: repeat(5, minmax(0, 1fr));
          gap: 28px;
        }

        .pm-why-item {
          min-width: 0;
        }

        .pm-why-item .pm-icon {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          margin-bottom: 16px;
        }

        .pm-why-item h3 {
          margin: 0 0 8px;
          color: ${i};
          font-family: "Inter", Arial, sans-serif;
          font-size: 12.5px;
          line-height: 1.35;
          font-weight: 700;
        }

        .pm-why-item p {
          margin: 0;
          color: ${r};
          font-size: 14.5px;
          line-height: 1.6;
        }

        /* ---------- 6. powered by ---------- */

        .pm-powered {
          background: #ffffff;
        }

        .pm-powered-wrap {
          padding-top: 44px;
          padding-bottom: 52px;
        }

        .pm-powered .pm-eyebrow {
          color: #6a7388;
          margin-bottom: 34px;
        }

        .pm-powered .pm-eyebrow::before {
          background: ${s};
        }

        .pm-logos {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 24px;
        }

        .pm-logo {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          color: ${i};
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-weight: 800;
          white-space: nowrap;
        }

        .pm-logo-aws {
          font-size: 24px;
          letter-spacing: -0.04em;
        }

        .pm-logo-google {
          font-size: 22px;
          font-weight: 700;
          letter-spacing: 0.12em;
        }

        .pm-logo-cloud {
          font-size: 13px;
          letter-spacing: 0.04em;
        }

        .pm-logo-cloud svg {
          color: #1b8bf0;
          fill: #1b8bf0;
        }

        .pm-logo-nc {
          color: #6d28d9;
          font-size: 26px;
          font-style: italic;
          letter-spacing: -0.04em;
        }

        .pm-logo-dell {
          width: 38px;
          height: 38px;
          justify-content: center;
          border: 2px solid #1b6fd6;
          border-radius: 50%;
          color: #1b6fd6;
          font-size: 9px;
          letter-spacing: 0;
        }

        /* ---------- responsive ---------- */

        @media (max-width: 1200px) {
          .pm-feature-grid,
          .pm-industry-grid,
          .pm-why-grid {
            grid-template-columns: repeat(3, minmax(0, 1fr));
          }

          .pm-industries-grid {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 900px) {
          .pm-container {
            padding-left: 32px;
            padding-right: 32px;
          }

          .pm-hero-grid,
          .pm-smart-grid {
            grid-template-columns: 1fr;
            gap: 40px;
            padding-top: 52px;
            padding-bottom: 60px;
          }

          .pm-h1 {
            font-size: 38px;
          }

          .pm-hero-frame {
            max-width: 620px;
          }

          .pm-logos {
            flex-wrap: wrap;
            justify-content: center;
            gap: 28px 44px;
          }
        }

        @media (max-width: 640px) {
          .pm-container {
            padding-left: 20px;
            padding-right: 20px;
          }

          .pm-h1 {
            font-size: 32px;
          }

          .pm-h2,
          .pm-smart .pm-h2 {
            font-size: 26px;
          }

          .pm-feature-grid,
          .pm-industry-grid,
          .pm-why-grid {
            grid-template-columns: 1fr;
          }

          .pm-hero-frame {
            padding: 14px;
          }

          .pm-badges {
            top: 16px;
            right: 16px;
          }

          .pm-paid {
            right: 10px;
          }

          .pm-pill {
            left: 16px;
            transform: none;
          }

          .pm-btn {
            width: 100%;
            justify-content: center;
          }
        }

        @media (prefers-reduced-motion: reduce) {
          .pm-feature,
          .pm-industry,
          .pm-btn {
            transition: none;
          }

          .pm-feature:hover,
          .pm-industry:hover,
          .pm-btn:hover {
            transform: none;
          }
        }
      `}),e.jsx("section",{className:"pm-hero",children:e.jsxs("div",{className:"pm-container pm-hero-grid",children:[e.jsxs("div",{children:[e.jsx("p",{className:"pm-eyebrow",children:"Payment Management"}),e.jsxs("h1",{className:"pm-h1",children:["Simplify Payments.",e.jsx("br",{}),"Improve Business Efficiency."]}),e.jsx("p",{className:"pm-hero-text",children:"TechTorch Solutions helps businesses organize payment operations, manage transactions, and improve financial visibility. Our payment management solutions support payment processing, reconciliation, recurring billing, and reporting to help streamline everyday financial activities."}),e.jsxs(m,{to:"/talk-to-expert",className:"pm-btn",children:["Talk to Our Experts",e.jsx(d,{size:15})]})]}),e.jsxs("div",{className:"pm-hero-frame",children:[e.jsx("img",{loading:"lazy",decoding:"async",className:"pm-hero-photo",src:"/PaymentManagement1.webp",alt:"Payment performance dashboard on a monitor"}),e.jsxs("div",{className:"pm-float pm-badges",children:[e.jsxs("div",{className:"pm-badge-row",children:[e.jsx(c,{size:14}),"Secure"]}),e.jsxs("div",{className:"pm-badge-row",children:[e.jsx(b,{size:14}),"Fast"]}),e.jsxs("div",{className:"pm-badge-row",children:[e.jsx(A,{size:14}),"Reliable"]})]}),e.jsx("div",{className:"pm-float pm-paid",children:e.jsxs("div",{className:"pm-paid-inner",children:[e.jsx("span",{className:"pm-paid-icon",children:e.jsx(l,{size:15,strokeWidth:2.4})}),e.jsx("strong",{children:"Payment Successful"}),e.jsx("small",{children:"$1,280.00 Processed"})]})})]})]})}),e.jsx("section",{className:"pm-smart",children:e.jsxs("div",{className:"pm-container pm-smart-grid",children:[e.jsxs("div",{className:"pm-smart-media",children:[e.jsx("img",{loading:"lazy",decoding:"async",className:"pm-smart-photo",src:"/PaymentManagement2.webp",alt:"Finance professional reviewing payment data on dual monitors"}),e.jsx("div",{className:"pm-float pm-methods",children:T.map(({icon:t,label:a})=>e.jsxs("div",{className:"pm-method",children:[e.jsx(t,{size:15}),a]},a))}),e.jsxs("div",{className:"pm-float pm-pill",children:[e.jsx("span",{className:"pm-pill-check",children:e.jsx(l,{size:13,strokeWidth:2.6})}),"Transaction Successful"]})]}),e.jsxs("div",{children:[e.jsx("p",{className:"pm-eyebrow",style:{marginBottom:22}}),e.jsx("h2",{className:"pm-h2",children:"Smarter Payment Management for Modern Businesses"}),e.jsx("p",{className:"pm-text",children:"Efficient payment operations help businesses maintain accurate records, monitor transactions, and deliver a smoother payment experience. TechTorch Solutions supports these needs with capabilities designed to simplify payment workflows, improve transaction visibility, and reduce manual effort."})]})]})}),e.jsx("section",{className:"pm-features",children:e.jsxs("div",{className:"pm-container pm-features-wrap",children:[e.jsx("p",{className:"pm-eyebrow",children:"Key Features"}),e.jsx("h2",{className:"pm-h2",children:"Key Features of Payment Management"}),e.jsx("div",{className:"pm-feature-grid",children:W.map(({icon:t,title:a,body:n},o)=>e.jsxs("div",{className:"pm-feature",children:[e.jsx("span",{className:"pm-icon",children:e.jsx(t,{size:19,strokeWidth:1.8})}),e.jsx("span",{className:"pm-num",children:String(o+1).padStart(2,"0")}),e.jsx("h3",{className:"pm-card-title",children:a}),e.jsx("p",{className:"pm-card-text",children:n})]},a))})]})}),e.jsx("section",{className:"pm-industries",children:e.jsxs("div",{className:"pm-container pm-industries-grid",children:[e.jsxs("div",{className:"pm-industries-copy",children:[e.jsx("p",{className:"pm-eyebrow",children:"Industries We Serve"}),e.jsx("h2",{className:"pm-h2",children:"Payment Solutions for Different Industries"}),e.jsx("p",{className:"pm-text",children:"Our solutions can support payment-related workflows across a range of business sectors."}),e.jsxs(m,{to:"/digitalsolution",className:"pm-link",children:["Explore All Industries",e.jsx(d,{size:14})]})]}),e.jsx("div",{className:"pm-industry-grid",children:B.map(({image:t,icon:a,title:n,body:o})=>e.jsxs("div",{className:"pm-industry",children:[e.jsx("img",{src:t,alt:n,loading:"lazy"}),e.jsxs("div",{className:"pm-industry-body",children:[e.jsx("span",{className:"pm-icon",children:e.jsx(a,{size:13,strokeWidth:1.9})}),e.jsx("h3",{children:n}),e.jsx("p",{children:o})]})]},n))})]})}),e.jsx("section",{className:"pm-why",children:e.jsxs("div",{className:"pm-container pm-why-wrap",children:[e.jsx("p",{className:"pm-eyebrow",children:"Why Choose TechTorch Solutions?"}),e.jsx("h2",{className:"pm-h2",children:"Built for Smarter Payment Operations"}),e.jsx("div",{className:"pm-why-grid",children:F.map(({icon:t,title:a,body:n})=>e.jsxs("div",{className:"pm-why-item",children:[e.jsx("span",{className:"pm-icon",children:e.jsx(t,{size:15,strokeWidth:1.9})}),e.jsx("h3",{children:a}),e.jsx("p",{children:n})]},a))})]})}),e.jsx("section",{className:"pm-powered",children:e.jsxs("div",{className:"pm-container pm-powered-wrap",children:[e.jsx("p",{className:"pm-eyebrow",children:"Delivering Solutions Powered By"}),e.jsxs("div",{className:"pm-logos",children:[e.jsx("span",{className:"pm-logo pm-logo-aws",children:"aws"}),e.jsxs("span",{className:"pm-logo pm-logo-google","aria-label":"Google",children:[e.jsx("span",{style:{color:"#4285F4"},children:"G"}),e.jsx("span",{style:{color:"#EA4335"},children:"o"}),e.jsx("span",{style:{color:"#FBBC05"},children:"o"}),e.jsx("span",{style:{color:"#4285F4"},children:"g"}),e.jsx("span",{style:{color:"#34A853"},children:"l"}),e.jsx("span",{style:{color:"#EA4335"},children:"e"})]}),e.jsxs("span",{className:"pm-logo pm-logo-cloud",children:[e.jsx(I,{size:26}),"CLOUD"]}),e.jsx("span",{className:"pm-logo pm-logo-nc",children:"nc"}),e.jsx("span",{className:"pm-logo pm-logo-dell","aria-label":"Dell",children:"DELL"})]})]})})]})}export{V as default};
