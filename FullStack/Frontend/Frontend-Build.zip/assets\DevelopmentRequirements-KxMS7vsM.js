import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as p}from"./vendor-router-L4ZCoGSs.js";import{F as D,s as I,a as E}from"./FormNotice-DRy7EQ_d.js";import{A as P}from"./index-BThRNyH6.js";const r="#8B0046",A=["Custom Software Development","Web Application Development","Mobile Application Development","Enterprise Software","API & System Integration","Software Modernization","Software Maintenance & Support","Not Sure Yet"],O=[{title:"Dedicated Development Team",description:"Professionals focused on your ongoing development requirements."},{title:"Extended Development Team",description:"Additional technical professionals working alongside your existing team."},{title:"Project-Based Development",description:"A development team structured around a defined project requirement."},{title:"Specialized Technical Support",description:"Additional expertise for a specific technology or development need."},{title:"Guidance & Consultation",description:"Discuss your requirement with our technology team."}],R=["Frontend Development","Backend Development","Full-Stack Development","Mobile Development","API & Integration","Cloud & DevOps","Software Architecture","Quality Assurance & Testing","Software Maintenance & Support","Other"],q=["Idea / Planning","Requirements & Design","Development","Existing Application","Modernization","Maintenance & Support","Not Sure Yet"],$=["1–2 Professionals","3–5 Professionals","6–10 Professionals","10+ Professionals","Not Sure"];function W(){const[n,a]=p.useState(""),[i,l]=p.useState(""),[u,m]=p.useState([]),[h,f]=p.useState(""),[g,b]=p.useState(""),[s,y]=p.useState({project:"",name:"",email:"",company:"",phone:""}),d=t=>{y(o=>({...o,[t.target.name]:t.target.value}))},S=t=>{m(o=>o.includes(t)?o.filter(T=>T!==t):[...o,t])},[v,j]=p.useState(!1),[k,w]=p.useState(""),[z,N]=p.useState(!1),C=async t=>{if(t.preventDefault(),!v){w(""),N(!1),j(!0);try{await I("inquiry",{formType:"offshore-requirements",fullName:s.name.trim(),email:s.email.trim(),company:s.company.trim(),phone:s.phone.trim(),topic:n||i,message:s.project.trim(),details:{developmentSupportFor:n,supportType:i,capabilities:u,projectStage:h,supportLevel:g}}),N(!0),y({project:"",name:"",email:"",company:"",phone:""}),a(""),l(""),m([]),f(""),b("")}catch(o){w(E(o))}finally{j(!1)}}};return e.jsxs("main",{className:"development-consultation",children:[e.jsx("section",{className:"consultation-hero-section",children:e.jsxs("div",{className:"consultation-hero-container",children:[e.jsxs("div",{className:"consultation-hero-content",children:[e.jsxs("div",{className:"consultation-badge",children:[e.jsx("span",{className:"consultation-badge-dot"}),e.jsx("span",{children:"DEVELOPMENT CONSULTATION"})]}),e.jsxs("h1",{className:"consultation-hero-heading",children:["Discuss Your Development",e.jsx("br",{className:"desktop-break"}),"Requirements"]}),e.jsx("p",{className:"consultation-hero-description",children:"Tell us about your project, development goals, and the technical capabilities you are looking for. Share a few details so our team can better understand your requirements and discuss a suitable development approach with you."})]}),e.jsx("div",{className:"consultation-hero-image-wrapper",children:e.jsxs("div",{className:"consultation-hero-image",children:[e.jsx("img",{loading:"lazy",decoding:"async",src:"/DevelopmentTeam.webp",alt:"Development Consultation"}),e.jsx("div",{className:"consultation-image-overlay",children:e.jsx("div",{className:"consultation-image-overlay-box",children:e.jsxs("p",{children:["TechTorch Solutions Architecture — Technical",e.jsx("br",{className:"desktop-break"}),"Consultation & Requirement Discovery"]})})})]})})]})}),e.jsx("section",{id:"development-form",className:"development-form-section",children:e.jsx("div",{className:"development-form-container",children:e.jsxs("form",{onSubmit:C,children:[e.jsxs("div",{className:"main-form-card",children:[e.jsx(c,{number:"01",title:"What do you need development support for?",subtitle:"Select the area closest to your requirement.",children:e.jsx("div",{className:"support-options-grid",children:A.map(t=>e.jsx(M,{text:t,selected:n===t,onClick:()=>a(t)},t))})}),e.jsx(c,{number:"02",title:"What type of support are you looking for?",subtitle:"Choose the engagement structure best suited for your plans.",children:e.jsx("div",{className:"support-types-grid",children:O.map(t=>e.jsx(F,{...t,selected:i===t.title,onClick:()=>l(t.title)},t.title))})}),e.jsx(c,{number:"03",title:"Which technical capabilities are relevant?",subtitle:"Select one or more",children:e.jsx("div",{className:"capabilities-list",children:R.map(t=>{const o=u.includes(t);return e.jsx("button",{type:"button",onClick:()=>S(t),className:`capability-button ${o?"selected":""}`,children:t},t)})})}),e.jsxs(c,{number:"04",title:"Tell Us About Your Project",subtitle:"Project Details",children:[e.jsx("p",{className:"project-help-text",children:"Describe your project, current application, technology environment, or the type of development assistance you require."}),e.jsx("textarea",{name:"project",value:s.project,onChange:d,rows:5,placeholder:"Briefly describe your project and the development support you are looking for...",className:"project-textarea"})]}),e.jsx(c,{number:"05",title:"What stage is your project in?",subtitle:"Select the current state of progress.",children:e.jsx("div",{className:"stage-options",children:q.map(t=>{const o=h===t;return e.jsx("button",{type:"button",onClick:()=>f(t),className:`stage-button ${o?"selected":""}`,children:t},t)})})}),e.jsx(c,{number:"06",title:"What level of support are you considering?",subtitle:"Estimate team capacity or scale.",children:e.jsx("div",{className:"support-level-options",children:$.map(t=>{const o=g===t;return e.jsx("button",{type:"button",onClick:()=>b(t),className:`support-level-button ${o?"selected":""}`,children:t},t)})})})]}),e.jsxs("div",{className:"contact-card",children:[e.jsx("span",{className:"contact-label",children:"YOUR CONTACT DETAILS"}),e.jsx("h2",{className:"contact-heading",children:"Let’s Continue the Conversation"}),e.jsx("p",{className:"contact-description",children:"Share your contact information so our team can review your requirements and get in touch regarding your development enquiry."}),e.jsxs("div",{className:"contact-input-grid",children:[e.jsx(x,{label:"Full Name *",name:"name",placeholder:"Enter your full name",value:s.name,onChange:d}),e.jsx(x,{label:"Business Email *",name:"email",type:"email",placeholder:"Enter your business email",value:s.email,onChange:d}),e.jsx(x,{label:"Company Name",name:"company",placeholder:"Enter your company name",value:s.company,onChange:d}),e.jsx(x,{label:"Phone Number",name:"phone",type:"tel",placeholder:"Enter your phone number",value:s.phone,onChange:d})]}),e.jsxs("div",{className:"submit-area",children:[e.jsx(D,{error:k,success:z}),e.jsxs("button",{type:"submit",disabled:v,className:"submit-button",children:[e.jsx("span",{children:"Submit Development Enquiry"}),e.jsx(P,{className:"submit-arrow",strokeWidth:2})]}),e.jsx("p",{className:"privacy-note",children:"The information you provide will be used to understand your enquiry and communicate with you regarding your requirements."})]})]})]})})}),e.jsx("style",{children:`

        /* =====================================================
           BASE
        ====================================================== */

        .development-consultation {
          width: 100%;
          min-height: 100vh;

          background: #f8f9fa;

          color: #15151a;

          font-family: "Inter", sans-serif;

          box-sizing: border-box;
        }

        .development-consultation *,
        .development-consultation *::before,
        .development-consultation *::after {
          box-sizing: border-box;
        }

        /* =====================================================
           HERO
        ====================================================== */

        .consultation-hero-section {
          width: 100%;

          padding: 50px 100px;
        }

        .consultation-hero-container {
          width: 100%;
          max-width: 1600px;

          margin: 0 auto;

          display: grid;

          grid-template-columns:
            minmax(0, 1.15fr)
            minmax(0, 0.85fr);

          min-height: 420px;

          overflow: hidden;

          border: 1px solid #e3e7eb;

          border-radius: 18px;

          background: #ffffff;
        }

        /* =====================================================
           HERO CONTENT
        ====================================================== */

        .consultation-hero-content {
          display: flex;
          flex-direction: column;
          justify-content: center;

          padding: 52px;
        }

        .consultation-badge {
          width: fit-content;

          display: inline-flex;
          align-items: center;

          gap: 8px;

          padding: 7px 14px;

          margin-bottom: 20px;

          border-radius: 999px;

          background: #f5f5f6;

          font-family: "Inter", sans-serif;

          font-size: 10px;
          font-weight: 700;

          line-height: 1.4;

          letter-spacing: 0.05em;

          color: #343434;
        }

        .consultation-badge-dot {
          width: 7px;
          height: 7px;

          flex-shrink: 0;

          border-radius: 50%;

          background: ${r};
        }

        .consultation-hero-heading {
          max-width: 700px;

          margin: 0;

          font-family: "Plus Jakarta Sans", sans-serif;

          font-size: 44px;

          font-weight: 600;

          line-height: 1.1;

          letter-spacing: -0.04em;

          color: #15151a;
        }

        .consultation-hero-description {
          max-width: 650px;

          margin: 22px 0 0;

          font-family: "Inter", sans-serif;

          font-size: 14px;

          font-weight: 400;

          line-height: 1.75;

          color: #6b6268;
        }

        /* =====================================================
           HERO IMAGE
        ====================================================== */

        .consultation-hero-image-wrapper {
          min-height: 420px;

          padding: 8px;
        }

        .consultation-hero-image {
          position: relative;

          width: 100%;
          height: 100%;

          min-height: 404px;

          overflow: hidden;

          border-radius: 12px;
        }

        .consultation-hero-image img {
          position: absolute;

          inset: 0;

          width: 100%;
          height: 100%;

          object-fit: cover;

          object-position: center;
        }

        .consultation-image-overlay {
          position: absolute;

          left: 0;
          right: 0;
          bottom: 0;

          padding: 16px;
        }

        .consultation-image-overlay-box {
          width: 100%;

          padding: 13px 16px;

          border: 1px solid rgba(255, 255, 255, 0.15);

          border-radius: 10px;

          background: rgba(0, 0, 0, 0.65);

          backdrop-filter: blur(4px);
        }

        .consultation-image-overlay-box p {
          margin: 0;

          font-family: "Inter", sans-serif;

          font-size: 11px;

          font-weight: 500;

          line-height: 1.45;

          color: #ffffff;
        }

        /* =====================================================
           FORM SECTION
        ====================================================== */

        .development-form-section {
          width: 100%;

          padding: 0 100px 60px;
        }

        .development-form-container {
          width: 100%;
          max-width: 1600px;

          margin: 0 auto;
        }

        /* =====================================================
           FORM CARD
        ====================================================== */

        .main-form-card,
        .contact-card {
          width: 100%;

          border: 1px solid #e3e7eb;

          border-radius: 16px;

          background: #ffffff;

          box-shadow:
            0 2px 8px rgba(20, 30, 45, 0.025);
        }

        .main-form-card {
          padding: 48px;
        }

        /* =====================================================
           FORM SECTION
        ====================================================== */

        .form-section {
          padding-bottom: 34px;

          margin-bottom: 34px;

          border-bottom: 1px solid #edf0f3;
        }

        .form-section:last-child {
          padding-bottom: 0;
          margin-bottom: 0;

          border-bottom: none;
        }

        .form-section-header {
          display: flex;
          align-items: flex-start;

          gap: 12px;

          margin-bottom: 18px;
        }

        .form-section-number {
          width: 24px;
          height: 24px;

          display: flex;
          align-items: center;
          justify-content: center;

          flex-shrink: 0;

          border-radius: 50%;

          background: ${r};

          color: #ffffff;

          font-family: "Plus Jakarta Sans", sans-serif;

          font-size: 9px;

          font-weight: 700;
        }

        .form-section-title {
          margin: 0;

          font-family: "Plus Jakarta Sans", sans-serif;

          font-size: 15px;

          font-weight: 700;

          line-height: 1.35;

          color: #20242a;
        }

        .form-section-subtitle {
          margin: 3px 0 0;

          font-family: "Inter", sans-serif;

          font-size: 10px;

          line-height: 1.5;

          color: #776d72;
        }

        /* =====================================================
           SUPPORT OPTIONS
        ====================================================== */

        .support-options-grid {
          display: grid;

          grid-template-columns:
            repeat(4, minmax(0, 1fr));

          gap: 12px;
        }

        .choice-button {
          position: relative;

          width: 100%;
          min-height: 58px;

          display: flex;
          align-items: center;
          justify-content: space-between;

          gap: 12px;

          padding: 11px 13px;

          border: 1px solid #e2e7ec;

          border-radius: 9px;

          background: #ffffff;

          text-align: left;

          cursor: pointer;

          font-family: "Inter", sans-serif;

          font-size: 11px;

          font-weight: 500;

          line-height: 1.4;

          color: #363b42;

          transition:
            border-color 0.2s ease,
            background 0.2s ease;
        }

        .choice-button:hover {
          border-color: #d4b1c1;

          background: #fffafb;
        }

        .choice-button.selected {
          border-color: #d3a3b9;

          background: #fff9fb;
        }

        .choice-button-text {
          max-width: calc(100% - 28px);
        }

        .choice-radio {
          width: 15px;
          height: 15px;

          display: flex;
          align-items: center;
          justify-content: center;

          flex-shrink: 0;

          border: 1px solid #e2b8ca;

          border-radius: 50%;
        }

        .choice-button.selected .choice-radio {
          border-color: ${r};
        }

        .choice-radio-inner {
          width: 6px;
          height: 6px;

          border-radius: 50%;

          background: ${r};
        }

        /* =====================================================
           SUPPORT TYPE
        ====================================================== */

        .support-types-grid {
          display: grid;

          grid-template-columns:
            repeat(3, minmax(0, 1fr));

          gap: 12px;
        }

        .support-type-card {
          position: relative;

          width: 100%;

          min-height: 125px;

          padding: 17px;

          border: 1px solid #e2e7ec;

          border-radius: 10px;

          background: #ffffff;

          text-align: left;

          cursor: pointer;

          transition:
            border-color 0.2s ease,
            background 0.2s ease;
        }

        .support-type-card:hover {
          border-color: #d4b1c1;
        }

        .support-type-card.selected {
          border-color: #d3a3b9;

          background: #fff9fb;
        }

        .support-type-radio {
          position: absolute;

          top: 13px;
          right: 13px;

          width: 15px;
          height: 15px;

          display: flex;
          align-items: center;
          justify-content: center;

          border: 1px solid #e2b8ca;

          border-radius: 50%;
        }

        .support-type-card.selected .support-type-radio {
          border-color: ${r};
        }

        .support-type-radio-inner {
          width: 6px;
          height: 6px;

          border-radius: 50%;

          background: ${r};
        }

        .support-type-title {
          max-width: 92%;

          padding-right: 20px;

          margin: 0;

          font-family: "Plus Jakarta Sans", sans-serif;

          font-size: 13px;

          font-weight: 700;

          line-height: 1.4;

          color: #30343a;
        }

        .support-type-description {
          max-width: 330px;

          margin: 10px 0 0;

          font-family: "Inter", sans-serif;

          font-size: 11px;

          font-weight: 400;

          line-height: 1.55;

          color: #766d72;
        }

        /* =====================================================
           CAPABILITIES
        ====================================================== */

        .capabilities-list,
        .stage-options,
        .support-level-options {
          display: flex;
          flex-wrap: wrap;

          gap: 8px;
        }

        .capability-button,
        .stage-button,
        .support-level-button {
          min-height: 36px;

          padding: 8px 13px;

          border: 1px solid #e2e7ec;

          border-radius: 7px;

          background: #ffffff;

          color: #3c424a;

          cursor: pointer;

          font-family: "Inter", sans-serif;

          font-size: 11px;

          font-weight: 500;

          line-height: 1.3;

          transition:
            border-color 0.2s ease,
            background 0.2s ease,
            color 0.2s ease;
        }

        .capability-button:hover,
        .stage-button:hover,
        .support-level-button:hover {
          border-color: #cfa6ba;

          background: #fff9fb;
        }

        .capability-button.selected {
          border-color: ${r};

          background: ${r};

          color: #ffffff;
        }

        .stage-button.selected,
        .support-level-button.selected {
          border-color: ${r};

          background: #fff7fa;

          color: ${r};
        }

        /* =====================================================
           PROJECT DETAILS
        ====================================================== */

        .project-help-text {
          margin: 0 0 10px;

          max-width: 850px;

          font-family: "Inter", sans-serif;

          font-size: 11px;

          line-height: 1.6;

          color: #71686d;
        }

        .project-textarea {
          width: 100%;

          min-height: 130px;

          resize: vertical;

          padding: 13px;

          border: 1px solid #e1e6eb;

          border-radius: 9px;

          background: #fafbfc;

          outline: none;

          font-family: "Inter", sans-serif;

          font-size: 12px;

          line-height: 1.6;

          color: #333840;
        }

        .project-textarea::placeholder {
          color: #aeb5be;
        }

        .project-textarea:focus {
          border-color: #c58ba7;

          background: #ffffff;
        }

        /* =====================================================
           CONTACT CARD
        ====================================================== */

        .contact-card {
          margin-top: 22px;

          padding: 42px 48px;
        }

        .contact-label {
          display: block;

          font-family: "Inter", sans-serif;

          font-size: 10px;

          font-weight: 700;

          line-height: 1.4;

          letter-spacing: 0.08em;

          color: ${r};
        }

        .contact-heading {
          margin: 7px 0 0;

          font-family: "Plus Jakarta Sans", sans-serif;

          font-size: 28px;

          font-weight: 600;

          line-height: 1.2;

          letter-spacing: -0.035em;

          color: #15151a;
        }

        .contact-description {
          max-width: 850px;

          margin: 7px 0 0;

          font-family: "Inter", sans-serif;

          font-size: 12px;

          line-height: 1.65;

          color: #6d6469;
        }

        /* =====================================================
           INPUT GRID
        ====================================================== */

        .contact-input-grid {
          display: grid;

          grid-template-columns:
            repeat(2, minmax(0, 1fr));

          gap: 18px 22px;

          margin-top: 26px;
        }

        .input-field {
          display: block;

          width: 100%;
        }

        .input-label {
          display: block;

          margin-bottom: 7px;

          font-family: "Plus Jakarta Sans", sans-serif;

          font-size: 12px;

          font-weight: 700;

          line-height: 1.4;

          color: #34383e;
        }

        .input-control {
          width: 100%;

          height: 44px;

          padding: 0 13px;

          border: 1px solid #e1e6eb;

          border-radius: 8px;

          background: #fafbfc;

          outline: none;

          font-family: "Inter", sans-serif;

          font-size: 12px;

          font-weight: 400;

          color: #303641;

          transition:
            border-color 0.2s ease,
            background 0.2s ease;
        }

        .input-control::placeholder {
          color: #aeb5be;
        }

        .input-control:focus {
          border-color: #c58ba7;

          background: #ffffff;
        }

        /* =====================================================
           SUBMIT
        ====================================================== */

        .submit-area {
          margin-top: 28px;
        }

        .submit-button {
          min-height: 44px;

          display: inline-flex;
          align-items: center;
          justify-content: center;

          gap: 9px;

          padding: 11px 22px;

          border: none;

          border-radius: 7px;

          background: #780042;

          color: #ffffff;

          cursor: pointer;

          font-family: "Plus Jakarta Sans", sans-serif;

          font-size: 11px;

          font-weight: 700;

          line-height: 1.3;

          transition:
            background 0.3s ease,
            transform 0.3s ease;
        }

        .submit-button:hover {
          background: #8b0046;

          transform: translateY(-2px);
        }

        .submit-arrow {
          width: 16px;
          height: 16px;
        }

        .privacy-note {
          margin: 8px 0 0;

          font-family: "Inter", sans-serif;

          font-size: 10px;

          line-height: 1.5;

          color: #766d72;
        }

        /* =====================================================
           1200px
        ====================================================== */

        @media (max-width: 1200px) {

          .consultation-hero-section {
            padding-left: 40px;
            padding-right: 40px;
          }

          .development-form-section {
            padding-left: 40px;
            padding-right: 40px;
          }

          .consultation-hero-content {
            padding: 42px;
          }

          .consultation-hero-heading {
            font-size: 40px;
          }

          .main-form-card {
            padding: 40px;
          }

          .contact-card {
            padding: 38px 40px;
          }

          .support-options-grid {
            grid-template-columns:
              repeat(3, minmax(0, 1fr));
          }
        }

        /* =====================================================
           900px
        ====================================================== */

        @media (max-width: 900px) {

          .consultation-hero-container {
            grid-template-columns: 1fr;

            min-height: auto;
          }

          .consultation-hero-content {
            padding: 40px;
          }

          .consultation-hero-image-wrapper {
            min-height: 350px;
          }

          .consultation-hero-image {
            min-height: 334px;
          }

          .support-options-grid {
            grid-template-columns:
              repeat(2, minmax(0, 1fr));
          }

          .support-types-grid {
            grid-template-columns:
              repeat(2, minmax(0, 1fr));
          }

          .support-type-card:last-child {
            grid-column: 1 / -1;
          }

          .main-form-card {
            padding: 34px;
          }

          .contact-card {
            padding: 34px;
          }
        }

        /* =====================================================
           700px
        ====================================================== */

        @media (max-width: 700px) {

          .consultation-hero-section {
            padding: 36px 24px;
          }

          .development-form-section {
            padding: 0 24px 40px;
          }

          .consultation-hero-content {
            padding: 34px 28px;
          }

          .consultation-badge {
            margin-bottom: 17px;

            padding: 6px 12px;

            font-size: 9px;
          }

          .consultation-hero-heading {
            font-size: 32px;

            line-height: 1.12;
          }

          .consultation-hero-description {
            margin-top: 17px;

            font-size: 12px;

            line-height: 1.7;
          }

          .desktop-break {
            display: none;
          }

          .consultation-hero-image-wrapper {
            min-height: 300px;

            padding: 7px;
          }

          .consultation-hero-image {
            min-height: 286px;
          }

          .consultation-image-overlay {
            padding: 12px;
          }

          .consultation-image-overlay-box {
            padding: 11px 13px;
          }

          .consultation-image-overlay-box p {
            font-size: 10px;
          }

          .main-form-card {
            padding: 28px 24px;

            border-radius: 14px;
          }

          .form-section {
            padding-bottom: 28px;

            margin-bottom: 28px;
          }

          .support-options-grid,
          .support-types-grid {
            grid-template-columns: 1fr;

            gap: 10px;
          }

          .support-type-card:last-child {
            grid-column: auto;
          }

          .choice-button {
            min-height: 52px;
          }

          .support-type-card {
            min-height: 112px;
          }

          .contact-card {
            padding: 30px 24px;

            border-radius: 14px;
          }

          .contact-heading {
            font-size: 24px;
          }

          .contact-description {
            font-size: 11px;
          }

          .contact-input-grid {
            grid-template-columns: 1fr;

            gap: 15px;
          }

          .submit-button {
            width: 100%;
          }
        }

        /* =====================================================
           480px
        ====================================================== */

        @media (max-width: 480px) {

          .consultation-hero-section {
            padding: 30px 16px;
          }

          .development-form-section {
            padding: 0 16px 30px;
          }

          .consultation-hero-container {
            border-radius: 14px;
          }

          .consultation-hero-content {
            padding: 28px 20px;
          }

          .consultation-badge {
            gap: 6px;

            padding: 5px 10px;

            font-size: 8px;
          }

          .consultation-badge-dot {
            width: 6px;
            height: 6px;
          }

          .consultation-hero-heading {
            font-size: 25px;

            letter-spacing: -0.035em;
          }

          .consultation-hero-description {
            font-size: 10.5px;

            line-height: 1.65;
          }

          .consultation-hero-image-wrapper {
            min-height: 245px;

            padding: 6px;
          }

          .consultation-hero-image {
            min-height: 233px;

            border-radius: 10px;
          }

          .consultation-image-overlay {
            padding: 9px;
          }

          .consultation-image-overlay-box {
            padding: 9px 10px;
          }

          .consultation-image-overlay-box p {
            font-size: 8.5px;
          }

          .main-form-card {
            padding: 23px 16px;

            border-radius: 12px;
          }

          .form-section {
            padding-bottom: 24px;

            margin-bottom: 24px;
          }

          .form-section-header {
            gap: 9px;

            margin-bottom: 14px;
          }

          .form-section-number {
            width: 21px;
            height: 21px;

            font-size: 8px;
          }

          .form-section-title {
            font-size: 12px;
          }

          .form-section-subtitle {
            font-size: 9px;
          }

          .choice-button {
            min-height: 48px;

            padding: 9px 11px;

            font-size: 9.5px;
          }

          .support-type-card {
            min-height: 105px;

            padding: 14px;
          }

          .support-type-title {
            font-size: 11px;
          }

          .support-type-description {
            margin-top: 8px;

            font-size: 9.5px;
          }

          .capabilities-list,
          .stage-options,
          .support-level-options {
            gap: 6px;
          }

          .capability-button,
          .stage-button,
          .support-level-button {
            min-height: 33px;

            padding: 7px 10px;

            font-size: 9px;
          }

          .project-help-text {
            font-size: 9.5px;
          }

          .project-textarea {
            min-height: 115px;

            padding: 11px;

            font-size: 10px;
          }

          .contact-card {
            margin-top: 16px;

            padding: 26px 16px;

            border-radius: 12px;
          }

          .contact-label {
            font-size: 8px;
          }

          .contact-heading {
            font-size: 21px;
          }

          .contact-description {
            font-size: 9.5px;

            line-height: 1.6;
          }

          .contact-input-grid {
            margin-top: 21px;

            gap: 13px;
          }

          .input-label {
            font-size: 10px;
          }

          .input-control {
            height: 41px;

            padding: 0 11px;

            font-size: 10px;
          }

          .submit-area {
            margin-top: 23px;
          }

          .submit-button {
            min-height: 42px;

            padding: 10px 16px;

            font-size: 9.5px;
          }

          .privacy-note {
            font-size: 8px;
          }
        }

        /* =====================================================
           360px
        ====================================================== */

        @media (max-width: 360px) {

          .consultation-hero-heading {
            font-size: 23px;
          }

          .consultation-hero-description {
            font-size: 10px;
          }

          .form-section-title {
            font-size: 11.5px;
          }

          .contact-heading {
            font-size: 19px;
          }

          .submit-button {
            font-size: 9px;
          }
        }

      `})]})}function c({number:n,title:a,subtitle:i,children:l}){return e.jsxs("div",{className:"form-section",children:[e.jsxs("div",{className:"form-section-header",children:[e.jsx("span",{className:"form-section-number",children:n}),e.jsxs("div",{children:[e.jsx("h3",{className:"form-section-title",children:a}),e.jsx("p",{className:"form-section-subtitle",children:i})]})]}),l]})}function M({text:n,selected:a,onClick:i}){return e.jsxs("button",{type:"button",onClick:i,className:`choice-button ${a?"selected":""}`,children:[e.jsx("span",{className:"choice-button-text",children:n}),e.jsx("span",{className:"choice-radio",children:a&&e.jsx("span",{className:"choice-radio-inner"})})]})}function F({title:n,description:a,selected:i,onClick:l}){return e.jsxs("button",{type:"button",onClick:l,className:`support-type-card ${i?"selected":""}`,children:[e.jsx("span",{className:"support-type-radio",children:i&&e.jsx("span",{className:"support-type-radio-inner"})}),e.jsx("h4",{className:"support-type-title",children:n}),e.jsx("p",{className:"support-type-description",children:a})]})}function x({label:n,name:a,type:i="text",placeholder:l,value:u,onChange:m}){return e.jsxs("label",{className:"input-field",children:[e.jsx("span",{className:"input-label",children:n}),e.jsx("input",{type:i,name:a,value:u,onChange:m,placeholder:l,className:"input-control"})]})}export{W as default};
