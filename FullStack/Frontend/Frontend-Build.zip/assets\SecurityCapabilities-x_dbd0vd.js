import{j as e}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";const t=[{number:"01",title:"Risk & Security Assessment",description:"Understand where your current environment may be exposed. We help assess systems, applications and processes to identify security gaps and areas that require greater attention."},{number:"02",title:"Threat Monitoring",description:"Security requires visibility. Monitoring helps organizations identify unusual activity and potential threats so appropriate action can be taken before an issue becomes a larger operational problem."},{number:"03",title:"Application Security",description:"Security should begin with the applications your business relies on. We consider application-level risks and security requirements to help create stronger and more dependable digital products."},{number:"04",title:"Data Protection",description:"Business information is one of an organization's most important assets. We help establish appropriate controls for protecting sensitive information and managing access to it."},{number:"05",title:"Identity & Access Security",description:"Not every user should have access to everything. A structured approach to identity and access helps ensure people can access the systems and information they need while limiting unnecessary exposure."},{number:"06",title:"Incident Response",description:"When a security incident occurs, the response needs to be clear and controlled. We help organizations establish processes for identifying, containing and recovering from security incidents."},{number:"07",title:"Security Testing",description:"Testing provides an opportunity to identify weaknesses before they are exploited. We incorporate security considerations into testing and validation so vulnerabilities can be identified and addressed earlier."},{number:"08",title:"Security Support",description:"Security needs to evolve as systems, users and threats change. Our support helps organizations maintain security practices, address issues and make improvements over time."}];function i(){return e.jsx("section",{className:`\r
        w-full\r
        overflow-hidden\r
        bg-white\r
        px-4 py-10\r
        sm:px-6 sm:py-12\r
        md:px-10 md:py-14\r
        lg:px-[100px] lg:py-16\r
        xl:py-20\r
      `,children:e.jsxs("div",{className:"w-full",children:[e.jsxs("div",{className:"flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between sm:gap-6",children:[e.jsxs("div",{className:"min-w-0",children:[e.jsx("span",{className:"text-[9px] font-semibold tracking-[0.15em] text-[#730042] sm:text-[10px]",style:{fontFamily:"'Inter', sans-serif"},children:"CYBERSECURITY CAPABILITIES"}),e.jsx("h1",{className:`\r
                mt-2\r
                w-full\r
                max-w-[350px]\r
                text-[22px]\r
                font-bold\r
                leading-[1.3]\r
                text-slate-900\r
                sm:max-w-xl\r
                sm:text-[25px]\r
                md:max-w-2xl\r
                md:text-[28px]\r
                lg:max-w-3xl\r
                lg:text-[30px]\r
                xl:text-[32px]\r
              `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Security Across the Digital Environment"})]}),e.jsx("span",{className:`\r
              inline-flex\r
              w-fit\r
              shrink-0\r
              items-center\r
              rounded-full\r
              border\r
              border-slate-200\r
              px-3\r
              py-1\r
              text-[9px]\r
              font-medium\r
              tracking-wide\r
              text-slate-500\r
              sm:mt-1\r
              sm:text-[10px]\r
            `,style:{fontFamily:"'Inter', sans-serif"},children:"DEFENSE DEPTH // ENTERPRISE GRADE"})]}),e.jsxs("div",{className:"relative mt-7 w-full overflow-hidden rounded-lg sm:mt-8 sm:rounded-xl",children:[e.jsx("img",{src:"/Cryptographic Interface  Security Layers.webp",alt:"Enterprise layer encryption architecture",loading:"lazy",className:`\r
              block\r
              h-[220px]\r
              w-full\r
              object-cover\r
              object-center\r
              sm:h-[260px]\r
              md:h-[280px]\r
              lg:h-[300px]\r
              xl:h-[320px]\r
            `}),e.jsxs("div",{className:`\r
              absolute\r
              inset-x-0\r
              bottom-0\r
              flex\r
              flex-col\r
              gap-1\r
              bg-black/55\r
              px-3\r
              py-2\r
              sm:flex-row\r
              sm:items-center\r
              sm:justify-between\r
              sm:px-4\r
              sm:py-2.5\r
            `,children:[e.jsx("span",{className:"text-[9px] tracking-wide text-slate-200 sm:text-[10px]",style:{fontFamily:"'Inter', sans-serif"},children:"Enterprise Layer Encryption Architecture"}),e.jsx("span",{className:"text-[8px] tracking-wide text-slate-400 sm:text-[9px] md:text-[10px]",style:{fontFamily:"'Inter', sans-serif"},children:"SECURED_STORAGE_ACTIVE"})]})]}),e.jsx("div",{className:`\r
            mt-8\r
            grid\r
            grid-cols-1\r
            gap-4\r
            sm:mt-10\r
            sm:grid-cols-2\r
            sm:gap-5\r
            lg:grid-cols-4\r
            lg:gap-5\r
            xl:gap-6\r
          `,children:t.map(n=>e.jsxs("div",{className:`\r
                w-full\r
                min-w-0\r
                rounded-lg\r
                bg-slate-50\r
                p-5\r
                transition-all\r
                duration-300\r
                hover:-translate-y-1\r
                hover:shadow-sm\r
                sm:p-6\r
                lg:p-5\r
                xl:p-6\r
              `,children:[e.jsx("span",{className:"inline-flex items-center rounded-full bg-rose-100 px-2.5 py-1 text-[10px] font-semibold text-[#730042]",style:{fontFamily:"'Inter', sans-serif"},children:n.number}),e.jsx("h3",{className:"mt-4 text-[15px] font-semibold leading-[1.4] text-slate-900 sm:text-[16px] md:text-[17px]",style:{fontFamily:"'Inter', sans-serif"},children:n.title}),e.jsx("p",{className:"mt-2 text-[13px] leading-[1.7] text-slate-500 sm:text-[14px] sm:leading-[1.75]",style:{fontFamily:"'Inter', sans-serif"},children:n.description})]},n.number))})]})})}export{i as default};
