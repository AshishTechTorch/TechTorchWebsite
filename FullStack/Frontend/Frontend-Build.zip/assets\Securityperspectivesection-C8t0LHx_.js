import{j as e}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";function s(){return e.jsx("section",{className:`\r
        w-full\r
        overflow-hidden\r
        bg-[#FAF6F1]\r
        px-4 py-10\r
        sm:px-6 sm:py-12\r
        md:px-10 md:py-14\r
        lg:px-[100px] lg:py-16\r
        xl:py-20\r
      `,children:e.jsxs("div",{className:"w-full",children:[e.jsx("span",{className:"inline-flex w-fit items-center rounded-full bg-[#730042] px-3 py-1 text-[9px] font-semibold tracking-[0.15em] text-white sm:text-[10px]",style:{fontFamily:"'Inter', sans-serif"},children:"STRATEGIC PERSPECTIVE"}),e.jsx("h1",{className:`\r
            mt-4\r
            max-w-[350px]\r
            text-[22px]\r
            font-bold\r
            leading-[1.3]\r
            text-slate-900\r
            sm:max-w-xl\r
            sm:text-[25px]\r
            md:max-w-2xl\r
            md:text-[28px]\r
            lg:max-w-3xl\r
            lg:text-[30px]\r
            xl:text-[32px]\r
          `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Security Shouldn't Be an Afterthought"}),e.jsx("p",{className:`\r
            mt-5\r
            max-w-4xl\r
            text-[13px]\r
            leading-[1.75]\r
            text-slate-600\r
            sm:mt-6\r
            sm:text-[14px]\r
            md:text-[15px]\r
            md:leading-[1.8]\r
          `,style:{fontFamily:"'Inter', sans-serif"},children:"As businesses become more connected, the systems they depend on also become more exposed. Applications, cloud environments, employee devices, networks and business data all form part of the digital environment—and each connection can introduce new security considerations."}),e.jsx("p",{className:`\r
            mt-4\r
            max-w-4xl\r
            text-[13px]\r
            leading-[1.75]\r
            text-slate-600\r
            sm:text-[14px]\r
            md:text-[15px]\r
            md:leading-[1.8]\r
          `,style:{fontFamily:"'Inter', sans-serif"},children:"Cybersecurity, therefore, cannot be treated as something that is added after a system has already been built."}),e.jsx("div",{className:"mt-5 w-full border-l-4 border-[#730042] bg-white px-4 py-3 sm:mt-6 sm:px-5 sm:py-3.5",children:e.jsx("p",{className:"text-[13px] font-medium leading-[1.6] text-slate-900 sm:text-[14px] md:text-[15px]",style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"It needs to be considered as part of how the business operates."})}),e.jsxs("div",{className:`\r
            mt-7\r
            w-full\r
            rounded-md\r
            border-l-4\r
            border-[#730042]\r
            bg-white\r
            px-4\r
            py-5\r
            sm:mt-8\r
            sm:px-6\r
            sm:py-6\r
            md:px-7\r
          `,children:[e.jsx("span",{className:"text-[9px] font-semibold tracking-[0.15em] text-[#730042] sm:text-[10px]",style:{fontFamily:"'Inter', sans-serif"},children:"EXECUTIVE PERSPECTIVE"}),e.jsx("p",{className:`\r
              mt-3\r
              text-[13px]\r
              italic\r
              leading-[1.75]\r
              text-slate-700\r
              sm:text-[14px]\r
              md:text-[15px]\r
              md:leading-[1.8]\r
            `,style:{fontFamily:"'Inter', sans-serif"},children:'"At TechTorch, we take a business-focused approach to cybersecurity. We look beyond individual security tools to understand the environment those tools are protecting. This includes understanding your applications, infrastructure, data, users and the way information moves through your organization."'})]}),e.jsx("p",{className:`\r
            mt-7\r
            max-w-4xl\r
            text-[13px]\r
            leading-[1.75]\r
            text-slate-600\r
            sm:mt-8\r
            sm:text-[14px]\r
            md:text-[15px]\r
            md:leading-[1.8]\r
          `,style:{fontFamily:"'Inter', sans-serif"},children:"The objective is not simply to create more layers of technology. It is to identify where your business is exposed, strengthen the areas that matter most and establish security practices that can continue to support the organization as it changes."}),e.jsx("p",{className:`\r
            mt-4\r
            max-w-4xl\r
            text-[13px]\r
            leading-[1.75]\r
            text-slate-600\r
            sm:text-[14px]\r
            md:text-[15px]\r
            md:leading-[1.8]\r
          `,style:{fontFamily:"'Inter', sans-serif"},children:"A strong security approach also needs to account for what happens when something goes wrong. Prevention is important, but businesses also need the ability to identify unusual activity, respond appropriately and recover without unnecessary disruption."}),e.jsx("p",{className:`\r
            mt-4\r
            max-w-4xl\r
            text-[13px]\r
            leading-[1.75]\r
            text-slate-600\r
            sm:text-[14px]\r
            md:text-[15px]\r
            md:leading-[1.8]\r
          `,style:{fontFamily:"'Inter', sans-serif"},children:"That is why effective cybersecurity is ultimately about more than protection."}),e.jsx("div",{className:"mt-5 w-full border-l-4 border-[#730042] bg-white px-4 py-3 sm:mt-6 sm:px-5 sm:py-3.5",children:e.jsx("p",{className:"text-[13px] font-medium leading-[1.6] text-slate-900 sm:text-[14px] md:text-[15px]",style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"It is about building confidence in the technology your business depends on."})})]})})}export{s as default};
