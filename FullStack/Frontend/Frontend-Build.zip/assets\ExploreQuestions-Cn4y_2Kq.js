import{j as e}from"./vendor-query-PraSc8EQ.js";import{d as k,r as n}from"./vendor-router-L4ZCoGSs.js";import{r as T,a3 as m,A as h,Z as z,a4 as C}from"./index-BThRNyH6.js";import{C as A}from"./clock-3-D3KlVi6Z.js";import{C as R}from"./circle-question-mark-qtdJEbSs.js";import{M as O}from"./mail-3Flp59qD.js";import{P}from"./phone-B3rJcDGo.js";import{M as D}from"./map-pin-1B7qH9Hm.js";function H(){const g=k(),[N,w]=n.useState(null),[a,c]=n.useState(null),[x,r]=n.useState(!1),b={fullName:"",email:"",company:"",area:"",question:""},[t,y]=n.useState(b),[d,j]=n.useState(!1),[f,u]=n.useState(""),v={general:"Exploring / General",active:"Active Project Need",immediate:"Immediate Decision"},o=s=>{const{name:i,value:p}=s.target;y(l=>({...l,[i]:p})),f&&u("")},E=async s=>{if(s.preventDefault(),!d){u(""),j(!0);try{const i={fullName:t.fullName.trim(),businessEmail:t.email.trim(),companyName:t.company.trim(),inquiryArea:t.area,question:t.question.trim()};a&&(i.urgencyTimeline=v[a]),await C("/api/explore-questions",{method:"POST",body:i}),y(b),c(null),r(!0),window.setTimeout(()=>{r(!1)},3e3)}catch(i){u(i.message||"Could not send your question. Please try again.")}finally{j(!1)}}};n.useEffect(()=>{if(!x)return;const s=i=>{i.key==="Enter"&&(i.preventDefault(),i.stopPropagation(),r(!1))};return window.addEventListener("keydown",s),()=>{window.removeEventListener("keydown",s)}},[x]);const q=[{category:"SERVICES & CAPABILITIES",question:"What services does TechTorch Solutions provide?",answer:"TechTorch Solutions provides technology and digital solutions for enterprise requirements."},{category:"SERVICES & CAPABILITIES",question:"Can you develop custom software for my business?",answer:"Yes, custom software solutions can be developed according to specific business requirements."},{category:"SERVICES & CAPABILITIES",question:"Do you provide AI and Cloud solutions?",answer:"AI and Cloud capabilities can be incorporated into enterprise technology solutions."},{category:"ENTERPRISE ERP & SYSTEMS",question:"Do you provide ERP solutions?",answer:"ERP solutions can be designed around connected enterprise processes and systems."},{category:"ENTERPRISE ERP & SYSTEMS",question:"Can your solutions be customized for our business?",answer:"Solutions can be adapted according to your business processes and technical requirements."},{category:"ENTERPRISE ERP & SYSTEMS",question:"Can you integrate new software with existing legacy systems?",answer:"Integration can be planned around existing enterprise systems and technical architecture."},{category:"SECURITY & GOVERNANCE",question:"Do you provide cybersecurity services?",answer:"Cybersecurity requirements can be addressed as part of enterprise technology engagements."},{category:"SECURITY & GOVERNANCE",question:"How is proprietary code & data protected during engagements?",answer:"Security and confidentiality requirements can be addressed throughout the engagement."},{category:"SUPPORT & ENGAGEMENT",question:"Do you provide ongoing support after implementation?",answer:"Ongoing support can be discussed according to project and business requirements."},{category:"SUPPORT & ENGAGEMENT",question:"What engagement models do you support?",answer:"Engagement models can be structured around project scope and business requirements."}],S=["SERVICES & CAPABILITIES","ENTERPRISE ERP & SYSTEMS","SECURITY & GOVERNANCE","SUPPORT & ENGAGEMENT"],I=s=>q.filter(i=>i.category===s);return e.jsxs("div",{className:"ask-question-page",children:[e.jsx("style",{children:`

        /* =========================================================
           GLOBAL
        ========================================================= */

        * {
          box-sizing: border-box;
        }

        .ask-question-page {
          width: 100%;
          overflow-x: hidden;
          background: #ffffff;
          color: #151b2b;
          font-family: "Inter", sans-serif;
        }

        .aq-container {
          width: 100%;
          max-width: none;
          margin: 0;
          padding-left: 100px;
          padding-right: 100px;
        }

        .aq-heading {
          margin: 0;
          color: #151b2b;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-weight: 700;
          letter-spacing: -0.6px;
        }

        .aq-text {
          margin: 0;
          color: #687184;
          font-family: "Inter", sans-serif;
          font-weight: 400;
          line-height: 1.6;
        }

        .aq-eyebrow {
          margin: 0 0 8px;
          color: #730042;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 12px;
          line-height: 1.3;
          font-weight: 700;
          letter-spacing: 0.6px;
          text-transform: uppercase;
        }

        button {
          font-family: "Inter", sans-serif;
        }

        /* =========================================================
           QUESTION HERO
        ========================================================= */

        .question-hero {
          width: 100%;
          padding: 78px 0 82px;
          background:
            radial-gradient(
              circle at 75% 35%,
              rgba(115, 0, 66, 0.05),
              transparent 30%
            ),
            #ffffff;
        }

        .question-hero-grid {
          display: grid;
          grid-template-columns: 1.15fr 0.85fr;
          align-items: center;
          gap: 70px;
        }

        .question-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 22px;
          padding: 7px 14px;
          border: 1px solid rgba(115, 0, 66, 0.18);
          border-radius: 30px;
          background: rgba(115, 0, 66, 0.025);
          color: #730042;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.4px;
        }

        .question-badge-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: #730042;
        }

        .question-title {
          max-width: 650px;
          font-size: 38px;
          line-height: 1.04;
        }

        .question-title span {
          display: block;
          color: #730042;
        }

        .question-description {
          max-width: 650px;
          margin-top: 25px;
          font-size: 15px;
          line-height: 1.65;
        }

        .question-meta {
          display: flex;
          align-items: center;
          flex-wrap: wrap;
          gap: 20px;
          margin-top: 28px;
        }

        .question-meta-item {
          display: flex;
          align-items: center;
          gap: 7px;
          color: #687184;
          font-family: "Inter", sans-serif;
          font-size: 14px;
        }

        .question-meta-item svg {
          color: #730042;
        }

        .question-meta-dot {
          width: 5px;
          height: 5px;
          border-radius: 50%;
          background: #d2d5da;
        }

        /* =========================================================
           CONSULTATION CARD
        ========================================================= */

        .consultation-card {
          min-height: 300px;
          padding: 32px;
          border-radius: 25px;
          background: #ffffff;
          box-shadow:
            0 20px 45px rgba(25, 30, 45, 0.12),
            0 3px 10px rgba(25, 30, 45, 0.04);

          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          text-align: center;
        }

        .consultation-icon {
          width: 100px;
          height: 100px;
          margin-bottom: 20px;
          border-radius: 50%;
          background: rgba(115, 0, 66, 0.045);
          color: #730042;

          display: flex;
          align-items: center;
          justify-content: center;
        }

        .consultation-icon svg {
          width: 52px;
          height: 52px;
        }

        .consultation-title {
          margin: 0;
          color: #151b2b;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 18px;
          font-weight: 700;
        }

        .consultation-description {
          max-width: 350px;
          margin: 9px 0 0;
          color: #7a8290;
          font-family: "Inter", sans-serif;
          font-size: 14px;
          line-height: 1.55;
        }

        .consultation-link {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          margin-top: 20px;
          padding: 0;
          border: none;
          background: transparent;
          color: #730042;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 700;
          cursor: pointer;
        }

        /* =========================================================
           FORM SECTION
        ========================================================= */

        .form-section {
          padding: 85px 0 100px;
          background: #ffffff;
        }

        .form-header {
          max-width: 800px;
          margin: 0 auto 42px;
          text-align: center;
        }

        .form-title {
          font-size: 38px;
          line-height: 1.15;
        }

        .form-subtitle {
          margin-top: 13px;
          font-size: 15px;
        }

        .question-form {
          width: min(860px, 100%);
          margin: 0 auto;
          padding: 40px;
          border: 1px solid #e2e5e9;
          border-radius: 18px;
          background: #ffffff;
          box-shadow: 0 5px 18px rgba(20, 25, 40, 0.04);
        }

        .form-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 22px 20px;
        }

        .form-group.full {
          grid-column: 1 / -1;
        }

        .form-label {
          display: block;
          margin-bottom: 8px;
          color: #303847;
          font-family: "Inter", sans-serif;
          font-size: 14px;
          font-weight: 600;
        }

        .required {
          color: #730042;
        }

        .form-input,
        .form-select,
        .form-textarea {
          width: 100%;
          border: 1px solid #d9dde4;
          border-radius: 8px;
          outline: none;
          background: #ffffff;
          color: #252b38;
          font-family: "Inter", sans-serif;
          font-size: 14px;
          transition: 0.2s ease;
        }

        .form-input,
        .form-select {
          height: 48px;
          padding: 0 14px;
        }

        .form-textarea {
          min-height: 105px;
          padding: 13px 14px;
          resize: vertical;
        }

        .form-input::placeholder,
        .form-textarea::placeholder {
          color: #9aa1ad;
        }

        .form-input:focus,
        .form-select:focus,
        .form-textarea:focus {
          border-color: #730042;
          box-shadow: 0 0 0 3px rgba(115, 0, 66, 0.08);
        }

        .textarea-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 15px;
        }

        .character-count {
          color: #9aa1ad;
          font-family: "Inter", sans-serif;
          font-size: 11px;
        }

        /* =========================================================
           URGENCY
        ========================================================= */

        .urgency-section {
          margin-top: 28px;
        }

        .urgency-title {
          margin: 0 0 10px;
          color: #303847;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 600;
        }

        .urgency-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
        }

        .urgency-option {
          min-height: 43px;
          padding: 0 13px;
          border: 1px solid #e2e5ea;
          border-radius: 8px;
          background: #ffffff;
          color: #444b58;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 600;

          display: flex;
          align-items: center;
          gap: 9px;

          cursor: pointer;
        }

        .urgency-option.selected {
          border-color: rgba(115, 0, 66, 0.3);
        }

        .radio-circle {
          width: 17px;
          height: 17px;
          flex-shrink: 0;
          border: 2px solid #adb4bf;
          border-radius: 50%;

          display: flex;
          align-items: center;
          justify-content: center;
        }

        .urgency-option.selected .radio-circle {
          border-color: #730042;
        }

        .urgency-option.selected .radio-circle::after {
          content: "";
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: #730042;
        }

        /* =========================================================
           FORM BOTTOM
        ========================================================= */

        .form-bottom {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 20px;
          margin-top: 26px;
          padding-top: 8px;
          border-top: 1px solid #edf0f3;
        }

        .submit-button {
          min-height: 46px;
          padding: 0 25px;
          border: none;
          border-radius: 25px;
          background: #730042;
          color: #ffffff;

          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 10px;

          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 600;

          cursor: pointer;
          box-shadow: 0 5px 12px rgba(115, 0, 66, 0.16);
          transition: 0.2s ease;
        }

        .submit-button:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 18px rgba(115, 0, 66, 0.22);
        }

        .response-note {
          display: flex;
          align-items: center;
          gap: 6px;
          color: #8a919d;
          font-family: "Inter", sans-serif;
          font-size: 12px;
        }

        .response-note svg {
          color: #f4b400;
        }

        /* =========================================================
           FAQ
        ========================================================= */

        .faq-section {
          padding: 85px 0 95px;
          background: #faf9f6;
        }

        .faq-header {
          margin-bottom: 38px;
        }

        .faq-title {
          font-size: 36px;
          line-height: 1.12;
        }

        .faq-description {
          margin-top: 10px;
          font-size: 14px;
        }

        .faq-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 38px 25px;
        }

        .faq-column-title {
          margin: 0 0 14px 8px;
          color: #a5adba;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 12px;
          font-weight: 700;
          letter-spacing: 0.4px;
        }

        .faq-list {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .faq-item {
          overflow: hidden;
          border: 1px solid #e4e6e9;
          border-radius: 12px;
          background: #ffffff;
        }

        .faq-question {
          width: 100%;
          min-height: 61px;
          padding: 0 17px;
          border: none;
          background: transparent;
          color: #343b49;

          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 15px;

          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 600;
          text-align: left;

          cursor: pointer;
        }

        .faq-question svg {
          flex-shrink: 0;
          color: #8f97a4;
          transition: transform 0.25s ease;
        }

        .faq-question.open svg {
          transform: rotate(180deg);
          color: #730042;
        }

        .faq-answer {
          padding: 0 17px 17px;
          color: #727b89;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          line-height: 1.6;
        }

        /* =========================================================
           ASK ANOTHER QUESTION
        ========================================================= */

        .another-question {
          margin-top: 48px;
          padding: 30px 32px;
          border: 1px solid #e4e6e9;
          border-radius: 16px;
          background: #ffffff;

          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 35px;
        }

        .another-badge {
          display: inline-flex;
          padding: 6px 12px;
          border: 1px solid rgba(115, 0, 66, 0.15);
          border-radius: 20px;
          background: rgba(115, 0, 66, 0.025);
          color: #730042;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.4px;
        }

        .another-title {
          margin-top: 12px;
          font-size: 28px;
          line-height: 1.2;
        }

        .another-description {
          max-width: 620px;
          margin-top: 8px;
          font-size: 14px;
        }

        .direct-links {
          display: flex;
          align-items: center;
          flex-wrap: wrap;
          gap: 12px;
          margin-top: 12px;
        }

        .direct-label {
          color: #9aa1ac;
          font-family: "Inter", sans-serif;
          font-size: 12px;
        }

        .direct-link {
          padding: 0;
          border: none;
          background: transparent;
          color: #730042;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
        }

        .direct-dot {
          width: 4px;
          height: 4px;
          border-radius: 50%;
          background: #d2d5da;
        }

        .question-button {
          min-width: 205px;
          min-height: 43px;
          padding: 0 22px;
          border: none;
          border-radius: 25px;
          background: #730042;
          color: #ffffff;

          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 600;

          cursor: pointer;
          white-space: nowrap;
        }

        /* =========================================================
           IMMEDIATE REACH
        ========================================================= */

        .reach-section {
          padding: 70px 0 85px;
          background: #ffffff;
        }

        .reach-card {
          padding: 36px 38px 38px;
          border: 1px solid #e3e5e8;
          border-radius: 23px;
          background: #ffffff;
        }

        .reach-top {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 30px;
        }

        .reach-title {
          font-size: 32px;
          line-height: 1.15;
        }

        .reach-description {
          margin-top: 5px;
          font-size: 14px;
        }

        .helpdesk-status {
          display: inline-flex;
          align-items: center;
          gap: 9px;
          min-height: 37px;
          padding: 0 17px;
          border: 1px solid #9eeed0;
          border-radius: 22px;
          background: #f2fff9;
          color: #217b62;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 600;
          white-space: nowrap;
        }

        .status-dot {
          width: 10px;
          height: 10px;
          border-radius: 50%;
          background: #17b981;
        }

        .reach-divider {
          height: 1px;
          margin: 38px 0 32px;
          background: #e8e9ec;
        }

        .reach-items {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 35px;
        }

        .reach-item {
          display: flex;
          align-items: flex-start;
          gap: 17px;
        }

        .reach-icon {
          width: 32px;
          height: 32px;
          flex-shrink: 0;
          border-radius: 17px;
          background: #f9edf4;
          color: #730042;

          display: flex;
          align-items: center;
          justify-content: center;
        }

        .reach-icon svg {
          width: 18px;
          height: 18px;
        }

        .reach-label {
          margin: 1px 0 5px;
          color: #a3aab6;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.5px;
        }

        .reach-value {
          margin: 0;
          color: #252c39;
          font-family: "Inter", sans-serif;
          font-size: 14px;
          line-height: 1.45;
          font-weight: 700;
        }

        .reach-subtext {
          margin: 3px 0 0;
          color: #8b929e;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          line-height: 1.45;
        }

        /* =========================================================
           FINAL CTA
        ========================================================= */

        .final-cta {
          position: relative;
          overflow: hidden;
          min-height: 340px;
          padding: 75px 0;
          background: #730042;
          color: #ffffff;
        }

        .final-cta::before {
          content: "";
          position: absolute;
          width: 650px;
          height: 250px;
          left: 42%;
          top: 45%;
          transform: translate(-50%, -50%);
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.07);
          filter: blur(20px);
        }

        .final-cta-inner {
          position: relative;
          z-index: 2;

          display: grid;
          grid-template-columns: 1fr auto;
          align-items: center;
          gap: 50px;
        }

        .final-cta .aq-eyebrow {
          color: rgba(255, 255, 255, 0.85);
        }

        .final-title {
          color: #ffffff;
          font-size: 34px;
          line-height: 1.1;
        }  

        .final-description {
          max-width: 690px;
          margin-top: 15px;
          color: rgba(255, 255, 255, 0.85);
          font-size: 15px;
          line-height: 1.65;
        }

        .final-actions {
          display: flex;
          align-items: center;
          gap: 20px;
        }

        .white-button {
          min-height: 41px;
          padding: 0 30px;
          border: none;
          border-radius: 32px;
          background: #ffffff;
          color: #730042;

          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 10px;

          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 700;

          cursor: pointer;
          white-space: nowrap;
          transition: 0.2s ease;
        }

        .white-button:hover {
          transform: translateY(-2px);
        }

        .outline-button {
          min-height: 41px;
          padding: 0 30px;
          border: 2px solid rgba(255, 255, 255, 0.55);
          border-radius: 32px;
          background: transparent;
          color: #ffffff;

          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 10px;

          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 700;

          cursor: pointer;
          white-space: nowrap;
        }

        /* =========================================================
           TABLET
        ========================================================= */

        @media (max-width: 1024px) {
          .aq-container {
            width: 100%;
            max-width: none;
            padding-left: 40px;
            padding-right: 40px;
          }

          .question-hero-grid {
            gap: 40px;
          }

          .question-title {
            font-size: 45px;
          }

          .reach-items {
            gap: 22px;
          }

          .final-cta-inner {
            grid-template-columns: 1fr;
          }

          .final-actions {
            justify-content: flex-start;
          }
        }

        /* =========================================================
           MOBILE / TABLET
        ========================================================= */

        @media (max-width: 768px) {
          .aq-container {
            width: 100%;
            max-width: none;
            padding-left: 24px;
            padding-right: 24px;
          }

          .question-hero {
            padding: 58px 0 65px;
          }

          .question-hero-grid {
            grid-template-columns: 1fr;
            gap: 42px;
          }

          .question-title {
            font-size: clamp(36px, 8vw, 48px);
          }

          .question-description {
            font-size: 15px;
          }

          .consultation-card {
            width: min(100%, 440px);
            margin: 0 auto;
          }

          .form-section {
            padding: 65px 0 75px;
          }

          .question-form {
            padding: 27px 22px;
          }

          .form-grid {
            grid-template-columns: 1fr;
          }

          .form-group.full {
            grid-column: auto;
          }

          .urgency-grid {
            grid-template-columns: 1fr;
          }

          .form-bottom {
            align-items: flex-start;
            flex-direction: column;
          }

          .response-note {
            order: -1;
          }

          .submit-button {
            width: 100%;
          }

          .faq-section {
            padding: 65px 0 70px;
          }

          .faq-grid {
            grid-template-columns: 1fr;
            gap: 30px;
          }

          .another-question {
            align-items: flex-start;
            flex-direction: column;
            padding: 25px;
          }

          .question-button {
            width: 100%;
          }

          .reach-section {
            padding: 55px 0 65px;
          }

          .reach-top {
            flex-direction: column;
          }

          .helpdesk-status {
            white-space: normal;
          }

          .reach-items {
            grid-template-columns: 1fr;
            gap: 25px;
          }

          .final-cta {
            min-height: auto;
            padding: 60px 0;
          }

          .final-actions {
            width: 100%;
            flex-direction: column;
            align-items: stretch;
          }

          .white-button,
          .outline-button {
            width: 100%;
          }
        }

        /* =========================================================
           SMALL MOBILE
        ========================================================= */

        @media (max-width: 639px) {
          .aq-container {
            padding-left: 16px;
            padding-right: 16px;
          }
        }

        @media (max-width: 480px) {
          .aq-container {
            width: 100%;
            max-width: none;
            padding-left: 16px;
            padding-right: 16px;
          }

          .question-hero {
            padding: 45px 0 52px;
          }

          .question-title {
            font-size: 34px;
          }

          .question-description {
            font-size: 14px;
          }

          .question-meta {
            gap: 12px;
          }

          .question-meta-dot {
            display: none;
          }

          .consultation-card {
            padding: 25px 18px;
          }

          .form-title {
            font-size: 28px;
          }

          .question-form {
            padding: 23px 16px;
            border-radius: 14px;
          }

          .form-input,
          .form-select {
            height: 46px;
          }

          .textarea-header {
            align-items: flex-start;
            flex-direction: column;
            gap: 2px;
          }

          .faq-title {
            font-size: 30px;
          }

          .faq-question {
            min-height: 57px;
            padding: 0 14px;
            font-size: 12px;
          }

          .another-question {
            padding: 21px;
          }

          .another-title {
            font-size: 21px;
          }

          .reach-card {
            padding: 25px 20px;
            border-radius: 18px;
          }

          .reach-title {
            font-size: 29px;
          }

          .reach-item {
            gap: 13px;
          }

          .reach-icon {
            width: 53px;
            height: 53px;
            border-radius: 14px;
          }

          .reach-value {
            font-size: 14px;
          }

          .final-title {
            font-size: 31px;
          }

          .final-description {
            font-size: 14px;
          }

          .white-button,
          .outline-button {
            min-height: 54px;
            font-size: 12px;
          }
        }

        @media (max-width: 360px) {
          .question-title {
            font-size: 30px;
          }

          .question-description {
            font-size: 13px;
          }

          .consultation-icon {
            width: 82px;
            height: 82px;
          }

          .reach-item {
            gap: 10px;
          }

          .reach-value {
            font-size: 13px;
          }
        }


        .aq-success-overlay {
          position: fixed;
          inset: 0;
          z-index: 9999;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
          background: rgba(21, 27, 43, 0.55);
        }

        .aq-success-dialog {
          width: min(100%, 420px);
          padding: 32px 28px;
          border-radius: 16px;
          background: #ffffff;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
          text-align: center;
        }

        .aq-success-icon {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 58px;
          height: 58px;
          margin: 0 auto 16px;
          border-radius: 50%;
          background: rgba(115, 0, 66, 0.09);
          color: #730042;
          font-size: 28px;
          font-weight: 700;
        }

        .aq-success-dialog h3 {
          margin: 0 0 10px;
          color: #151b2b;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 21px;
          font-weight: 700;
        }

        .aq-success-dialog p {
          margin: 0 0 24px;
          color: #687184;
          font-family: "Inter", sans-serif;
          font-size: 14px;
          line-height: 1.6;
        }

        .aq-success-close {
          min-height: 43px;
          padding: 0 26px;
          border: 0;
          border-radius: 24px;
          background: #730042;
          color: #ffffff;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
        }


        .aq-form-error {
          margin: 0 0 12px;
          padding: 10px 14px;
          border: 1px solid #f5c6c6;
          border-radius: 8px;
          background: #fdecec;
          color: #a12020;
          font-size: 13px;
          line-height: 1.5;
        }

        .submit-button:disabled {
          opacity: 0.65;
          cursor: not-allowed;
        }

      `}),e.jsx("section",{className:"question-hero",children:e.jsxs("div",{className:"aq-container question-hero-grid",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"question-badge",children:[e.jsx("span",{className:"question-badge-dot"}),"ASK A QUESTION · TECHTORCH SUPPORT & ADVISORY"]}),e.jsxs("h1",{className:"aq-heading question-title",children:["Have a Question?",e.jsx("span",{children:"We’re Here to Help."})]}),e.jsx("p",{className:"aq-text question-description",children:"Whether you need guidance on enterprise architectures, our digital solutions, engagement models, or technical capabilities, our specialists are ready to answer your questions with clarity."}),e.jsxs("div",{className:"question-meta",children:[e.jsxs("div",{className:"question-meta-item",children:[e.jsx(A,{size:16}),"1 Business Day Turnaround"]}),e.jsx("span",{className:"question-meta-dot"}),e.jsxs("div",{className:"question-meta-item",children:[e.jsx(T,{size:17}),"Confidential & Certified Architects"]})]})]}),e.jsxs("div",{className:"consultation-card",children:[e.jsx("div",{className:"consultation-icon",children:e.jsx(R,{})}),e.jsx("h2",{className:"consultation-title",children:"Direct Technical Consultation"}),e.jsx("p",{className:"consultation-description",children:"Not sure where to begin? Submit your challenge and a TechTorch specialist will evaluate and reply promptly."}),e.jsxs("button",{type:"button",className:"consultation-link",onClick:()=>document.querySelector(".form-section")?.scrollIntoView({behavior:"smooth"}),children:["SKIP STRAIGHT TO QUESTION FORM",e.jsx(m,{size:16})]})]})]})}),e.jsx("section",{className:"form-section",children:e.jsxs("div",{className:"aq-container",children:[e.jsxs("div",{className:"form-header",children:[e.jsx("p",{className:"aq-eyebrow",children:"QUICK ADVISORY INTAKE"}),e.jsx("h2",{className:"aq-heading form-title",children:"Submit Your Question Directly to Our Advisory Team"}),e.jsx("p",{className:"aq-text form-subtitle",children:"Provide as much detail as possible to help our senior consultants understand your technical scenario."})]}),e.jsxs("form",{className:"question-form",onSubmit:E,children:[e.jsxs("div",{className:"form-grid",children:[e.jsxs("div",{className:"form-group",children:[e.jsxs("label",{className:"form-label",children:["Full Name ",e.jsx("span",{className:"required",children:"*"})]}),e.jsx("input",{type:"text",className:"form-input",name:"fullName",value:t.fullName,onChange:o,placeholder:"Enter your full name",required:!0})]}),e.jsxs("div",{className:"form-group",children:[e.jsxs("label",{className:"form-label",children:["Business Email ",e.jsx("span",{className:"required",children:"*"})]}),e.jsx("input",{type:"email",className:"form-input",name:"email",value:t.email,onChange:o,placeholder:"Enter your business email",required:!0})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"Company / Organization Name"}),e.jsx("input",{type:"text",className:"form-input",name:"company",value:t.company,onChange:o,placeholder:"Enter company name"})]}),e.jsxs("div",{className:"form-group",children:[e.jsxs("label",{className:"form-label",children:["Topic / Area of Inquiry ",e.jsx("span",{className:"required",children:"*"})]}),e.jsxs("select",{className:"form-select",name:"area",value:t.area,onChange:o,required:!0,children:[e.jsx("option",{value:"",disabled:!0,children:"Select an area of inquiry"}),e.jsx("option",{children:"Software Development"}),e.jsx("option",{children:"ERP Solutions"}),e.jsx("option",{children:"AI & Cloud"}),e.jsx("option",{children:"Cybersecurity"}),e.jsx("option",{children:"Digital Transformation"})]})]}),e.jsxs("div",{className:"form-group full",children:[e.jsxs("div",{className:"textarea-header",children:[e.jsxs("label",{className:"form-label",children:["What is your question or business challenge?"," ",e.jsx("span",{className:"required",children:"*"})]}),e.jsx("span",{className:"character-count",children:"Max 500 characters"})]}),e.jsx("textarea",{className:"form-textarea",name:"question",value:t.question,onChange:o,maxLength:500,placeholder:"Briefly describe your project, technical constraint, architecture question, or business challenge...",required:!0})]})]}),e.jsxs("div",{className:"urgency-section",children:[e.jsx("p",{className:"urgency-title",children:"Urgency / Timeline Requirement"}),e.jsxs("div",{className:"urgency-grid",children:[e.jsxs("label",{className:`urgency-option ${a==="general"?"selected":""}`,children:[e.jsx("input",{type:"radio",name:"urgency",hidden:!0,checked:a==="general",onChange:()=>c("general")}),e.jsx("span",{className:"radio-circle"}),"Exploring / General"]}),e.jsxs("label",{className:`urgency-option ${a==="active"?"selected":""}`,children:[e.jsx("input",{type:"radio",name:"urgency",hidden:!0,checked:a==="active",onChange:()=>c("active")}),e.jsx("span",{className:"radio-circle"}),"Active Project Need"]}),e.jsxs("label",{className:`urgency-option ${a==="immediate"?"selected":""}`,children:[e.jsx("input",{type:"radio",name:"urgency",hidden:!0,checked:a==="immediate",onChange:()=>c("immediate")}),e.jsx("span",{className:"radio-circle"}),"Immediate Decision"]})]})]}),e.jsxs("div",{className:"form-bottom",children:[f&&e.jsx("p",{className:"aq-form-error",role:"alert",children:f}),e.jsxs("button",{type:"submit",className:"submit-button",disabled:d,children:[d?"Sending…":"Send Question",!d&&e.jsx(h,{size:17})]}),e.jsxs("p",{className:"response-note",children:[e.jsx(z,{size:14}),"Our solutions architects typically respond within 1 business day."]})]})]})]})}),e.jsx("section",{className:"faq-section",children:e.jsxs("div",{className:"aq-container",children:[e.jsxs("div",{className:"faq-header",children:[e.jsx("p",{className:"aq-eyebrow",children:"FAQS & KNOWLEDGE BASE"}),e.jsx("h2",{className:"aq-heading faq-title",children:"Frequently Asked Questions"}),e.jsx("p",{className:"aq-text faq-description",children:"Quick answers to common questions about TechTorch Solutions, deployment models, and services."})]}),e.jsx("div",{className:"faq-grid",children:S.map(s=>e.jsxs("div",{children:[e.jsx("h3",{className:"faq-column-title",children:s}),e.jsx("div",{className:"faq-list",children:I(s).map(i=>{const p=q.indexOf(i),l=N===p;return e.jsxs("div",{className:"faq-item",children:[e.jsxs("button",{type:"button",className:`faq-question ${l?"open":""}`,onClick:()=>w(l?null:p),children:[e.jsx("span",{children:i.question}),e.jsx(m,{size:17})]}),l&&e.jsx("div",{className:"faq-answer",children:i.answer})]},i.question)})})]},s))}),e.jsxs("div",{className:"another-question",children:[e.jsxs("div",{children:[e.jsx("span",{className:"another-badge",children:"NEED SPECIFIC GUIDANCE?"}),e.jsx("h2",{className:"aq-heading another-title",children:"Didn’t Find Your Answer? Ask Another Question"}),e.jsx("p",{className:"aq-text another-description",children:"Can’t find what you are looking for in our knowledge base? Send your question directly to our enterprise solutions architects and receive a tailored, detailed response within 1 business day."}),e.jsxs("div",{className:"direct-links",children:[e.jsx("span",{className:"direct-label",children:"Or connect directly:"}),e.jsx("button",{type:"button",className:"direct-link",children:"✉ Email Advisory Desk"}),e.jsx("span",{className:"direct-dot"}),e.jsx("button",{type:"button",className:"direct-link",children:"☎ +91 581 3500381"})]})]}),e.jsxs("button",{type:"button",className:"question-button",onClick:()=>g("/explore-questions"),children:["ASK YOUR QUESTION",e.jsx(h,{size:15})]})]})]})}),e.jsx("section",{className:"reach-section",children:e.jsx("div",{className:"aq-container",children:e.jsxs("div",{className:"reach-card",children:[e.jsxs("div",{className:"reach-top",children:[e.jsxs("div",{children:[e.jsx("p",{className:"aq-eyebrow",children:"IMMEDIATE REACH"}),e.jsx("h2",{className:"aq-heading reach-title",children:"Prefer to Speak Directly?"}),e.jsx("p",{className:"aq-text reach-description",children:"Reach out via our direct enterprise channels across regions."})]}),e.jsxs("div",{className:"helpdesk-status",children:[e.jsx("span",{className:"status-dot"}),"Helpdesks Active Mon–Fri (9:30 AM – 6:30 PM IST)"]})]}),e.jsx("div",{className:"reach-divider"}),e.jsxs("div",{className:"reach-items",children:[e.jsxs("div",{className:"reach-item",children:[e.jsx("div",{className:"reach-icon",children:e.jsx(O,{})}),e.jsxs("div",{children:[e.jsx("p",{className:"reach-label",children:"ADVISORY DESK"}),e.jsx("p",{className:"reach-value",children:"contact@techtorch.solutions"}),e.jsx("p",{className:"reach-subtext",children:"Formal RFPs & Technical Inquiries"})]})]}),e.jsxs("div",{className:"reach-item",children:[e.jsx("div",{className:"reach-icon",children:e.jsx(P,{})}),e.jsxs("div",{children:[e.jsx("p",{className:"reach-label",children:"DIRECT LINE"}),e.jsxs("p",{className:"reach-value",children:["+91 581 3500381",e.jsx("br",{}),"+91 7251090147"]})]})]}),e.jsxs("div",{className:"reach-item",children:[e.jsx("div",{className:"reach-icon",children:e.jsx(D,{})}),e.jsxs("div",{children:[e.jsx("p",{className:"reach-label",children:"GLOBAL HUBS"}),e.jsx("p",{className:"reach-value",children:"Noida · Bareilly · Florida, USA"}),e.jsx("p",{className:"reach-subtext",children:"On-site & Distributed delivery teams"})]})]})]})]})})}),e.jsx("section",{className:"final-cta",children:e.jsxs("div",{className:"aq-container final-cta-inner",children:[e.jsxs("div",{children:[e.jsx("p",{className:"aq-eyebrow",children:"ENTERPRISE SCOPING & CONSULTATION"}),e.jsx("h2",{className:"aq-heading final-title",children:"Ready to Discuss Your Project in Depth?"}),e.jsx("p",{className:"aq-text final-description",children:"If your question requires architectural scoping, RFP review, or custom enterprise solution design, let’s connect for an executive consultation."})]}),e.jsxs("div",{className:"final-actions",children:[e.jsxs("button",{type:"button",className:"white-button",onClick:()=>g("/start-conversation"),children:["TALK TO OUR EXPERTS",e.jsx(h,{size:18})]}),e.jsxs("button",{type:"button",className:"outline-button",onClick:()=>document.querySelector(".form-section")?.scrollIntoView({behavior:"smooth"}),children:["ASK ANOTHER QUESTION",e.jsx(m,{size:17})]})]})]})}),x&&e.jsx("div",{className:"aq-success-overlay",role:"presentation",onClick:s=>{s.target===s.currentTarget&&r(!1)},children:e.jsxs("div",{className:"aq-success-dialog",role:"dialog","aria-modal":"true","aria-labelledby":"aq-success-title",children:[e.jsx("div",{className:"aq-success-icon","aria-hidden":"true",children:"✓"}),e.jsx("h3",{id:"aq-success-title",children:"Question submitted successfully"}),e.jsx("p",{children:"Thank you for reaching out. Your question has been submitted successfully."}),e.jsx("button",{type:"button",className:"aq-success-close",onClick:()=>r(!1),children:"Okay"})]})})]})}export{H as default};
