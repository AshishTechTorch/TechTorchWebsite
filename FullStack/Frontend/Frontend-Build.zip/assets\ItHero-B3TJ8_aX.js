import{j as i}from"./vendor-query-PraSc8EQ.js";import{d as s,L as n}from"./vendor-router-L4ZCoGSs.js";import{A as r}from"./index-BThRNyH6.js";import{S as p}from"./share-2-Ceim1j9X.js";const t="#7A1F3D",e="#1B1B2A",a="#5b5a63";function g(){const o=s();return i.jsxs(i.Fragment,{children:[i.jsx("style",{children:`

        * {
          box-sizing: border-box;
        }

        /* =========================================================
           IT HERO
        ========================================================= */

        .it-hero-section {
          width: 100%;
          overflow: hidden;

          background: linear-gradient(
            135deg,
            #fbeef1 0%,
            #f7f5f2 40%,
            #ffffff 100%
          );

          color: ${e};
          font-family: "Inter", Arial, sans-serif;
        }

        /*
          Horizontal spacing standard:
          Desktop  : 100px
          Tablet   : 40px
          Mobile   : 24px
          Small    : 16px
        */

        .it-hero-container {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;

          padding-top: 78px;
          padding-bottom: 78px;
          padding-left: 100px;
          padding-right: 100px;

          display: grid;
          grid-template-columns: minmax(0, 1fr) minmax(0, 0.95fr);
          gap: 64px;
          align-items: center;
        }

        /* =========================================================
           LEFT CONTENT
        ========================================================= */

        .it-hero-content {
          min-width: 0;
        }

        .it-hero-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;

          margin-bottom: 22px;
          padding: 7px 13px;

          border: 1px solid #f0d6de;
          border-radius: 999px;
          background: #ffffff;

          color: ${t};

          font-family: "Inter", Arial, sans-serif;
          font-size: 10px;
          line-height: 1;
          font-weight: 700;
          letter-spacing: 0.7px;
        }

        .it-hero-badge-dot {
          width: 6px;
          height: 6px;
          flex-shrink: 0;

          border-radius: 50%;
          background: ${t};
        }

        .it-hero-heading {
          max-width: 680px;
          margin: 0 0 22px;

          color: ${e};

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 44px;
          line-height: 1.16;
          font-weight: 800;
          letter-spacing: -1.2px;
        }

        .it-hero-description {
          max-width: 650px;
          margin: 0 0 14px;

          color: ${a};

          font-family: "Inter", Arial, sans-serif;
          font-size: 14px;
          line-height: 1.75;
          font-weight: 500;
        }

        .it-hero-description:last-of-type {
          margin-bottom: 30px;
        }

        /* =========================================================
           BUTTONS
        ========================================================= */

        .it-hero-actions {
          display: flex;
          flex-wrap: wrap;
          align-items: center;
          gap: 11px;
        }

        .it-hero-button {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;

          min-height: 44px;
          padding: 0 19px;

          /* UPDATED FROM 999px TO 6px */
          border-radius: 6px;

          font-family: "Inter", Arial, sans-serif;
          font-size: 12px;
          line-height: 1;
          font-weight: 600;

          cursor: pointer;

          transition:
            transform 0.22s ease,
            box-shadow 0.22s ease,
            background 0.22s ease,
            border-color 0.22s ease,
            color 0.22s ease;
        }

        .it-hero-primary {
          border: 1px solid ${t};
          background: ${t};
          color: #ffffff;
        }

        .it-hero-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 20px rgba(122, 31, 61, 0.2);
        }

        .it-hero-secondary {
          border: 1px solid #d8d5d0;
          background: #ffffff;
          color: ${e};
        }

        .it-hero-secondary:hover {
          transform: translateY(-2px);
          border-color: ${t};
          color: ${t};
        }

        /* =========================================================
           IMAGE AREA
        ========================================================= */

        .it-hero-visual {
          position: relative;
          min-width: 0;
          padding-bottom: 28px;
        }

        .it-hero-image-wrapper {
          position: relative;

          width: 100%;
          height: 440px;

          overflow: hidden;

          border-radius: 22px;
          background: #1c2230;

          box-shadow:
            0 18px 45px rgba(27, 27, 42, 0.13);
        }

        .it-hero-image {
          display: block;

          width: 100%;
          height: 100%;

          object-fit: cover;

          transition: transform 0.5s ease;
        }

        .it-hero-image-wrapper:hover .it-hero-image {
          transform: scale(1.03);
        }

        .it-hero-image-overlay {
          position: absolute;
          inset: 0;

          background:
            linear-gradient(
              180deg,
              rgba(0, 0, 0, 0.02) 30%,
              rgba(0, 0, 0, 0.48) 100%
            );
        }

        .it-hero-image-label {
          position: absolute;

          left: 18px;
          bottom: 18px;

          padding: 7px 11px;

          border: 1px solid rgba(255, 255, 255, 0.15);
          border-radius: 999px;

          background: rgba(20, 20, 25, 0.6);
          backdrop-filter: blur(8px);

          color: #ffffff;

          font-family: "Inter", Arial, sans-serif;
          font-size: 9px;
          line-height: 1;
          font-weight: 600;
          letter-spacing: 0.5px;
          text-transform: uppercase;
        }

        /* =========================================================
           FLOATING CARD
        ========================================================= */

        .it-status-card {
          position: absolute;

          left: 18px;
          right: 18px;
          bottom: 0;

          display: flex;
          align-items: center;
          gap: 11px;

          min-width: 0;

          padding: 12px 14px;

          border: 1px solid rgba(0, 0, 0, 0.04);
          border-radius: 13px;

          background: #ffffff;

          box-shadow:
            0 12px 30px rgba(27, 27, 42, 0.12);
        }

        .it-status-icon {
          display: flex;
          align-items: center;
          justify-content: center;

          width: 37px;
          height: 37px;

          flex-shrink: 0;

          border-radius: 9px;
          background: #fbeef1;
          color: ${t};
        }

        .it-status-content {
          min-width: 0;
          flex: 1;
        }

        .it-status-title {
          margin: 0 0 3px;

          color: ${e};

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 12px;
          line-height: 1.35;
          font-weight: 700;
        }

        .it-status-description {
          margin: 0;

          color: ${a};

          font-family: "Inter", Arial, sans-serif;
          font-size: 9px;
          line-height: 1.4;
          font-weight: 400;
        }

        .it-status-badge {
          display: inline-flex;
          align-items: center;
          gap: 5px;

          flex-shrink: 0;

          padding: 6px 9px;

          border-radius: 999px;
          background: #e5f7ec;
          color: #1a9455;

          font-family: "Inter", Arial, sans-serif;
          font-size: 8px;
          line-height: 1;
          font-weight: 600;
          white-space: nowrap;
        }

        .it-status-badge-dot {
          width: 5px;
          height: 5px;

          border-radius: 50%;
          background: #1a9455;
        }

        /* =========================================================
           TABLET / MEDIUM DESKTOP
        ========================================================= */

        @media (max-width: 1199px) {
          .it-hero-container {
            padding-left: 40px;
            padding-right: 40px;

            padding-top: 65px;
            padding-bottom: 65px;

            gap: 42px;
          }

          .it-hero-heading {
            font-size: 39px;
          }

          .it-hero-image-wrapper {
            height: 400px;
          }

          .it-status-card {
            left: 14px;
            right: 14px;
          }
        }

        /* =========================================================
           TABLET
        ========================================================= */

        @media (max-width: 900px) {
          .it-hero-container {
            grid-template-columns: 1fr;

            gap: 45px;

            padding-left: 40px;
            padding-right: 40px;

            padding-top: 58px;
            padding-bottom: 70px;
          }

          .it-hero-content {
            width: 100%;
            max-width: 760px;
          }

          .it-hero-heading {
            max-width: 700px;
            font-size: 38px;
          }

          .it-hero-description {
            max-width: 720px;
          }

          .it-hero-visual {
            width: 100%;
            max-width: 760px;
            margin: 0 auto;
          }

          .it-hero-image-wrapper {
            height: 410px;
          }
        }

        /* =========================================================
           MOBILE
        ========================================================= */

        @media (max-width: 767px) {
          .it-hero-container {
            padding-left: 24px;
            padding-right: 24px;

            padding-top: 48px;
            padding-bottom: 60px;

            gap: 35px;
          }

          .it-hero-badge {
            margin-bottom: 17px;
            padding: 6px 11px;
            font-size: 9px;
          }

          .it-hero-badge-dot {
            width: 5px;
            height: 5px;
          }

          .it-hero-heading {
            margin-bottom: 17px;

            font-size: 30px;
            line-height: 1.22;
            letter-spacing: -0.7px;
          }

          .it-hero-description {
            margin-bottom: 12px;

            font-size: 12.5px;
            line-height: 1.7;
          }

          .it-hero-description:last-of-type {
            margin-bottom: 24px;
          }

          .it-hero-actions {
            width: 100%;

            flex-direction: column;
            align-items: stretch;
          }

          .it-hero-button {
            width: 100%;
            min-height: 45px;

            /* SAME RADIUS ON MOBILE */
            border-radius: 6px;
          }

          .it-hero-visual {
            padding-bottom: 24px;
          }

          .it-hero-image-wrapper {
            height: 350px;
            border-radius: 17px;
          }

          .it-hero-image-label {
            left: 13px;
            bottom: 13px;
            font-size: 8px;
          }

          .it-status-card {
            left: 10px;
            right: 10px;

            gap: 8px;
            padding: 10px;

            border-radius: 11px;
          }

          .it-status-icon {
            width: 34px;
            height: 34px;

            border-radius: 8px;
          }

          .it-status-title {
            font-size: 10.5px;
          }

          .it-status-description {
            font-size: 8px;
          }

          .it-status-badge {
            padding: 5px 7px;
            font-size: 7px;
          }
        }

        /* =========================================================
           SMALL MOBILE
        ========================================================= */

        @media (max-width: 480px) {
          .it-hero-container {
            padding-left: 16px;
            padding-right: 16px;

            padding-top: 42px;
            padding-bottom: 52px;
          }

          .it-hero-heading {
            font-size: 27px;
            letter-spacing: -0.5px;
          }

          .it-hero-description {
            font-size: 11.5px;
          }

          .it-hero-button {
            border-radius: 6px;
          }

          .it-hero-image-wrapper {
            height: 300px;
            border-radius: 15px;
          }

          .it-status-card {
            left: 7px;
            right: 7px;
          }

          .it-status-description {
            font-size: 7.5px;
          }

          .it-status-badge {
            display: none;
          }
        }

        /* =========================================================
           EXTRA SMALL MOBILE
        ========================================================= */

        @media (max-width: 360px) {
          .it-hero-container {
            padding-left: 16px;
            padding-right: 16px;

            padding-top: 36px;
            padding-bottom: 45px;
          }

          .it-hero-heading {
            font-size: 24px;
          }

          .it-hero-description {
            font-size: 11px;
          }

          .it-hero-button {
            border-radius: 6px;
          }

          .it-hero-image-wrapper {
            height: 260px;
          }

          .it-status-card {
            padding: 9px;
          }

          .it-status-icon {
            width: 31px;
            height: 31px;
          }

          .it-status-title {
            font-size: 9.5px;
          }

          .it-status-description {
            font-size: 7px;
          }
        }

        /* =========================================================
           REDUCED MOTION
        ========================================================= */

        @media (prefers-reduced-motion: reduce) {
          .it-hero-button,
          .it-hero-image {
            transition: none;
          }

          .it-hero-button:hover {
            transform: none;
          }

          .it-hero-image-wrapper:hover .it-hero-image {
            transform: none;
          }
        }
      `}),i.jsx("section",{className:"it-hero-section",children:i.jsxs("div",{className:"it-hero-container",children:[i.jsxs("div",{className:"it-hero-content",children:[i.jsxs("span",{className:"it-hero-badge",children:[i.jsx("span",{className:"it-hero-badge-dot"}),"INFORMATION TECHNOLOGY"]}),i.jsx("h1",{className:"it-hero-heading",children:"Technology Solutions Designed Around Your Business"}),i.jsx("p",{className:"it-hero-description",children:"Technology plays an important role in how businesses operate, communicate and grow. From software applications and cloud infrastructure to cybersecurity and digital platforms, organizations need technology that supports their business requirements and evolving needs."}),i.jsx("p",{className:"it-hero-description",children:"TechTorch Solutions brings together technology consulting, software engineering, cloud infrastructure, cybersecurity, artificial intelligence, software development and technology support to help businesses build and improve their digital environment."}),i.jsxs("div",{className:"it-hero-actions",children:[i.jsxs(n,{to:"/talk-to-expert",className:"it-hero-button it-hero-primary",children:["Talk to Our Experts",i.jsx(r,{size:15})]}),i.jsxs("button",{type:"button",className:"it-hero-button it-hero-secondary",onClick:()=>o("/it-get-in-touch"),children:["Get in Touch",i.jsx(r,{size:15})]})]})]}),i.jsxs("div",{className:"it-hero-visual",children:[i.jsxs("div",{className:"it-hero-image-wrapper",children:[i.jsx("img",{src:"/it.webp",alt:"Information technology team reviewing business architecture",className:"it-hero-image"}),i.jsx("div",{className:"it-hero-image-overlay"}),i.jsx("span",{className:"it-hero-image-label",children:"INFORMATION TECHNOLOGY"})]}),i.jsxs("div",{className:"it-status-card",children:[i.jsx("span",{className:"it-status-icon",children:i.jsx(p,{size:16})}),i.jsxs("div",{className:"it-status-content",children:[i.jsx("p",{className:"it-status-title",children:"Enterprise Ops Command Center"}),i.jsx("p",{className:"it-status-description",children:"Cloud Architecture · Real-time Telemetry"})]}),i.jsxs("span",{className:"it-status-badge",children:[i.jsx("span",{className:"it-status-badge-dot"}),"Verified Architecture"]})]})]})]})})]})}export{g as default};
