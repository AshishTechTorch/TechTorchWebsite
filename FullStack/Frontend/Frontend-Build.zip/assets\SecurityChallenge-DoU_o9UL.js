import{j as n}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";const s=["Business applications and software","Networks and connected systems","Cloud environments","Employee and user access","Sensitive business information","External integrations","Security monitoring and response","Business continuity"];function a(){return n.jsx("section",{className:`\r
        w-full\r
        overflow-hidden\r
        bg-[#730042]\r
        px-4 py-10\r
        sm:px-6 sm:py-12\r
        md:px-10 md:py-14\r
        lg:px-[100px] lg:py-16\r
        xl:py-20\r
      `,children:n.jsxs("div",{className:`\r
          grid\r
          w-full\r
          grid-cols-1\r
          gap-8\r
          sm:gap-10\r
          md:gap-12\r
          lg:grid-cols-2\r
          lg:gap-14\r
          xl:gap-16\r
        `,children:[n.jsxs("div",{className:"w-full min-w-0",children:[n.jsx("span",{className:"inline-flex w-fit items-center rounded-full bg-white/15 px-3 py-1 text-[9px] font-semibold tracking-[0.15em] text-white sm:text-[10px]",style:{fontFamily:"'Inter', sans-serif"},children:"THE SECURITY CHALLENGE"}),n.jsx("h1",{className:`\r
              mt-4\r
              max-w-[350px]\r
              text-[22px]\r
              font-bold\r
              leading-[1.3]\r
              text-white\r
              sm:max-w-xl\r
              sm:text-[25px]\r
              md:max-w-2xl\r
              md:text-[28px]\r
              lg:max-w-xl\r
              lg:text-[30px]\r
              xl:text-[32px]\r
            `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Your Digital Environment Is Bigger Than Your Network"}),n.jsx("p",{className:`\r
              mt-5\r
              max-w-2xl\r
              text-[13px]\r
              leading-[1.75]\r
              text-rose-100/90\r
              sm:mt-6\r
              sm:text-[14px]\r
              md:text-[15px]\r
              md:leading-[1.8]\r
            `,style:{fontFamily:"'Inter', sans-serif"},children:"Modern businesses rarely operate from a single system. Employees work across devices. Applications communicate through APIs. Business data moves between departments and platforms. Cloud services support critical workloads, while customers and partners interact with digital systems from outside the organization."}),n.jsx("p",{className:`\r
              mt-4\r
              max-w-2xl\r
              text-[13px]\r
              leading-[1.75]\r
              text-rose-100/90\r
              sm:text-[14px]\r
              md:text-[15px]\r
              md:leading-[1.8]\r
            `,style:{fontFamily:"'Inter', sans-serif"},children:"This creates a wider environment that needs to be understood and protected."}),n.jsxs("div",{className:"mt-7 w-full overflow-hidden rounded-lg sm:mt-8 sm:rounded-xl",children:[n.jsx("img",{src:"/Secure Software Architecture  Engineering.webp",alt:"Developer working on code across multiple monitors",loading:"lazy",className:`\r
                block\r
                h-auto\r
                min-h-[190px]\r
                w-full\r
                object-cover\r
                sm:min-h-[230px]\r
                md:min-h-[260px]\r
                lg:min-h-[250px]\r
                xl:min-h-[280px]\r
              `}),n.jsx("div",{className:"bg-black/45 px-4 py-4 sm:px-5 sm:py-4 md:px-6 md:py-5",children:n.jsx("p",{className:"text-[12px] leading-[1.7] text-white/90 sm:text-[13px] md:text-[14px]",style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Rigorous code architecture, authenticated endpoints, and deep software-level controls form the baseline of organizational defense."})})]})]}),n.jsxs("div",{className:`\r
            w-full\r
            min-w-0\r
            self-start\r
            rounded-lg\r
            bg-white/10\r
            p-4\r
            sm:p-5\r
            md:p-6\r
            lg:p-7\r
            xl:p-8\r
          `,children:[n.jsx("h2",{className:"text-[17px] font-bold leading-[1.4] text-white sm:text-[18px] md:text-[20px]",style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Key Environmental Vectors"}),n.jsx("div",{className:"mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-3.5 md:mt-6",children:s.map(e=>n.jsxs("div",{className:`\r
                  flex\r
                  items-start\r
                  gap-2.5\r
                  rounded-md\r
                  bg-white/10\r
                  px-3\r
                  py-3\r
                  text-[12px]\r
                  leading-[1.5]\r
                  text-white\r
                  transition-colors\r
                  duration-300\r
                  hover:bg-white/15\r
                  sm:px-3.5\r
                  sm:py-3.5\r
                  sm:text-[13px]\r
                `,style:{fontFamily:"'Inter', sans-serif"},children:[n.jsx("span",{className:"mt-1.5 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-rose-300"}),n.jsx("span",{children:e})]},e))}),n.jsx("div",{className:"mt-5 rounded-md bg-white/10 px-4 py-4 sm:mt-6 sm:px-5 sm:py-4",children:n.jsx("p",{className:"text-[12px] leading-[1.7] text-rose-100/90 sm:text-[13px] md:text-[14px]",style:{fontFamily:"'Inter', sans-serif"},children:"The right approach depends on the organization, its technology landscape and the risks it needs to manage."})})]})]})})}export{a as default};
