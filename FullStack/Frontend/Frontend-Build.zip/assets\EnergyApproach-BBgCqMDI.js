import{j as e}from"./vendor-query-PraSc8EQ.js";import{d as s,L as c}from"./vendor-router-L4ZCoGSs.js";import{A as n}from"./index-BThRNyH6.js";const d="/energy2.webp",a="#7A1F3D",t="#1B1B2A",h="#5b5a63",x=[{num:"01",title:"Understand",body:"Understand your business objectives, existing environment and technology requirements."},{num:"02",title:"Design & Develop",body:"Plan and develop the solution around the identified requirements."},{num:"03",title:"Test & Deploy",body:"Test the solution and prepare it for implementation."},{num:"04",title:"Support & Maintain",body:"Provide ongoing maintenance and support as requirements evolve."}];function f(){const i=s();return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`

        /* =========================
           BASE
        ========================= */

        .approach-page {
          width: 100%;
          color: ${t};
          font-family: "Inter", Arial, sans-serif;
          overflow: hidden;
          box-sizing: border-box;
        }

        .approach-page *,
        .approach-page *::before,
        .approach-page *::after {
          box-sizing: border-box;
        }


        /* =========================
           OUR APPROACH
        ========================= */

        .approach-section {
          width: 100%;
          background: #f2f2f5;
        }

        .approach-container {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;
          padding: 72px 100px;
        }

        .approach-eyebrow {
          margin: 0 0 12px;
          color: ${a};
          font-size: 12px;
          font-weight: 700;
          line-height: 1.4;
          letter-spacing: 0.12em;
          text-transform: uppercase;
        }

        .approach-heading {
          margin: 0 0 34px;
          color: ${t};
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 38px;
          line-height: 1.2;
          font-weight: 700;
          letter-spacing: -0.03em;
        }


        /* =========================
           APPROACH CARDS
        ========================= */

        .approach-steps {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 18px;
          width: 100%;
        }

        .approach-card {
          min-height: 255px;

          display: flex;
          flex-direction: column;

          padding: 26px 22px 24px;

          background: #ffffff;
          border-radius: 16px;

          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.05);

          transition:
            transform 0.3s ease,
            box-shadow 0.3s ease;
        }

        .approach-card:hover {
          transform: translateY(-5px);
          box-shadow: 0 12px 30px rgba(27, 27, 42, 0.08);
        }

        .approach-number {
          margin: 0 0 22px;

          color: #e3d3d9;

          font-size: 36px;
          line-height: 1;
          font-weight: 700;
        }

        .approach-card-title {
          margin: 0 0 10px;

          color: ${t};

          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 17px;
          line-height: 1.35;
          font-weight: 700;
        }

        .approach-card-body {
          margin: 0;

          color: ${h};

          font-size: 13px;
          line-height: 1.7;
        }

        .approach-line {
          width: 28px;
          height: 2px;

          margin-top: auto;

          background: ${a};
        }


        /* =====================================
           CTA WITH BACKGROUND IMAGE
        ===================================== */

        .energy-cta {
          position: relative;

          width: 100%;
          min-height: 520px;

          overflow: hidden;

          background: #1c2230;
        }

        .energy-cta-bg {
          position: absolute;
          inset: 0;

          background-image: url("${d}");
          background-size: cover;
          background-position: center;
          background-repeat: no-repeat;

          z-index: 0;

          transform: scale(1.02);
        }

        .energy-cta-overlay {
          position: absolute;
          inset: 0;

          z-index: 1;

          background:
            linear-gradient(
              135deg,
              rgba(16, 18, 28, 0.84) 0%,
              rgba(30, 20, 31, 0.78) 48%,
              rgba(74, 18, 48, 0.82) 100%
            );
        }

        .energy-cta-container {
          position: relative;
          z-index: 2;

          width: 100%;
          max-width: 1600px;
          min-height: 520px;

          margin: 0 auto;
          padding: 100px;

          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;

          text-align: center;
        }

        .cta-eyebrow {
          margin: 0 0 20px;

          color: #f0ceda;

          font-size: 11px;
          font-weight: 700;
          line-height: 1.4;
          letter-spacing: 0.2em;
          text-transform: uppercase;
        }

        .cta-heading {
          max-width: 950px;

          margin: 0 auto 26px;

          color: #ffffff;

          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 44px;
          line-height: 1.2;
          font-weight: 700;
          letter-spacing: -0.035em;

          text-shadow: 0 2px 14px rgba(0, 0, 0, 0.22);
        }

        .cta-description {
          max-width: 720px;

          margin: 0 auto 34px;

          display: flex;
          flex-direction: column;

          gap: 12px;
        }

        .cta-description p {
          margin: 0;

          color: #f0dce4;

          font-size: 15px;
          line-height: 1.75;

          text-shadow: 0 1px 8px rgba(0, 0, 0, 0.22);
        }


        /* =========================
           CTA BUTTONS
        ========================= */

        .cta-buttons {
          display: flex;
          flex-wrap: wrap;

          justify-content: center;
          align-items: center;

          gap: 12px;
        }

        .cta-button {
          min-height: 46px;

          display: inline-flex;
          align-items: center;
          justify-content: center;

          gap: 9px;

          padding: 12px 22px;

          /* UPDATED: reduced border radius */
          border-radius: 8px;

          font-family: "Inter", Arial, sans-serif;
          font-size: 13px;
          font-weight: 600;

          cursor: pointer;

          transition:
            transform 0.25s ease,
            background 0.25s ease,
            border-color 0.25s ease,
            box-shadow 0.25s ease;
        }

        .cta-button:hover {
          transform: translateY(-2px);
        }


        /* LEFT BUTTON */

        .cta-secondary {
          color: #ffffff;

          background: #730042;

          border: 1px solid rgba(255, 255, 255, 0.45);

          backdrop-filter: blur(4px);
          -webkit-backdrop-filter: blur(4px);
        }

        .cta-secondary:hover {
          border-color: #730042;
          color: #730042;

          background: #ffffff;
        }


        /* RIGHT BUTTON */

        .cta-primary {
          color: ${a};

          background: #ffffff;

          border: 1px solid #ffffff;
        }

        .cta-primary:hover {
          background: #730042;
          color: #ffffff;

          box-shadow:
            0 8px 20px rgba(0, 0, 0, 0.15);
        }


        /* =========================
           TABLET
        ========================= */

        @media (max-width: 1100px) {
          .approach-container {
            padding-left: 40px;
            padding-right: 40px;
          }

          .approach-steps {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .approach-card {
            min-height: 235px;
          }

          .energy-cta,
          .energy-cta-container {
            min-height: 480px;
          }

          .energy-cta-container {
            padding: 85px 40px;
          }

          .cta-heading {
            font-size: 38px;
          }
        }


        /* =========================
           MOBILE
        ========================= */

        @media (max-width: 700px) {
          .approach-container {
            padding: 50px 24px;
          }

          .approach-eyebrow {
            font-size: 11px;
            margin-bottom: 10px;
          }

          .approach-heading {
            font-size: 30px;
            line-height: 1.25;

            margin-bottom: 26px;
          }

          .approach-steps {
            grid-template-columns: 1fr;

            gap: 14px;
          }

          .approach-card {
            min-height: auto;

            padding: 23px 20px;
          }

          .approach-number {
            font-size: 31px;

            margin-bottom: 17px;
          }

          .approach-card-title {
            font-size: 16px;
          }

          .approach-card-body {
            font-size: 13px;

            line-height: 1.65;
          }


          /* CTA */

          .energy-cta,
          .energy-cta-container {
            min-height: 500px;
          }

          .energy-cta-bg {
            background-position: center center;
          }

          .energy-cta-container {
            padding: 70px 24px;
          }

          .cta-eyebrow {
            font-size: 10px;

            margin-bottom: 16px;
          }

          .cta-heading {
            font-size: 30px;
            line-height: 1.25;

            margin-bottom: 22px;
          }

          .cta-description {
            margin-bottom: 28px;
          }

          .cta-description p {
            font-size: 13px;

            line-height: 1.7;
          }


          /* BUTTONS */

          .cta-buttons {
            flex-direction: column;

            width: 100%;
          }

          .cta-button {
            width: 100%;
            max-width: 320px;

            min-height: 48px;

            border-radius: 8px;
          }

          .desktop-break {
            display: none;
          }
        }


        /* =========================
           SMALL MOBILE
        ========================= */

        @media (max-width: 480px) {
          .approach-container {
            padding: 42px 16px;
          }

          .approach-heading {
            font-size: 26px;
          }

          .approach-card {
            border-radius: 13px;

            padding: 21px 18px;
          }

          .approach-number {
            font-size: 28px;
          }

          .approach-card-title {
            font-size: 15px;
          }

          .approach-card-body {
            font-size: 12px;
          }


          /* CTA */

          .energy-cta-container {
            padding: 58px 16px;
          }

          .cta-heading {
            font-size: 26px;
          }

          .cta-description p {
            font-size: 12px;
          }

          .cta-button {
            max-width: 100%;

            font-size: 12px;

            border-radius: 8px;
          }
        }


        /* =========================
           VERY SMALL MOBILE
        ========================= */

        @media (max-width: 340px) {
          .approach-heading,
          .cta-heading {
            font-size: 23px;
          }

          .cta-description p {
            font-size: 11.5px;
          }
        }


        /* =========================
           REDUCED MOTION
        ========================= */

        @media (prefers-reduced-motion: reduce) {
          .approach-card,
          .cta-button {
            transition: none;
          }

          .cta-button:hover {
            transform: none;
          }
        }
      `}),e.jsxs("div",{className:"approach-page",children:[e.jsx("section",{className:"approach-section",children:e.jsxs("div",{className:"approach-container",children:[e.jsx("p",{className:"approach-eyebrow",children:"OUR APPROACH"}),e.jsx("h2",{className:"approach-heading",children:"From Requirement to Support"}),e.jsx("div",{className:"approach-steps",children:x.map(({num:r,title:o,body:p})=>e.jsxs("div",{className:"approach-card",children:[e.jsx("p",{className:"approach-number",children:r}),e.jsx("h3",{className:"approach-card-title",children:o}),e.jsx("p",{className:"approach-card-body",children:p}),e.jsx("div",{className:"approach-line"})]},r))})]})}),e.jsxs("section",{className:"energy-cta",children:[e.jsx("div",{className:"energy-cta-bg"}),e.jsx("div",{className:"energy-cta-overlay"}),e.jsxs("div",{className:"energy-cta-container",children:[e.jsx("p",{className:"cta-eyebrow",children:"GET IN TOUCH"}),e.jsxs("h2",{className:"cta-heading",children:["Let's Build Technology Around",e.jsx("br",{className:"desktop-break"}),"Your Business"]}),e.jsxs("div",{className:"cta-description",children:[e.jsx("p",{children:"Discuss your Energy business and technology requirements with the TechTorch team."}),e.jsx("p",{children:"Whether you need ERP, operations management, software development, cloud infrastructure, cybersecurity or other technology services, our team can discuss your requirements and the appropriate approach."})]}),e.jsxs("div",{className:"cta-buttons",children:[e.jsxs(c,{to:"/talk-to-expert",className:"cta-button cta-secondary",children:["Talk to Our Experts",e.jsx(n,{size:15})]}),e.jsxs("button",{type:"button",className:"cta-button cta-primary",onClick:()=>i("/energy-get-in-touch"),children:["Get in Touch",e.jsx(n,{size:15})]})]})]})]})]})]})}export{f as default};
