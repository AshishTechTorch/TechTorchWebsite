import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as s,L as c}from"./vendor-router-L4ZCoGSs.js";import{A as f}from"./arrow-up-right-BppImEly.js";import{P as x}from"./phone-B3rJcDGo.js";import{K as m}from"./index-BThRNyH6.js";import{M as g}from"./mail-3Flp59qD.js";function j(){const[n,t]=s.useState(!1),o=s.useRef(null),a=s.useRef(null),l=()=>{a.current&&clearTimeout(a.current),t(!0)},p=()=>{a.current=setTimeout(()=>{t(!1)},450)};s.useEffect(()=>{const i=r=>{o.current&&!o.current.contains(r.target)&&t(!1)},d=r=>{r.key==="Escape"&&t(!1)};return document.addEventListener("mousedown",i),document.addEventListener("keydown",d),()=>{document.removeEventListener("mousedown",i),document.removeEventListener("keydown",d),a.current&&clearTimeout(a.current)}},[]);const h=[{label:"Call us",icon:e.jsx(x,{size:17}),href:"tel:+915813500381"},{label:"WhatsApp",icon:e.jsx(m,{size:17}),href:"https://wa.me/91XXXXXXXXXX?text=Hello%20TechTorch%20Solutions",external:!0},{label:"Email us",icon:e.jsx(g,{size:17}),href:"https://mail.google.com/mail/?view=cm&fs=1&to=contact@techtorch.solutions&su=Data%20and%20Decisions%20Enquiry",external:!0}];return e.jsxs("div",{className:"data-decisions-page",children:[e.jsxs("section",{className:"data-decisions-hero",children:[e.jsx("img",{loading:"lazy",decoding:"async",src:"/DataDecisions.webp",alt:"Data and Decision Making",className:"data-decisions-hero-image"}),e.jsx("div",{className:"data-decisions-hero-overlay"}),e.jsxs("div",{className:"data-decisions-hero-content",children:[e.jsxs("div",{className:"data-decisions-eyebrow",children:[e.jsx("span",{}),"TECH PULSE · DATA & DECISIONS"]}),e.jsxs("h1",{children:["MORE DATA DOESN'T MEAN BETTER",e.jsx("br",{}),"DECISIONS"]}),e.jsx("h2",{children:"The value of data is not in how much you have. It's in how clearly you can use it."}),e.jsx("p",{children:"Modern businesses generate information across finance, operations, customers, supply chains and everyday business processes. But more information does not automatically create better decisions."}),e.jsx("p",{children:"What matters is having the right information, in the right context, at the right time."}),e.jsx("p",{children:"TechTorch Solutions helps businesses connect technology, processes and information to create greater visibility, improve operational efficiency and support more informed business decisions."}),e.jsxs("div",{className:"data-decisions-buttons",children:[e.jsx(c,{to:"/digitalsolution",className:"data-decisions-primary-btn",children:"Explore Digital Solutions"}),e.jsxs("div",{className:"data-decisions-contact-wrapper",ref:o,onMouseEnter:l,onMouseLeave:p,children:[e.jsxs(c,{to:"/talk-to-expert",className:"data-decisions-secondary-btn group",children:["Talk to Our Experts",e.jsx(f,{size:18,strokeWidth:1.8,className:"data-decisions-arrow"})]}),e.jsx("div",{className:`data-decisions-contact-options ${n?"show":""}`,"aria-hidden":!n,children:h.map(i=>e.jsx("a",{href:i.href,"aria-label":i.label,title:i.label,tabIndex:n?0:-1,target:i.external?"_blank":void 0,rel:i.external?"noopener noreferrer":void 0,className:"data-decisions-contact-icon",onClick:()=>t(!1),children:i.icon},i.label))})]})]})]})]}),e.jsx("style",{children:`
        .data-decisions-page {
          width: 100%;
          background: #f7f8fa;
          color: #171717;
          font-family: "Inter", sans-serif;
          overflow: hidden;
        }

        /* ================= HERO ================= */

        .data-decisions-hero {
          position: relative;
          width: 100%;
          min-height: 500px;
          margin: 0;
          overflow: hidden;
          background: #101d32;
        }

        .data-decisions-hero-image {
          position: absolute;
          inset: 0;
          width: 100%;
          height: 100%;
          display: block;
          object-fit: cover;
          object-position: center;
        }

        /* ================= OVERLAY ================= */

        .data-decisions-hero-overlay {
          position: absolute;
          inset: 0;
          background:
            linear-gradient(
              90deg,
              rgba(3, 8, 20, 0.88) 0%,
              rgba(5, 12, 28, 0.76) 40%,
              rgba(5, 13, 30, 0.48) 72%,
              rgba(4, 10, 22, 0.58) 100%
            ),
            linear-gradient(
              to bottom,
              rgba(0, 0, 0, 0.15),
              rgba(0, 0, 0, 0.5)
            );
        }

        /* ================= HERO CONTENT ================= */

        .data-decisions-hero-content {
          position: relative;
          z-index: 2;
          width: 100%;
          min-height: 500px;
          padding: 40px 16px;
          display: flex;
          flex-direction: column;
          justify-content: center;
        }

        @media (min-width: 640px) {
          .data-decisions-hero-content {
            padding: 48px 24px;
          }
        }

        @media (min-width: 768px) {
          .data-decisions-hero-content {
            padding: 56px 40px;
          }
        }

        @media (min-width: 1024px) {
          .data-decisions-hero-content {
            padding: 64px 100px;
          }
        }

        @media (min-width: 1280px) {
          .data-decisions-hero-content {
            padding: 80px 100px;
          }
        }

        /* ================= EYEBROW ================= */

        .data-decisions-eyebrow {
          width: fit-content;
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 20px;
          padding: 6px 11px;
          border: 1px solid rgba(183, 200, 228, 0.28);
          border-radius: 20px;
          background: rgba(85, 111, 153, 0.25);
          color: #ffffff;
          font-size: 9px;
          font-weight: 700;
          letter-spacing: 0.7px;
        }

        .data-decisions-eyebrow span {
          width: 6px;
          height: 6px;
          flex: 0 0 6px;
          border-radius: 50%;
          background: #f49ab9;
        }

        /* ================= HEADING ================= */

        .data-decisions-hero h1 {
          max-width: 850px;
          margin: 0 0 12px;
          color: #ffffff;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 30px;
          line-height: 1.05;
          font-weight: 600;
          letter-spacing: -1.2px;
        }

        /* ================= SUB HEADING ================= */

        .data-decisions-hero h2 {
          max-width: 900px;
          margin: 0 0 17px;
          color: #ffffff;
          font-family: "Inter", sans-serif;
          font-size: 15px;
          line-height: 1.4;
          font-weight: 400;
        }

        /* ================= DESCRIPTION ================= */

        .data-decisions-hero p {
          max-width: 850px;
          margin: 0 0 12px;
          color: rgba(235, 240, 248, 0.82);
          font-size: 14px;
          line-height: 1.5;
          font-weight: 400;
        }

        /* ================= BUTTONS ================= */

        .data-decisions-buttons {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-top: 17px;
        }

        .data-decisions-primary-btn,
        .data-decisions-secondary-btn {
          min-height: 40px;
          padding: 10px 21px;
          border-radius: 6px;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 700;
          text-decoration: none;
          cursor: pointer;
          transition: all 0.2s ease;
          display: inline-flex;
          align-items: center;
          justify-content: center;
        }

        /* ================= PRIMARY BUTTON ================= */

        .data-decisions-primary-btn {
          border: 1px solid #730042;
          background: #730042;
          color: #ffffff;
          box-shadow: 0 7px 18px rgba(128, 0, 68, 0.25);
        }

        .data-decisions-primary-btn:hover {
          background: #970052;
          border-color: #970052;
        }

        /* ================= SECONDARY BUTTON ================= */

        .data-decisions-secondary-btn {
          border: 1px solid rgba(220, 228, 241, 0.3);
          background: rgba(255, 255, 255, 0.08);
          color: #ffffff;
          backdrop-filter: blur(5px);
          gap: 8px;
        }

        .data-decisions-secondary-btn:hover {
          background: rgba(255, 255, 255, 0.15);
        }

        /* ================= ARROW ================= */

        .data-decisions-arrow {
          flex-shrink: 0;
          transition: transform 0.3s ease;
        }

        .data-decisions-secondary-btn:hover .data-decisions-arrow {
          transform: translate(4px, -4px);
        }

        /* ================= CONTACT ICONS ================= */

        .data-decisions-contact-wrapper {
          position: relative;
          display: inline-block;
        }

        .data-decisions-contact-options {
          position: absolute;
          left: 100%;
          top: 50%;
          z-index: 10;
          display: flex;
          align-items: center;
          gap: 8px;
          margin-left: 10px;
          transform: translateY(-50%);
          visibility: hidden;
          opacity: 0;
          pointer-events: none;
          transition:
            opacity 0.3s ease,
            visibility 0.3s ease;
        }

        .data-decisions-contact-options.show {
          visibility: visible;
          opacity: 1;
          pointer-events: auto;
        }

        .data-decisions-contact-icon {
          width: 36px;
          height: 36px;
          flex: 0 0 36px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          border: 1px solid rgba(255, 255, 255, 0.35);
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.95);
          color: #730042;
          text-decoration: none;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.18);
          transition:
            background 0.2s ease,
            color 0.2s ease,
            transform 0.2s ease;
        }

        .data-decisions-contact-icon:hover {
          background: #730042;
          color: #ffffff;
          transform: translateY(-2px);
        }

        /* ================= TABLET ================= */

        @media (max-width: 900px) {
          .data-decisions-hero h1 {
            font-size: 28px;
          }
        }

        /* ================= MOBILE ================= */

        @media (max-width: 650px) {
          .data-decisions-hero,
          .data-decisions-hero-content {
            min-height: 570px;
          }

          .data-decisions-eyebrow {
            font-size: 8px;
          }

          .data-decisions-hero h1 {
            font-size: 27px;
            line-height: 1.08;
            letter-spacing: -1px;
          }

          .data-decisions-hero h2 {
            font-size: 14px;
          }

          .data-decisions-hero p {
            font-size: 11px;
          }

          .data-decisions-buttons {
            flex-direction: column;
            align-items: stretch;
            width: fit-content;
          }

          .data-decisions-primary-btn,
          .data-decisions-secondary-btn {
            width: 210px;
          }

          .data-decisions-contact-wrapper {
            width: 210px;
          }

          .data-decisions-contact-options {
            left: auto;
            right: 0;
            top: calc(100% + 8px);
            margin-left: 0;
            transform: none;
          }
        }

        /* ================= SMALL MOBILE ================= */

        @media (max-width: 420px) {
          .data-decisions-hero,
          .data-decisions-hero-content {
            min-height: 560px;
          }

          .data-decisions-hero h1 {
            font-size: 24px;
          }

          .data-decisions-hero h2 {
            font-size: 13px;
          }

          .data-decisions-hero p {
            font-size: 10px;
          }
        }
      `})]})}export{j as default};
