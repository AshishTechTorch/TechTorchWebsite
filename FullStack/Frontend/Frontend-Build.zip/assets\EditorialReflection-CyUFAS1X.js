import{j as e}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";function s(){return e.jsx("section",{className:`\r
        w-full\r
        overflow-hidden\r
        bg-white\r
        px-4 py-10\r
        sm:px-6 sm:py-12\r
        md:px-10 md:py-14\r
        lg:px-[100px] lg:py-16\r
        xl:py-20\r
      `,children:e.jsxs("div",{className:"w-full",children:[e.jsx("span",{className:"text-[9px] font-semibold tracking-[0.15em] text-[#730042] sm:text-[10px]",style:{fontFamily:"'Inter', sans-serif"},children:"EDITORIAL REFLECTION"}),e.jsx("h1",{className:`\r
            mt-3\r
            w-full\r
            text-[22px]\r
            font-bold\r
            leading-[1.3]\r
            text-slate-900\r
            sm:text-[26px]\r
            md:text-[30px]\r
            lg:text-[34px]\r
            xl:text-[36px]\r
          `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"The Cost of Waiting Can Be Greater Than the Cost of Preparing"}),e.jsx("p",{className:`\r
            mt-5\r
            w-full\r
            text-[13px]\r
            leading-[1.75]\r
            text-slate-600\r
            sm:mt-6\r
            sm:text-[14px]\r
            md:text-[15px]\r
            md:leading-[1.8]\r
          `,style:{fontFamily:"'Inter', sans-serif"},children:"Cybersecurity often receives attention after something has already gone wrong."}),e.jsx("div",{className:`\r
            mt-6\r
            w-full\r
            border-l-4\r
            border-[#730042]\r
            bg-slate-50\r
            px-4\r
            py-3\r
            sm:mt-7\r
            sm:px-5\r
            sm:py-4\r
            md:px-6\r
          `,children:e.jsx("p",{className:"text-[13px] font-medium leading-[1.6] text-slate-900 sm:text-[14px] md:text-[15px]",style:{fontFamily:"'Inter', sans-serif"},children:"A suspicious login. A compromised account. An unavailable system. A data exposure."})}),e.jsxs("div",{className:"mt-6 w-full sm:mt-7",children:[e.jsx("p",{className:"text-[13px] leading-[1.75] text-slate-600 sm:text-[14px] md:text-[15px] md:leading-[1.8]",style:{fontFamily:"'Inter', sans-serif"},children:"By that point, the organization is responding under pressure."}),e.jsx("p",{className:"mt-4 text-[13px] leading-[1.75] text-slate-600 sm:text-[14px] md:text-[15px] md:leading-[1.8]",style:{fontFamily:"'Inter', sans-serif"},children:"A proactive security approach changes the conversation."}),e.jsx("p",{className:"mt-4 text-[13px] leading-[1.75] text-slate-600 sm:text-[14px] md:text-[15px] md:leading-[1.8]",style:{fontFamily:"'Inter', sans-serif"},children:"Instead of asking what to do after an incident, businesses can ask where they are exposed today, what information needs greater protection and how quickly they could respond if something unexpected happened."}),e.jsx("p",{className:"mt-4 text-[13px] leading-[1.75] text-slate-600 sm:text-[14px] md:text-[15px] md:leading-[1.8]",style:{fontFamily:"'Inter', sans-serif"},children:"That shift—from reaction to preparation—is what makes cybersecurity part of good business management."})]}),e.jsx("p",{className:`\r
            mt-7\r
            w-full\r
            text-[14px]\r
            font-semibold\r
            leading-[1.7]\r
            text-slate-900\r
            sm:mt-8\r
            sm:text-[15px]\r
            md:text-[16px]\r
            md:leading-[1.75]\r
          `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Security isn't about assuming nothing will go wrong. It's about being prepared when it does."})]})})}export{s as default};
