import{j as e}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";const t=[{title:"Understand the Environment",description:"We begin by understanding your systems, applications, users and business requirements."},{title:"Focus on Risk",description:"Security decisions are prioritized around the areas that can have the greatest impact on your organization."},{title:"Build for Resilience",description:"We consider not only prevention, but also detection, response and recovery."},{title:"Keep Security Practical",description:"Security controls should protect the business without creating unnecessary complexity for the people using them."},{title:"Evolve With the Business",description:"As your technology and business requirements change, your security approach needs to change with them."}];function a(){return e.jsx("section",{className:`\r
        w-full\r
        overflow-hidden\r
        bg-[#FAF6F1]\r
        px-4 py-10\r
        sm:px-6 sm:py-12\r
        md:px-10 md:py-14\r
        lg:px-[100px] lg:py-16\r
        xl:py-20\r
      `,children:e.jsxs("div",{className:"w-full",children:[e.jsxs("div",{className:"w-full",children:[e.jsx("span",{className:"text-[9px] font-semibold tracking-[0.15em] text-[#730042] sm:text-[10px]",style:{fontFamily:"'Inter', sans-serif"},children:"WHY TECHTORCH"}),e.jsx("h1",{className:`\r
              mt-3\r
              w-full\r
              max-w-[350px]\r
              text-[22px]\r
              font-bold\r
              leading-[1.3]\r
              text-slate-900\r
              sm:max-w-xl\r
              sm:text-[25px]\r
              md:max-w-2xl\r
              md:text-[28px]\r
              lg:max-w-3xl\r
              lg:text-[30px]\r
              xl:text-[32px]\r
            `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"A Business-Focused Approach to Cybersecurity"}),e.jsx("p",{className:`\r
              mt-4\r
              max-w-[340px]\r
              text-[13px]\r
              leading-[1.7]\r
              text-slate-500\r
              sm:max-w-xl\r
              sm:text-[14px]\r
              md:text-[15px]\r
              md:leading-[1.8]\r
            `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Our approach focuses on understanding the business first and building security around its people, systems, risks and goals."})]}),e.jsx("div",{className:`\r
            mt-8\r
            grid\r
            grid-cols-1\r
            gap-4\r
            sm:mt-10\r
            sm:grid-cols-2\r
            sm:gap-5\r
            lg:mt-12\r
            lg:grid-cols-3\r
            lg:gap-6\r
          `,children:t.map((n,s)=>e.jsxs("div",{className:`\r
                group\r
                w-full\r
                min-w-0\r
                rounded-lg\r
                border\r
                border-slate-200\r
                bg-white\r
                p-5\r
                transition-all\r
                duration-300\r
                hover:-translate-y-1\r
                hover:border-[#730042]\r
                hover:shadow-md\r
                sm:p-6\r
                lg:p-6\r
              `,children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsx("span",{className:"text-[22px] font-bold leading-none text-slate-200 sm:text-[24px]",style:{fontFamily:"'Inter', sans-serif"},children:String(s+1).padStart(2,"0")}),e.jsx("span",{className:"h-0.5 w-8 bg-[#730042] transition-all duration-300 group-hover:w-12"})]}),e.jsx("h3",{className:"mt-5 text-[15px] font-semibold leading-[1.4] text-slate-900 sm:text-[16px] md:text-[17px]",style:{fontFamily:"'Inter', sans-serif"},children:n.title}),e.jsx("p",{className:"mt-2 text-[13px] leading-[1.7] text-slate-500 sm:text-[14px] sm:leading-[1.75]",style:{fontFamily:"'Inter', sans-serif"},children:n.description})]},n.title))})]})})}export{a as default};
