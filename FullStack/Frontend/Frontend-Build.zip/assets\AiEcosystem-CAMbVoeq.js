import{j as e}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";import{t as i,b as c,s as r}from"./index-BThRNyH6.js";import{C as d}from"./cloud-DZemR4H4.js";import{S as p}from"./shield-B_34gOBp.js";import{S as m}from"./smartphone-p6bJo9dM.js";const o={name:"message-square-text",size:24,node:[["path",{d:"M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",key:"18887p"}],["path",{d:"M7 11h10",key:"1twpyw"}],["path",{d:"M7 15h6",key:"d9of3u"}],["path",{d:"M7 7h8",key:"af5zfr"}]]};o.node;const l=i(o);const n={name:"monitor-cog",size:24,node:[["path",{d:"M12 17v4",key:"1riwvh"}],["path",{d:"m14.305 7.53.923-.382",key:"1mlnsw"}],["path",{d:"m15.228 4.852-.923-.383",key:"82mpwg"}],["path",{d:"m16.852 3.228-.383-.924",key:"ln4sir"}],["path",{d:"m16.852 8.772-.383.923",key:"1dejw0"}],["path",{d:"m19.148 3.228.383-.924",key:"192kgf"}],["path",{d:"m19.53 9.696-.382-.924",key:"fiavlr"}],["path",{d:"m20.772 4.852.924-.383",key:"1j8mgp"}],["path",{d:"m20.772 7.148.924.383",key:"zix9be"}],["path",{d:"M22 13v2a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7",key:"1tnzv8"}],["path",{d:"M8 21h8",key:"1ev6f3"}],["circle",{cx:"18",cy:"6",r:"3",key:"1h7g24"}]]};n.node;const x=i(n),t="#730024",h=[{icon:l,title:"IT Consultancy",description:"Technology consulting designed to guide businesses through their digital transformation journey."},{icon:c,title:"Artificial Intelligence",description:"Artificial Intelligence as a Service that enables businesses to harness AI without the complexity of building and maintaining their own infrastructure.",featured:!0,badge:"ACTIVE FOCUS"},{icon:d,title:"Cloud Infrastructure",description:"Cloud Infrastructure as a Service designed to help businesses scale and optimize their IT operations."},{icon:p,title:"Cyber Security",description:"Cybersecurity services focused on protecting an organization's digital assets in an environment where cyber threats continue to evolve."},{icon:x,title:"Software Engineering Services",description:"Engineering services designed to support businesses in achieving their technical and operational goals."},{icon:m,title:"Software Development & Support",description:"End-to-end software development and support services designed to help businesses achieve operational excellence and drive innovation."},{icon:r,title:"Resource & Staffing",description:"Resource and staffing services that provide businesses with skilled professionals and flexible workforce solutions."}];function z(){return e.jsxs("section",{className:"ecosystem-section",children:[e.jsxs("div",{className:"ecosystem-container",children:[e.jsxs("div",{className:"ecosystem-header",children:[e.jsxs("div",{className:"ecosystem-header-content",children:[e.jsxs("div",{className:"ecosystem-eyebrow",children:[e.jsx("span",{className:"ecosystem-eyebrow-line"}),e.jsx("span",{className:"ecosystem-eyebrow-text",children:"TechTorch Ecosystem"})]}),e.jsx("h1",{className:"ecosystem-heading",children:"TechTorch Technology Services"}),e.jsx("p",{className:"ecosystem-subheading",children:"Artificial Intelligence is one part of the wider technology capabilities offered by TechTorch Solutions."})]}),e.jsx("span",{className:"ecosystem-count",children:"8 Integrated Practices"})]}),e.jsx("div",{className:"ecosystem-grid",children:h.map(s=>{const a=s.icon;return e.jsxs("div",{className:`ecosystem-card ${s.featured?"is-featured":""}`,children:[e.jsxs("div",{className:"ecosystem-card-top",children:[e.jsx("div",{className:"ecosystem-icon-wrapper",children:e.jsx(a,{className:"ecosystem-icon"})}),s.badge&&e.jsx("span",{className:"ecosystem-badge",children:s.badge})]}),e.jsx("h3",{className:"ecosystem-card-title",children:s.title}),e.jsx("p",{className:"ecosystem-card-description",children:s.description}),e.jsx("div",{className:"ecosystem-card-footer",children:e.jsx("span",{className:"ecosystem-card-label",children:s.footerLabel})})]},s.title)})})]}),e.jsx("style",{children:`
        .ecosystem-section { width: 100%; overflow: hidden; background: #fff; }

        .ecosystem-container {
          width: 100%;
          box-sizing: border-box;
          padding: 70px 100px;
        }

        /* HEADER */
        .ecosystem-header {
          width: 100%;
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          gap: 30px;
          margin-bottom: 42px;
        }
        .ecosystem-header-content { min-width: 0; flex: 1; }

        .ecosystem-eyebrow { display: flex; align-items: center; gap: 8px; margin-bottom: 14px; }
        .ecosystem-eyebrow-line { width: 32px; height: 1px; flex-shrink: 0; background: ${t}; }
        .ecosystem-eyebrow-text {
          font-family: "Inter", sans-serif;
          font-size: 11px; font-weight: 600; line-height: 1.4;
          letter-spacing: 0.08em; color: ${t};
        }

        .ecosystem-heading {
          max-width: 850px; margin: 0 0 8px 0;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 38px; font-weight: 700; line-height: 1.2;
          letter-spacing: -0.02em; color: #1c1c1c;
        }
        .ecosystem-subheading {
          max-width: 700px; margin: 0;
          font-family: "Inter", sans-serif;
          font-size: 14px; font-weight: 400; line-height: 1.65; color: #737373;
        }
        .ecosystem-count {
          flex-shrink: 0; white-space: nowrap; padding: 7px 13px;
          border-radius: 999px;
          font-family: "Inter", sans-serif;
          font-size: 10px; font-weight: 500; line-height: 1.3;
          color: #737373; background: #f5f5f5;
        }

        /* GRID */
        .ecosystem-grid {
          width: 100%;
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 24px;
        }

        /* CARD: static, not clickable */
        .ecosystem-card {
          min-width: 0;
          min-height: 230px;
          display: flex;
          flex-direction: column;
          box-sizing: border-box;
          padding: 24px;
          border: 1px solid #e5e5e5;
          border-radius: 12px;
          background: #fff;
          cursor: default;
        }
        .ecosystem-card.is-featured {
          border-color: rgba(115, 0, 36, 0.16);
          box-shadow: 0 12px 30px rgba(0, 0, 0, 0.07);
        }

        .ecosystem-card-top {
          width: 100%;
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 10px;
          margin-bottom: 21px;
        }

        .ecosystem-icon-wrapper {
          width: 38px; height: 38px;
          display: flex; align-items: center; justify-content: center;
          flex-shrink: 0; box-sizing: border-box;
          border: 1px solid #e5e5e5; border-radius: 8px; background: #fafafa;
        }
        .is-featured .ecosystem-icon-wrapper { border-color: ${t}; background: #fdf1f6; }
        .ecosystem-icon { width: 17px; height: 17px; color: ${t}; }

        /* Badge: solid maroon pill like "CORE BENEFIT" */
        .ecosystem-badge {
          flex-shrink: 0; padding: 5px 10px; border-radius: 999px;
          font-family: "Inter", sans-serif;
          font-size: 8px; font-weight: 700; line-height: 1.2;
          letter-spacing: 0.06em; white-space: nowrap;
          color: #fff; background: ${t};
        }

        .ecosystem-card-title {
          margin: 0 0 9px 0;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 14px; font-weight: 700; line-height: 1.4; color: #1c1c1c;
        }
        .ecosystem-card-description {
          flex: 1; margin: 0;
          font-family: "Inter", sans-serif;
          font-size: 12.5px; font-weight: 400; line-height: 1.7; color: #737373;
        }


        /* <= 1200px */
        @media (max-width: 1200px) {
          .ecosystem-container { padding: 60px 40px; }
          .ecosystem-heading { font-size: 35px; }
          .ecosystem-grid { gap: 20px; }
          .ecosystem-card { padding: 21px; }
        }

        /* <= 900px */
        @media (max-width: 900px) {
          .ecosystem-container { padding: 52px 40px; }
          .ecosystem-header { align-items: flex-start; gap: 18px; margin-bottom: 32px; }
          .ecosystem-heading { font-size: 32px; }
          .ecosystem-subheading { font-size: 13px; }
          .ecosystem-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 18px; }
          .ecosystem-card { min-height: 275px; padding: 20px; }
          .ecosystem-card-description { font-size: 12px; }
        }

        /* <= 700px */
        @media (max-width: 700px) {
          .ecosystem-container { padding: 44px 24px; }
          .ecosystem-header { flex-direction: column; align-items: flex-start; gap: 16px; margin-bottom: 28px; }
          .ecosystem-eyebrow { gap: 7px; margin-bottom: 11px; }
          .ecosystem-eyebrow-line { width: 26px; }
          .ecosystem-eyebrow-text { font-size: 10px; }
          .ecosystem-heading { max-width: 100%; font-size: 28px; line-height: 1.22; }
          .ecosystem-subheading { max-width: 100%; font-size: 12px; }
          .ecosystem-count { font-size: 9px; padding: 6px 11px; }
          .ecosystem-grid { grid-template-columns: 1fr; gap: 15px; }
          .ecosystem-card { min-height: auto; padding: 20px; }
          .ecosystem-card-top { margin-bottom: 18px; }
          .ecosystem-card-description { line-height: 1.65; }
        }

        /* <= 480px */
        @media (max-width: 480px) {
          .ecosystem-container { padding: 36px 16px; }
          .ecosystem-header { margin-bottom: 24px; }
          .ecosystem-eyebrow-line { width: 22px; }
          .ecosystem-eyebrow-text { font-size: 9px; letter-spacing: 0.07em; }
          .ecosystem-heading { font-size: 25px; line-height: 1.2; }
          .ecosystem-subheading { font-size: 11.5px; }
          .ecosystem-count { padding: 5px 10px; font-size: 8.5px; }
          .ecosystem-grid { gap: 13px; }
          .ecosystem-card { padding: 17px; border-radius: 10px; }
          .ecosystem-card-top { margin-bottom: 16px; }
          .ecosystem-icon-wrapper { width: 36px; height: 36px; }
          .ecosystem-icon { width: 16px; height: 16px; }
          .ecosystem-badge { padding: 4px 8px; font-size: 7px; }
          .ecosystem-card-title { margin-bottom: 8px; font-size: 13px; }
          .ecosystem-card-description { margin-bottom: 16px; font-size: 11.5px; }
        }

        /* <= 360px */
        @media (max-width: 360px) {
          .ecosystem-heading { font-size: 23px; }
          .ecosystem-subheading { font-size: 11px; }
          .ecosystem-card { padding: 16px; }
          .ecosystem-card-title { font-size: 12.5px; }
          .ecosystem-card-description { font-size: 11px; }
          .ecosystem-badge { font-size: 6.5px; }
        }
      `})]})}export{z as default};
