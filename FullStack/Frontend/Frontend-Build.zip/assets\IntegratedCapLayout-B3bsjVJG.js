import{j as e}from"./vendor-query-PraSc8EQ.js";import{u as n,e as r,i as d,O as p}from"./vendor-router-L4ZCoGSs.js";const o=[{name:"ERP Integration",path:"erp-integration",icon:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.8",children:[e.jsx("circle",{cx:"12",cy:"12",r:"3"}),e.jsx("circle",{cx:"5",cy:"7",r:"1.5"}),e.jsx("circle",{cx:"19",cy:"7",r:"1.5"}),e.jsx("circle",{cx:"5",cy:"17",r:"1.5"}),e.jsx("circle",{cx:"19",cy:"17",r:"1.5"}),e.jsx("path",{d:"M9.5 10 6.2 8"}),e.jsx("path",{d:"M14.5 10 17.8 8"}),e.jsx("path",{d:"M9.5 14 6.2 16"}),e.jsx("path",{d:"M14.5 14 17.8 16"})]})},{name:"Operations",path:"operations-management",icon:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.8",children:[e.jsx("path",{d:"M4 20h16"}),e.jsx("path",{d:"M6 17h12"}),e.jsx("path",{d:"M7 17V9h10v8"}),e.jsx("path",{d:"M5 9h14"}),e.jsx("path",{d:"m8 6 4-3 4 3"})]})},{name:"Data Orchestration",path:"data-orchestration",icon:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.8",children:[e.jsx("rect",{x:"5",y:"4",width:"14",height:"16",rx:"1.5"}),e.jsx("path",{d:"M8 8h8"}),e.jsx("path",{d:"M8 12h8"}),e.jsx("path",{d:"M8 16h5"})]})},{name:"Legacy Modernization",path:"legacy-modernization",icon:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.8",children:[e.jsx("path",{d:"M4 7h7l3 3h6v8H4z"}),e.jsx("path",{d:"M8 14h7"}),e.jsx("path",{d:"M12 11v6"})]})}];function x(){const a=n();return r.useEffect(()=>{window.scrollTo({top:0,left:0,behavior:"instant"})},[a.pathname]),e.jsxs("div",{className:"integrated-cap-layout",children:[e.jsxs("aside",{className:"integrated-cap-sidebar",children:[e.jsx("div",{className:"integrated-cap-brand",children:"TechTorch"}),e.jsx("nav",{className:"integrated-cap-nav",children:o.map(t=>e.jsxs(d,{to:t.path,end:!0,className:({isActive:i})=>`integrated-cap-nav-item ${i?"integrated-cap-nav-item-active":""}`,children:[e.jsx("span",{className:"integrated-cap-nav-icon",children:t.icon}),e.jsx("span",{className:"integrated-cap-nav-text",children:t.name})]},t.path))})]}),e.jsx("main",{className:"integrated-cap-main",children:e.jsx(p,{})}),e.jsx("style",{children:`

        .integrated-cap-layout {
          width: 100%;
          min-height: 100vh;
          display: flex;
          background: #f7f8fa;
          color: #171717;
          font-family: "Inter", sans-serif;
        }

        .integrated-cap-sidebar {
          position: sticky;
          top: 0;
          width: 220px;
          height: 520px;
          flex: 0 0 220px;
          background: #ffffff;
          border-right: 1px solid #eeeeee;
          padding: 28px 24px;
          z-index: 50;
          overflow-y: auto;
        }

        .integrated-cap-brand {
          margin-bottom: 26px;
          color: #641033;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 16px;
          line-height: 1;
          font-weight: 700;
          letter-spacing: -0.4px;
        }

        .integrated-cap-nav {
          width: 100%;
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .integrated-cap-nav-item {
          width: 100%;
          min-height: 38px;
          display: flex;
          align-items: center;
          gap: 9px;
          padding: 8px 10px;
          border-radius: 3px;
          color: #51494d;
          text-decoration: none;
          font-size: 10px;
          font-weight: 600;
          line-height: 1.15;
          transition:
            background 0.2s ease,
            color 0.2s ease;
        }

        .integrated-cap-nav-item:hover {
          background: #880047;
          color: #ffffff;
        }

        .integrated-cap-nav-item-active {
          background: #880047;
          color: #ffffff;
        }

        .integrated-cap-nav-item-active:hover {
          background: #880047;
          color: #ffffff;
        }

        .integrated-cap-nav-icon {
          width: 15px;
          height: 15px;
          flex: 0 0 15px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .integrated-cap-nav-icon svg {
          width: 15px;
          height: 15px;
        }

        .integrated-cap-nav-text {
          display: block;
          max-width: 105px;
        }

        .integrated-cap-main {
          width: calc(100% - 220px);
          min-width: 0;
          flex: 1;
          overflow: hidden;
        }

        @media (max-width: 900px) {

          .integrated-cap-sidebar {
            width: 200px;
            flex-basis: 200px;
            padding: 24px 17px;
            height: 480px;
          }

          .integrated-cap-main {
            width: calc(100% - 200px);
          }

          .integrated-cap-nav-item {
            padding-left: 8px;
            padding-right: 8px;
            font-size: 9px;
          }
        }

        @media (max-width: 650px) {

          .integrated-cap-layout {
            display: block;
          }

          .integrated-cap-sidebar {
            position: sticky;
            top: 0;
            width: 100%;
            height: auto;
            padding: 14px 16px 11px;
            border-right: none;
            border-bottom: 1px solid #eeeeee;
            overflow: hidden;
          }

          .integrated-cap-brand {
            margin-bottom: 11px;
            font-size: 15px;
          }

          .integrated-cap-nav {
            flex-direction: row;
            gap: 5px;
            overflow-x: auto;
            scrollbar-width: none;
          }

          .integrated-cap-nav::-webkit-scrollbar {
            display: none;
          }

          .integrated-cap-nav-item {
            width: auto;
            min-width: max-content;
            min-height: 34px;
            padding: 7px 9px;
            font-size: 9px;
          }

          .integrated-cap-nav-icon {
            width: 13px;
            height: 13px;
            flex-basis: 13px;
          }

          .integrated-cap-nav-icon svg {
            width: 13px;
            height: 13px;
          }

          .integrated-cap-main {
            width: 100%;
          }
        }

        @media (max-width: 420px) {

          .integrated-cap-sidebar {
            padding-left: 12px;
            padding-right: 12px;
          }

          .integrated-cap-brand {
            font-size: 14px;
          }

          .integrated-cap-nav-item {
            font-size: 8px;
            padding: 6px 8px;
          }
        }

      `})]})}export{x as default};
