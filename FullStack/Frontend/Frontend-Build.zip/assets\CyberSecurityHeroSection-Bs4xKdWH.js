import{j as n}from"./vendor-query-PraSc8EQ.js";import{d as e}from"./vendor-router-L4ZCoGSs.js";function a(){const r=e();return n.jsxs("section",{className:`\r
        relative\r
        w-full\r
        min-h-[500px]\r
        overflow-hidden\r
        bg-slate-900\r
        sm:min-h-[560px]\r
        md:min-h-[600px]\r
        lg:min-h-[640px]\r
        xl:min-h-[680px]\r
      `,children:[n.jsx("div",{className:"absolute inset-0 bg-cover bg-center bg-no-repeat",style:{backgroundImage:"url('/Card4hero.webp')"}}),n.jsx("div",{className:"absolute inset-0 bg-black/45"}),n.jsxs("div",{className:`\r
          relative\r
          z-10\r
          flex\r
          min-h-[500px]\r
          w-full\r
          flex-col\r
          justify-center\r
          px-4 py-10\r
          sm:min-h-[560px] sm:px-6 sm:py-12\r
          md:min-h-[600px] md:px-10 md:py-14\r
          lg:min-h-[640px] lg:px-[100px] lg:py-16\r
          xl:min-h-[680px] xl:py-20\r
        `,children:[n.jsx("span",{className:"inline-flex w-fit items-center rounded-full bg-[#730042] px-3 py-1 text-[10px] font-semibold tracking-[0.15em] text-white",style:{fontFamily:"'Inter', sans-serif"},children:"CYBER SECURITY"}),n.jsx("h1",{className:`\r
            mt-5\r
            w-full\r
            max-w-[330px]\r
            text-[25px]\r
            font-bold\r
            leading-[1.25]\r
            text-white\r
            sm:max-w-xl\r
            sm:text-[30px]\r
            md:max-w-2xl\r
            md:text-[38px]\r
            lg:max-w-3xl\r
            lg:text-[44px]\r
            xl:text-[48px]\r
          `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Security Built Into Your Business"}),n.jsx("p",{className:`\r
            mt-6\r
            w-full\r
            max-w-[330px]\r
            text-[13px]\r
            leading-[1.7]\r
            text-white/90\r
            sm:max-w-xl\r
            sm:text-[14px]\r
            md:max-w-2xl\r
            md:text-[15px]\r
            lg:max-w-2xl\r
            lg:text-[16px]\r
            lg:leading-[1.75]\r
          `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Cyber threats can affect more than your technology. They can disrupt operations, expose sensitive information and impact the trust your customers place in your business."}),n.jsx("p",{className:`\r
            mt-4\r
            w-full\r
            max-w-[330px]\r
            text-[13px]\r
            leading-[1.7]\r
            text-white/90\r
            sm:max-w-xl\r
            sm:text-[14px]\r
            md:max-w-2xl\r
            md:text-[15px]\r
            lg:max-w-2xl\r
            lg:text-[16px]\r
            lg:leading-[1.75]\r
          `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"TechTorch helps organizations strengthen their security posture with practical cybersecurity solutions designed around their systems, data, people and business requirements."}),n.jsxs("button",{type:"button",onClick:()=>r("/secure-business"),className:`\r
    mt-8\r
    inline-flex\r
    w-fit\r
    items-center\r
    gap-2\r
    rounded-[6px]\r
    bg-[#730042]\r
    px-6\r
    py-3\r
    text-xs\r
    font-semibold\r
    tracking-wide\r
    text-white\r
    transition-colors\r
    duration-300\r
    hover:bg-white\r
    hover:text-[#730042]\r
    sm:text-sm\r
  `,style:{fontFamily:"'Inter', sans-serif"},children:["Secure Your Business",n.jsx("span",{"aria-hidden":"true",children:"→"})]})]})]})}export{a as default};
