import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as n}from"./vendor-router-L4ZCoGSs.js";import{w as p,O as d,z as l,s as h}from"./index-BThRNyH6.js";import{C as g}from"./chart-line-B_0B5Rbj.js";const m="#7A1F3D",s="#1B1B2A",x="#5b5a63",b=[{num:"01",icon:p,title:"Storefront Design",body:"Create responsive online storefronts that provide customers with an easy way to browse and interact with your business."},{num:"02",icon:d,title:"Product Management",body:"Manage product listings, inventory information, pricing and promotions through an organized platform."},{num:"03",icon:l,title:"Payment Processing",body:"Support online transactions through payment gateway capabilities designed for the purchasing process."},{num:"04",icon:h,title:"Customer Relationship Tools",body:"Manage customer information, preferences and purchase history to support customer engagement and service."},{num:"05",icon:g,title:"Analytics & Reporting",body:"Review sales performance, customer trends and website activity through reporting and analytics."}];function f({num:a,icon:t,title:o,body:i,index:r,isVisible:c}){return e.jsxs("article",{className:`ecommerce-card ${c?"ecommerce-card-visible":""}`,style:{transitionDelay:c?`${r*140}ms`:"0ms"},children:[e.jsxs("div",{className:"ecommerce-card-top",children:[e.jsx("span",{className:"ecommerce-card-icon",children:e.jsx(t,{size:17,strokeWidth:1.8,"aria-hidden":"true"})}),e.jsx("span",{className:"ecommerce-card-number",children:a})]}),e.jsx("h3",{className:"ecommerce-card-title",children:o}),e.jsx("p",{className:"ecommerce-card-body",children:i})]})}function E(){const a=n.useRef(null),[t,o]=n.useState(!1);return n.useEffect(()=>{const i=a.current;if(!i)return;const r=new IntersectionObserver(([c])=>{c.isIntersecting&&(o(!0),r.unobserve(i))},{threshold:.15});return r.observe(i),()=>r.disconnect()},[]),e.jsxs("section",{ref:a,className:"ecommerce-capabilities-section",children:[e.jsx("style",{children:`

        /* =========================================
           SECTION
        ========================================= */

        .ecommerce-capabilities-section {
          width: 100%;
          overflow: hidden;
          background: #ffffff;
          color: ${s};
          font-family: "Inter", sans-serif;
        }

        /* =========================================
           MAIN WRAPPER
        ========================================= */

        .ecommerce-capabilities-wrapper {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;
          padding: 80px 100px;
          box-sizing: border-box;
        }

        /* =========================================
           HEADER
        ========================================= */

        .ecommerce-capabilities-label {
          margin: 0 0 14px;
          color: ${m};
          font-family: "Inter", sans-serif;
          font-size: 10px;
          font-weight: 700;
          line-height: 1.4;
          letter-spacing: 0.08em;
        }

        .ecommerce-capabilities-heading {
          margin: 0 0 48px;
          max-width: 900px;
          color: ${s};
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 38px;
          font-weight: 700;
          line-height: 1.2;
          letter-spacing: -0.025em;
        }

        /* =========================================
           GRID
        ========================================= */

        .ecommerce-capabilities-grid {
          display: grid;
          grid-template-columns: repeat(6, minmax(0, 1fr));
          gap: 20px;
        }

        .ecommerce-capabilities-card-wrapper {
          min-width: 0;
        }

        /* First two cards */
        .ecommerce-capabilities-card-wrapper:nth-child(1),
        .ecommerce-capabilities-card-wrapper:nth-child(2) {
          grid-column: span 3;
        }

        /* Last three cards */
        .ecommerce-capabilities-card-wrapper:nth-child(3),
        .ecommerce-capabilities-card-wrapper:nth-child(4),
        .ecommerce-capabilities-card-wrapper:nth-child(5) {
          grid-column: span 2;
        }

        /* =========================================
           CARD
        ========================================= */

        .ecommerce-card {
          min-height: 220px;
          height: 100%;
          padding: 24px;
          box-sizing: border-box;

          display: flex;
          flex-direction: column;

          background: #ffffff;
          border: 1px solid #ece9e4;
          border-radius: 16px;

          opacity: 0;
          transform: translateY(32px) scale(0.97);

          transition:
            opacity 700ms ease,
            transform 700ms cubic-bezier(0.22, 1, 0.36, 1),
            box-shadow 350ms ease,
            border-color 350ms ease;
        }

        .ecommerce-card-visible {
          opacity: 1;
          transform: translateY(0) scale(1);
        }

        .ecommerce-card:hover {
          transform: translateY(-8px) scale(1);
          border-color: rgba(122, 31, 61, 0.16);
          box-shadow: 0 16px 35px rgba(122, 31, 61, 0.10);
        }

        /* =========================================
           CARD TOP
        ========================================= */

        .ecommerce-card-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 15px;
          margin-bottom: 22px;
        }

        .ecommerce-card-icon {
          width: 40px;
          height: 40px;
          flex-shrink: 0;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 9px;
          background: #fbeef1;
          color: ${m};
        }

        .ecommerce-card-number {
          color: #e3d3d9;
          font-family: "Inter", sans-serif;
          font-size: 18px;
          font-weight: 700;
          line-height: 1;
        }

        /* =========================================
           CARD CONTENT
        ========================================= */

        .ecommerce-card-title {
          margin: 0 0 10px;
          color: ${s};
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 17px;
          font-weight: 700;
          line-height: 1.35;
        }

        .ecommerce-card-body {
          margin: 0;
          color: ${x};
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 400;
          line-height: 1.7;
        }

        /* =========================================
           TABLET
        ========================================= */

        @media (max-width: 1200px) {
          .ecommerce-capabilities-wrapper {
            padding-left: 40px;
            padding-right: 40px;
            padding-top: 70px;
            padding-bottom: 70px;
          }

          .ecommerce-capabilities-heading {
            font-size: 34px;
            margin-bottom: 40px;
          }

          .ecommerce-capabilities-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
          }

          .ecommerce-capabilities-card-wrapper:nth-child(1),
          .ecommerce-capabilities-card-wrapper:nth-child(2),
          .ecommerce-capabilities-card-wrapper:nth-child(3),
          .ecommerce-capabilities-card-wrapper:nth-child(4),
          .ecommerce-capabilities-card-wrapper:nth-child(5) {
            grid-column: span 1;
          }

          .ecommerce-card {
            min-height: 235px;
          }
        }

        /* =========================================
           MOBILE
        ========================================= */

        @media (max-width: 700px) {
          .ecommerce-capabilities-wrapper {
            padding-left: 24px;
            padding-right: 24px;
            padding-top: 56px;
            padding-bottom: 56px;
          }

          .ecommerce-capabilities-label {
            margin-bottom: 12px;
            font-size: 9px;
          }

          .ecommerce-capabilities-heading {
            margin-bottom: 30px;
            font-size: 28px;
            line-height: 1.22;
          }

          .ecommerce-capabilities-grid {
            grid-template-columns: 1fr;
            gap: 15px;
          }

          .ecommerce-capabilities-card-wrapper:nth-child(1),
          .ecommerce-capabilities-card-wrapper:nth-child(2),
          .ecommerce-capabilities-card-wrapper:nth-child(3),
          .ecommerce-capabilities-card-wrapper:nth-child(4),
          .ecommerce-capabilities-card-wrapper:nth-child(5) {
            grid-column: span 1;
          }

          .ecommerce-card {
            min-height: 215px;
            padding: 21px;
            border-radius: 14px;
          }

          .ecommerce-card-top {
            margin-bottom: 20px;
          }

          .ecommerce-card-icon {
            width: 38px;
            height: 38px;
          }

          .ecommerce-card-number {
            font-size: 16px;
          }

          .ecommerce-card-title {
            font-size: 16px;
          }

          .ecommerce-card-body {
            font-size: 12.5px;
            line-height: 1.65;
          }
        }

        /* =========================================
           SMALL MOBILE
        ========================================= */

        @media (max-width: 480px) {
          .ecommerce-capabilities-wrapper {
            padding-left: 16px;
            padding-right: 16px;
            padding-top: 48px;
            padding-bottom: 48px;
          }

          .ecommerce-capabilities-heading {
            font-size: 24px;
            margin-bottom: 26px;
          }

          .ecommerce-capabilities-grid {
            gap: 13px;
          }

          .ecommerce-card {
            min-height: 205px;
            padding: 19px;
          }

          .ecommerce-card-title {
            font-size: 15px;
          }

          .ecommerce-card-body {
            font-size: 12px;
          }
        }

        /* =========================================
           REDUCED MOTION
        ========================================= */

        @media (prefers-reduced-motion: reduce) {
          .ecommerce-card {
            opacity: 1;
            transform: none;
            transition: none;
          }

          .ecommerce-card:hover {
            transform: none;
          }
        }
      `}),e.jsxs("div",{className:"ecommerce-capabilities-wrapper",children:[e.jsx("p",{className:"ecommerce-capabilities-label",children:"E-COMMERCE CAPABILITIES"}),e.jsx("h2",{className:"ecommerce-capabilities-heading",children:"Key Capabilities for Your Online Business"}),e.jsx("div",{className:"ecommerce-capabilities-grid",children:b.map((i,r)=>e.jsx("div",{className:"ecommerce-capabilities-card-wrapper",children:e.jsx(f,{...i,index:r,isVisible:t})},i.num))})]})]})}export{E as default};
