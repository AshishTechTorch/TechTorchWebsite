import{j as e}from"./vendor-query-PraSc8EQ.js";import{L as t}from"./vendor-router-L4ZCoGSs.js";import{t as s,A as n,r as o}from"./index-BThRNyH6.js";import{N as p}from"./network-Bh2G015s.js";import{S as c}from"./sparkles-y22GUl0e.js";const a={name:"fingerprint-pattern",size:24,node:[["path",{d:"M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4",key:"1nerag"}],["path",{d:"M14 13.12c0 2.38 0 6.38-1 8.88",key:"o46ks0"}],["path",{d:"M17.29 21.02c.12-.6.43-2.3.5-3.02",key:"ptglia"}],["path",{d:"M2 12a10 10 0 0 1 18-6",key:"ydlgp0"}],["path",{d:"M2 16h.01",key:"1gqxmh"}],["path",{d:"M21.8 16c.2-2 .131-5.354 0-6",key:"drycrb"}],["path",{d:"M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2",key:"1tidbn"}],["path",{d:"M8.65 22c.21-.66.45-1.32.57-2",key:"13wd9y"}],["path",{d:"M9 6.8a6 6 0 0 1 9 5.2v2",key:"1fr1j5"}]],aliases:["fingerprint"]};a.node;const d=s(a),x=[{icon:p,title:"Infrastructure-Free Deployment"},{icon:o,title:"Zero Upfront Complexity"},{icon:d,title:"Enterprise Model Governance"},{icon:c,title:"Future-Ready Integration"}];function v(){return e.jsxs(e.Fragment,{children:[e.jsx("section",{className:"ai-service-hero",children:e.jsxs("div",{className:"ai-service-hero-container",children:[e.jsxs("div",{className:"ai-service-eyebrow",children:[e.jsx("span",{className:"ai-service-eyebrow-dot"}),e.jsx("span",{className:"ai-service-eyebrow-text",children:"Artificial Intelligence as a Service"})]}),e.jsx("h1",{className:"ai-service-title",children:"Artificial Intelligence as a Service for Modern Businesses"}),e.jsxs("div",{className:"ai-service-description",children:[e.jsx("p",{children:"At TechTorch Solutions, we provide Artificial Intelligence as a Service that enables businesses to harness the power of AI without the complexity of building and maintaining their own infrastructure."}),e.jsx("p",{children:"Our approach is focused on making advanced technology more accessible to businesses while helping them move towards a more efficient, technology-driven and future-ready environment."})]}),e.jsxs(t,{to:"/talk-to-expert",className:"ai-service-cta",children:[e.jsx("span",{children:"Talk to Our Experts"}),e.jsx(n,{className:"ai-service-cta-icon"})]}),e.jsx("div",{className:"ai-service-divider"}),e.jsx("div",{className:"ai-service-features",children:x.map(({icon:r,title:i})=>e.jsxs("div",{className:"ai-service-feature",children:[e.jsx(r,{className:"ai-service-feature-icon"}),e.jsx("span",{className:"ai-service-feature-title",children:i})]},i))})]})}),e.jsx("style",{children:`
        /* =====================================================
           HERO
        ====================================================== */

        .ai-service-hero {
          width: 100%;
          min-height: 640px;
          display: flex;
          align-items: center;
          overflow: hidden;

          background:
            radial-gradient(
              120% 140% at 15% 10%,
              #5c0f38 0%,
              #3a0a26 45%,
              #24061a 100%
            );
        }

        .ai-service-hero-container {
          width: 100%;
          padding-left: 100px;
          padding-right: 100px;
          padding-top: 80px;
          padding-bottom: 80px;
        }

        /* =====================================================
           EYEBROW
        ====================================================== */

        .ai-service-eyebrow {
          display: inline-flex;
          align-items: center;
          gap: 9px;

          margin-bottom: 24px;
          padding: 7px 15px;

          border: 1px solid rgba(255, 255, 255, 0.15);
          border-radius: 999px;

          background: rgba(255, 255, 255, 0.05);
        }

        .ai-service-eyebrow-dot {
          width: 6px;
          height: 6px;
          flex-shrink: 0;

          border-radius: 50%;
          background: #fda4af;
        }

        .ai-service-eyebrow-text {
          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 500;
          line-height: 1.4;
          letter-spacing: 0.02em;
          color: rgba(255, 241, 242, 0.9);
        }

        /* =====================================================
           MAIN TITLE
        ====================================================== */

        .ai-service-title {
          width: 100%;
          max-width: 850px;

          margin: 0 0 20px 0;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 48px;
          font-weight: 700;
          line-height: 1.15;
          letter-spacing: -0.025em;

          color: #ffffff;
        }

        /* =====================================================
           DESCRIPTION
        ====================================================== */

        .ai-service-description {
          width: 100%;
          max-width: 760px;

          display: flex;
          flex-direction: column;
          gap: 13px;

          margin-bottom: 28px;
        }

        .ai-service-description p {
          margin: 0;

          font-family: "Inter", sans-serif;
          font-size: 15px;
          font-weight: 400;
          line-height: 1.7;

          color: rgba(255, 241, 242, 0.7);
        }

        .ai-service-description p:last-child {
          color: rgba(255, 241, 242, 0.55);
        }

        /* =====================================================
           CTA
        ====================================================== */

        .ai-service-cta {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 9px;

          margin-bottom: 42px;
          padding: 12px 24px;

          border: none;
          border-radius: 6px;

          background: #ffffff;

          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 600;

          color: #3a0a26;

          cursor: pointer;

          transition:
            transform 0.3s ease,
            background-color 0.3s ease,
            color 0.3s ease,
            box-shadow 0.3s ease;
        }

        .ai-service-cta:hover {
          transform: translateY(-2px);
          background: #730042;
          color: #ffffff;
          box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }

        .ai-service-cta-icon {
          width: 16px;
          height: 16px;
          transition: transform 0.3s ease;
        }

        .ai-service-cta:hover .ai-service-cta-icon {
          transform: translateX(3px);
        }

        /* =====================================================
           DIVIDER
        ====================================================== */

        .ai-service-divider {
          width: 100%;
          height: 1px;

          margin-bottom: 22px;

          background: rgba(255, 255, 255, 0.1);
        }

        /* =====================================================
           FEATURES
        ====================================================== */

        .ai-service-features {
          width: 100%;

          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));

          gap: 16px;
        }

        .ai-service-feature {
          min-width: 0;

          display: flex;
          align-items: flex-start;
          gap: 12px;

          padding: 16px;

          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 12px;

          background: rgba(255, 255, 255, 0.03);

          transition:
            background-color 0.3s ease,
            border-color 0.3s ease,
            transform 0.3s ease;
        }

        .ai-service-feature:hover {
          transform: translateY(-2px);
          background: rgba(255, 255, 255, 0.06);
          border-color: rgba(255, 255, 255, 0.16);
        }

        .ai-service-feature-icon {
          width: 17px;
          height: 17px;

          flex-shrink: 0;
          margin-top: 1px;

          stroke-width: 1.8;

          color: rgba(255, 228, 230, 0.8);
        }

        .ai-service-feature-title {
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 500;
          line-height: 1.45;

          color: rgba(255, 255, 255, 0.85);
        }

        /* =====================================================
           LARGE TABLET
           Horizontal spacing: 40px
        ====================================================== */

        @media (max-width: 1200px) {
          .ai-service-hero {
            min-height: 600px;
          }

          .ai-service-hero-container {
            padding-left: 40px;
            padding-right: 40px;
            padding-top: 70px;
            padding-bottom: 70px;
          }

          .ai-service-title {
            max-width: 760px;
            font-size: 44px;
          }

          .ai-service-description {
            max-width: 700px;
          }

          .ai-service-features {
            gap: 12px;
          }

          .ai-service-feature {
            padding: 14px;
          }

          .ai-service-feature-title {
            font-size: 12px;
          }
        }

        /* =====================================================
           TABLET
        ====================================================== */

        @media (max-width: 900px) {
          .ai-service-hero {
            min-height: auto;
          }

          .ai-service-hero-container {
            padding-left: 40px;
            padding-right: 40px;
            padding-top: 60px;
            padding-bottom: 60px;
          }

          .ai-service-eyebrow {
            margin-bottom: 20px;
          }

          .ai-service-title {
            max-width: 700px;
            font-size: 38px;
          }

          .ai-service-description {
            max-width: 680px;
            margin-bottom: 26px;
          }

          .ai-service-description p {
            font-size: 14px;
          }

          .ai-service-cta {
            margin-bottom: 34px;
          }

          .ai-service-features {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 12px;
          }

          .ai-service-feature {
            padding: 15px;
          }
        }

        /* =====================================================
           MOBILE
           Horizontal spacing: 24px
        ====================================================== */

        @media (max-width: 700px) {
          .ai-service-hero-container {
            padding-left: 24px;
            padding-right: 24px;
            padding-top: 50px;
            padding-bottom: 50px;
          }

          .ai-service-eyebrow {
            margin-bottom: 18px;
            padding: 6px 12px;
            gap: 7px;
          }

          .ai-service-eyebrow-dot {
            width: 5px;
            height: 5px;
          }

          .ai-service-eyebrow-text {
            font-size: 9px;
          }

          .ai-service-title {
            max-width: 100%;
            margin-bottom: 18px;

            font-size: 30px;
            line-height: 1.18;
          }

          .ai-service-description {
            gap: 11px;
            margin-bottom: 24px;
          }

          .ai-service-description p {
            font-size: 12.5px;
            line-height: 1.7;
          }

          .ai-service-cta {
            margin-bottom: 32px;
            padding: 11px 20px;
            font-size: 11px;
          }

          .ai-service-cta-icon {
            width: 14px;
            height: 14px;
          }

          .ai-service-divider {
            margin-bottom: 18px;
          }

          .ai-service-features {
            grid-template-columns: 1fr;
            gap: 10px;
          }

          .ai-service-feature {
            align-items: center;
            padding: 13px;
          }

          .ai-service-feature-icon {
            width: 16px;
            height: 16px;
          }

          .ai-service-feature-title {
            font-size: 11.5px;
          }
        }

        /* =====================================================
           SMALL MOBILE
           Horizontal spacing: 16px
        ====================================================== */

        @media (max-width: 480px) {
          .ai-service-hero-container {
            padding-left: 16px;
            padding-right: 16px;
            padding-top: 42px;
            padding-bottom: 42px;
          }

          .ai-service-eyebrow {
            margin-bottom: 16px;
            padding: 5px 10px;
          }

          .ai-service-eyebrow-text {
            font-size: 8.5px;
          }

          .ai-service-title {
            font-size: 26px;
            line-height: 1.2;
          }

          .ai-service-description {
            gap: 10px;
            margin-bottom: 22px;
          }

          .ai-service-description p {
            font-size: 11.5px;
            line-height: 1.7;
          }

          .ai-service-cta {
            width: auto;
            margin-bottom: 28px;
            padding: 10px 17px;
            font-size: 10.5px;
          }

          .ai-service-divider {
            margin-bottom: 16px;
          }

          .ai-service-feature {
            padding: 12px;
            border-radius: 10px;
          }

          .ai-service-feature-title {
            font-size: 11px;
          }
        }
      `})]})}export{v as default};
