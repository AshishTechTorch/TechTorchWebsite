import{j as n}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";import{D as e}from"./database-Dq2-QkKw.js";import{R as t,y as o,b as s}from"./index-BThRNyH6.js";import{S as p}from"./sliders-horizontal-CGLDIiLF.js";const c="#7A1F3D",d=[{icon:e,title:"Centralized Data",body:"Bring important business information together."},{icon:t,title:"Integrated Processes",body:"Connect different business functions through technology."},{icon:o,title:"Reporting & Analytics",body:"Use business information to support better visibility."},{icon:s,title:"Process Automation",body:"Support routine activities through technology-enabled workflows."},{icon:p,title:"Flexible Technology",body:"Adapt solutions to changing business requirements."}];function l(){return n.jsxs(n.Fragment,{children:[n.jsx("style",{children:`

        /* =====================================================
           MAIN SECTION
        ===================================================== */

        .erp-manufacturing-section {
          width: 100%;
          background: #f2f2f5;
          padding: 40px 100px;
          font-family: "Inter", sans-serif;
          overflow: hidden;
          box-sizing: border-box;
        }

        .erp-manufacturing-container {
          width: 100%;
          max-width: 1440px;
          margin: 0 auto;
          padding: 48px;
          border-radius: 28px;
          background: ${c};
          box-sizing: border-box;
        }

        /* =====================================================
           HEADER
        ===================================================== */

        .erp-manufacturing-label {
          margin: 0 0 12px;

          color: #f3d9e2;

          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.16em;
          line-height: 1.4;
        }

        .erp-manufacturing-heading {
          margin: 0 0 14px;

          color: #ffffff;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: clamp(28px, 3vw, 38px);
          font-weight: 700;
          line-height: 1.25;

          letter-spacing: -0.03em;
        }

        .erp-manufacturing-subheading {
          max-width: 720px;

          margin: 0 0 34px;

          color: #e3c3cf;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 14px;
          font-weight: 500;
          line-height: 1.8;
        }

        /* =====================================================
           CARDS
        ===================================================== */

        .erp-manufacturing-grid {
          display: grid;

          grid-template-columns:
            repeat(5, minmax(0, 1fr));

          gap: 16px;

          width: 100%;
        }

        .erp-manufacturing-card {
          min-width: 0;

          padding: 21px 18px;

          border-radius: 15px;

          background: rgba(255, 255, 255, 0.08);

          border: 1px solid rgba(255, 255, 255, 0.12);

          transition:
            transform 0.25s ease,
            background 0.25s ease,
            border-color 0.25s ease;

          box-sizing: border-box;
        }

        .erp-manufacturing-card:hover {
          transform: translateY(-5px);

          background: rgba(255, 255, 255, 0.12);

          border-color: rgba(255, 255, 255, 0.2);
        }

        /* =====================================================
           ICON
        ===================================================== */

        .erp-manufacturing-icon {
          display: block;

          margin-bottom: 16px;

          color: #ffffff;
        }

        /* =====================================================
           CARD TITLE
        ===================================================== */

        .erp-manufacturing-card-title {
          margin: 0 0 8px;

          color: #ffffff;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 14px;
          font-weight: 600;
          line-height: 1.4;
        }

        /* =====================================================
           CARD BODY
        ===================================================== */

        .erp-manufacturing-card-body {
          margin: 0;

          color: #d9b7c4;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 400;
          line-height: 1.7;
        }

        /* =====================================================
           LARGE TABLET
        ===================================================== */

        @media (max-width: 1100px) {

          .erp-manufacturing-section {
            padding: 32px 40px;
          }

          .erp-manufacturing-container {
            padding: 40px;
          }

          .erp-manufacturing-grid {
            grid-template-columns:
              repeat(3, minmax(0, 1fr));
          }
        }

        /* =====================================================
           TABLET
        ===================================================== */

        @media (max-width: 800px) {

          .erp-manufacturing-section {
            padding: 28px 40px;
          }

          .erp-manufacturing-container {
            padding: 34px;
            border-radius: 24px;
          }

          .erp-manufacturing-heading {
            font-size: 30px;
          }

          .erp-manufacturing-subheading {
            font-size: 13.5px;
            line-height: 1.75;
            margin-bottom: 28px;
          }

          .erp-manufacturing-grid {
            grid-template-columns:
              repeat(2, minmax(0, 1fr));

            gap: 14px;
          }

          .erp-manufacturing-card {
            padding: 20px;
          }
        }

        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 600px) {

          .erp-manufacturing-section {
            padding: 24px;
          }

          .erp-manufacturing-container {
            padding: 28px 20px;
            border-radius: 20px;
          }

          .erp-manufacturing-label {
            font-size: 9.5px;
            letter-spacing: 0.13em;
          }

          .erp-manufacturing-heading {
            font-size: 26px;
            line-height: 1.25;
            letter-spacing: -0.02em;
          }

          .erp-manufacturing-subheading {
            font-size: 13px;
            line-height: 1.75;
            margin-bottom: 25px;
          }

          .erp-manufacturing-grid {
            grid-template-columns: 1fr;
            gap: 12px;
          }

          .erp-manufacturing-card {
            padding: 19px;
            border-radius: 14px;
          }

          .erp-manufacturing-icon {
            margin-bottom: 13px;
          }

          .erp-manufacturing-card-title {
            font-size: 14px;
          }

          .erp-manufacturing-card-body {
            font-size: 12px;
          }
        }

        /* =====================================================
           SMALL MOBILE
        ===================================================== */

        @media (max-width: 400px) {

          .erp-manufacturing-section {
            padding: 22px 16px;
          }

          .erp-manufacturing-container {
            padding: 25px 17px;
            border-radius: 18px;
          }

          .erp-manufacturing-heading {
            font-size: 24px;
          }

          .erp-manufacturing-subheading {
            font-size: 12px;
          }

          .erp-manufacturing-card {
            padding: 17px;
          }

          .erp-manufacturing-card-title {
            font-size: 13px;
          }

          .erp-manufacturing-card-body {
            font-size: 11.5px;
          }
        }

        /* =====================================================
           VERY SMALL MOBILE
        ===================================================== */

        @media (max-width: 340px) {

          .erp-manufacturing-section {
            padding: 20px 16px;
          }

          .erp-manufacturing-container {
            padding: 22px 14px;
          }

          .erp-manufacturing-heading {
            font-size: 22px;
          }

          .erp-manufacturing-subheading {
            font-size: 11.5px;
          }
        }

        /* =====================================================
           REDUCED MOTION
        ===================================================== */

        @media (prefers-reduced-motion: reduce) {

          .erp-manufacturing-card {
            transition: none;
          }
        }
      `}),n.jsx("section",{className:"erp-manufacturing-section",children:n.jsxs("div",{className:"erp-manufacturing-container",children:[n.jsxs("div",{children:[n.jsx("p",{className:"erp-manufacturing-label",children:"ERP FOR MANUFACTURING"}),n.jsx("h2",{className:"erp-manufacturing-heading",children:"Bring Core Business Functions Together"}),n.jsx("p",{className:"erp-manufacturing-subheading",children:"Manufacturing businesses depend on different functions working together. Connecting these areas through technology can create a more organized environment for managing business information and processes."})]}),n.jsx("div",{className:"erp-manufacturing-grid",children:d.map(({icon:i,title:a,body:r})=>n.jsxs("div",{className:"erp-manufacturing-card",children:[n.jsx(i,{size:18,strokeWidth:1.8,className:"erp-manufacturing-icon"}),n.jsx("h3",{className:"erp-manufacturing-card-title",children:a}),n.jsx("p",{className:"erp-manufacturing-card-body",children:r})]},a))})]})})]})}export{l as default};
