import{j as e}from"./vendor-query-PraSc8EQ.js";import{d as o,L as l}from"./vendor-router-L4ZCoGSs.js";import{A as c,r as p,J as d}from"./index-BThRNyH6.js";import{A as h}from"./activity-BBAyi7CR.js";const a="#7A1F3D",t="#1B1B2A",i="#5b5a63",x="/healthcarehero.webp",g=[{icon:p,label:"HIPAA & HL7/FHIR Compliant"},{icon:h,label:"Real-Time Diagnostic Telemetry"},{icon:d,label:"Role-Based Clinical Security"}];function w(){const n=o();return e.jsxs("section",{className:"healthcare-hero-section",children:[e.jsx("style",{children:`
        @import url(
          'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap'
        );

        /* =====================================================
           SCOPED BOX SIZING
        ===================================================== */

        .healthcare-hero-section,
        .healthcare-hero-section * {
          box-sizing: border-box;
        }

        /* =====================================================
           MAIN SECTION
        ===================================================== */

        .healthcare-hero-section {
          width: 100%;
          background: #ffffff;
          color: ${t};
          font-family: "Inter", sans-serif;
          overflow: hidden;
        }

        /* =====================================================
           MAIN CONTAINER
        ===================================================== */

        .healthcare-hero-container {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;
          padding: 78px 100px;
        }

        /* =====================================================
           MAIN GRID
        ===================================================== */

        .healthcare-hero-grid {
          display: grid;
          grid-template-columns:
            minmax(0, 1fr)
            minmax(0, 1fr);

          gap: 64px;
          align-items: center;
        }

        /* =====================================================
           LEFT CONTENT
        ===================================================== */

        .healthcare-hero-content {
          min-width: 0;
          max-width: 680px;
        }

        /* =====================================================
           BADGE
        ===================================================== */

        .healthcare-hero-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;

          margin-bottom: 20px;
          padding: 7px 12px;

          border-radius: 999px;

          background: #fbeef1;
          color: ${a};

          font-family: "Inter", sans-serif;
          font-size: 9px;
          line-height: 1.3;
          font-weight: 700;
          letter-spacing: 0.05em;
        }

        .healthcare-hero-badge-dot {
          width: 6px;
          height: 6px;

          flex-shrink: 0;

          border-radius: 50%;
          background: ${a};
        }

        /* =====================================================
           MAIN HEADING
        ===================================================== */

        .healthcare-hero-heading {
          margin: 0 0 22px;
          max-width: 680px;

          font-family: "Plus Jakarta Sans", sans-serif;

          font-size: 44px;
          line-height: 1.13;
          font-weight: 700;

          letter-spacing: -1.2px;

          color: ${t};
        }

        /* =====================================================
           DESCRIPTION
        ===================================================== */

        .healthcare-hero-description {
          max-width: 650px;

          margin: 0 0 14px;

          font-family: "Plus Jakarta Sans", sans-serif;

          font-size: 13px;
          line-height: 1.75;
          font-weight: 500;

          color: ${i};
        }

        .healthcare-hero-description-last {
          margin-bottom: 28px;
        }

        /* =====================================================
           BUTTONS
        ===================================================== */

        .healthcare-hero-actions {
          display: flex;
          align-items: center;
          flex-wrap: wrap;

          gap: 10px;

          margin-bottom: 28px;
        }

        .healthcare-primary-btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;

          gap: 8px;

          min-height: 46px;
          padding: 0 21px;

          border: none;

          /* UPDATED */
          border-radius: 6px;

          background: ${a};
          color: #ffffff;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 600;

          cursor: pointer;

          transition:
            transform 0.2s ease,
            background 0.2s ease;
        }

        .healthcare-primary-btn:hover {
          background: #5c1730;
          transform: translateY(-1px);
        }

        .healthcare-secondary-btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;

          min-height: 46px;
          padding: 0 21px;

          border: 1px solid #d8d5d0;

          /* UPDATED */
          border-radius: 6px;

          background: #ffffff;
          color: ${t};

          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 600;

          cursor: pointer;

          transition:
            border-color 0.2s ease,
            color 0.2s ease,
            background 0.2s ease;
        }

        .healthcare-secondary-btn:hover {
          border-color: ${a};
          color: ${a};
          background: #fffafb;
        }

        /* =====================================================
           TRUST AREA
        ===================================================== */

        .healthcare-trust-area {
          padding-top: 17px;
          border-top: 1px solid #ece9e4;
        }

        .healthcare-trust-list {
          display: flex;
          align-items: center;
          flex-wrap: wrap;

          gap: 14px 24px;
        }

        .healthcare-trust-item {
          display: flex;
          align-items: center;

          gap: 7px;

          min-width: 0;
        }

        .healthcare-trust-item svg {
          flex-shrink: 0;
          color: ${a};
        }

        .healthcare-trust-item span {
          font-family: "Inter", sans-serif;

          font-size: 10px;
          line-height: 1.4;

          color: ${i};
        }

        /* =====================================================
           RIGHT IMAGE AREA
        ===================================================== */

        .healthcare-image-wrapper {
          position: relative;

          width: 100%;
          min-width: 0;

          padding-bottom: 30px;
        }

        /* =====================================================
           HERO IMAGE
        ===================================================== */

        .healthcare-hero-image {
          position: relative;

          width: 100%;
          height: 460px;

          display: block;

          object-fit: cover;
          object-position: center;

          border-radius: 20px;

          background: #e9eef1;

          box-shadow:
            0 18px 45px
            rgba(31, 41, 55, 0.12);

          overflow: hidden;
        }

        /* =====================================================
           IMAGE OVERLAY
        ===================================================== */

        .healthcare-image-overlay {
          position: absolute;
          inset: 0;

          border-radius: 20px;

          pointer-events: none;

          background:
            linear-gradient(
              180deg,
              rgba(0, 0, 0, 0.02) 0%,
              rgba(0, 0, 0, 0) 55%,
              rgba(0, 0, 0, 0.08) 100%
            );
        }

        /* =====================================================
           FLOATING STATUS CARD
        ===================================================== */

        .healthcare-status-card {
          position: absolute;

          left: 22px;
          right: 22px;
          bottom: 0;

          display: flex;
          align-items: center;

          gap: 12px;

          padding: 13px 15px;

          border-radius: 14px;

          background: #ffffff;

          box-shadow:
            0 14px 35px
            rgba(0, 0, 0, 0.13);

          z-index: 3;
        }

        .healthcare-status-icon {
          width: 38px;
          height: 38px;

          display: flex;
          align-items: center;
          justify-content: center;

          flex-shrink: 0;

          border-radius: 10px;

          background: #fbeef1;
          color: ${a};
        }

        .healthcare-status-content {
          flex: 1;
          min-width: 0;
        }

        .healthcare-status-label {
          margin: 0 0 3px;

          font-family: "Inter", sans-serif;

          font-size: 9px;
          line-height: 1.3;
          font-weight: 700;

          letter-spacing: 0.05em;

          color: ${a};
        }

        .healthcare-status-title {
          margin: 0;

          font-family: "Plus Jakarta Sans", sans-serif;

          font-size: 12px;
          line-height: 1.4;
          font-weight: 700;

          color: ${t};

          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        /* =====================================================
           ACTIVE SYNC
        ===================================================== */

        .healthcare-active-sync {
          display: inline-flex;
          align-items: center;

          gap: 5px;

          flex-shrink: 0;

          padding: 5px 9px;

          border-radius: 999px;

          background: #e5f7ec;
          color: #1a9455;

          font-family: "Inter", sans-serif;

          font-size: 9px;
          line-height: 1.3;
          font-weight: 600;
        }

        .healthcare-active-dot {
          width: 6px;
          height: 6px;

          border-radius: 50%;

          background: #1a9455;
        }

        /* =====================================================
           LARGE DESKTOP / LAPTOP
        ===================================================== */

        @media (max-width: 1200px) {
          .healthcare-hero-container {
            padding: 72px 40px;
          }

          .healthcare-hero-grid {
            gap: 48px;
          }

          .healthcare-hero-heading {
            font-size: 40px;
          }

          .healthcare-hero-image {
            height: 420px;
          }
        }

        /* =====================================================
           TABLET
        ===================================================== */

        @media (max-width: 950px) {
          .healthcare-hero-container {
            padding: 60px 40px;
          }

          .healthcare-hero-grid {
            grid-template-columns: 1fr;
            gap: 48px;
          }

          .healthcare-hero-content {
            max-width: 800px;
            width: 100%;
            margin: 0 auto;
          }

          .healthcare-hero-heading {
            max-width: 760px;
            font-size: 38px;
          }

          .healthcare-hero-description {
            max-width: 760px;
          }

          .healthcare-image-wrapper {
            width: 100%;
            max-width: 900px;
            margin: 0 auto;
          }

          .healthcare-hero-image {
            height: 430px;
          }
        }

        /* =====================================================
           SMALL TABLET
        ===================================================== */

        @media (max-width: 700px) {
          .healthcare-hero-container {
            padding: 52px 24px 58px;
          }

          .healthcare-hero-heading {
            font-size: 33px;
            letter-spacing: -0.8px;
          }

          .healthcare-hero-description {
            font-size: 12px;
            line-height: 1.75;
          }

          .healthcare-trust-list {
            gap: 11px 18px;
          }

          .healthcare-hero-image {
            height: 350px;
          }
        }

        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 600px) {
          .healthcare-hero-container {
            padding: 46px 24px 52px;
          }

          .healthcare-hero-grid {
            gap: 40px;
          }

          .healthcare-hero-badge {
            margin-bottom: 16px;

            padding: 6px 10px;

            font-size: 8px;
            letter-spacing: 0.035em;
          }

          .healthcare-hero-badge-dot {
            width: 5px;
            height: 5px;
          }

          .healthcare-hero-heading {
            margin-bottom: 18px;

            font-size: 29px;
            line-height: 1.18;
            letter-spacing: -0.6px;
          }

          .healthcare-hero-description {
            margin-bottom: 12px;

            font-size: 11.5px;
            line-height: 1.75;
          }

          .healthcare-hero-description-last {
            margin-bottom: 23px;
          }

          /* BUTTONS */

          .healthcare-hero-actions {
            align-items: stretch;

            gap: 9px;

            margin-bottom: 24px;
          }

          .healthcare-primary-btn,
          .healthcare-secondary-btn {
            min-height: 44px;

            padding-left: 17px;
            padding-right: 17px;

            font-size: 10.5px;

            /* SAME BUTTON RADIUS */
            border-radius: 6px;
          }

          /* TRUST */

          .healthcare-trust-area {
            padding-top: 15px;
          }

          .healthcare-trust-list {
            display: grid;
            grid-template-columns: 1fr;

            gap: 10px;
          }

          .healthcare-trust-item span {
            font-size: 9.5px;
          }

          /* IMAGE */

          .healthcare-image-wrapper {
            padding-bottom: 27px;
          }

          .healthcare-hero-image {
            height: 310px;

            border-radius: 16px;
          }

          .healthcare-image-overlay {
            border-radius: 16px;
          }

          /* STATUS CARD */

          .healthcare-status-card {
            left: 12px;
            right: 12px;

            gap: 9px;

            padding: 10px 11px;

            border-radius: 11px;
          }

          .healthcare-status-icon {
            width: 32px;
            height: 32px;

            border-radius: 8px;
          }

          .healthcare-status-icon svg {
            width: 15px;
            height: 15px;
          }

          .healthcare-status-label {
            font-size: 7px;
          }

          .healthcare-status-title {
            font-size: 10px;
          }

          .healthcare-active-sync {
            padding: 4px 7px;
            font-size: 8px;
          }

          .healthcare-active-dot {
            width: 5px;
            height: 5px;
          }
        }

        /* =====================================================
           SMALL MOBILE
        ===================================================== */

        @media (max-width: 480px) {
          .healthcare-hero-container {
            padding: 40px 16px 48px;
          }

          .healthcare-hero-heading {
            font-size: 27px;
            line-height: 1.2;
          }

          .healthcare-hero-description {
            font-size: 11px;
            line-height: 1.7;
          }

          .healthcare-hero-actions {
            flex-direction: column;
            width: 100%;
          }

          .healthcare-primary-btn,
          .healthcare-secondary-btn {
            width: 100%;
            min-height: 43px;

            border-radius: 6px;
          }

          .healthcare-hero-image {
            height: 275px;
            border-radius: 14px;
          }

          .healthcare-image-overlay {
            border-radius: 14px;
          }

          .healthcare-status-card {
            left: 8px;
            right: 8px;

            padding: 9px;
            gap: 8px;
          }

          .healthcare-status-icon {
            width: 29px;
            height: 29px;
          }

          .healthcare-status-title {
            font-size: 9px;
          }

          .healthcare-active-sync {
            display: none;
          }
        }

        /* =====================================================
           VERY SMALL MOBILE
        ===================================================== */

        @media (max-width: 340px) {
          .healthcare-hero-container {
            padding: 38px 16px 42px;
          }

          .healthcare-hero-heading {
            font-size: 24px;
          }

          .healthcare-hero-description {
            font-size: 10px;
          }

          .healthcare-primary-btn,
          .healthcare-secondary-btn {
            border-radius: 6px;
          }

          .healthcare-hero-image {
            height: 245px;
          }

          .healthcare-status-title {
            font-size: 8.5px;
          }
        }

        /* =====================================================
           REDUCED MOTION
        ===================================================== */

        @media (prefers-reduced-motion: reduce) {
          .healthcare-primary-btn,
          .healthcare-secondary-btn {
            transition: none;
          }

          .healthcare-primary-btn:hover {
            transform: none;
          }
        }
      `}),e.jsx("div",{className:"healthcare-hero-container",children:e.jsxs("div",{className:"healthcare-hero-grid",children:[e.jsxs("div",{className:"healthcare-hero-content",children:[e.jsxs("span",{className:"healthcare-hero-badge",children:[e.jsx("span",{className:"healthcare-hero-badge-dot"}),"HEALTHCARE & LIFE SCIENCES • CONNECTED CARE PLATFORMS"]}),e.jsx("h1",{className:"healthcare-hero-heading",children:"Technology for More Connected Healthcare Operations"}),e.jsx("p",{className:"healthcare-hero-description",children:"Healthcare organizations manage patients, people, resources, information and daily operations across multiple functions. The right technology can help bring these activities together in a more organized and connected environment."}),e.jsx("p",{className:`\r
                healthcare-hero-description\r
                healthcare-hero-description-last\r
              `,children:"TechTorch provides healthcare and hospital management solutions designed to support the operational needs of hospitals, clinics, diagnostic centers and other healthcare providers."}),e.jsxs("div",{className:"healthcare-hero-actions",children:[e.jsxs(l,{to:"/talk-to-expert",className:"healthcare-primary-btn",children:["Talk to Our Experts",e.jsx(c,{size:15})]}),e.jsx("button",{type:"button",className:"healthcare-secondary-btn",onClick:()=>n("/healthcare-get-in-touch"),children:"Get in Touch"})]}),e.jsx("div",{className:"healthcare-trust-area",children:e.jsx("div",{className:"healthcare-trust-list",children:g.map(({icon:s,label:r})=>e.jsxs("div",{className:"healthcare-trust-item",children:[e.jsx(s,{size:14,strokeWidth:1.8}),e.jsx("span",{children:r})]},r))})})]}),e.jsxs("div",{className:"healthcare-image-wrapper",children:[e.jsx("img",{src:x,alt:"Healthcare team reviewing diagnostic monitors",className:"healthcare-hero-image"}),e.jsx("div",{className:"healthcare-image-overlay"}),e.jsxs("div",{className:"healthcare-status-card",children:[e.jsx("span",{className:"healthcare-status-icon",children:e.jsx(h,{size:17,strokeWidth:1.8})}),e.jsxs("div",{className:"healthcare-status-content",children:[e.jsx("p",{className:"healthcare-status-label",children:"TORCHX HEALTHCARE SUITE"}),e.jsx("p",{className:"healthcare-status-title",children:"Centralized Hospital Telemetry Node"})]}),e.jsxs("span",{className:"healthcare-active-sync",children:[e.jsx("span",{className:"healthcare-active-dot"}),"Active Sync"]})]})]})]})})]})}export{w as default};
