import{t as o}from"./index-BThRNyH6.js";const e={name:"code",size:24,node:[["path",{d:"m16 18 6-6-6-6",key:"eg8j8"}],["path",{d:"m8 6-6 6 6 6",key:"ppft3o"}]]};e.node;const a=o(e);export{a as C};
