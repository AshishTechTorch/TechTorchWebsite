import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as s}from"./vendor-router-L4ZCoGSs.js";import{t as l,T as d,s as p}from"./index-BThRNyH6.js";import{L as x}from"./link-2-WSmG37JH.js";const c={name:"life-buoy",size:24,node:[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m4.93 4.93 4.24 4.24",key:"1ymg45"}],["path",{d:"m14.83 9.17 4.24-4.24",key:"1cb5xl"}],["path",{d:"m14.83 14.83 4.24 4.24",key:"q42g0n"}],["path",{d:"m9.17 14.83-4.24 4.24",key:"bqpfvv"}],["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}]]};c.node;const b=l(c);const m={name:"square-pen",size:24,node:[["path",{d:"M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7",key:"1m0v6g"}],["path",{d:"M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z",key:"ohrbg2"}]],aliases:["pen-box","edit","pen-square"]};m.node;const u=l(m),f=[{number:"01",icon:d,title:"Scalable",description:"Technology that can grow as your requirements grow."},{number:"02",icon:u,title:"Customizable",description:"Solutions that can adapt to your business processes."},{number:"03",icon:x,title:"Connected",description:"Technology that helps bring different business functions together."},{number:"04",icon:p,title:"Human-Centered",description:"Tools designed to be usable by the people who rely on them every day."},{number:"05",icon:b,title:"Supported",description:"A technology relationship that continues beyond implementation."}];function N(){const o=s.useRef(null),[a,i]=s.useState(!1);return s.useEffect(()=>{const n=o.current;if(!n)return;const t=new IntersectionObserver(([r])=>{r.isIntersecting?i(!0):i(!1)},{threshold:.2});return t.observe(n),()=>{t.disconnect()}},[]),e.jsxs("section",{ref:o,className:`\r
        w-full\r
        overflow-hidden\r
        bg-[#FAF6F1]\r
        px-4 py-10\r
        sm:px-6 sm:py-12\r
        md:px-10 md:py-14\r
        lg:px-[100px] lg:py-16\r
        xl:py-20\r
      `,children:[e.jsxs("div",{className:"w-full",children:[e.jsx("span",{className:`\r
            text-[9px]\r
            font-semibold\r
            tracking-[0.15em]\r
            text-[#6B1E3F]\r
            sm:text-[10px]\r
          `,style:{fontFamily:"'Inter', sans-serif"},children:"INSTITUTIONAL COMMITMENT"}),e.jsx("h1",{className:`\r
            mt-3\r
            max-w-xl\r
            text-[23px]\r
            font-semibold\r
            leading-[1.3]\r
            text-[#6B1E3F]\r
            sm:text-[26px]\r
            md:text-[30px]\r
            lg:text-3xl\r
          `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Technology Should Be a Long-Term Advantage"}),e.jsx("p",{className:`\r
            mt-4\r
            max-w-3xl\r
            text-[13px]\r
            leading-[1.75]\r
            text-slate-600\r
            sm:text-[14px]\r
            sm:leading-relaxed\r
            md:text-[15px]\r
          `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Choosing technology isn't just about solving today's problem. It's about creating a foundation that can continue to support the business tomorrow. TechTorch focuses on creating solutions that are scalable, customizable, practical, and built around real business requirements. Its software development services also emphasize secure, scalable, cost-effective solutions and ongoing support."}),e.jsx("div",{className:`\r
            mt-8\r
            grid\r
            grid-cols-1\r
            gap-4\r
            sm:mt-10\r
            sm:grid-cols-2\r
            md:grid-cols-3\r
            lg:grid-cols-5\r
          `,children:f.map((n,t)=>{const r=n.icon;return e.jsxs("div",{className:`
                  commitment-card
                  group
                  relative
                  w-full
                  min-w-0
                  rounded-md
                  border
                  border-slate-200
                  bg-white
                  p-5
                  sm:p-6
                  ${a?"commitment-card-visible":"commitment-card-hidden"}
                `,style:{transitionDelay:a?`${t*180}ms`:"0ms"},children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsx("span",{className:`\r
                      card-number\r
                      text-2xl\r
                      font-bold\r
                      text-slate-300\r
                    `,style:{fontFamily:"'Inter', sans-serif"},children:n.number}),e.jsx("span",{className:`\r
                      card-icon\r
                      flex\r
                      h-8\r
                      w-8\r
                      shrink-0\r
                      items-center\r
                      justify-center\r
                      rounded-full\r
                      bg-rose-100\r
                      text-[#6B1E3F]\r
                    `,children:e.jsx(r,{size:15,strokeWidth:2})})]}),e.jsx("h3",{className:`\r
                    mt-4\r
                    text-[14px]\r
                    font-semibold\r
                    leading-snug\r
                    text-slate-900\r
                    sm:text-[15px]\r
                    md:text-base\r
                  `,style:{fontFamily:"'Inter', sans-serif"},children:n.title}),e.jsx("p",{className:`\r
                    mt-2\r
                    text-[12.5px]\r
                    leading-[1.7]\r
                    text-slate-500\r
                    sm:text-[13px]\r
                    md:text-sm\r
                  `,style:{fontFamily:"'Inter', sans-serif"},children:n.description}),e.jsx("div",{className:"card-bottom-line"})]},n.number)})})]}),e.jsx("style",{children:`
        /* ==========================================
           SECTION ENTRY
        ========================================== */

        .commitment-card {
          opacity: 0;
          transform: translateY(45px) scale(0.88);
          filter: blur(5px);

          transition:
            opacity 0.7s ease,
            transform 0.7s cubic-bezier(0.22, 1, 0.36, 1),
            filter 0.7s ease,
            box-shadow 0.35s ease,
            border-color 0.35s ease;
        }

        .commitment-card-visible {
          opacity: 1;
          transform: translateY(0) scale(1);
          filter: blur(0);
        }

        /* ==========================================
           CARD HOVER
           Only CARD moves
           ICON DOES NOT MOVE
        ========================================== */

        .commitment-card-visible:hover {
          transform: translateY(-8px) scale(1.025);

          border-color: rgba(107, 30, 63, 0.25);

          box-shadow:
            0 18px 35px rgba(107, 30, 63, 0.12),
            0 5px 12px rgba(0, 0, 0, 0.04);
        }

        /* ==========================================
           ICON
           No hover animation
        ========================================== */

        .card-icon {
          transform: none !important;
          transition: none !important;
        }

        .commitment-card:hover .card-icon {
          transform: none !important;
          box-shadow: none !important;
          background-color: #FCE7F3;
          color: #6B1E3F;
        }

        /* ==========================================
           NUMBER
        ========================================== */

        .card-number {
          transition: color 0.3s ease;
        }

        .commitment-card-visible:hover .card-number {
          color: rgba(107, 30, 63, 0.28);
        }

        /* ==========================================
           BOTTOM LINE
        ========================================== */

        .card-bottom-line {
          position: absolute;

          left: 0;
          bottom: 0;

          width: 100%;
          height: 3px;

          background: #6B1E3F;

          transform: scaleX(0);
          transform-origin: left;

          transition:
            transform 0.5s cubic-bezier(0.22, 1, 0.36, 1);
        }

        .commitment-card-visible:hover .card-bottom-line {
          transform: scaleX(1);
        }

        /* ==========================================
           MOBILE
        ========================================== */

        @media (hover: none) {
          .commitment-card-visible:hover {
            transform: translateY(0) scale(1);
            box-shadow: none;
          }

          .commitment-card-visible:hover .card-number {
            color: #cbd5e1;
          }

          .commitment-card-visible:hover .card-bottom-line {
            transform: scaleX(0);
          }
        }

        /* ==========================================
           REDUCED MOTION
        ========================================== */

        @media (prefers-reduced-motion: reduce) {
          .commitment-card {
            opacity: 1;
            transform: none;
            filter: none;
            transition: none !important;
          }

          .card-icon,
          .card-number,
          .card-bottom-line {
            transition: none !important;
          }
        }
      `})]})}export{N as default};
