import{j as e}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";function t(){return e.jsxs("div",{className:"operations-page",children:[e.jsxs("section",{className:"operations-hero",children:[e.jsx("img",{loading:"lazy",decoding:"async",className:"operations-hero-image",src:"/OpManagement.webp",alt:"Operations control room"}),e.jsx("div",{className:"operations-hero-overlay"}),e.jsxs("div",{className:"operations-hero-content",children:[e.jsxs("div",{className:"operations-badge",children:[e.jsx("span",{className:"operations-badge-icon",children:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.8",children:[e.jsx("circle",{cx:"12",cy:"12",r:"3"}),e.jsx("circle",{cx:"5",cy:"7",r:"1.5"}),e.jsx("circle",{cx:"19",cy:"7",r:"1.5"}),e.jsx("circle",{cx:"5",cy:"17",r:"1.5"}),e.jsx("circle",{cx:"19",cy:"17",r:"1.5"}),e.jsx("path",{d:"M9.5 10 6.2 8"}),e.jsx("path",{d:"M14.5 10 17.8 8"}),e.jsx("path",{d:"M9.5 14 6.2 16"}),e.jsx("path",{d:"M14.5 14 17.8 16"})]})}),"OPERATIONS MANAGEMENT"]}),e.jsxs("h1",{children:["Intelligent Operations",e.jsx("br",{}),"Management:",e.jsx("br",{}),"Orchestrating Excellence"]}),e.jsxs("div",{className:"operations-hero-buttons",children:[e.jsx("button",{type:"button",className:"operations-primary-btn",onClick:()=>document.getElementById("workflow-automation")?.scrollIntoView({behavior:"smooth",block:"start"}),children:"Automate Workflows"}),e.jsx("button",{type:"button",className:"operations-secondary-btn",onClick:()=>document.getElementById("operations-analytics")?.scrollIntoView({behavior:"smooth",block:"start"}),children:"View Analytics"})]})]})]}),e.jsxs("section",{className:"operations-intro",children:[e.jsx("h2",{children:"Transforming Complexity into Clarity"}),e.jsx("p",{children:"TechTorch empowers enterprise teams by dismantling departmental silos and surfacing actionable insights. Through advanced predictive maintenance and resilient operational frameworks, we orchestrate excellence across every layer of your infrastructure, reducing friction and amplifying strategic outcomes."})]}),e.jsxs("section",{className:"operations-features",children:[e.jsx("div",{className:"workflow-card",id:"workflow-automation",style:{scrollMarginTop:"110px"},children:e.jsxs("div",{className:"workflow-content",children:[e.jsx("div",{className:"feature-icon workflow-icon",children:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.8",children:[e.jsx("rect",{x:"4",y:"4",width:"6",height:"6",rx:"1"}),e.jsx("rect",{x:"14",y:"14",width:"6",height:"6",rx:"1"}),e.jsx("path",{d:"M10 7h4a2 2 0 0 1 2 2v5"}),e.jsx("path",{d:"M14 17h-4a2 2 0 0 1-2-2v-5"})]})}),e.jsx("h3",{children:"Workflow Automation"}),e.jsx("p",{children:"Streamline complex processes with intelligent automation that adapts to real-time data inputs. Eliminate manual handoffs and ensure consistent execution across distributed teams."}),e.jsxs("div",{className:"workflow-stats",children:[e.jsxs("div",{className:"stat-box",children:[e.jsx("strong",{children:"40%"}),e.jsx("span",{children:"REDUCTION IN MANUAL TASKS"})]}),e.jsxs("div",{className:"stat-box",children:[e.jsx("strong",{children:"3x"}),e.jsx("span",{children:"FASTER RESOLUTION TIMES"})]})]})]})}),e.jsxs("div",{className:"maintenance-card",id:"operations-analytics",style:{scrollMarginTop:"110px"},children:[e.jsx("div",{className:"feature-icon maintenance-icon",children:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.8",children:[e.jsx("path",{d:"M4 17l5-5 4 3 7-8"}),e.jsx("path",{d:"M17 7h3v3"}),e.jsx("circle",{cx:"4",cy:"17",r:"1.2"}),e.jsx("circle",{cx:"9",cy:"12",r:"1.2"}),e.jsx("circle",{cx:"13",cy:"15",r:"1.2"}),e.jsx("circle",{cx:"20",cy:"7",r:"1.2"})]})}),e.jsxs("h3",{children:["Predictive",e.jsx("br",{}),"Maintenance"]}),e.jsx("p",{children:"Anticipate system failures before they occur. TechTorch utilizes machine learning models to analyze operational telemetry, ensuring maximum uptime and reliability for critical infrastructure."}),e.jsx("div",{className:"maintenance-chart",children:e.jsxs("div",{className:"chart-bars",children:[e.jsx("span",{className:"bar bar-1"}),e.jsx("span",{className:"bar bar-2"}),e.jsx("span",{className:"bar bar-3"}),e.jsx("span",{className:"bar bar-4"}),e.jsx("span",{className:"bar bar-5"}),e.jsx("span",{className:"bar bar-6"})]})})]})]}),e.jsxs("section",{className:"resilience-card",children:[e.jsxs("div",{className:"resilience-content",children:[e.jsx("div",{className:"feature-icon resilience-icon",children:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.8",children:[e.jsx("path",{d:"M12 3 19 6v5c0 4.5-2.8 8-7 10-4.2-2-7-5.5-7-10V6l7-3Z"}),e.jsx("path",{d:"m9 12 2 2 4-4"})]})}),e.jsxs("h2",{children:["Operational",e.jsx("br",{}),"Resilience"]}),e.jsx("p",{children:"Build robust operational frameworks designed to withstand disruption. TechTorch provides dynamic resource allocation, automated failovers, and comprehensive audit trails to maintain continuity under pressure."}),e.jsxs("div",{className:"resilience-list",children:[e.jsxs("div",{className:"resilience-item",children:[e.jsx("span",{children:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"8"}),e.jsx("path",{d:"m9 12 2 2 4-4"})]})}),"Automated Incident Response"]}),e.jsxs("div",{className:"resilience-item",children:[e.jsx("span",{children:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"8"}),e.jsx("path",{d:"m9 12 2 2 4-4"})]})}),"Dynamic Load Balancing"]}),e.jsxs("div",{className:"resilience-item",children:[e.jsx("span",{children:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("circle",{cx:"12",cy:"12",r:"8"}),e.jsx("path",{d:"m9 12 2 2 4-4"})]})}),"Compliance Auditing & Reporting"]})]})]}),e.jsx("div",{className:"resilience-image-wrapper",children:e.jsx("img",{loading:"lazy",decoding:"async",src:"/OpManagement1.webp",alt:"Digital network operations",className:"resilience-image"})})]}),e.jsx("style",{children:`
        * {
          box-sizing: border-box;
        }

        .operations-page {
          width: 100%;
          min-height: 100vh;
          background: #f7f8fa;
          color: #171717;
          font-family: "Inter", sans-serif;
          padding: 28px 28px 60px;
        }

        /* ================= HERO ================= */

        .operations-hero {
          position: relative;
          width: 100%;
          max-width: 1100px;
          height: 520px;
          margin: 0 auto;
          overflow: hidden;
          border-radius: 0;
        }

        .operations-hero-image {
          position: absolute;
          inset: 0;
          width: 100%;
          height: 100%;
          object-fit: cover;
          object-position: center;
        }

        .operations-hero-overlay {
          position: absolute;
          inset: 0;
          background:
            linear-gradient(
              90deg,
              rgba(9, 16, 19, 0.88) 0%,
              rgba(9, 16, 19, 0.67) 48%,
              rgba(9, 16, 19, 0.42) 100%
            );
        }

        .operations-hero-content {
          position: relative;
          z-index: 2;
          height: 100%;
          display: flex;
          flex-direction: column;
          justify-content: center;
          padding: 55px 70px;
        }

        .operations-badge {
          width: fit-content;
          display: flex;
          align-items: center;
          gap: 9px;
          padding: 7px 15px;
          border-radius: 7px;
          background: rgba(124, 19, 72, 0.55);
          border: 1px solid rgba(224, 166, 198, 0.45);
          color: #e9d8e2;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 1px;
        }

        .operations-badge-icon {
          width: 18px;
          height: 18px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .operations-badge-icon svg {
          width: 17px;
          height: 17px;
        }

        .operations-hero h1 {
          max-width: 760px;
          margin: 27px 0 28px;
          color: #ffffff;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 50px;
          line-height: 1.04;
          font-weight: 800;
          letter-spacing: -2px;
        }

        .operations-hero-buttons {
          display: flex;
          align-items: center;
          gap: 15px;
        }

        .operations-primary-btn,
        .operations-secondary-btn {
          min-height: 40px;
          padding: 0 28px;
          border-radius: 4px;
          font-family: "Inter", sans-serif;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .operations-primary-btn {
          border: 1px solid #8b004b;
          background: #8b004b;
          color: #ffffff;
        }

        .operations-primary-btn:hover {
          background: #a00058;
        }

        .operations-secondary-btn {
          border: 1px solid rgba(255,255,255,0.65);
          background: transparent;
          color: #ffffff;
        }

        .operations-secondary-btn:hover {
          background: rgba(255,255,255,0.1);
        }

        /* ================= INTRO ================= */

        .operations-intro {
          width: 100%;
          max-width: 850px;
          margin: 48px auto 85px;
          text-align: center;
        }

        .operations-intro h2 {
          margin: 0 0 26px;
          color: #68103a;
          font-family: "Inter", sans-serif;
          font-size: 30px;
          line-height: 1.2;
          font-weight: 600;
          letter-spacing: -1.2px;
        }

        .operations-intro p {
          margin: 0;
          color: #75676d;
          font-family: "Inter", sans-serif;
          font-size: 15px;
          line-height: 1.55;
          font-weight: 400;
        }

        /* ================= FEATURES ================= */

        .operations-features {
          width: 100%;
          max-width: 900px;
          margin: 0 auto 38px;
          display: grid;
          grid-template-columns: minmax(0, 1fr) 270px;
          gap: 20px;
          align-items: start;
        }

        /* WORKFLOW */

        .workflow-card {
          height: 390px;
          min-height: 390px;
          align-self: start;
          background: #ffffff;
          border: 1px solid #eeeeee;
          border-radius: 15px;
          box-shadow:
            0 8px 30px rgba(45, 25, 35, 0.025);
        }

        .workflow-content {
          height: 100%;
          padding: 42px 42px 35px;
          display: flex;
          flex-direction: column;
        }

        .feature-icon {
          width: 28px;
          height: 28px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .feature-icon svg {
          width: 25px;
          height: 25px;
        }

        .workflow-icon {
          color: #71003d;
        }

        .workflow-content h3 {
          margin: 24px 0 14px;
          color: #202020;
          font-family: "Inter", sans-serif;
          font-size: 22px;
          line-height: 1.2;
          font-weight: 750;
        }

        .workflow-content p {
          max-width: 580px;
          margin: 0;
          color: #75676d;
          font-size: 14px;
          line-height: 1.55;
        }

        .workflow-stats {
          margin-top: auto;
          padding-top: 35px;
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 16px;
        }

        .stat-box {
          min-height: 100px;
          padding: 18px 20px;
          border: 1px solid #e5e8ed;
          border-radius: 7px;
          background: #fafbfc;
          display: flex;
          flex-direction: column;
          justify-content: center;
        }

        .stat-box strong {
          color: #6d1640;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 23px;
          line-height: 1;
          font-weight: 500;
        }

        .stat-box span {
          margin-top: 9px;
          max-width: 130px;
          color: #75676d;
          font-size: 10px;
          line-height: 1.3;
          font-weight: 700;
        }

        /* MAINTENANCE */

        .maintenance-card {
          height: 420px;
          min-height: 420px;
          align-self: start;
          padding: 38px 30px 28px;
          background: #fcf9fb;
          border: 1px solid #f1edf0;
          border-radius: 15px;
          display: flex;
          flex-direction: column;
        }

        .maintenance-icon {
          color: #185b2d;
        }

        .maintenance-card h3 {
          margin: 22px 0 14px;
          color: #202020;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 23px;
          line-height: 1.18;
          font-weight: 750;
        }

        .maintenance-card p {
          margin: 0;
          color: #75676d;
          font-size: 13px;
          line-height: 1.55;
        }

        .maintenance-chart {
          width: 130px;
          height: 105px;
          margin-top: auto;
          border: 1px solid #e0e4e9;
          border-radius: 4px;
          background: #fbfcfd;
          display: flex;
          align-items: flex-end;
          justify-content: center;
          padding: 16px 13px;
        }

        .chart-bars {
          width: 100%;
          height: 65px;
          display: flex;
          align-items: flex-end;
          justify-content: center;
          gap: 5px;
        }

        .bar {
          display: block;
          width: 15px;
          border-radius: 2px 2px 0 0;
          background: #d9c8d2;
        }

        .bar-1 {
          height: 20px;
        }

        .bar-2 {
          height: 31px;
          background: #c9b1c0;
        }

        .bar-3 {
          height: 43px;
          background: #aa899f;
        }

        .bar-4 {
          height: 34px;
          background: #93627e;
        }

        .bar-5 {
          height: 54px;
          background: #74244f;
        }

        .bar-6 {
          height: 28px;
          background: #719277;
        }

        /* ================= RESILIENCE ================= */

        .resilience-card {
          width: 100%;
          max-width: 900px;
          min-height: 450px;
          margin: 0 auto;
          overflow: hidden;
          border-radius: 15px;
          background: #ffffff;
          display: grid;
          grid-template-columns: 1fr 1fr;
          border: 1px solid #eeeeee;
        }

        .resilience-content {
          padding: 43px 45px;
          background: #f8f8f9;
        }

        .resilience-icon {
          color: #71003d;
        }

        .resilience-content h2 {
          margin: 25px 0 20px;
          color: #1d1d1d;
          font-family: "Inter", sans-serif;
          font-size: 28px;
          line-height: 1.12;
          font-weight: 750;
          letter-spacing: -0.8px;
        }

        .resilience-content p {
          max-width: 380px;
          margin: 0;
          color: #75676d;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          line-height: 1.55;
        }

        .resilience-list {
          margin-top: 30px;
          display: flex;
          flex-direction: column;
          gap: 15px;
        }

        .resilience-item {
          display: flex;
          align-items: center;
          gap: 10px;
          color: #343034;
          font-size: 12px;
          font-family: "Inter", sans-serif;
          font-weight: 500;
        }

        .resilience-item span {
          width: 15px;
          height: 15px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #8b3a68;
        }

        .resilience-item svg {
          width: 14px;
          height: 14px;
        }

        .resilience-image-wrapper {
          min-height: 450px;
          overflow: hidden;
        }

        .resilience-image {
          width: 100%;
          height: 100%;
          display: block;
          object-fit: cover;
          object-position: center;
        }

        /* ================= TABLET ================= */

        @media (max-width: 900px) {

          .operations-page {
            padding: 22px 20px 45px;
          }

          .operations-hero {
            height: 470px;
          }

          .operations-hero-content {
            padding: 45px 48px;
          }

          .operations-hero h1 {
            font-size: clamp(38px, 6vw, 58px);
          }

          .operations-intro {
            margin: 42px auto 65px;
          }

          .operations-intro p {
            font-size: 17px;
          }

          .operations-features {
            max-width: 820px;
            grid-template-columns: minmax(0, 1fr) 245px;
          }

          .workflow-content {
            padding: 35px 32px;
          }

          .maintenance-card {
            padding: 32px 25px;
          }

          .resilience-card {
            max-width: 820px;
          }

          .resilience-content {
            padding: 38px 35px;
          }
        }

        /* ================= MOBILE ================= */

        @media (max-width: 650px) {

          .operations-page {
            padding: 15px 14px 35px;
          }

          .operations-hero {
            height: 500px;
          }

          .operations-hero-content {
            padding: 35px 25px;
            justify-content: center;
          }

          .operations-badge {
            padding: 6px 11px;
            font-size: 8px;
            letter-spacing: 0.7px;
          }

          .operations-badge-icon,
          .operations-badge-icon svg {
            width: 14px;
            height: 14px;
          }

          .operations-hero h1 {
            margin: 22px 0 25px;
            font-size: clamp(34px, 9vw, 48px);
            line-height: 1.05;
            letter-spacing: -1.5px;
          }

          .operations-hero-buttons {
            flex-wrap: wrap;
            gap: 10px;
          }

          .operations-primary-btn,
          .operations-secondary-btn {
            min-height: 43px;
            padding: 0 20px;
            font-size: 10px;
          }

          .operations-intro {
            margin: 40px auto 55px;
            padding: 0 10px;
          }

          .operations-intro h2 {
            margin-bottom: 18px;
            font-size: 25px;
          }

          .operations-intro p {
            font-size: 15px;
            line-height: 1.55;
          }

          .operations-features {
            display: flex;
            flex-direction: column;
            gap: 18px;
            margin-bottom: 25px;
          }

          .workflow-card {
            height: auto;
            min-height: auto;
          }

          .workflow-content {
            padding: 30px 25px;
          }

          .workflow-content h3 {
            font-size: 22px;
            margin-top: 18px;
          }

          .workflow-content p {
            font-size: 13px;
          }

          .workflow-stats {
            margin-top: 25px;
            padding-top: 0;
            gap: 10px;
          }

          .stat-box {
            min-height: 90px;
            padding: 15px;
          }

          .stat-box strong {
            font-size: 24px;
          }

          .maintenance-card {
            height: auto;
            min-height: 370px;
          }

          .maintenance-card h3 {
            font-size: 22px;
          }

          .maintenance-card p {
            font-size: 13px;
          }

          .resilience-card {
            display: flex;
            flex-direction: column;
            min-height: auto;
          }

          .resilience-content {
            padding: 32px 25px;
          }

          .resilience-content h2 {
            font-size: 27px;
            margin-top: 20px;
          }

          .resilience-content p {
            font-size: 13px;
          }

          .resilience-list {
            margin-top: 25px;
            gap: 13px;
          }

          .resilience-item {
            font-size: 11px;
          }

          .resilience-image-wrapper {
            height: 280px;
            min-height: 280px;
          }
        }

        /* ================= SMALL MOBILE ================= */

        @media (max-width: 420px) {

          .operations-page {
            padding-left: 10px;
            padding-right: 10px;
          }

          .operations-hero {
            height: 460px;
          }

          .operations-hero-content {
            padding: 30px 20px;
          }

          .operations-hero h1 {
            font-size: 31px;
            letter-spacing: -1px;
          }

          .operations-primary-btn,
          .operations-secondary-btn {
            padding: 0 15px;
            font-size: 9px;
          }

          .operations-intro h2 {
            font-size: 22px;
          }

          .operations-intro p {
            font-size: 14px;
          }

          .workflow-content,
          .maintenance-card,
          .resilience-content {
            padding-left: 20px;
            padding-right: 20px;
          }

          .workflow-stats {
            grid-template-columns: 1fr;
          }

          .stat-box {
            min-height: 80px;
          }

          .resilience-image-wrapper {
            height: 240px;
            min-height: 240px;
          }
        }
      `})]})}export{t as default};
