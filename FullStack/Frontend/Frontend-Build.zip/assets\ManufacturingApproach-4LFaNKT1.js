import{j as a}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";const e="#7A1F3D",p="#1B1B2A",r="#5b5a63",t=[{num:"01",title:"Understand",body:"Understand your business processes, technology environment and requirements."},{num:"02",title:"Plan",body:"Define an approach aligned with your business objectives and technology needs."},{num:"03",title:"Develop & Integrate",body:"Develop, configure or integrate the required technology solutions."},{num:"04",title:"Implement",body:"Support the implementation of the solution within your business environment."},{num:"05",title:"Support",body:"Provide ongoing maintenance, training and technology support as requirements evolve."}];function c(){return a.jsxs(a.Fragment,{children:[a.jsx("style",{children:`

        /* =====================================================
           MAIN SECTION
        ===================================================== */

        .approach-section {
          width: 100%;
          background: #f4f1ec;
          color: ${p};
          font-family: "Inter", sans-serif;
          overflow: hidden;
        }

        .approach-container {
          width: 100%;
          max-width: 1440px;
          margin: 0 auto;
          padding: 80px 100px;
          box-sizing: border-box;
        }

        /* =====================================================
           HEADER
        ===================================================== */

        .approach-header {
          width: 100%;
          max-width: 680px;
          margin: 0 auto 48px;
          text-align: center;
        }

        .approach-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;

          padding: 7px 13px;
          margin-bottom: 18px;

          border-radius: 999px;

          background: #fbeef1;
          color: ${e};

          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.08em;
        }

        .approach-badge-dot {
          width: 6px;
          height: 6px;

          border-radius: 50%;
          background: ${e};

          flex-shrink: 0;
        }

        /* =====================================================
           MAIN HEADING
        ===================================================== */

        .approach-heading {
          margin: 0 0 14px;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: clamp(28px, 3vw, 38px);
          line-height: 1.25;
          font-weight: 700;

          letter-spacing: -0.03em;

          color: ${p};
        }

        /* =====================================================
           SUBHEADING
        ===================================================== */

        .approach-subheading {
          margin: 0 auto;
          max-width: 620px;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 14px;
          line-height: 1.8;
          font-weight: 500;

          color: ${r};
        }

        /* =====================================================
           STEPS
        ===================================================== */

        .approach-steps {
          display: grid;

          grid-template-columns:
            repeat(5, minmax(0, 1fr));

          gap: 18px;

          width: 100%;
        }

        /* =====================================================
           CARD
        ===================================================== */

        .approach-card {
          min-width: 0;

          background: #ffffff;

          border-radius: 16px;

          padding: 22px 20px;

          box-shadow:
            0 2px 8px rgba(0, 0, 0, 0.045);

          border: 1px solid rgba(27, 27, 42, 0.035);

          transition:
            transform 0.25s ease,
            box-shadow 0.25s ease;

          box-sizing: border-box;
        }

        .approach-card:hover {
          transform: translateY(-5px);

          box-shadow:
            0 14px 30px rgba(27, 27, 42, 0.09);
        }

        /* =====================================================
           NUMBER
        ===================================================== */

        .approach-number {
          display: inline-flex;

          align-items: center;
          justify-content: center;

          min-width: 34px;
          height: 26px;

          padding: 0 8px;
          margin-bottom: 17px;

          border-radius: 7px;

          background: #fbeef1;
          color: ${e};

          font-family: "Inter", sans-serif;
          font-size: 10px;
          font-weight: 700;

          letter-spacing: 0.04em;

          box-sizing: border-box;
        }

        /* =====================================================
           CARD TITLE
        ===================================================== */

        .approach-card-title {
          margin: 0 0 9px;

          font-family: "Plus Jakarta Sans", sans-serif;

          font-size: 15px;
          line-height: 1.4;
          font-weight: 700;

          color: ${p};
        }

        /* =====================================================
           CARD BODY
        ===================================================== */

        .approach-card-body {
          margin: 0;

          font-family: "Inter", sans-serif;

          font-size: 12px;
          line-height: 1.7;
          font-weight: 400;

          color: ${r};
        }

        /* =====================================================
           LARGE TABLET
        ===================================================== */

        @media (max-width: 1100px) {

          .approach-container {
            padding: 64px 40px;
          }

          .approach-steps {
            grid-template-columns:
              repeat(3, minmax(0, 1fr));

            gap: 18px;
          }

          .approach-card {
            padding: 22px;
          }
        }

        /* =====================================================
           TABLET
        ===================================================== */

        @media (max-width: 800px) {

          .approach-container {
            padding: 58px 40px;
          }

          .approach-header {
            margin-bottom: 38px;
          }

          .approach-heading {
            font-size: 30px;
          }

          .approach-subheading {
            font-size: 13.5px;
            line-height: 1.75;
          }

          .approach-steps {
            grid-template-columns:
              repeat(2, minmax(0, 1fr));

            gap: 16px;
          }

          .approach-card {
            padding: 20px;
          }
        }

        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 600px) {

          .approach-container {
            padding: 50px 24px;
          }

          .approach-header {
            margin-bottom: 32px;
          }

          .approach-badge {
            font-size: 10px;

            padding: 6px 11px;
            margin-bottom: 16px;
          }

          .approach-heading {
            font-size: 27px;

            line-height: 1.25;

            letter-spacing: -0.02em;

            margin-bottom: 12px;
          }

          .approach-subheading {
            font-size: 13px;
            line-height: 1.75;
          }

          .approach-steps {
            grid-template-columns: 1fr;

            gap: 14px;
          }

          .approach-card {
            padding: 20px;

            border-radius: 14px;
          }

          .approach-number {
            margin-bottom: 14px;
          }

          .approach-card-title {
            font-size: 15px;
          }

          .approach-card-body {
            font-size: 12px;

            line-height: 1.7;
          }
        }

        /* =====================================================
           SMALL MOBILE
        ===================================================== */

        @media (max-width: 400px) {

          .approach-container {
            padding: 44px 16px;
          }

          .approach-heading {
            font-size: 25px;
          }

          .approach-subheading {
            font-size: 12.5px;
          }

          .approach-card {
            padding: 18px;
          }

          .approach-card-title {
            font-size: 14px;
          }

          .approach-card-body {
            font-size: 11.5px;
          }
        }

        /* =====================================================
           VERY SMALL MOBILE
        ===================================================== */

        @media (max-width: 340px) {

          .approach-container {
            padding: 40px 16px;
          }

          .approach-heading {
            font-size: 23px;
          }

          .approach-subheading {
            font-size: 12px;
          }

          .approach-card {
            padding: 16px;
          }
        }

        /* =====================================================
           REDUCED MOTION
        ===================================================== */

        @media (prefers-reduced-motion: reduce) {

          .approach-card {
            transition: none;
          }
        }
      `}),a.jsx("section",{className:"approach-section",children:a.jsxs("div",{className:"approach-container",children:[a.jsxs("div",{className:"approach-header",children:[a.jsxs("span",{className:"approach-badge",children:[a.jsx("span",{className:"approach-badge-dot"}),"OUR APPROACH"]}),a.jsx("h2",{className:"approach-heading",children:"From Requirement to Long-Term Support"}),a.jsx("p",{className:"approach-subheading",children:"Our approach starts with understanding your business requirements and continues through development, implementation and ongoing support."})]}),a.jsx("div",{className:"approach-steps",children:t.map(({num:n,title:i,body:o})=>a.jsxs("div",{className:"approach-card",children:[a.jsx("span",{className:"approach-number",children:n}),a.jsx("h3",{className:"approach-card-title",children:i}),a.jsx("p",{className:"approach-card-body",children:o})]},n))})]})})]})}export{c as default};
