import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as s}from"./vendor-router-L4ZCoGSs.js";import{X as c}from"./index-BThRNyH6.js";import{A as p}from"./activity-BBAyi7CR.js";import{S as m}from"./share-2-Ceim1j9X.js";import{C as d}from"./clock-mGZ0mVau.js";const x=[{icon:c,title:"Understand",description:"Deep dive into operational workflows to map the current state and identify genuine pain points."},{icon:p,title:"Build",description:"Engineer scalable, secure architectures tailored to your specific operational requirements."},{icon:m,title:"Connect",description:"Integrate disparate systems to create unified data models and seamless user experiences."},{icon:d,title:"Evolve",description:"Establish continuous improvement loops to ensure technology adapts alongside the business."}];function v(){const a=s.useRef(null),[i,o]=s.useState(!1);return s.useEffect(()=>{const n=a.current;if(!n)return;const r=new IntersectionObserver(([t])=>{t.isIntersecting?o(!0):o(!1)},{threshold:.25});return r.observe(n),()=>{r.disconnect()}},[]),e.jsxs("section",{ref:a,className:`\r
        perspective-section\r
        w-full\r
        overflow-hidden\r
        bg-white\r
        px-4\r
        py-10\r
        sm:px-6\r
        sm:py-12\r
        md:px-10\r
        md:py-14\r
        lg:px-[100px]\r
        lg:py-16\r
        xl:py-20\r
      `,children:[e.jsxs("div",{className:"w-full",children:[e.jsx("span",{className:`\r
            text-[10px]\r
            font-semibold\r
            tracking-[0.14em]\r
            text-slate-500\r
            sm:text-[11px]\r
          `,style:{fontFamily:"'Inter', sans-serif"},children:"OUR PERSPECTIVE"}),e.jsxs("div",{className:`\r
            mt-3\r
            flex\r
            flex-col\r
            gap-5\r
            border-b\r
            border-slate-200\r
            pb-7\r
            sm:mt-4\r
            sm:gap-6\r
            sm:pb-8\r
            lg:flex-row\r
            lg:items-end\r
            lg:justify-between\r
            lg:gap-10\r
            lg:pb-9\r
          `,children:[e.jsx("h2",{className:`\r
              w-full\r
              max-w-2xl\r
              text-[22px]\r
              font-bold\r
              leading-[1.3]\r
              text-slate-900\r
              sm:text-[25px]\r
              md:text-[28px]\r
              lg:text-[30px]\r
              xl:text-[32px]\r
            `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Technology works best when it is connected to the business."}),e.jsx("p",{className:`\r
              w-full\r
              max-w-xl\r
              text-[13px]\r
              leading-[1.7]\r
              text-slate-500\r
              sm:text-[14px]\r
              md:max-w-md\r
              md:text-[15px]\r
              lg:max-w-sm\r
            `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"At TechTorch, technology capabilities cover areas critical to modern enterprise operations."})]}),e.jsx("div",{className:`\r
            mt-8\r
            grid\r
            grid-cols-1\r
            gap-4\r
            sm:mt-9\r
            sm:grid-cols-2\r
            sm:gap-5\r
            md:mt-10\r
            md:gap-6\r
            lg:grid-cols-4\r
            lg:gap-5\r
            xl:gap-6\r
          `,children:x.map(({icon:n,title:r,description:t},l)=>e.jsxs("div",{className:`
                perspective-card
                group
                w-full
                rounded-lg
                bg-slate-50
                p-5
                transition-all
                duration-700
                hover:-translate-y-1
                hover:shadow-sm
                sm:p-6
                md:p-6
                lg:p-5
                xl:p-6
                ${i?"perspective-card-show":"perspective-card-hide"}
              `,style:{transitionDelay:i?`${l*180}ms`:"0ms"},children:[e.jsx("div",{className:`\r
                  mb-4\r
                  flex\r
                  h-9\r
                  w-9\r
                  items-center\r
                  justify-center\r
                  rounded-full\r
                  border\r
                  border-[#730042]\r
                  transition-colors\r
                  duration-300\r
                  group-hover:border-[#730042]\r
                  sm:mb-5\r
                `,children:e.jsx(n,{size:16,strokeWidth:1.8,className:"text-fuchsia-900"})}),e.jsx("h3",{className:`\r
                  text-[15px]\r
                  font-semibold\r
                  leading-[1.4]\r
                  text-slate-900\r
                  sm:text-[16px]\r
                `,style:{fontFamily:"'Inter', sans-serif"},children:r}),e.jsx("p",{className:`\r
                  mt-2\r
                  text-[13px]\r
                  leading-[1.7]\r
                  text-slate-500\r
                  sm:text-[14px]\r
                  sm:leading-[1.75]\r
                `,style:{fontFamily:"'Inter', sans-serif"},children:t})]},r))})]}),e.jsx("style",{children:`
        .perspective-card {
          opacity: 0;
          transform: translateY(45px) scale(0.92);
          filter: blur(5px);
          will-change: transform, opacity, filter;
        }

        .perspective-card-show {
          opacity: 1;
          transform: translateY(0) scale(1);
          filter: blur(0);
        }

        .perspective-card-hide {
          opacity: 0;
          transform: translateY(45px) scale(0.92);
          filter: blur(5px);
        }

        /* 
          Jab hover ho to animation ke baad
          card thoda upar move kare
        */
        .perspective-card-show:hover {
          transform: translateY(-4px) scale(1);
        }

        @media (prefers-reduced-motion: reduce) {
          .perspective-card {
            opacity: 1;
            transform: none;
            filter: none;
            transition: none !important;
          }
        }
      `})]})}export{v as default};
