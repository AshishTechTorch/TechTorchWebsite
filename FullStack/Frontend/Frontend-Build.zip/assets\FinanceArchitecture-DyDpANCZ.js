import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as g}from"./vendor-router-L4ZCoGSs.js";import{Q as u,z as m,b as x,s as f,r as b}from"./index-BThRNyH6.js";import{G as v}from"./globe-B6UvVB5H.js";import{C as y}from"./code-xml-DcjisM7r.js";import{C as w}from"./cloud-DZemR4H4.js";const s="#7A1F3D",l="#1B1B2A",p="#5b5a63",z="#fbeef1",j=[{icon:u,title:"Financial Management",body:"Bring financial activities and information into a more organized digital environment to support everyday business operations.",tags:["Financial Operations","Records","Reporting","Data Management"]},{icon:m,title:"Payment Management",body:"Support payment-related activities with technology that helps organize transactions and financial information.",tags:["Payments","Transactions","Tracking","Reporting"]},{icon:x,title:"Enterprise Resource Planning",body:"Connect finance with other important business functions through an integrated ERP environment.",tags:["Business Processes","Finance","Centralized Data","Workflows"]},{icon:f,title:"Customer Relationship Management",body:"Manage customer information and interactions through a connected CRM environment designed around business needs.",tags:["Customer Data","Interactions","Sales","Service"]},{icon:v,title:"Web Portals",body:"Create digital portals that provide customers, partners or employees with easier access to relevant services and information.",tags:["Web Applications","Digital Access","User Experience","Integration"]},{icon:y,title:"Software Development",body:"Develop software around specific business requirements, whether you need a new application, system integration or modernization.",tags:["Custom Software","Web Applications","Integration","Modernization"]},{icon:w,title:"Cloud Infrastructure",body:"Build a flexible technology foundation that supports changing operational and business requirements.",tags:["Cloud Infrastructure","Scalability","Accessibility","Support"]},{icon:b,title:"Cyber Security",body:"Strengthen the security of business applications, systems and information through technology-focused security services.",tags:["Data Protection","System Security","Access Management","Support"]}];function P(){const h=g.useRef(null);return g.useEffect(()=>{const i=h.current;if(!i)return;const c=Array.from(i.querySelectorAll(".core-card-observer")),o=window.matchMedia("(prefers-reduced-motion: reduce)");let t;function n(){t?.disconnect(),i.classList.remove("core-reveal-enabled"),c.forEach(r=>{r.classList.remove("is-visible")}),!(o.matches||!("IntersectionObserver"in window))&&(i.classList.add("core-reveal-enabled"),t=new IntersectionObserver(r=>{r.filter(a=>a.isIntersecting).sort((a,d)=>Number(a.target.dataset.index)-Number(d.target.dataset.index)).forEach((a,d)=>{a.target.style.setProperty("--reveal-delay",`${d*160}ms`),a.target.classList.add("is-visible")}),r.forEach(a=>{a.isIntersecting||a.target.classList.remove("is-visible")})},{threshold:0}),c.forEach(r=>t.observe(r)))}return n(),o.addEventListener("change",n),()=>{t?.disconnect(),o.removeEventListener("change",n),i.classList.remove("core-reveal-enabled")}},[]),e.jsxs("section",{className:"core-architecture-section",children:[e.jsx("style",{children:`

        .core-architecture-section {
          --core-icon-bg: ${z};

          width: 100%;
          background: #f7f7fa;
          color: ${l};
          font-family: "Inter", Arial, sans-serif;
          overflow: hidden;
          box-sizing: border-box;
        }

        .core-architecture-section *,
        .core-architecture-section *::before,
        .core-architecture-section *::after {
          box-sizing: border-box;
        }

        .core-architecture-container {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;
          padding: 78px 100px;
        }

        .core-architecture-header {
          display: grid;
          grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
          gap: 56px;
          align-items: start;
          margin-bottom: 40px;
        }

        .core-architecture-header > * {
          min-width: 0;
        }

        .core-architecture-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          max-width: 100%;
          padding: 6px 12px;
          margin-bottom: 16px;
          border-radius: 999px;
          background: var(--core-icon-bg);
          color: ${s};
          font-size: 11px;
          font-weight: 600;
          letter-spacing: 0.04em;
          line-height: 1.3;
        }

        .core-architecture-badge-dot {
          width: 6px;
          height: 6px;
          flex-shrink: 0;
          border-radius: 50%;
          background: ${s};
        }

        .core-architecture-heading {
          margin: 0;
          color: ${l};
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 36px;
          line-height: 1.25;
          font-weight: 700;
          letter-spacing: -0.025em;
        }

        .core-architecture-heading span {
          color: ${s};
        }

        .core-architecture-subheading {
          margin: 0;
          padding-top: 4px;
          color: ${p};
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 15px;
          line-height: 1.75;
          font-weight: 500;
          max-width: 680px;
        }

        .core-architecture-grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 20px;
        }

        /* Observe a stationary wrapper to avoid animation flicker. */
        .core-card-observer {
          display: flex;
          min-width: 0;
        }

        .core-card-reveal {
          display: flex;
          width: 100%;
          min-width: 0;
        }

        .core-reveal-enabled
        > .core-card-observer
        > .core-card-reveal {
          opacity: 0;
        }

        .core-reveal-enabled
        > .core-card-observer.is-visible
        > .core-card-reveal {
          animation: core-card-enter
            650ms
            cubic-bezier(0.22, 1, 0.36, 1)
            var(--reveal-delay, 0ms)
            both;
        }

        @keyframes core-card-enter {
          from {
            opacity: 0;
            transform: translateY(32px);
          }

          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .core-architecture-card {
          --card-padding: 22px;
          --icon-size: 38px;
          --spread-origin: calc(
            var(--card-padding) + var(--icon-size) / 2
          );

          position: relative;
          isolation: isolate;
          width: 100%;
          min-width: 0;
          padding: var(--card-padding);
          overflow: hidden;
          background: #ffffff;
          border-radius: 12px;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
          transition:
            transform 0.3s ease,
            box-shadow 0.3s ease;
        }

        /* Pink layer expands from the exact center of the icon. */
        .core-architecture-card::before {
          content: "";
          position: absolute;
          inset: 0;
          z-index: 0;
          pointer-events: none;
          background: var(--core-icon-bg);
          clip-path: circle(
            0% at var(--spread-origin) var(--spread-origin)
          );
          transition: clip-path 650ms cubic-bezier(0.22, 1, 0.36, 1);
        }

        /* Keep all content above the expanding background. */
        .core-architecture-card > * {
          position: relative;
          z-index: 1;
        }

        @media (hover: hover) {
          .core-architecture-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.07);
          }

          .core-architecture-card:hover::before {
            clip-path: circle(
              150% at var(--spread-origin) var(--spread-origin)
            );
          }
        }

        .core-architecture-icon {
          width: var(--icon-size);
          height: var(--icon-size);
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 16px;
          border-radius: 8px;
          background: var(--core-icon-bg);
          color: ${s};
        }

        .core-architecture-card-title {
          margin: 0 0 8px;
          color: ${l};
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 14px;
          line-height: 1.4;
          font-weight: 700;
          overflow-wrap: break-word;
        }

        .core-architecture-card-body {
          margin: 0 0 16px;
          color: ${p};
          font-size: 12px;
          line-height: 1.7;
          font-weight: 400;
        }

        .core-architecture-tags {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
        }

        .core-architecture-tag {
          display: inline-flex;
          align-items: center;
          max-width: 100%;
          padding: 4px 8px;
          border-radius: 6px;
          background: #f2f1f5;
          color: ${p};
          font-size: 10px;
          line-height: 1.4;
          font-weight: 500;
          overflow-wrap: anywhere;
        }

        @media (max-width: 1200px) {
          .core-architecture-container {
            padding-left: 40px;
            padding-right: 40px;
          }

          .core-architecture-header {
            gap: 40px;
          }

          .core-architecture-heading {
            font-size: 33px;
          }

          .core-architecture-grid {
            grid-template-columns: repeat(3, minmax(0, 1fr));
          }
        }

        @media (max-width: 900px) {
          .core-architecture-container {
            padding: 62px 40px;
          }

          .core-architecture-header {
            grid-template-columns: 1fr;
            gap: 18px;
            margin-bottom: 34px;
          }

          .core-architecture-heading {
            font-size: 30px;
          }

          .core-architecture-subheading {
            padding-top: 0;
            max-width: 760px;
          }

          .core-architecture-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
          }

          .core-architecture-card {
            --card-padding: 20px;
          }
        }

        @media (max-width: 600px) {
          .core-architecture-container {
            padding: 52px 24px;
          }

          .core-architecture-header {
            gap: 16px;
            margin-bottom: 28px;
          }

          .core-architecture-badge {
            margin-bottom: 14px;
            font-size: 10px;
          }

          .core-architecture-heading {
            font-size: 26px;
            line-height: 1.3;
          }

          .core-architecture-subheading {
            font-size: 14px;
            line-height: 1.7;
          }

          .core-architecture-grid {
            grid-template-columns: minmax(0, 1fr);
            gap: 16px;
          }

          .core-architecture-card {
            --card-padding: 19px;
          }

          .core-architecture-card-body {
            line-height: 1.65;
          }
        }

        @media (max-width: 480px) {
          .core-architecture-container {
            padding: 44px 16px;
          }

          .core-architecture-heading {
            font-size: 23px;
          }

          .core-architecture-subheading {
            font-size: 13px;
          }

          .core-architecture-card {
            --card-padding: 17px;
            --icon-size: 35px;
          }

          .core-architecture-icon {
            margin-bottom: 14px;
          }

          .core-architecture-tag {
            font-size: 9px;
            padding: 4px 7px;
          }
        }

        @media (max-width: 340px) {
          .core-architecture-container {
            padding: 38px 16px;
          }

          .core-architecture-heading {
            font-size: 21px;
          }

          .core-architecture-subheading {
            font-size: 12px;
          }

          .core-architecture-card {
            --card-padding: 16px;
          }

          .core-architecture-card-body {
            font-size: 11px;
          }

          .core-architecture-tag {
            font-size: 8.5px;
          }
        }

        @media (prefers-reduced-motion: reduce) {
          .core-reveal-enabled
          > .core-card-observer
          > .core-card-reveal,
          .core-reveal-enabled
          > .core-card-observer.is-visible
          > .core-card-reveal {
            animation: none;
            opacity: 1;
            transform: none;
          }

          .core-architecture-card,
          .core-architecture-card::before {
            transition: none;
          }

          .core-architecture-card:hover {
            transform: none;
          }
        }
      `}),e.jsxs("div",{className:"core-architecture-container",children:[e.jsxs("div",{className:"core-architecture-header",children:[e.jsxs("div",{children:[e.jsxs("span",{className:"core-architecture-badge",children:[e.jsx("span",{className:"core-architecture-badge-dot"}),"TECHTORCH CORE ARCHITECTURE"]}),e.jsxs("h2",{className:"core-architecture-heading",children:["Digital Solutions Designed",e.jsx("br",{}),e.jsx("span",{children:"Around Operational Precision"})]})]}),e.jsx("p",{className:"core-architecture-subheading",children:"Every financial organization demands tailored compliance, speed, and reliability. TechTorch builds, modernizes, and deploys cohesive digital infrastructure engineered around your exact workflows."})]}),e.jsx("div",{ref:h,className:"core-architecture-grid",children:j.map(({icon:i,title:c,body:o,tags:t},n)=>e.jsx("div",{className:"core-card-observer","data-index":n,children:e.jsx("div",{className:"core-card-reveal",children:e.jsxs("article",{className:"core-architecture-card",children:[e.jsx("span",{className:"core-architecture-icon",children:e.jsx(i,{size:16,strokeWidth:1.8})}),e.jsx("h3",{className:"core-architecture-card-title",children:c}),e.jsx("p",{className:"core-architecture-card-body",children:o}),e.jsx("div",{className:"core-architecture-tags",children:t.map(r=>e.jsx("span",{className:"core-architecture-tag",children:r},r))})]})})},c))})]})]})}export{P as default};
