import{t as a}from"./index-BThRNyH6.js";const o={name:"cloud",size:24,node:[["path",{d:"M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z",key:"p7xjir"}]]};o.node;const t=a(o);export{t as C};
