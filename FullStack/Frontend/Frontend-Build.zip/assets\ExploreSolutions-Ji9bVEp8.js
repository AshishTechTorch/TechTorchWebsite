import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as i,d as y,L as j}from"./vendor-router-L4ZCoGSs.js";import{A as f}from"./arrow-up-right-BppImEly.js";import{P as w}from"./phone-B3rJcDGo.js";import{K as b}from"./index-BThRNyH6.js";import{M as v}from"./mail-3Flp59qD.js";function k(){const[n,r]=i.useState(!1),s=i.useRef(null),t=i.useRef(null),p=()=>{t.current&&(clearTimeout(t.current),t.current=null),r(!0)},d=()=>{t.current&&clearTimeout(t.current),t.current=setTimeout(()=>{r(!1),t.current=null},500)};i.useEffect(()=>{const o=a=>{s.current&&!s.current.contains(a.target)&&(t.current&&(clearTimeout(t.current),t.current=null),r(!1))},c=a=>{a.key==="Escape"&&(t.current&&(clearTimeout(t.current),t.current=null),r(!1))};return document.addEventListener("mousedown",o),document.addEventListener("keydown",c),()=>{document.removeEventListener("mousedown",o),document.removeEventListener("keydown",c),t.current&&clearTimeout(t.current)}},[]);const h=[{label:"Call Us",Icon:w,href:"tel:+915813500381"},{label:"WhatsApp",Icon:b,href:"https://wa.me/91XXXXXXXXXX?text=Hi%2C%20I%27d%20like%20to%20know%20more%20about%20your%20technology%20solutions.",external:!0},{label:"Email Us",Icon:v,href:"https://mail.google.com/mail/?view=cm&fs=1&to=contact@techtorch.solutions&su=Enquiry%20about%20TechTorch%20Solutions",external:!0}];return e.jsxs("section",{className:`\r
        relative\r
        w-full\r
        min-h-[550px]\r
        overflow-hidden\r
        bg-[#0a1128]\r
        font-['Plus_Jakarta_Sans']\r
      `,children:[e.jsx("div",{className:`\r
          absolute\r
          inset-0\r
          bg-cover\r
          bg-center\r
          bg-no-repeat\r
        `,style:{backgroundImage:"url('/slide1.1.webp')"}}),e.jsx("div",{className:"absolute inset-0",style:{background:"linear-gradient(90deg, rgba(10,10,20,0.85) 0%, rgba(10,10,20,0.55) 42%, rgba(10,10,20,0.15) 65%, rgba(10,10,20,0) 100%)"}}),e.jsxs("div",{className:`\r
          relative\r
          z-10\r
          flex\r
          min-h-[450px]\r
          flex-col\r
          justify-center\r
          max-w-2xl\r
          px-4\r
          sm:px-6\r
          md:px-10\r
          lg:px-[100px]\r
        `,children:[e.jsxs("h1",{className:`\r
            text-white\r
            font-['Plus_Jakarta_Sans']\r
            font-semibold\r
            leading-[1.09]\r
            text-[34px]\r
            sm:text-[34px]\r
            md:text-[36px]\r
            tracking-tight\r
            translate-y-8\r
            whitespace-nowrap\r
          `,children:["Technology Solutions Built",e.jsx("br",{}),"Around Your Business"]}),e.jsx("p",{className:`\r
            mt-20\r
            text-white/85\r
            font-['Inter']\r
            text-[15px]\r
            sm:text-[16px]\r
            leading-relaxed\r
            max-w-md\r
          `,children:"Every business has its own challenges, priorities and goals. We bring together technology, expertise and practical thinking to create solutions that fit the way your business works."}),e.jsxs("div",{ref:s,className:"relative mt-20 w-fit",onMouseEnter:p,onMouseLeave:d,children:[e.jsxs(j,{to:"/talk-to-expert",onMouseEnter:p,className:`\r
              group\r
              inline-flex\r
              items-center\r
              gap-3\r
              border\r
              border-white/70\r
              text-white\r
              text-[14px]\r
              font-medium\r
              tracking-wide\r
              px-4\r
              py-2\r
              whitespace-nowrap\r
              hover:bg-white\r
              hover:text-[#0a1128]\r
              transition-colors\r
              duration-300\r
            `,children:["Talk to Our Experts",e.jsx(f,{size:16,className:`\r
                shrink-0\r
                transition-transform\r
                duration-300\r
                group-hover:translate-x-1\r
                group-hover:-translate-y-1\r
              `})]}),e.jsx("div",{className:`
              absolute
              left-full
              top-1/2
              ml-1
              flex
              -translate-y-1/2
              items-center
              gap-2
              transition-all
              duration-300
              ${n?"visible opacity-100":"invisible opacity-0 pointer-events-none"}
            `,"aria-label":"Contact options","aria-hidden":!n,children:h.map(({label:o,Icon:c,href:a,external:x})=>e.jsx("a",{href:a,title:o,"aria-label":o,target:x?"_blank":void 0,rel:x?"noopener noreferrer":void 0,tabIndex:n?0:-1,className:`\r
                    flex\r
                    h-11\r
                    w-11\r
                    shrink-0\r
                    items-center\r
                    justify-center\r
                    rounded-full\r
                    border\r
                    border-white/50\r
                    bg-[#0a1128]/80\r
                    text-white\r
                    backdrop-blur-md\r
                    transition-all\r
                    duration-300\r
                    hover:scale-110\r
                    hover:border-[#730042]\r
                    hover:bg-[#730042]\r
                    focus-visible:outline-none\r
                    focus-visible:ring-2\r
                    focus-visible:ring-[#730042]\r
                  `,children:e.jsx(c,{size:18})},o))})]})]})]})}function N(){return e.jsx("section",{className:"w-full overflow-hidden bg-[#F8F7F0] text-[#191919]",children:e.jsxs("div",{className:`\r
          w-full\r
          px-4\r
          py-9\r
\r
          sm:px-6\r
          sm:py-10\r
\r
          md:px-10\r
          md:py-11\r
\r
          lg:px-[100px]\r
          lg:py-11\r
        `,children:[e.jsx("p",{className:`\r
            font-['Plus_Jakarta_Sans']\r
            !text-[14px]\r
            font-bold\r
            uppercase\r
            leading-none\r
            tracking-[0.01em]\r
            text-[#252525]\r
\r
            sm:text-[12px]\r
          `,children:"OUR PERSPECTIVE"}),e.jsxs("div",{className:`\r
            mt-6\r
            grid\r
            w-full\r
            grid-cols-1\r
            gap-y-10\r
\r
            sm:gap-y-12\r
\r
            md:grid-cols-[minmax(0,1fr)_200px_minmax(0,1fr)]\r
            md:gap-x-6\r
            md:gap-y-0\r
\r
            lg:grid-cols-[minmax(0,1fr)_215px_minmax(0,1fr)]\r
            lg:gap-x-7\r
\r
            xl:grid-cols-[minmax(0,1fr)_225px_minmax(0,1fr)]\r
            xl:gap-x-8\r
          `,children:[e.jsxs("div",{className:`\r
              min-w-0\r
              max-w-full\r
            `,children:[e.jsxs("h2",{className:`\r
                font-['Plus_Jakarta_Sans']\r
                text-[25px]\r
                font-semibold\r
                leading-[1.08]\r
                tracking-[-0.035em]\r
\r
                sm:text-[26px]\r
                md:text-[26px]\r
                lg:text-[28px]\r
              `,children:["Building Technology",e.jsx("br",{}),"With Purpose"]}),e.jsxs("div",{className:`\r
                mt-7\r
                max-w-full\r
                break-words\r
                font-['Inter']\r
                text-[14px]\r
                font-normal\r
                leading-[1.38]\r
                text-[#303030]\r
\r
                sm:text-[15px]\r
                md:text-[15px]\r
                lg:text-[15px]\r
                lg:leading-[1.36]\r
              `,children:[e.jsx("p",{children:"Technology is now a fundamental part of how businesses operate, serve customers and respond to change. But successful transformation is not simply about adopting the latest tools or technologies. It is about understanding what the business needs and finding the right way to address it."}),e.jsx("p",{className:"mt-6",children:"At TechTorch, we take a practical approach to technology. We begin by understanding the challenge, the existing environment and the outcome the business wants to achieve. From there, we bring together the right capabilities, expertise and technology to create solutions that work in the real world."}),e.jsx("p",{className:"mt-6",children:"Sometimes, that means building a new digital experience. Sometimes, it means modernizing an existing system, automating a repetitive process or introducing AI where it can create genuine value. In other situations, businesses need additional technology expertise to move an important project forward. The right solution depends on the problem, not the technology trend."})]})]}),e.jsx("div",{className:`\r
              flex\r
              w-full\r
              min-w-0\r
              items-start\r
              justify-center\r
              mt-10\r
\r
              md:mt-[92px]\r
              lg:mt-[96px]\r
            `,children:e.jsxs("div",{className:`\r
                w-full\r
                max-w-[205px]\r
                rounded-[7px]\r
                border\r
                border-[#C9C9C9]\r
                bg-[#FBFAF4]\r
                px-5\r
                py-7\r
\r
                sm:px-6\r
                sm:py-6\r
\r
                md:px-5\r
                md:py-5\r
              `,children:[e.jsx("div",{className:`\r
                  relative\r
                  top-5\r
                  font-serif\r
                  text-[40px]\r
                  font-bold\r
                  leading-[0.55]\r
                  text-[#730042]\r
                `,children:"“"}),e.jsxs("p",{className:`\r
                  mt-5\r
                  font-['Inter']\r
                  text-[20px]\r
                  font-medium\r
                  leading-[1.65]\r
                  tracking-[-0.025em]\r
                  text-[#111111]\r
\r
                  sm:text-[20px]\r
                `,children:["Transformation",e.jsx("br",{}),"should be",e.jsx("br",{}),"purposeful, not",e.jsx("br",{}),"complicated."]}),e.jsx("div",{className:`\r
                  relative\r
                  -top-2\r
                  mt-5\r
                  h-[3px]\r
                  w-[58px]\r
                  bg-[#730042]\r
                `})]})}),e.jsxs("div",{className:`\r
              min-w-0\r
              max-w-full\r
              break-words\r
              font-['Inter']\r
              text-[14px]\r
              leading-[1.38]\r
              text-[#303030]\r
\r
              sm:text-[15px]\r
              md:text-[15px]\r
              lg:text-[16px]\r
              lg:leading-[1.36]\r
\r
              md:mt-2\r
              lg:mt-2\r
            `,children:[e.jsx("p",{children:"Our capabilities across digital solutions, AI and automation, technology services, IT augmentation, B.P.O services and platforms allow us to address different business needs while keeping the focus on one thing — creating measurable and sustainable value."}),e.jsx("p",{className:"mt-6",children:"We also recognise that meaningful change happens over time. A successful technology journey may begin with a single process, application or business challenge and grow from there. By taking a focused approach, businesses can make improvements that are easier to adopt, easier to measure and easier to scale."}),e.jsx("p",{className:"mt-6",children:"For us, good technology is not defined by how complex it is. It is defined by how effectively it solves a problem, supports people and helps a business move forward."}),e.jsx("p",{className:"mt-6",children:"That is the role we aim to play — helping businesses turn technology into practical progress."})]})]})]})})}const l="#8f1046",E="#8f1046",m={search:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:l,strokeWidth:"1.75",strokeLinecap:"round",strokeLinejoin:"round",width:"24",height:"24",children:[e.jsx("circle",{cx:"11",cy:"11",r:"8"}),e.jsx("path",{d:"M21 21l-4.35-4.35"})]}),clipboard:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:l,strokeWidth:"1.75",strokeLinecap:"round",strokeLinejoin:"round",width:"24",height:"24",children:[e.jsx("rect",{x:"9",y:"2",width:"6",height:"4",rx:"1"}),e.jsx("path",{d:"M9 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-3"}),e.jsx("path",{d:"M9 12h6"}),e.jsx("path",{d:"M9 16h6"})]}),code:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:l,strokeWidth:"1.75",strokeLinecap:"round",strokeLinejoin:"round",width:"24",height:"24",children:[e.jsx("polyline",{points:"16 18 22 12 16 6"}),e.jsx("polyline",{points:"8 6 2 12 8 18"})]}),send:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:l,strokeWidth:"1.75",strokeLinecap:"round",strokeLinejoin:"round",width:"24",height:"24",children:[e.jsx("path",{d:"M22 2 11 13"}),e.jsx("path",{d:"M22 2 15 22l-4-9-9-4 20-7z"})]}),trend:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:l,strokeWidth:"1.75",strokeLinecap:"round",strokeLinejoin:"round",width:"24",height:"24",children:[e.jsx("polyline",{points:"23 6 13.5 15.5 8.5 10.5 1 18"}),e.jsx("polyline",{points:"17 6 23 6 23 12"})]})},u=[{num:"01",title:"Understand",desc:"We start by understanding your business, your challenges and what you want to achieve.",icon:m.search},{num:"02",title:"Define",desc:"We identify the right priorities and shape an approach around your specific needs.",icon:m.clipboard},{num:"03",title:"Build",desc:"We bring together the right technology and expertise to develop a solution that works.",icon:m.code},{num:"04",title:"Deliver",desc:"We focus on a smooth implementation with minimal disruption to your business.",icon:m.send},{num:"05",title:"Evolve",desc:"We continue to improve and scale the solution as your business needs change.",icon:m.trend}];function T(){const n=i.useRef(null),[r,s]=i.useState(!1);return i.useEffect(()=>{const t=n.current;if(!t)return;const p=new IntersectionObserver(d=>{d[0].isIntersecting?(s(!1),requestAnimationFrame(()=>{requestAnimationFrame(()=>{s(!0)})})):s(!1)},{threshold:.25});return p.observe(t),()=>p.disconnect()},[]),e.jsxs("section",{ref:n,className:`how-work-section ${r?"is-visible":""}`,children:[e.jsxs("div",{className:"how-work-container",children:[e.jsx("p",{className:"how-work-label",children:"HOW WE WORK"}),e.jsxs("h2",{className:"how-work-heading",children:["From Business Challenge to"," ",e.jsx("span",{children:"Practical Solutions"})]}),e.jsx("p",{className:"how-work-description",children:"A clear, collaborative approach focused on delivering solutions that create real and lasting value."}),e.jsxs("div",{className:"process-wrapper",children:[e.jsx("svg",{className:"process-line",viewBox:"0 0 1000 520",preserveAspectRatio:"none",children:e.jsx("path",{className:"process-path",pathLength:"1",d:`\r
    M 35 35\r
    H 450\r
    H 875\r
    H 1000\r
    V 260\r
    H 20\r
    V 325\r
    H 390\r
  `,fill:"none",stroke:E,strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round"})}),e.jsx(g,{step:u[0],className:"step-1",delay:"0s"}),e.jsx(g,{step:u[1],className:"step-2",delay:"0.45s"}),e.jsx(g,{step:u[2],className:"step-3",delay:"0.90s"}),e.jsx(g,{step:u[3],className:"step-4",delay:"1.35s"}),e.jsx(g,{step:u[4],className:"step-5",delay:"1.80s"})]})]}),e.jsx("style",{children:`

        /* =========================================
           MAIN SECTION
        ========================================== */

        .how-work-section {
          width: 100%;
          background: #ffffff;
          font-family: "Plus Jakarta Sans", sans-serif;
          overflow: hidden;
        }


        .how-work-container {
          width: 100%;
          max-width: 1200px;
          margin: 0 auto;
          padding: 56px 32px 70px;
          box-sizing: border-box;
        }


        /* =========================================
           HEADER
        ========================================== */

        .how-work-label {
          text-align: center;
          font-size: 12px;
          font-weight: 700;
          letter-spacing: 0.12em;
          color: #141414;
          margin: -15px 0 16px;
        }


        .how-work-heading {
          text-align: center;
          font-size: 28px;
          font-weight: 700;
          line-height: 1.25;
          color: #141414;
          margin: 0 0 16px;
        }


        .how-work-heading span {
          color: ${l};
        }


        .how-work-description {
          text-align: center;
          font-size: 15px;
          font-weight: 400;
          color: #444444;
          line-height: 1.5;
          margin: 0 auto 56px;
          max-width: 850px;
        }


        /* =========================================
           PROCESS WRAPPER
        ========================================== */

        .process-wrapper {
          position: relative;
          width: 100%;
          height: 520px;
        }


        /* =========================================
           CONNECTING LINE
        ========================================== */

        .process-line {
          position: absolute;
          inset: 0;

          width: 100%;
          height: 100%;

          pointer-events: none;

          z-index: 1;

          overflow: visible;
        }


        .process-path {
          /*
            Line completely hidden initially.
          */

          stroke-dasharray: 2400;
          stroke-dashoffset: 2400;

          transition:
            stroke-dashoffset 2.5s
            cubic-bezier(0.65, 0, 0.35, 1);

          transition-delay: 0.05s;
        }


        /*
          Line draws completely
          when section enters viewport.
        */

        .how-work-section.is-visible .process-path {
          stroke-dashoffset: 0;
        }


        /* =========================================
           PROCESS STEP
        ========================================== */

        .process-step {
          position: absolute;

          transform: translate(-50%, -50%);

          width: 235px;

          z-index: 2;

          font-family: "Inter", sans-serif;
        }


        /* =========================================
           DESKTOP POSITIONS
        ========================================== */

        .step-1 {
          left: 10%;
          top: 100px;
        }


        .step-2 {
          left: 50%;
          top: 100px;
        }


        .step-3 {
          left: 91%;
          top: 100px;
        }


        .step-4 {
          left: 10%;
          top: 400px;
        }


        /*
          Evolve is positioned at 46%.
          SVG endpoint is also aligned to
          this position.
        */

        .step-5 {
          left: 46%;
          top: 400px;
        }


        /* =========================================
           ICON CIRCLE
        ========================================== */

        .step-icon {
          width: 62px;
          height: 62px;

          border-radius: 50%;

          border: 1.8px solid ${l};

          background: #ffffff;

          display: flex;
          align-items: center;
          justify-content: center;

          position: relative;

          z-index: 3;

          opacity: 0;

          transform:
            translateY(30px)
            scale(0.55);

          transition:
            opacity 0.55s ease,
            transform 0.8s
              cubic-bezier(0.16, 1, 0.3, 1);

          transition-delay: var(--step-delay);

          will-change:
            transform,
            opacity;
        }


        .how-work-section.is-visible .step-icon {
          opacity: 1;

          transform:
            translateY(0)
            scale(1);
        }


        /* =========================================
           INNER ICON
        ========================================== */

        .step-icon svg {
          opacity: 0;

          transform:
            scale(0.4)
            rotate(-15deg);

          transition:
            opacity 0.45s ease,
            transform 0.7s
              cubic-bezier(0.16, 1, 0.3, 1);

          transition-delay:
            calc(var(--step-delay) + 0.15s);

          will-change:
            transform,
            opacity;
        }


        .how-work-section.is-visible .step-icon svg {
          opacity: 1;

          transform:
            scale(1)
            rotate(0deg);
        }


        /* =========================================
           CONTENT
        ========================================== */

        .step-content {
          margin-top: 20px;

          opacity: 0;

          transform: translateY(22px);

          transition:
            opacity 0.6s ease,
            transform 0.7s
              cubic-bezier(0.16, 1, 0.3, 1);

          transition-delay:
            calc(var(--step-delay) + 0.15s);

          will-change:
            transform,
            opacity;
        }


        .how-work-section.is-visible .step-content {
          opacity: 1;

          transform: translateY(0);
        }


        /* =========================================
           TEXT
        ========================================== */

        .step-number {
          font-size: 15px;
          font-weight: 600;
          color: #141414;
          margin: 0 0 4px;
        }


        .step-title {
          font-size: 18px;
          font-weight: 700;
          color: ${l};
          margin: 0 0 10px;
        }


        .step-description {
          font-size: 14px;
          color: #3a3a3a;
          line-height: 1.55;
          margin: 0;
          max-width: 215px;
        }


        /* =========================================
           TABLET
        ========================================== */

        @media (max-width: 1100px) {

          .how-work-container {
            padding-left: 24px;
            padding-right: 24px;
          }

          .process-step {
            width: 210px;
          }

          .step-description {
            max-width: 195px;
            font-size: 13.5px;
          }

          .step-1 {
            left: 10%;
          }

          .step-2 {
            left: 50%;
          }

          .step-3 {
            left: 90%;
          }

          .step-4 {
            left: 11%;
          }

          .step-5 {
            left: 46%;
          }
        }


        /* =========================================
           SMALL TABLET
        ========================================== */

        @media (max-width: 850px) {

          .how-work-container {
            padding: 48px 22px 60px;
          }

          .how-work-heading {
            font-size: 28px;
          }

          .how-work-description {
            font-size: 16px;
            margin-bottom: 45px;
          }

          .process-wrapper {
            height: 560px;
          }

          .process-step {
            width: 190px;
          }

          .step-icon {
            width: 58px;
            height: 58px;
          }

          .step-title {
            font-size: 17px;
          }

          .step-description {
            font-size: 13px;
            max-width: 180px;
          }

          .step-1 {
            left: 12%;
            top: 100px;
          }

          .step-2 {
            left: 50%;
            top: 100px;
          }

          .step-3 {
            left: 88%;
            top: 100px;
          }

          .step-4 {
            left: 20%;
            top: 420px;
          }

          .step-5 {
            left: 55%;
            top: 420px;
          }
        }


        /* =========================================
           MOBILE
        ========================================== */

        @media (max-width: 600px) {

          .how-work-container {
            padding: 38px 18px 50px;
          }

          .how-work-label {
            font-size: 11px;
            margin: 0 0 12px;
          }

          .how-work-heading {
            font-size: 24px;
            line-height: 1.25;
            margin-bottom: 12px;
          }

          .how-work-description {
            font-size: 14px;
            line-height: 1.55;
            max-width: 340px;
            margin-bottom: 35px;
          }

          .process-wrapper {
            height: auto;

            display: flex;
            flex-direction: column;

            gap: 38px;

            padding: 5px 0 5px 8px;
          }


          /*
            No connecting line on mobile.
          */

          .process-line {
            display: none;
          }


          .process-step {
            position: relative;

            left: auto !important;
            top: auto !important;

            transform: none;

            width: 100%;
            max-width: 420px;

            display: grid;

            grid-template-columns: 62px 1fr;

            column-gap: 18px;

            align-items: start;
          }


          .step-icon {
            width: 58px;
            height: 58px;

            grid-row: span 2;
          }


          .step-content {
            margin-top: 0;
            padding-top: 1px;
          }


          .step-number {
            font-size: 13px;
            margin-bottom: 3px;
          }


          .step-title {
            font-size: 18px;
            margin-bottom: 7px;
          }


          .step-description {
            font-size: 13.5px;
            line-height: 1.55;
            max-width: 100%;
          }
        }


        /* =========================================
           SMALL MOBILE
        ========================================== */

        @media (max-width: 400px) {

          .how-work-container {
            padding-left: 15px;
            padding-right: 15px;
          }

          .how-work-heading {
            font-size: 22px;
          }

          .how-work-description {
            font-size: 13.5px;
          }

          .process-wrapper {
            gap: 32px;
            padding-left: 4px;
          }

          .process-step {
            grid-template-columns: 54px 1fr;
            column-gap: 15px;
          }

          .step-icon {
            width: 52px;
            height: 52px;
          }

          .step-icon svg {
            width: 21px;
            height: 21px;
          }

          .step-number {
            font-size: 12px;
          }

          .step-title {
            font-size: 17px;
          }

          .step-description {
            font-size: 13px;
          }
        }


        /* =========================================
           REDUCED MOTION
        ========================================== */

        @media (prefers-reduced-motion: reduce) {

          .process-path,
          .step-icon,
          .step-icon svg,
          .step-content {
            transition: none !important;
            transform: none !important;
            opacity: 1 !important;
          }
        }

      `})]})}function g({step:n,className:r,delay:s}){return e.jsxs("div",{className:`process-step ${r}`,style:{"--step-delay":s},children:[e.jsx("div",{className:"step-icon",children:n.icon}),e.jsxs("div",{className:"step-content",children:[e.jsx("p",{className:"step-number",children:n.num}),e.jsx("p",{className:"step-title",children:n.title}),e.jsx("p",{className:"step-description",children:n.desc})]})]})}function L(){const[n,r]=i.useState(!1),s=i.useRef(null),t=i.useRef(null),p=y(),d=()=>{t.current&&clearTimeout(t.current),r(!0)},h=()=>{t.current=setTimeout(()=>{r(!1)},500)};i.useEffect(()=>{const c=x=>{s.current&&!s.current.contains(x.target)&&r(!1)},a=x=>{x.key==="Escape"&&r(!1)};return document.addEventListener("mousedown",c),document.addEventListener("keydown",a),()=>{document.removeEventListener("mousedown",c),document.removeEventListener("keydown",a),t.current&&clearTimeout(t.current)}},[]);const o=()=>{p("/talk-to-expert")};return e.jsxs("section",{className:"relative w-full h-[535px] overflow-hidden bg-[#18001f]",children:[e.jsx("img",{loading:"lazy",decoding:"async",src:"/slide1.2.webp",alt:"Technology future",className:"absolute inset-0 w-full h-full object-fill"}),e.jsx("div",{className:"absolute inset-0",style:{background:"linear-gradient(90deg, rgba(24,0,31,0.82) 0%, rgba(24,0,31,0.60) 38%, rgba(24,0,31,0.20) 68%, rgba(24,0,31,0.05) 100%)"}}),e.jsx("div",{className:"relative z-10 min-h-[600px] w-full flex items-center",children:e.jsx("div",{className:"w-full px-4 sm:px-6 md:px-10 lg:px-[100px]",children:e.jsxs("div",{className:"max-w-[600px] text-white",children:[e.jsxs("h2",{className:"font-['Plus_Jakarta_Sans'] font-semibold text-[30px] sm:text-[34px] md:text-[34px] lg:text-[36px] leading-[1.08] tracking-tight -translate-y-10",children:["Let’s Turn Your Next",e.jsx("br",{}),"Challenge Into an",e.jsx("br",{}),"Opportunity"]}),e.jsxs("p",{className:"relative -top-4 mt-7 max-w-[540px] font-['Inter'] text-[15px] sm:text-[16px] md:text-[16px] lg:text-[16px] leading-[1.4] text-white/85",children:["Whether you're looking to modernize,",e.jsx("br",{}),"automate, build or scale, let's explore what the right technology",e.jsx("br",{}),"approach could look like for your business."]}),e.jsxs("div",{ref:s,className:"relative -top-6 mt-24 inline-block",onMouseEnter:d,onMouseLeave:h,children:[e.jsxs("button",{type:"button",onClick:o,className:"group inline-flex items-center gap-2 border border-white/80 px-4 py-2 text-[14px] font-medium text-white transition duration-300 hover:bg-white hover:text-[#18001f]","aria-label":"Talk to Our Experts",children:["Talk to Our Experts",e.jsx(f,{size:16,strokeWidth:1.8,className:"transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1"})]}),n&&e.jsxs("div",{className:"absolute left-full top-1/2 ml-2 flex -translate-y-1/2 items-center gap-2",onMouseEnter:d,onMouseLeave:h,children:[e.jsx("a",{href:"tel:+915813500381","aria-label":"Call us",title:"Call us",className:"flex h-10 w-10 items-center justify-center rounded-full border border-white/80 bg-[#18001f] text-white transition duration-300 hover:border-[#730042] hover:bg-[#730042]",children:e.jsx(w,{size:18})}),e.jsx("a",{href:"https://wa.me/91XXXXXXXXXX?text=Hi%2C%20I%27d%20like%20to%20know%20more%20about%20your%20technology%20solutions.",target:"_blank",rel:"noopener noreferrer","aria-label":"Chat on WhatsApp",title:"WhatsApp",className:"flex h-10 w-10 items-center justify-center rounded-full border border-white/80 bg-[#18001f] text-white transition duration-300 hover:border-[#730042] hover:bg-[#730042]",children:e.jsx(b,{size:18})}),e.jsx("a",{href:"https://mail.google.com/mail/?view=cm&fs=1&to=contact@techtorch.solutions&su=Technology%20Services%20Enquiry",target:"_blank",rel:"noopener noreferrer","aria-label":"Email us",title:"Email us",className:"flex h-10 w-10 items-center justify-center rounded-full border border-white/80 bg-[#18001f] text-white transition duration-300 hover:border-[#730042] hover:bg-[#730042]",children:e.jsx(v,{size:18})})]})]})]})})})]})}function W(){return e.jsxs(e.Fragment,{children:[e.jsx(k,{}),e.jsx(N,{}),e.jsx(T,{}),e.jsx(L,{})]})}export{T as HowWeWork,L as PurpleHero,k as TechHero,N as WithPurpose,W as default};
