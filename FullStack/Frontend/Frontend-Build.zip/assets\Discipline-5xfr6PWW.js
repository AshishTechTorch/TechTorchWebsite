import{j as e}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";const i=[{number:"01",title:"IT CONSULTANCY",description:"Technology guidance aligned with business objectives and digital transformation requirements.",image:"https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=900&q=85"},{number:"02",title:"ARTIFICIAL INTELLIGENCE",description:"AI capabilities that allow organizations to explore intelligent solutions without internal maintenance overhead.",image:"/Ai integration.webp"},{number:"03",title:"CLOUD INFRASTRUCTURE",description:"Scalable infrastructure designed to support evolving enterprise IT requirements and high availability.",image:"/Professionalenterprise.webp"},{number:"04",title:"CYBER SECURITY",description:"Technology and security services focused on protecting digital assets and sensitive business information.",image:"https://images.unsplash.com/photo-1563013544-824ae1b704d3?auto=format&fit=crop&w=900&q=85"},{number:"05",title:"SOFTWARE ENGINEERING",description:"Engineering expertise focused on mission-critical technical and operational requirements.",image:"/Engineering visualization.webp"},{number:"06",title:"SOFTWARE DEV & SUPPORT",description:"End-to-end development, integration, modernization and ongoing technical support services.",image:"https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=85"},{number:"07",title:"RESOURCE & STAFFING",description:"Skilled technology professionals and flexible workforce solutions tailored to project demands.",image:"https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=900&q=85"}];function a(){return e.jsxs("section",{className:"technology-capabilities",children:[e.jsxs("div",{className:"technology-container",children:[e.jsxs("div",{className:"technology-header",children:[e.jsxs("div",{className:"technology-badge",children:[e.jsx("span",{className:"badge-dot"}),"ENGINEERING DISCIPLINE"]}),e.jsxs("h2",{children:["Technology Should Create Clarity,",e.jsx("br",{}),"Not Complexity"]}),e.jsxs("p",{children:["TechTorch's broader technology capabilities allow businesses to approach digital",e.jsx("br",{className:"desktop-break"}),"transformation from multiple directions."]})]}),e.jsx("div",{className:"technology-grid",children:i.map(t=>e.jsxs("article",{className:"technology-card",children:[e.jsxs("div",{className:"technology-image-wrapper",children:[e.jsx("img",{loading:"lazy",decoding:"async",src:t.image,alt:t.title,className:"technology-image"}),e.jsxs("div",{className:"capability-label",children:["CAPABILITY  ",t.number]})]}),e.jsxs("div",{className:"technology-card-content",children:[e.jsx("h3",{children:t.title}),e.jsx("p",{children:t.description})]})]},t.number))}),e.jsx("div",{className:"technology-footer",children:"THESE CAPABILITIES ARE PART OF TECHTORCH'S CURRENT ENTERPRISE SERVICES PORTFOLIO."})]}),e.jsx("style",{children:`
        /* ================================
           MAIN SECTION (padding same as other sections)
        ================================= */

        .technology-capabilities {
          width: 100%;
          background: #faf9f4;
          padding: 40px 16px;
          overflow: hidden;
          font-family: "Inter", sans-serif;
          color: #11172b;
        }

        @media (min-width: 640px) {
          .technology-capabilities {
            padding: 48px 24px;
          }
        }

        @media (min-width: 768px) {
          .technology-capabilities {
            padding: 56px 40px;
          }
        }

        @media (min-width: 1024px) {
          .technology-capabilities {
            padding: 64px 100px;
          }
        }

        @media (min-width: 1280px) {
          .technology-capabilities {
            padding: 80px 100px;
          }
        }

        .technology-container {
          width: 100%;
        }

        .technology-header {
          width: 100%;
        }

        .technology-badge {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          height: 22px;
          padding: 0 10px;
          border: 1px solid #e4bfd1;
          border-radius: 14px;
          background: #fff9fc;
          color: #850047;
          font-size: 9.5px;
          line-height: 1;
          font-weight: 800;
          letter-spacing: 0.75px;
        }

        .badge-dot {
          width: 5px;
          height: 5px;
          border-radius: 50%;
          background: #a30058;
          flex-shrink: 0;
        }

        .technology-header h2 {
          margin: 12px 0 8px;
          max-width: 650px;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 30px;
          line-height: 1.08;
          letter-spacing: -1.25px;
          font-weight: 500;
          color: #0f1528;
        }

        .technology-header p {
          margin: 0;
          max-width: 700px;
          color: #627089;
          font-size: 11px;
          line-height: 1.5;
          font-weight: 400;
        }

        .technology-grid {
          width: 100%;
          margin-top: 43px;
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 16px;
        }

        .technology-card {
          width: 100%;
          min-width: 0;
          height: 252px;
          overflow: hidden;
          background: #ffffff;
          border: 1px solid #e3e7ec;
          border-radius: 10px;
          box-shadow: 0 2px 7px rgba(18, 27, 43, 0.04);
        }

        .technology-image-wrapper {
          position: relative;
          width: 100%;
          height: 110px;
          overflow: hidden;
          background: #202633;
        }

        .technology-image {
          display: block;
          width: 100%;
          height: 100%;
          object-fit: cover;
          object-position: center;
          filter: brightness(0.74) saturate(0.85);
        }

        .capability-label {
          position: absolute;
          top: 10px;
          left: 9px;
          z-index: 2;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-height: 17px;
          padding: 0 6px;
          background: #fffafc;
          border: 1px solid #e2c0d1;
          border-radius: 2px;
          color: #830047;
          font-family: "Inter", sans-serif;
          font-size: 9px;
          line-height: 1;
          font-weight: 800;
          letter-spacing: 0.65px;
        }

        .technology-card-content {
          padding: 17px 14px 14px;
        }

        .technology-card-content h3 {
          margin: 0 0 7px;
          color: #171c2b;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 12px;
          line-height: 1.25;
          font-weight: 800;
          letter-spacing: -0.25px;
        }

        .technology-card-content p {
          margin: 0;
          color: #637087;
          font-size: 12px;
          line-height: 1.6;
          font-weight: 400;
        }

        .technology-footer {
          margin-top: 34px;
          text-align: center;
          color: #9aa7b8;
          font-size: 10px;
          line-height: 1.4;
          font-weight: 700;
          letter-spacing: 0.35px;
        }

        /* ================================
           LARGE DESKTOP
        ================================= */

        @media (min-width: 1500px) {
          .technology-header h2 {
            font-size: 34px;
          }

          .technology-header p {
            font-size: 12px;
          }

          .technology-grid {
            margin-top: 47px;
            gap: 18px;
          }

          .technology-card {
            height: 270px;
          }

          .technology-image-wrapper {
            height: 120px;
          }

          .technology-card-content {
            padding: 19px 16px 16px;
          }

          .technology-card-content h3 {
            font-size: 13px;
          }

          .technology-card-content p {
            font-size: 12.5px;
          }
        }

        /* ================================
           TABLET
        ================================= */

        @media (max-width: 1000px) {
          .technology-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
          }

          .technology-card {
            height: 270px;
          }

          .technology-image-wrapper {
            height: 125px;
          }
        }

        /* ================================
           MOBILE
        ================================= */

        @media (max-width: 700px) {
          .technology-header h2 {
            font-size: 27px;
            letter-spacing: -0.9px;
          }

          .technology-header p {
            font-size: 10.5px;
          }

          .desktop-break {
            display: none;
          }

          .technology-grid {
            margin-top: 32px;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
          }

          .technology-card {
            height: 260px;
          }

          .technology-image-wrapper {
            height: 115px;
          }

          .technology-card-content {
            padding: 15px 13px 13px;
          }

          .technology-card-content h3 {
            font-size: 11px;
          }

          .technology-card-content p {
            font-size: 11px;
            line-height: 1.55;
          }
        }

        /* ================================
           SMALL MOBILE
        ================================= */

        @media (max-width: 520px) {
          .technology-badge {
            height: 21px;
            padding: 0 9px;
            font-size: 7px;
          }

          .technology-header h2 {
            margin-top: 11px;
            font-size: 24px;
            line-height: 1.1;
            letter-spacing: -0.7px;
          }

          .technology-header p {
            font-size: 10px;
            line-height: 1.5;
          }

          .technology-grid {
            grid-template-columns: 1fr;
            gap: 14px;
            margin-top: 28px;
          }

          .technology-card {
            height: auto;
            min-height: 270px;
          }

          .technology-image-wrapper {
            height: 135px;
          }

          .technology-card-content {
            padding: 17px 15px;
          }

          .technology-card-content h3 {
            font-size: 12px;
            margin-bottom: 7px;
          }

          .technology-card-content p {
            font-size: 11px;
            line-height: 1.6;
          }

          .capability-label {
            top: 9px;
            left: 9px;
            font-size: 6.5px;
          }

          .technology-footer {
            margin-top: 28px;
            font-size: 6.5px;
          }
        }

        @media (max-width: 380px) {
          .technology-header h2 {
            font-size: 22px;
          }

          .technology-header p {
            font-size: 9.5px;
          }

          .technology-image-wrapper {
            height: 125px;
          }

          .technology-card {
            min-height: 255px;
          }

          .technology-card-content {
            padding: 15px 13px;
          }

          .technology-card-content h3 {
            font-size: 11px;
          }

          .technology-card-content p {
            font-size: 10.5px;
          }
        }
      `})]})}export{a as default};
