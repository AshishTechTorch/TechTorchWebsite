import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as p}from"./vendor-router-L4ZCoGSs.js";import{U as l}from"./user-BaVexer9.js";import{M as c}from"./mail-3Flp59qD.js";import{v as d,Y as x}from"./index-BThRNyH6.js";import{P as f}from"./phone-B3rJcDGo.js";import{L as h}from"./lock-keyhole-qgr5czx6.js";import{C as m}from"./clock-3-D3KlVi6Z.js";import{S as g}from"./settings-Dm05DpDI.js";import{M as u}from"./message-square-tRi_lmBc.js";import{N as b}from"./network-Bh2G015s.js";const E=()=>{const[t,a]=p.useState(["infrastructure"]),r=[{id:"infrastructure",tag:"INFRASTRUCTURE",tagClass:"pink",title:"IT Infrastructure & Support",description:"Discuss your infrastructure requirements, technical challenges, and ongoing IT support needs."},{id:"cloud",tag:"CLOUD",tagClass:"pink",title:"Cloud Infrastructure",description:"Explore cloud infrastructure requirements designed to support scalability, accessibility, and efficient IT operations."},{id:"security",tag:"SECURITY",tagClass:"green",title:"Cyber Security",description:"Discuss your cybersecurity requirements and approaches for protecting your systems, applications, and digital assets."},{id:"engineering",tag:"ENGINEERING",tagClass:"blue",title:"Software Engineering",description:"Explore software engineering requirements, application development, system integration, and technical solutions."},{id:"development",tag:"DEVELOPMENT",tagClass:"pink",title:"Software Development & Support",description:"Discuss application development, software maintenance, technical support, and ongoing improvement requirements."},{id:"consulting",tag:"CONSULTING",tagClass:"blue",title:"IT Consultancy",description:"Get guidance on technology challenges, digital transformation requirements, and solutions aligned with your business objectives."},{id:"operations",tag:"OPERATIONS",tagClass:"green",title:"Business Process Support",description:"Explore technology-enabled approaches that can help improve business processes and operational efficiency."},{id:"resources",tag:"RESOURCES",tagClass:"pink",title:"Resource & Staffing",description:"Discuss your requirements for skilled technology professionals and flexible resource solutions."}],n=i=>{a(s=>s.includes(i)?s.filter(o=>o!==i):[...s,i])};return e.jsxs("div",{className:"discuss-page",children:[e.jsx("style",{children:`
        /* =========================================================
           GLOBAL
        ========================================================= */

        * {
          box-sizing: border-box;
        }

        .discuss-page {
          width: 100%;
          min-height: 100vh;
          background: #f7f8fa;
          color: #20232a;
          font-family: "Inter", Arial, Helvetica, sans-serif;
          overflow-x: hidden;
        }

        .discuss-page h1,
        .discuss-page h2,
        .discuss-page h3 {
          font-family: "Plus Jakarta Sans", Arial, Helvetica, sans-serif;
        }

        /* =========================================================
           UNIVERSAL CONTAINER
           Desktop: 100px
           Tablet: 40px
           Mobile: 24px
           Small Mobile: 16px
        ========================================================= */

        .discuss-container {
          width: 100%;
          padding-left: 100px;
          padding-right: 100px;
          margin: 0 auto;
        }

        /* =========================================================
           TOP HEADER
        ========================================================= */

        .discuss-header {
          width: 100%;
          text-align: center;
          padding: 65px 100px 38px;
        }

        .discuss-header-inner {
          width: 100%;
          max-width: 900px;
          margin: 0 auto;
        }

        .discuss-label {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 7px;
          padding: 7px 14px;
          border-radius: 20px;
          border: 1px solid #d7bccb;
          background: #f0e8ed;
          color: #70003f;
          font-family: "Inter", Arial, sans-serif;
          font-size: 10px;
          line-height: 1;
          font-weight: 800;
          letter-spacing: 0.9px;
          text-transform: uppercase;
        }

        .discuss-label::before {
          content: "";
          width: 6px;
          height: 6px;
          flex-shrink: 0;
          border-radius: 50%;
          background: #70003f;
        }

        .discuss-header h1 {
          max-width: 850px;
          margin: 20px auto 13px;
          color: #202124;
          font-size: clamp(38px, 4.2vw, 56px);
          line-height: 1.08;
          letter-spacing: -2px;
          font-weight: 700;
        }

        .discuss-header p {
          max-width: 760px;
          margin: 0 auto;
          color: #3f506b;
          font-family: "Inter", Arial, sans-serif;
          font-size: 16px;
          line-height: 1.65;
          font-weight: 400;
        }

        /* =========================================================
           MAIN GRID
        ========================================================= */

        .discussion-layout {
          width: 100%;
          display: grid;
          grid-template-columns: minmax(0, 1.35fr) minmax(360px, 0.95fr);
          gap: 28px;
          align-items: start;
          padding-bottom: 24px;
        }

        /* =========================================================
           DISCUSSION AREAS CARD
        ========================================================= */

        .areas-card {
          width: 100%;
          padding: 30px 30px 25px;
          background: #ffffff;
          border: 1px solid #dce2e9;
          border-radius: 15px;
          box-shadow: 0 2px 5px rgba(30, 40, 55, 0.035);
        }

        .step-label {
          display: inline-flex;
          align-items: center;
          padding: 5px 11px;
          border-radius: 5px;
          background: #f0e7ed;
          color: #70003f;
          font-family: "Inter", Arial, sans-serif;
          font-size: 10px;
          line-height: 1;
          font-weight: 800;
          letter-spacing: 0.65px;
          text-transform: uppercase;
        }

        .areas-card h2,
        .consultation-card h2 {
          margin: 10px 0 5px;
          color: #24262b;
          font-size: 21px;
          line-height: 1.3;
          font-weight: 650;
          letter-spacing: -0.3px;
        }

        .areas-subtitle {
          margin: 0;
          color: #676767;
          font-family: "Inter", Arial, sans-serif;
          font-size: 12px;
          line-height: 1.5;
          font-weight: 600;
          letter-spacing: 0.15px;
        }

        /* =========================================================
           AREAS GRID
        ========================================================= */

        .areas-grid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 11px;
          margin-top: 19px;
        }

        .area-option {
          position: relative;
          min-height: 132px;
          padding: 14px;
          border: 1px solid #d8e0e9;
          border-radius: 10px;
          background: #ffffff;
          cursor: pointer;
          transition:
            border-color 0.22s ease,
            box-shadow 0.22s ease,
            transform 0.22s ease,
            background 0.22s ease;
        }

        .area-option:hover {
          border-color: #b9829e;
          box-shadow: 0 5px 15px rgba(112, 0, 63, 0.07);
          transform: translateY(-2px);
        }

        .area-option.selected {
          border-color: #b7c5d6;
        }

        .area-top {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 10px;
        }

        .area-tag {
          display: inline-flex;
          align-items: center;
          min-height: 24px;
          padding: 4px 8px;
          border-radius: 4px;
          font-family: "Inter", Arial, sans-serif;
          font-size: 9px;
          line-height: 1;
          font-weight: 800;
          letter-spacing: 0.55px;
        }

        .area-tag.pink {
          color: #8a1456;
          background: #f5eaf0;
          border: 1px solid #e2c7d6;
        }

        .area-tag.green {
          color: #007657;
          background: #e8f8f3;
          border: 1px solid #b8eadb;
        }

        .area-tag.blue {
          color: #46566e;
          background: #edf2f7;
          border: 1px solid #d9e2ed;
        }

        .custom-checkbox {
          width: 15px;
          height: 15px;
          flex-shrink: 0;
          margin-top: 1px;
          border: 1px solid #a5a8ac;
          border-radius: 2px;
          background: #ffffff;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: 0.2s ease;
        }

        .custom-checkbox.checked {
          background: #70003f;
          border-color: #70003f;
        }

        .custom-checkbox.checked::after {
          content: "✓";
          color: #ffffff;
          font-family: "Inter", Arial, sans-serif;
          font-size: 10px;
          line-height: 1;
          font-weight: 800;
        }

        .area-option h3 {
          margin: 10px 0 5px;
          padding-right: 5px;
          color: #1e2738;
          font-size: 13px;
          line-height: 1.35;
          font-weight: 700;
          letter-spacing: -0.15px;
        }

        .area-option p {
          margin: 0;
          color: #53637b;
          font-family: "Inter", Arial, sans-serif;
          font-size: 11.5px;
          line-height: 1.52;
        }

        .areas-footer {
          margin-top: 16px;
          padding-top: 12px;
          border-top: 1px solid #e2e6eb;
          color: #777777;
          font-family: "Inter", Arial, sans-serif;
          font-size: 10px;
          line-height: 1.4;
          letter-spacing: 0.35px;
        }

        /* =========================================================
           CONSULTATION CARD
        ========================================================= */

        .consultation-card {
          width: 100%;
          padding: 27px 28px 26px;
          background: #ffffff;
          border: 1px solid #dce2e9;
          border-radius: 15px;
          box-shadow: 0 3px 7px rgba(30, 40, 55, 0.06);
        }

        .consultation-intro {
          margin: 0 0 17px;
          color: #666666;
          font-family: "Inter", Arial, sans-serif;
          font-size: 12px;
          line-height: 1.5;
          font-weight: 500;
        }

        /* =========================================================
           FORM
        ========================================================= */

        .form-group {
          margin-bottom: 12px;
        }

        .form-label {
          display: block;
          margin-bottom: 6px;
          color: #303238;
          font-family: "Inter", Arial, sans-serif;
          font-size: 11px;
          line-height: 1.25;
          font-weight: 700;
          letter-spacing: 0.15px;
        }

        .input-wrap {
          position: relative;
        }

        .input-wrap svg {
          position: absolute;
          left: 10px;
          top: 50%;
          width: 14px;
          height: 14px;
          transform: translateY(-50%);
          color: #777777;
          pointer-events: none;
        }

        .form-input,
        .form-select,
        .form-textarea {
          width: 100%;
          border: 1px solid #dbe2e9;
          border-radius: 7px;
          background: #f8fafc;
          color: #303238;
          outline: none;
          font-family: "Inter", Arial, sans-serif;
          transition:
            border-color 0.2s ease,
            box-shadow 0.2s ease,
            background 0.2s ease;
        }

        .form-input,
        .form-select {
          height: 40px;
          padding: 0 11px;
          font-size: 12px;
        }

        .input-with-icon {
          padding-left: 34px;
        }

        .form-textarea {
          min-height: 82px;
          padding: 10px;
          resize: vertical;
          font-size: 12px;
          line-height: 1.45;
        }

        .form-input::placeholder,
        .form-textarea::placeholder {
          color: #a1a4a8;
        }

        .form-input:focus,
        .form-select:focus,
        .form-textarea:focus {
          border-color: #b8879f;
          background: #ffffff;
          box-shadow: 0 0 0 3px rgba(112, 0, 63, 0.06);
        }

        .two-column {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 10px;
        }

        .form-select {
          appearance: none;
          -webkit-appearance: none;
          background-image:
            linear-gradient(45deg, transparent 50%, #888888 50%),
            linear-gradient(135deg, #888888 50%, transparent 50%);
          background-position:
            calc(100% - 14px) 17px,
            calc(100% - 10px) 17px;
          background-size: 4px 4px, 4px 4px;
          background-repeat: no-repeat;
          padding-right: 27px;
          cursor: pointer;
        }

        /* =========================================================
           BOTTOM INFO
        ========================================================= */

        .form-bottom-info {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 15px;
          margin: 5px 0 14px;
          color: #666666;
          font-family: "Inter", Arial, sans-serif;
          font-size: 9.5px;
          letter-spacing: 0.35px;
        }

        .form-bottom-info span {
          display: inline-flex;
          align-items: center;
          gap: 5px;
        }

        .form-bottom-info svg {
          width: 12px;
          height: 12px;
        }

        .form-bottom-info .secure {
          color: #58725d;
        }

        .form-bottom-info .response {
          color: #6e3455;
        }

        /* =========================================================
           SUBMIT
        ========================================================= */

        .consultation-submit {
          width: 100%;
          height: 41px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          border: 0;
          border-radius: 6px;
          background: #820044;
          color: #ffffff;
          font-family: "Inter", Arial, sans-serif;
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 0.8px;
          cursor: pointer;
          transition:
            background 0.25s ease,
            transform 0.25s ease,
            box-shadow 0.25s ease;
        }

        .consultation-submit:hover {
          background: #6f003c;
          transform: translateY(-1px);
          box-shadow: 0 6px 14px rgba(112, 0, 63, 0.16);
        }

        .consultation-note {
          margin: 14px auto 0;
          max-width: 290px;
          text-align: center;
          color: #777777;
          font-family: "Inter", Arial, sans-serif;
          font-size: 9.5px;
          line-height: 1.4;
          letter-spacing: 0.65px;
          font-weight: 600;
        }

        /* =========================================================
           WHAT YOU CAN EXPECT
        ========================================================= */

        .expect-card {
          width: 100%;
          margin-bottom: 35px;
          padding: 26px 28px 24px;
          background: #ffffff;
          border: 1px solid #dce2e9;
          border-radius: 15px;
          box-shadow: 0 2px 5px rgba(30, 40, 55, 0.035);
        }

        .expect-header {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 20px;
          margin-bottom: 20px;
        }

        .expect-heading {
          display: flex;
          align-items: flex-start;
          gap: 10px;
        }

        .expect-icon {
          width: 24px;
          height: 24px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          margin-top: 1px;
          border-radius: 6px;
          background: #f2e8ee;
          border: 1px solid #dec7d4;
          color: #70003f;
        }

        .expect-icon svg {
          width: 13px;
          height: 13px;
        }

        .expect-title-label {
          margin: 0 0 4px;
          color: #70003f;
          font-family: "Inter", Arial, sans-serif;
          font-size: 9px;
          line-height: 1;
          font-weight: 800;
          letter-spacing: 0.8px;
          text-transform: uppercase;
        }

        .expect-description {
          margin: 0;
          color: #65758e;
          font-family: "Inter", Arial, sans-serif;
          font-size: 11px;
          line-height: 1.5;
        }

        .no-obligation {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          min-width: 141px;
          padding: 6px 10px;
          border: 1px solid #dce3ea;
          border-radius: 20px;
          color: #596a7f;
          font-family: "Inter", Arial, sans-serif;
          font-size: 9px;
          line-height: 1.15;
        }

        .no-obligation::before {
          content: "";
          width: 6px;
          height: 6px;
          flex-shrink: 0;
          border-radius: 50%;
          background: #13a56f;
        }

        .expect-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 11px;
        }

        .expect-item {
          min-height: 225px;
          padding: 13px;
          border: 1px solid #dce3ea;
          border-radius: 10px;
          background: #fbfcfd;
          transition:
            transform 0.22s ease,
            box-shadow 0.22s ease,
            border-color 0.22s ease;
        }

        .expect-item:hover {
          transform: translateY(-2px);
          border-color: #d2bac8;
          box-shadow: 0 5px 15px rgba(40, 45, 60, 0.05);
        }

        .expect-item-top {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 10px;
        }

        .expect-item-icon {
          width: 25px;
          height: 25px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 6px;
          border: 1px solid #dec7d4;
          background: #f2e8ee;
          color: #70003f;
        }

        .expect-item-icon svg {
          width: 14px;
          height: 14px;
        }

        .expect-number {
          color: #91a0b4;
          font-family: "Inter", Arial, sans-serif;
          font-size: 9px;
          font-weight: 700;
        }

        .expect-item h3 {
          margin: 0 0 8px;
          color: #1f2939;
          font-size: 12px;
          line-height: 1.35;
          font-weight: 700;
        }

        .expect-item p {
          margin: 0;
          color: #53647b;
          font-family: "Inter", Arial, sans-serif;
          font-size: 11px;
          line-height: 1.55;
        }

        /* =========================================================
           TABLET
           40px horizontal spacing
        ========================================================= */

        @media (max-width: 1200px) {
          .discuss-container {
            padding-left: 40px;
            padding-right: 40px;
          }

          .discuss-header {
            padding-left: 40px;
            padding-right: 40px;
          }

          .discussion-layout {
            grid-template-columns:
              minmax(0, 1.15fr)
              minmax(330px, 0.85fr);
            gap: 22px;
          }

          .areas-card,
          .consultation-card {
            padding-left: 23px;
            padding-right: 23px;
          }

          .expect-card {
            padding-left: 23px;
            padding-right: 23px;
          }
        }

        /* =========================================================
           TABLET / SMALL LAPTOP
        ========================================================= */

        @media (max-width: 900px) {
          .discuss-header {
            padding-top: 52px;
            padding-bottom: 34px;
          }

          .discuss-header h1 {
            font-size: 42px;
            letter-spacing: -1.4px;
          }

          .discuss-header p {
            font-size: 15px;
          }

          .discussion-layout {
            grid-template-columns: 1fr;
            gap: 20px;
          }

          .areas-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .expect-grid {
            grid-template-columns: repeat(3, minmax(0, 1fr));
          }
        }

        /* =========================================================
           MOBILE
           24px horizontal spacing
        ========================================================= */

        @media (max-width: 700px) {
          .discuss-container {
            padding-left: 24px;
            padding-right: 24px;
          }

          .discuss-header {
            padding:
              42px
              24px
              28px;
          }

          .discuss-label {
            max-width: 100%;
            padding: 6px 11px;
            font-size: 8px;
            letter-spacing: 0.65px;
            white-space: normal;
            line-height: 1.35;
          }

          .discuss-header h1 {
            margin-top: 17px;
            font-size: 32px;
            line-height: 1.12;
            letter-spacing: -1px;
          }

          .discuss-header p {
            font-size: 13px;
            line-height: 1.6;
          }

          .areas-card,
          .consultation-card,
          .expect-card {
            border-radius: 12px;
          }

          .areas-card {
            padding: 22px 17px 19px;
          }

          .consultation-card {
            padding: 22px 17px;
          }

          .areas-card h2,
          .consultation-card h2 {
            font-size: 19px;
          }

          .areas-subtitle,
          .consultation-intro {
            font-size: 11px;
          }

          .areas-grid {
            grid-template-columns: 1fr;
            gap: 9px;
          }

          .area-option {
            min-height: auto;
            padding: 13px;
          }

          .area-option h3 {
            font-size: 13px;
          }

          .area-option p {
            font-size: 11px;
          }

          .two-column {
            grid-template-columns: 1fr;
            gap: 0;
          }

          .form-bottom-info {
            font-size: 8.5px;
          }

          .expect-card {
            padding: 22px 17px;
          }

          .expect-header {
            flex-direction: column;
            gap: 13px;
          }

          .no-obligation {
            align-self: flex-start;
          }

          .expect-grid {
            grid-template-columns: 1fr;
            gap: 9px;
          }

          .expect-item {
            min-height: auto;
          }
        }

        /* =========================================================
           SMALL MOBILE
           16px horizontal spacing
        ========================================================= */

        @media (max-width: 480px) {
          .discuss-container {
            padding-left: 16px;
            padding-right: 16px;
          }

          .discuss-header {
            padding-left: 16px;
            padding-right: 16px;
            padding-top: 34px;
          }

          .discuss-header h1 {
            font-size: 28px;
            letter-spacing: -0.8px;
          }

          .discuss-header p {
            font-size: 12.5px;
          }

          .areas-card,
          .consultation-card,
          .expect-card {
            padding-left: 14px;
            padding-right: 14px;
          }

          .step-label {
            font-size: 8px;
          }

          .areas-card h2,
          .consultation-card h2 {
            font-size: 18px;
          }

          .form-input,
          .form-select {
            font-size: 11.5px;
          }

          .form-textarea {
            font-size: 11.5px;
          }

          .form-bottom-info {
            flex-direction: column;
            align-items: flex-start;
            gap: 7px;
          }

          .consultation-submit {
            height: 42px;
            font-size: 10px;
          }

          .expect-description {
            font-size: 10.5px;
          }
        }

        /* =========================================================
           EXTRA SMALL
        ========================================================= */

        @media (max-width: 360px) {
          .discuss-header h1 {
            font-size: 25px;
          }

          .discuss-header p {
            font-size: 12px;
          }

          .area-option h3 {
            font-size: 12px;
          }

          .area-option p {
            font-size: 10.5px;
          }

          .form-label {
            font-size: 10.5px;
          }

          .expect-item h3 {
            font-size: 11.5px;
          }

          .expect-item p {
            font-size: 10.5px;
          }
        }
      `}),e.jsx("section",{className:"discuss-header",children:e.jsxs("div",{className:"discuss-header-inner",children:[e.jsx("div",{className:"discuss-label",children:"TECHTORCH MSP SUPPORT • IT CONSULTATION"}),e.jsxs("h1",{children:["Discuss Your IT Requirements &",e.jsx("br",{}),"Business Priorities"]}),e.jsx("p",{children:"Connect with the TechTorch team to discuss your technology environment, operational requirements, and current IT challenges. We’ll understand your needs and help identify the right technology approach for your business."})]})}),e.jsxs("div",{className:"discuss-container",children:[e.jsxs("div",{className:"discussion-layout",children:[e.jsxs("div",{className:"areas-card",children:[e.jsx("div",{className:"step-label",children:"STEP 01 · DISCUSSION AREAS"}),e.jsx("h2",{children:"What Would You Like to Discuss?"}),e.jsx("p",{className:"areas-subtitle",children:"Select the areas that best match your current technology requirements."}),e.jsx("div",{className:"areas-grid",children:r.map(i=>{const s=t.includes(i.id);return e.jsxs("div",{className:`area-option ${s?"selected":""}`,onClick:()=>n(i.id),children:[e.jsxs("div",{className:"area-top",children:[e.jsx("span",{className:`area-tag ${i.tagClass}`,children:i.tag}),e.jsx("span",{className:`custom-checkbox ${s?"checked":""}`})]}),e.jsx("h3",{children:i.title}),e.jsx("p",{children:i.description})]},i.id)})}),e.jsx("div",{className:"areas-footer",children:"Explore the technology areas where TechTorch can support your business."})]}),e.jsxs("div",{className:"consultation-card",children:[e.jsx("div",{className:"step-label",children:"STEP 02 · CONSULTATION DETAILS"}),e.jsx("h2",{children:"Request an IT Consultation"}),e.jsx("p",{className:"consultation-intro",children:"Tell us about your technology requirements, current challenges, or upcoming initiatives. Our team will review your enquiry and connect with you to discuss the next steps."}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"Full Name"}),e.jsxs("div",{className:"input-wrap",children:[e.jsx(l,{}),e.jsx("input",{className:"form-input input-with-icon",type:"text",placeholder:"e.g. Eleanor Vance"})]})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"Business Email Address"}),e.jsxs("div",{className:"input-wrap",children:[e.jsx(c,{}),e.jsx("input",{className:"form-input input-with-icon",type:"email",placeholder:"name@company.com"})]})]}),e.jsxs("div",{className:"two-column",children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"Company Name"}),e.jsxs("div",{className:"input-wrap",children:[e.jsx(d,{}),e.jsx("input",{className:"form-input input-with-icon",type:"text",placeholder:"e.g. Acme Corp"})]})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"Team / Business Size"}),e.jsxs("select",{className:"form-select",children:[e.jsx("option",{children:"50 – 200 employees"}),e.jsx("option",{children:"1 – 50 employees"}),e.jsx("option",{children:"200 – 500 employees"}),e.jsx("option",{children:"500+ employees"})]})]})]}),e.jsxs("div",{className:"two-column",children:[e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"Phone Number"}),e.jsxs("div",{className:"input-wrap",children:[e.jsx(f,{}),e.jsx("input",{className:"form-input input-with-icon",type:"tel",placeholder:"+1 (555) 000-0000"})]})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"Preferred Timeline"}),e.jsxs("select",{className:"form-select",children:[e.jsx("option",{children:"Within 1 – 2 Weeks"}),e.jsx("option",{children:"Within 1 Month"}),e.jsx("option",{children:"Within 3 Months"}),e.jsx("option",{children:"Exploring Options"})]})]})]}),e.jsxs("div",{className:"form-group",children:[e.jsx("label",{className:"form-label",children:"What Would You Like to Discuss?"}),e.jsx("textarea",{className:"form-textarea",placeholder:"Tell us about your current IT environment, technology challenges, upcoming projects, or support requirements..."})]}),e.jsxs("div",{className:"form-bottom-info",children:[e.jsxs("span",{className:"secure",children:[e.jsx(h,{}),"Confidential Discussion"]}),e.jsxs("span",{className:"response",children:[e.jsx(m,{}),"Timely Response"]})]}),e.jsxs("button",{className:"consultation-submit",children:["REQUEST A CONSULTATION",e.jsx("span",{children:"→"})]}),e.jsxs("p",{className:"consultation-note",children:["Professional Consultation · Business-Focused",e.jsx("br",{}),"Technology Discussion"]})]})]}),e.jsxs("div",{className:"expect-card",children:[e.jsxs("div",{className:"expect-header",children:[e.jsxs("div",{className:"expect-heading",children:[e.jsx("div",{className:"expect-icon",children:e.jsx(g,{})}),e.jsxs("div",{children:[e.jsx("p",{className:"expect-title-label",children:"WHAT YOU CAN EXPECT"}),e.jsx("p",{className:"expect-description",children:"How TechTorch approaches every initial advisory conversation"})]})]}),e.jsxs("div",{className:"no-obligation",children:["No-obligation",e.jsx("br",{}),"Consultation"]})]}),e.jsxs("div",{className:"expect-grid",children:[e.jsxs("div",{className:"expect-item",children:[e.jsxs("div",{className:"expect-item-top",children:[e.jsx("div",{className:"expect-item-icon",children:e.jsx(u,{})}),e.jsx("span",{className:"expect-number",children:"01"})]}),e.jsx("h3",{children:"Technology-Focused Discussion"}),e.jsx("p",{children:"Share your requirements with the TechTorch team and discuss the technology challenges affecting your business."})]}),e.jsxs("div",{className:"expect-item",children:[e.jsxs("div",{className:"expect-item-top",children:[e.jsx("div",{className:"expect-item-icon",children:e.jsx(x,{})}),e.jsx("span",{className:"expect-number",children:"02"})]}),e.jsx("h3",{children:"Business-Aligned Solutions"}),e.jsx("p",{children:"We focus on understanding your requirements before identifying an appropriate technology approach."})]}),e.jsxs("div",{className:"expect-item",children:[e.jsxs("div",{className:"expect-item-top",children:[e.jsx("div",{className:"expect-item-icon",children:e.jsx(b,{})}),e.jsx("span",{className:"expect-number",children:"03"})]}),e.jsx("h3",{children:"End-to-End Technology Expertise"}),e.jsx("p",{children:"Explore support across IT consulting, cloud infrastructure, cybersecurity, software engineering, software development, and related technology services."})]})]})]})]})]})};export{E as default};
