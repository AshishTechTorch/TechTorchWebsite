import{j as e}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";import{C as s}from"./chevron-left-BgtRXmaB.js";import{t as l}from"./index-BThRNyH6.js";const a={name:"shield-exclamation-point",size:24,node:[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M12 8v4",key:"1got3b"}],["path",{d:"M12 16h.01",key:"1drbdi"}]],aliases:["shield-alert"]};a.node;const c=l(a),o="#7A1F3D",t="#1B1B2A",n="#5b5a63",r=["ERP Architecture","Operations Mgmt","Supply Chain","People Resources","Web Portals","Finance Systems","Payment Solutions","CRM Platforms"];function h(){return e.jsxs("section",{className:"telecom-technology-section",children:[e.jsx("style",{children:`

        /* =========================================
           MAIN SECTION
        ========================================= */

        .telecom-technology-section {
          width: 100%;
          overflow: hidden;

          background: #f4f1ec;
          color: ${t};

          font-family: "Inter", sans-serif;
        }

        .telecom-technology-section *,
        .telecom-technology-section *::before,
        .telecom-technology-section *::after {
          box-sizing: border-box;
        }

        /* =========================================
           MAIN CONTAINER
           Desktop: 100px
           Tablet: 40px
           Mobile: 24px
           Small Mobile: 16px
        ========================================= */

        .telecom-technology-container {
          width: 100%;
          max-width: 1440px;
          margin: 0 auto;

          padding: 90px 100px;

          display: grid;
          grid-template-columns: minmax(0, 1.1fr) minmax(0, 0.9fr);
          gap: 70px;
          align-items: start;
        }

        /* =========================================
           LEFT CONTENT
        ========================================= */

        .telecom-technology-label {
          margin: 0 0 14px;

          color: ${o};

          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 700;
          line-height: 1.4;
          letter-spacing: 0.14em;
          text-transform: uppercase;
        }

        .telecom-technology-heading {
          margin: 0 0 25px;

          color: ${t};

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: clamp(28px, 3vw, 40px);
          font-weight: 700;
          line-height: 1.22;
          letter-spacing: -0.035em;
        }

        .telecom-technology-copy {
          display: flex;
          flex-direction: column;
          gap: 17px;
        }

        .telecom-technology-copy p {
          margin: 0;

          color: ${n};

          font-family: "Inter", sans-serif;
          font-size: 13.5px;
          font-weight: 400;
          line-height: 1.8;
        }

        /* =========================================
           RIGHT FRAMEWORK PANEL
        ========================================= */

        .telecom-framework-panel {
          width: 100%;
          padding: 28px;

          background: #ffffff;
          border-radius: 20px;

          box-shadow:
            0 1px 3px rgba(0, 0, 0, 0.06),
            0 12px 35px rgba(30, 20, 25, 0.035);
        }

        /* =========================================
           FRAMEWORK BADGE
        ========================================= */

        .telecom-framework-badge {
          display: inline-flex;
          align-items: center;
          gap: 5px;

          margin-bottom: 20px;
          padding: 6px 11px;

          border-radius: 999px;

          background: #fbeef1;
          color: ${o};

          font-family: "Inter", sans-serif;
          font-size: 9px;
          font-weight: 700;
          line-height: 1.3;
          letter-spacing: 0.04em;
        }

        /* =========================================
           PANEL HEADING
        ========================================= */

        .telecom-framework-title {
          margin: 0 0 11px;

          color: ${t};

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 18px;
          font-weight: 700;
          line-height: 1.4;
          letter-spacing: -0.02em;
        }

        .telecom-framework-description {
          margin: 0 0 23px;

          color: ${n};

          font-family: "Inter", sans-serif;
          font-size: 11.5px;
          font-weight: 400;
          line-height: 1.75;
        }

        /* =========================================
           BULLETS
        ========================================= */

        .telecom-bullets {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          column-gap: 22px;
          row-gap: 11px;
        }

        .telecom-bullet {
          min-width: 0;

          display: flex;
          align-items: center;
          gap: 9px;
        }

        .telecom-bullet-dot {
          width: 5px;
          height: 5px;
          flex-shrink: 0;

          border-radius: 50%;
          background: ${o};
        }

        .telecom-bullet-text {
          color: ${t};

          font-family: "Inter", sans-serif;
          font-size: 11px;
          font-weight: 500;
          line-height: 1.5;
        }

        /* =========================================
           ARCHITECTURAL NOTE
        ========================================= */

        .telecom-cohesion-note {
          width: 100%;

          display: flex;
          align-items: flex-start;
          gap: 12px;

          margin-top: 17px;
          padding: 17px;

          background: #ffffff;
          border-radius: 15px;

          box-shadow:
            0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .telecom-cohesion-icon {
          width: 30px;
          height: 30px;
          flex-shrink: 0;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 50%;

          background: #fbeef1;
          color: ${o};
        }

        .telecom-cohesion-content {
          min-width: 0;
        }

        .telecom-cohesion-title {
          margin: 0 0 5px;

          color: ${t};

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 11.5px;
          font-weight: 700;
          line-height: 1.4;
        }

        .telecom-cohesion-description {
          margin: 0;

          color: ${n};

          font-family: "Inter", sans-serif;
          font-size: 10.5px;
          font-weight: 400;
          line-height: 1.65;
        }

        /* =========================================
           LARGE TABLET
           100px → 40px
        ========================================= */

        @media (max-width: 1200px) {
          .telecom-technology-container {
            padding-left: 40px;
            padding-right: 40px;

            padding-top: 80px;
            padding-bottom: 80px;

            gap: 50px;
          }
        }

        /* =========================================
           TABLET
        ========================================= */

        @media (max-width: 1050px) {
          .telecom-technology-container {
            padding-left: 40px;
            padding-right: 40px;

            padding-top: 75px;
            padding-bottom: 75px;

            gap: 45px;
          }

          .telecom-technology-heading {
            font-size: 32px;
          }

          .telecom-framework-panel {
            padding: 25px;
          }
        }

        /* =========================================
           SINGLE COLUMN TABLET
        ========================================= */

        @media (max-width: 850px) {
          .telecom-technology-container {
            grid-template-columns: 1fr;

            gap: 40px;

            padding-left: 40px;
            padding-right: 40px;

            padding-top: 70px;
            padding-bottom: 70px;
          }

          .telecom-technology-heading {
            max-width: 650px;
            font-size: 32px;
          }

          .telecom-technology-copy {
            max-width: 750px;
          }

          .telecom-framework-panel {
            max-width: 100%;
          }
        }

        /* =========================================
           MOBILE
           40px → 24px
        ========================================= */

        @media (max-width: 600px) {
          .telecom-technology-container {
            padding-left: 24px;
            padding-right: 24px;

            padding-top: 60px;
            padding-bottom: 60px;

            gap: 30px;
          }

          .telecom-technology-label {
            margin-bottom: 11px;

            font-size: 10px;
            letter-spacing: 0.12em;
          }

          .telecom-technology-heading {
            margin-bottom: 20px;

            font-size: 27px;
            line-height: 1.28;
            letter-spacing: -0.025em;
          }

          .telecom-technology-copy {
            gap: 14px;
          }

          .telecom-technology-copy p {
            font-size: 12.5px;
            line-height: 1.75;
          }

          .telecom-framework-panel {
            padding: 21px;
            border-radius: 17px;
          }

          .telecom-framework-badge {
            margin-bottom: 17px;
            padding: 6px 10px;
            font-size: 8.5px;
          }

          .telecom-framework-title {
            font-size: 16px;
            line-height: 1.4;
          }

          .telecom-framework-description {
            margin-bottom: 20px;

            font-size: 11px;
            line-height: 1.7;
          }

          .telecom-bullets {
            grid-template-columns: 1fr;
            gap: 10px;
          }

          .telecom-bullet-text {
            font-size: 11px;
          }

          .telecom-cohesion-note {
            margin-top: 14px;
            padding: 15px;
            gap: 10px;
          }

          .telecom-cohesion-title {
            font-size: 11px;
          }

          .telecom-cohesion-description {
            font-size: 10px;
          }
        }

        /* =========================================
           SMALL MOBILE
           24px → 16px
        ========================================= */

        @media (max-width: 400px) {
          .telecom-technology-container {
            padding-left: 16px;
            padding-right: 16px;

            padding-top: 52px;
            padding-bottom: 52px;
          }

          .telecom-technology-heading {
            font-size: 24px;
          }

          .telecom-technology-copy p {
            font-size: 12px;
          }

          .telecom-framework-panel {
            padding: 18px;
          }

          .telecom-framework-title {
            font-size: 15px;
          }

          .telecom-framework-description {
            font-size: 10.5px;
          }

          .telecom-cohesion-note {
            padding: 14px;
          }
        }

        /* =========================================
           DESKTOP BREAK
        ========================================= */

        .desktop-break {
          display: block;
        }

        @media (max-width: 850px) {
          .desktop-break {
            display: none;
          }
        }

        /* =========================================
           REDUCED MOTION
        ========================================= */

        @media (prefers-reduced-motion: reduce) {
          .telecom-technology-section * {
            scroll-behavior: auto !important;
          }
        }
      `}),e.jsxs("div",{className:"telecom-technology-container",children:[e.jsxs("div",{children:[e.jsx("p",{className:"telecom-technology-label",children:"Telecommunications Technology"}),e.jsxs("h2",{className:"telecom-technology-heading",children:["Connecting Technology With Business",e.jsx("br",{className:"desktop-break"}),"Operations"]}),e.jsxs("div",{className:"telecom-technology-copy",children:[e.jsx("p",{children:"Modern telecommunications businesses work across multiple functions, applications and digital processes. Managing these areas effectively requires technology that fits the organization's requirements and works with its existing business environment."}),e.jsx("p",{children:"TechTorch Solutions brings together a range of technology services and business solutions to support these requirements. Its capabilities include IT Consultancy, Software Engineering, Cloud Infrastructure, Cyber Security, Artificial Intelligence, Software Development & Support, Business Process Outsourcing and Resource & Staffing."}),e.jsx("p",{children:"The approach is centered around understanding the business requirement first and then developing or implementing technology that fits the organization. This can include building new software, improving existing systems, connecting applications, supporting cloud infrastructure or strengthening the technology environment."})]})]}),e.jsxs("div",{children:[e.jsxs("div",{className:"telecom-framework-panel",children:[e.jsxs("span",{className:"telecom-framework-badge",children:[e.jsx(s,{size:10,strokeWidth:3}),"Integrated Core Framework"]}),e.jsx("h3",{className:"telecom-framework-title",children:"Unified Enterprise Portfolio"}),e.jsx("p",{className:"telecom-framework-description",children:"TechTorch also provides digital solutions across Enterprise Resource Planning, Operations Management, Supply Chain Management, People Resources, Web Portals, Financial Management, Payment Management, Customer Relationship Management, E-Commerce and Project Management."}),e.jsx("div",{className:"telecom-bullets",children:r.map(i=>e.jsxs("div",{className:"telecom-bullet",children:[e.jsx("span",{className:"telecom-bullet-dot"}),e.jsx("span",{className:"telecom-bullet-text",children:i})]},i))})]}),e.jsxs("div",{className:"telecom-cohesion-note",children:[e.jsx("span",{className:"telecom-cohesion-icon",children:e.jsx(c,{size:14,strokeWidth:1.8})}),e.jsxs("div",{className:"telecom-cohesion-content",children:[e.jsx("p",{className:"telecom-cohesion-title",children:"Architectural Cohesion"}),e.jsx("p",{className:"telecom-cohesion-description",children:"Every software component is integrated with strict adherence to organizational security, regulatory mandates, and operational continuous uptime."})]})]})]})]})]})}export{h as default};
