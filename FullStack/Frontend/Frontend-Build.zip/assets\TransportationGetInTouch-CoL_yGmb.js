import{j as t}from"./vendor-query-PraSc8EQ.js";import{r as o}from"./vendor-router-L4ZCoGSs.js";import{F as A,s as R,a as P}from"./FormNotice-DRy7EQ_d.js";import{t as N,r as M,a7 as q,N as D,z as L,A as j}from"./index-BThRNyH6.js";import{B as v}from"./briefcase-business-RV2PnsxV.js";import{W as U}from"./workflow-69tH2pJ3.js";import{S as G}from"./settings-2-D9uA5HLI.js";import{C as B}from"./circle-user-round-C0yQqOzM.js";import{C as H}from"./code-xml-DcjisM7r.js";import{C as Y}from"./check-Cj2_y9Sm.js";import{M as F}from"./mail-3Flp59qD.js";import{P as W}from"./phone-B3rJcDGo.js";import{N as X}from"./network-Bh2G015s.js";import{S as V}from"./sparkles-y22GUl0e.js";const w={name:"earth",size:24,node:[["path",{d:"M21.54 15H17a2 2 0 0 0-2 2v4.54",key:"1djwo0"}],["path",{d:"M7 3.34V5a3 3 0 0 0 3 3a2 2 0 0 1 2 2c0 1.1.9 2 2 2a2 2 0 0 0 2-2c0-1.1.9-2 2-2h3.17",key:"1tzkfa"}],["path",{d:"M11 21.95V18a2 2 0 0 0-2-2a2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05",key:"14pb5j"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],aliases:["globe-2"]};w.node;const _=N(w);const E={name:"info",size:24,node:[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]]};E.node;const Q=N(E),J=[{title:"ERP Solutions",description:"Business processes, finance, people and supply chain.",icon:U},{title:"Operations Management",description:"Operational processes and workflow support.",icon:G},{title:"Supply Chain Management",description:"Procurement, inventory, suppliers and logistics.",icon:D},{title:"Financial Management",description:"Financial operations, records and reporting.",icon:L},{title:"CRM Solutions",description:"Customer information and relationship management.",icon:B},{title:"Project Management",description:"Planning, collaboration and workflow management.",icon:v},{title:"Web Portals",description:"Digital portals for customers, employees and business users.",icon:_},{title:"Software Solutions",description:"Custom software, applications and system integration.",icon:H}],$=[{title:"New Technology Solution",description:"Develop a new digital or business solution."},{title:"Existing System Improvement",description:"Improve or modernize an existing system."},{title:"Software Development",description:"Develop a custom application or software solution."},{title:"System Integration",description:"Connect existing applications or business systems."},{title:"Cloud Requirement",description:"Explore cloud infrastructure for your environment."},{title:"Digital Transformation",description:"Improve business processes through technology."},{title:"Technology Support",description:"Ongoing software or technology support."},{title:"Exploring Options",description:"Discuss your requirements with our team."}],K=["Initial Discussion","Requirement Planning","Existing System Improvement","Software Development","System Implementation","Technology Support","Exploring Options"];function mt(){const[p,h]=o.useState([]),[c,g]=o.useState(""),[l,f]=o.useState(""),[d,x]=o.useState(""),[a,u]=o.useState({requirements:"",fullName:"",email:"",company:"",phone:"",consent:!1}),[S,m]=o.useState(!1),z=r=>{h(e=>e.includes(r)?e.filter(i=>i!==r):[...e,r])},n=r=>{const{name:e,value:i,type:C,checked:O}=r.target;u(I=>({...I,[e]:C==="checkbox"?O:i}))},[b,y]=o.useState(!1),[T,s]=o.useState(""),k=async r=>{if(r.preventDefault(),!b){if(p.length===0){s("Please select at least one technology area.");return}if(!c){s("Please select what you are looking to achieve.");return}if(!l){s("Please select your current project stage.");return}if(!a.consent){s("Please agree to be contacted by TechTorch.");return}s(""),y(!0);try{await R("transportation",{technologyAreas:p,objectives:[c],currentProjectStage:l,requirement:a.requirements.trim(),fullName:a.fullName.trim(),businessEmail:a.email.trim(),companyOrganization:a.company.trim(),phoneNumber:a.phone.trim(),preferredContactMethod:d||"Email",contactConsent:a.consent===!0}),m(!0),setTimeout(()=>{m(!1)},3e3),u({requirements:"",fullName:"",email:"",company:"",phone:"",consent:!1}),h([]),g(""),f(""),x("")}catch(e){s(P(e))}finally{y(!1)}}};return t.jsxs("div",{className:"transportation-page",children:[t.jsx("style",{children:`
        * {
          box-sizing: border-box;
        }

        :root {
          --transport-beetroot: #730042;
          --transport-dark: #25282d;
          --transport-text: #62666d;
          --transport-muted: #858990;
          --transport-border: #e1e3e6;
          --transport-light: #f2f3f4;
          --transport-page: #f8f9fa;
        }

        .transportation-page {
          width: 100%;
          min-height: 100vh;
          background: var(--transport-page);
          color: var(--transport-dark);
          font-family: Arial, Helvetica, sans-serif;
          padding: 32px 26px 70px;
        }

        .transportation-container {
          width: 100%;
          max-width: 1380px;
          margin: 0 auto;
        }

        /* =====================================================
           SUCCESS ALERT
        ===================================================== */

        .transport-alert {
          position: fixed;
          top: 22px;
          left: 50%;
          transform: translateX(-50%);

          z-index: 99999;

          width: max-content;
          max-width: calc(100% - 30px);

          min-height: 44px;

          padding: 0 17px;

          display: flex;
          align-items: center;
          gap: 10px;

          border-radius: 7px;

          background: var(--transport-beetroot);
          color: #ffffff;

          font-size: 12px;
          font-weight: 600;

          box-shadow:
            0 8px 25px rgba(0, 0, 0, 0.18);

          animation: transportAlertIn 0.25s ease;
        }

        .transport-alert-close {
          margin-left: 8px;

          display: flex;
          align-items: center;
          justify-content: center;

          border: none;
          background: transparent;

          color: #ffffff;

          cursor: pointer;
        }

        @keyframes transportAlertIn {
          from {
            opacity: 0;
            transform: translate(-50%, -12px);
          }

          to {
            opacity: 1;
            transform: translate(-50%, 0);
          }
        }

        /* =====================================================
           HERO
        ===================================================== */

        .transport-hero {
          display: grid;

          grid-template-columns:
            minmax(0, 1.1fr)
            minmax(420px, 0.9fr);

          gap: 48px;

          align-items: start;

          margin-bottom: 54px;
        }

        .transport-hero-content {
          min-width: 0;
          padding-top: 4px;
        }

        .transport-eyebrow {
          display: inline-flex;
          align-items: center;

          padding: 6px 10px;

          margin-bottom: 14px;

          border-radius: 4px;

          background: #f6dce8;
          color: var(--transport-beetroot);

          font-size: 9px;
          font-weight: 800;

          letter-spacing: 0.15px;
          text-transform: uppercase;
        }

        .transport-hero h1 {
          max-width: 760px;

          margin: 0;

          color: var(--transport-beetroot);

          font-family:
            "Plus Jakarta Sans",
           
            sans-serif;

         font-size: 36px;

          line-height: 1.04;

          letter-spacing: -2px;

          font-weight: 700;
        }

        .transport-hero-description {
          max-width: 730px;

          margin: 25px 0 28px;

          color: #656971;

          font-family:
            "Inter",
            sans-serif;

          font-size: 14px;

          line-height: 1.65;
        }

        /* =====================================================
           HERO PROCESS CARDS
        ===================================================== */

        .transport-process-row {
          display: grid;

          grid-template-columns:
            repeat(4, minmax(0, 1fr));

          gap: 10px;

          max-width: 760px;
        }

        .transport-process-card {
          min-height: 112px;

          padding: 14px 13px;

          background: #ffffff;

          border: 1px solid #edf0f2;

          border-radius: 7px;

          box-shadow:
            0 2px 7px rgba(20, 30, 40, 0.025);
        }

        .transport-process-card h3 {
          margin: 0 0 8px;

          color: var(--transport-beetroot);

          font-size: 13px;
          line-height: 1.2;

          font-weight: 700;

          text-transform: uppercase;
        }

        .transport-process-card p {
          margin: 0;

          color: #666b73;

          font-size: 13px;
          line-height: 1.42;
        }

        /* =====================================================
           HERO IMAGE
        ===================================================== */

        .transport-hero-image-card {
          width: 100%;

          overflow: hidden;

          border-radius: 10px;

          background: #101b2e;

          box-shadow:
            0 7px 20px rgba(25, 35, 50, 0.12);
        }

        .transport-image-wrapper {
          position: relative;

          width: 100%;

          overflow: hidden;
        }

        .transport-image {
          display: block;

          width: 100%;

          aspect-ratio: 1.44 / 1;

          object-fit: cover;
        }

        .transport-image-top-label {
          position: absolute;

          top: 15px;
          left: 17px;

          min-height: 29px;

          padding: 0 12px;

          display: flex;
          align-items: center;

          gap: 7px;

          border-radius: 18px;

          background: rgba(255, 255, 255, 0.94);

          color: #34363b;

          font-size: 10px;

          font-weight: 700;

          box-shadow:
            0 2px 8px rgba(0, 0, 0, 0.08);
        }

        .transport-label-dot {
          width: 7px;
          height: 7px;

          flex-shrink: 0;

          border-radius: 50%;

          background: var(--transport-beetroot);
        }

        .transport-image-bottom-card {
          position: absolute;

          right: 17px;
          bottom: 16px;

          left: 17px;

          padding: 14px 17px;

          border-radius: 8px;

          background: rgba(255, 255, 255, 0.96);

          box-shadow:
            0 4px 15px rgba(0, 0, 0, 0.15);
        }

        .transport-image-bottom-title {
          display: flex;
          align-items: center;

          gap: 7px;

          margin-bottom: 6px;

          color: var(--transport-beetroot);

          font-size: 10px;

          line-height: 1.2;

          font-weight: 800;

          text-transform: uppercase;
        }

        .transport-image-bottom-card p {
          margin: 0;

          color: #34373d;

          font-size: 11px;

          line-height: 1.4;

          font-weight: 500;
        }

        /* =====================================================
           MAIN FORM CARD
        ===================================================== */

        .transport-form-card {
          width: 100%;

          padding: 31px 36px 34px;

          background: #ffffff;

          border: 1px solid #e3e5e8;

          border-radius: 10px;

          box-shadow:
            0 3px 15px rgba(25, 30, 40, 0.045);
        }

        .transport-form-eyebrow {
          margin-bottom: 8px;

          color: var(--transport-beetroot);

          font-size: 10px;

          font-weight: 700;

          text-transform: uppercase;
        }

        .transport-form-title {
          margin: 0;

          color: #25282d;

          font-family:
            "Plus Jakarta Sans",
            sans-serif;

          font-size: 25px;

          line-height: 1.2;

          font-weight: 700;
        }

        .transport-form-description {
          max-width: 850px;

          margin: 8px 0 30px;

          color: #6c7076;

          font-size: 14px;

          line-height: 1.55;
        }

        /* =====================================================
           SECTION TITLES
        ===================================================== */

        .transport-section {
          margin-top: 27px;
        }

        .transport-section:first-of-type {
          margin-top: 0;
        }

        .transport-section-heading {
          display: flex;
          align-items: center;

          gap: 9px;

          margin-bottom: 13px;
        }

        .transport-section-number {
          width: 21px;
          height: 21px;

          flex-shrink: 0;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 50%;

          background: var(--transport-beetroot);

          color: #ffffff;

          font-size: 9px;

          font-weight: 800;
        }

        .transport-section-heading h2 {
          margin: 0;

          color: #292c31;

          font-size: 16px;

          line-height: 1.25;

          font-weight: 700;
        }

        .transport-section-helper {
          margin-left: auto;

          color: #858890;

          font-size: 9px;

          text-align: right;
        }

        /* =====================================================
           TECHNOLOGY CARDS
        ===================================================== */

        .transport-technology-grid {
          display: grid;

          grid-template-columns:
            repeat(4, minmax(0, 1fr));

          gap: 12px;
        }

        .transport-tech-card {
          position: relative;

          min-height: 100px;

          padding: 13px;

          border: 1px solid transparent;

          border-radius: 7px;

          background: #f2f3f4;

          text-align: left;

          cursor: pointer;

          transition:
            border-color 0.2s ease,
            background 0.2s ease,
            transform 0.2s ease;
        }

        .transport-tech-card:hover {
          border-color: #d5a9bd;
        }

        .transport-tech-card.active {
          border-color: var(--transport-beetroot);

          background: #fff7fa;
        }

        .transport-tech-icon {
          display: block;

          margin-bottom: 9px;

          color: var(--transport-beetroot);
        }

        .transport-tech-card h3 {
          margin: 0 0 5px;

          color: #2f3237;

          font-size: 13px;

          line-height: 1.2;

          font-weight: 600;
        }

        .transport-tech-card p {
          margin: 0;

          color: #777b82;

          font-size: 13px;

          line-height: 1.4;
        }

        .transport-card-indicator {
          position: absolute;

          top: 14px;
          right: 14px;

          width: 15px;
          height: 15px;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 50%;

          background: #dfe2e5;

          color: transparent;
        }

        .transport-tech-card.active
          .transport-card-indicator {
          background: var(--transport-beetroot);

          color: #ffffff;
        }

        /* =====================================================
           ACHIEVEMENT OPTIONS
        ===================================================== */

        .transport-achievement-grid {
          display: grid;

          grid-template-columns:
            repeat(4, minmax(0, 1fr));

          gap: 10px;
        }

        .transport-achievement-card {
          min-height: 63px;

          padding: 10px 11px;

          display: grid;

          grid-template-columns: 11px minmax(0, 1fr);

          gap: 8px;

          align-items: start;

          border: 1px solid transparent;

          border-radius: 6px;

          background: #f2f3f4;

          cursor: pointer;

          text-align: left;
        }

        .transport-achievement-card.active {
          border-color: var(--transport-beetroot);

          background: #fff7fa;
        }

        .transport-achievement-dot {
          width: 10px;
          height: 10px;

          margin-top: 2px;

          border-radius: 50%;

          background: #dfe2e5;
        }

        .transport-achievement-card.active
          .transport-achievement-dot {
          background: var(--transport-beetroot);

          box-shadow:
            inset 0 0 0 3px #ffffff;
        }

        .transport-achievement-card h3 {
          margin: 0 0 2px;

          color: #33363b;

          font-size: 13px;

          line-height: 1.2;

          font-weight: 600;
        }

        .transport-achievement-card p {
          margin: 0;

          color: #777b82;

          font-size: 12px;

          line-height: 1.25;
        }

        /* =====================================================
           PROJECT STAGE
        ===================================================== */

        .transport-stage-grid {
          display: flex;

          flex-wrap: wrap;

          gap: 9px;
        }

        .transport-stage-option {
          min-height: 31px;

          padding: 0 13px;

          display: inline-flex;
          align-items: center;

          gap: 7px;

          border: 1px solid transparent;

          border-radius: 6px;

          background: #f2f3f4;

          color: #44474c;

          font-size: 12px;

          font-weight: 600;

          cursor: pointer;
        }

        .transport-stage-option.active {
          border-color: var(--transport-beetroot);

          background: #fff7fa;
        }

        .transport-stage-dot {
          width: 10px;
          height: 10px;

          border-radius: 50%;

          background: #dfe2e5;
        }

        .transport-stage-option.active
          .transport-stage-dot {
          background: var(--transport-beetroot);

          box-shadow:
            inset 0 0 0 3px #ffffff;
        }

        /* =====================================================
           REQUIREMENT TEXTAREA
        ===================================================== */

        .transport-textarea {
          width: 100%;

          min-height: 88px;

          padding: 15px;

          border: 1px solid #e3e5e8;

          border-radius: 7px;

          background: #f3f4f5;

          color: #33363c;

          font-family: inherit;

          font-size: 13px;

          line-height: 1.5;

          resize: vertical;

          outline: none;
        }

        .transport-textarea:focus {
          border-color: #c68ba7;

          background: #ffffff;

          box-shadow:
            0 0 0 2px rgba(115, 0, 66, 0.05);
        }

        .transport-textarea::placeholder {
          color: #a2a4a8;
        }

        /* =====================================================
           CONTACT INFORMATION
        ===================================================== */

        .transport-contact-grid {
          display: grid;

          grid-template-columns:
            repeat(2, minmax(0, 1fr));

          gap: 15px;
        }

        .transport-field {
          min-width: 0;
        }

        .transport-field label {
          display: block;

          margin-bottom: 7px;

          color: #33363b;

          font-size: 12px;

          font-weight: 700;

          text-transform: uppercase;
        }

        .transport-required {
          color: var(--transport-beetroot);
        }

        .transport-input {
          width: 100%;

          height: 40px;

          padding: 0 12px;

          border: 1px solid #e2e4e7;

          border-radius: 6px;

          background: #f3f4f5;

          color: #34373c;

          font-family: inherit;

          font-size: 11px;

          outline: none;
        }

        .transport-input:focus {
          border-color: #c68ba7;

          background: #ffffff;

          box-shadow:
            0 0 0 2px rgba(115, 0, 66, 0.05);
        }

        .transport-input::placeholder {
          color: #a2a6ad;
        }

        /* =====================================================
           CONTACT METHOD
        ===================================================== */

        .transport-contact-method {
          margin-top: 16px;

          display: flex;
          align-items: center;

          gap: 13px;

          color: #41454a;

          font-size: 13px;

          font-weight: 600;
        }

        .transport-contact-method-title {
          margin-right: 4px;

          color: #34373c;

          font-size: 12px;

          font-weight: 600;
        }

        .transport-radio {
          display: flex;
          align-items: center;

          gap: 6px;

          cursor: pointer;
        }

        .transport-radio input {
          width: 13px;
          height: 13px;

          margin: 0;

          accent-color: var(--transport-beetroot);
        }

        /* =====================================================
           CONSENT
        ===================================================== */

        .transport-consent {
          margin-top: 17px;

          display: flex;
          align-items: flex-start;

          gap: 9px;

          color: #41454a;

          font-size: 13px;

          line-height: 1.4;

          cursor: pointer;
        }

        .transport-consent input {
          width: 13px;
          height: 13px;

          margin: 1px 0 0;

          flex-shrink: 0;

          accent-color: var(--transport-beetroot);
        }

        /* =====================================================
           SUBMIT AREA
        ===================================================== */

        .transport-submit-row {
          margin-top: 24px;

          display: grid;

          grid-template-columns:
            auto minmax(0, 1fr);

          gap: 25px;

          align-items: center;
        }

        .transport-submit {
          min-width: 165px;

          height: 40px;

          padding: 0 18px;

          display: flex;
          align-items: center;
          justify-content: center;

          gap: 7px;

          border: none;

          border-radius: 7px;

          background: var(--transport-beetroot);

          color: #ffffff;

          font-size: 12px;

          font-weight: 600;

          cursor: pointer;

          transition: 0.2s ease;
        }

        .transport-submit:hover {
          background: #5c0035;
        }

        .transport-submit:active {
          transform: translateY(1px);
        }

        .transport-submit-info {
          display: flex;
          align-items: flex-start;

          gap: 8px;

          color: #747980;

          font-size: 11px;

          line-height: 1.4;
        }

        .transport-submit-info svg {
          flex-shrink: 0;

          margin-top: 1px;

          color: var(--transport-beetroot);
        }

        /* =====================================================
           CONSULTATION PROCESS
        ===================================================== */

        .transport-consultation {
          margin-top: 48px;
        }

        .transport-consultation-eyebrow {
          margin-bottom: 9px;

          color: var(--transport-beetroot);

          font-size: 11px;

          font-weight: 600;

          text-transform: uppercase;
        }

        .transport-consultation h2 {
          margin: 0;

          color: #272a2f;

          font-family:
            "Plus Jakarta Sans",
            sans-serif;

          font-size: 24px;

          line-height: 1.2;

          font-weight: 700;
        }

        .transport-consultation-description {
          margin: 8px 0 23px;

          color: #74787f;

          font-size: 13px;

          line-height: 1.5;
        }

        .transport-consultation-grid {
          display: grid;

          grid-template-columns:
            repeat(3, minmax(0, 1fr));

          gap: 18px;
        }

        .transport-consultation-card {
          min-height: 194px;

          padding: 19px;

          border: 1px solid #e7e8ea;

          border-radius: 8px;

          background: #ffffff;

          box-shadow:
            0 2px 10px rgba(25, 30, 40, 0.025);
        }

        .transport-consultation-top {
          display: flex;

          align-items: center;

          justify-content: space-between;

          gap: 10px;

          margin-bottom: 19px;
        }

        .transport-stage-label {
          color: var(--transport-beetroot);

          font-size: 10px;

          font-weight: 700;
        }

        .transport-tag {
          padding: 5px 8px;

          border-radius: 4px;

          background: #eceeef;

          color: #777a80;

          font-size: 9px;

          font-weight: 700;

          text-transform: uppercase;
        }

        .transport-consultation-card h3 {
          margin: 0 0 8px;

          color: #2c3035;

          font-size: 16px;

          line-height: 1.25;

          font-weight: 700;
        }

        .transport-consultation-card p {
          margin: 0;

          color: #70747a;

          font-size: 13px;

          line-height: 1.45;
        }

        .transport-consultation-footer {
          margin-top: 22px;

          display: flex;
          align-items: center;

          gap: 6px;

          color: var(--transport-beetroot);

          font-size: 10px;

          font-weight: 700;

          text-transform: uppercase;
        }

        /* =====================================================
           LARGE TABLET
        ===================================================== */

        @media (max-width: 1100px) {

          .transportation-page {
            padding-left: 24px;
            padding-right: 24px;
          }

          .transport-hero {
            grid-template-columns:
              minmax(0, 1fr)
              minmax(330px, 0.82fr);

            gap: 28px;
          }

          .transport-hero h1 {
            font-size: 42px;
          }

          .transport-process-row {
            grid-template-columns:
              repeat(2, minmax(0, 1fr));

            max-width: 650px;
          }

          .transport-technology-grid {
            grid-template-columns:
              repeat(2, minmax(0, 1fr));
          }

          .transport-achievement-grid {
            grid-template-columns:
              repeat(2, minmax(0, 1fr));
          }
        }

        /* =====================================================
           IPAD / SURFACE / TABLET
        ===================================================== */

        @media (min-width: 701px) and (max-width: 900px) {

          .transportation-page {
            padding: 28px 24px 55px;
          }

          .transport-hero {
            grid-template-columns:
              minmax(0, 1fr)
              minmax(285px, 0.85fr);

            gap: 22px;

            margin-bottom: 38px;
          }

          .transport-hero h1 {
            font-size: 34px;

            letter-spacing: -1.2px;
          }

          .transport-hero-description {
            margin-top: 17px;

            font-size: 12px;
          }

          .transport-process-row {
            grid-template-columns:
              repeat(2, minmax(0, 1fr));

            gap: 8px;
          }

          .transport-process-card {
            min-height: 94px;

            padding: 11px;
          }

          .transport-process-card h3 {
            font-size: 8px;
          }

          .transport-process-card p {
            font-size: 8px;
          }

          .transport-image-top-label {
            top: 10px;
            left: 10px;

            min-height: 24px;

            padding: 0 9px;

            font-size: 8px;
          }

          .transport-image-bottom-card {
            right: 10px;
            bottom: 10px;
            left: 10px;

            padding: 10px 11px;
          }

          .transport-image-bottom-title {
            font-size: 8px;
          }

          .transport-image-bottom-card p {
            font-size: 8px;
          }

          .transport-form-card {
            padding: 25px 24px 28px;
          }

          .transport-form-title {
            font-size: 22px;
          }

          .transport-section-heading h2 {
            font-size: 14px;
          }

          .transport-technology-grid {
            grid-template-columns:
              repeat(2, minmax(0, 1fr));

            gap: 9px;
          }

          .transport-achievement-grid {
            grid-template-columns:
              repeat(2, minmax(0, 1fr));
          }

          .transport-submit-row {
            grid-template-columns: 1fr;

            gap: 12px;
          }

          .transport-submit {
            width: 100%;
          }

          .transport-submit-info {
            justify-content: center;

            text-align: center;
          }

          .transport-consultation {
            margin-top: 38px;
          }

          .transport-consultation-grid {
            gap: 12px;
          }

          .transport-consultation-card {
            min-height: 175px;

            padding: 15px;
          }

          .transport-consultation-card h3 {
            font-size: 14px;
          }

          .transport-consultation-card p {
            font-size: 9px;
          }
        }

        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 700px) {

          .transportation-page {
            padding: 22px 14px 45px;
          }

          .transport-hero {
            display: flex;

            flex-direction: column;

            gap: 24px;

            margin-bottom: 32px;
          }

          .transport-hero-content {
            width: 100%;
          }

          .transport-eyebrow {
            font-size: 8px;

            padding: 5px 8px;
          }

          .transport-hero h1 {
            font-size: 31px;

            line-height: 1.08;

            letter-spacing: -1px;
          }

          .transport-hero-description {
            margin: 16px 0 20px;

            font-size: 12px;

            line-height: 1.55;
          }

          .transport-process-row {
            grid-template-columns: 1fr 1fr;

            gap: 8px;

            max-width: none;
          }

          .transport-process-card {
            min-height: 98px;

            padding: 11px;
          }

          .transport-process-card h3 {
            font-size: 8px;
          }

          .transport-process-card p {
            font-size: 8px;
          }

          .transport-hero-image-card {
            width: 100%;
          }

          .transport-image {
            aspect-ratio: 1.38 / 1;
          }

          .transport-image-top-label {
            top: 9px;
            left: 9px;

            min-height: 23px;

            padding: 0 8px;

            font-size: 7px;
          }

          .transport-label-dot {
            width: 5px;
            height: 5px;
          }

          .transport-image-bottom-card {
            right: 9px;
            bottom: 9px;
            left: 9px;

            padding: 9px 10px;
          }

          .transport-image-bottom-title {
            margin-bottom: 4px;

            font-size: 7px;
          }

          .transport-image-bottom-card p {
            font-size: 7px;

            line-height: 1.35;
          }

          .transport-form-card {
            padding: 22px 16px 25px;

            border-radius: 8px;
          }

          .transport-form-title {
            font-size: 21px;

            line-height: 1.25;
          }

          .transport-form-description {
            margin-bottom: 23px;

            font-size: 10px;
          }

          .transport-section {
            margin-top: 24px;
          }

          .transport-section-heading {
            align-items: flex-start;
          }

          .transport-section-heading h2 {
            font-size: 14px;
          }

          .transport-section-helper {
            display: none;
          }

          .transport-technology-grid {
            grid-template-columns: 1fr 1fr;

            gap: 8px;
          }

          .transport-tech-card {
            min-height: 105px;

            padding: 10px;
          }

          .transport-tech-icon {
            margin-bottom: 7px;
          }

          .transport-tech-card h3 {
            font-size: 9px;
          }

          .transport-tech-card p {
            font-size: 7.5px;
          }

          .transport-card-indicator {
            top: 10px;
            right: 10px;

            width: 13px;
            height: 13px;
          }

          .transport-achievement-grid {
            grid-template-columns: 1fr 1fr;

            gap: 8px;
          }

          .transport-achievement-card {
            min-height: 72px;

            padding: 9px;
          }

          .transport-achievement-card h3 {
            font-size: 8px;
          }

          .transport-achievement-card p {
            font-size: 7px;
          }

          .transport-stage-grid {
            display: grid;

            grid-template-columns: 1fr 1fr;

            gap: 7px;
          }

          .transport-stage-option {
            min-height: 32px;

            padding: 0 9px;

            font-size: 8px;
          }

          .transport-contact-grid {
            grid-template-columns: 1fr;

            gap: 13px;
          }

          .transport-contact-method {
            flex-wrap: wrap;

            gap: 11px;
          }

          .transport-contact-method-title {
            width: 100%;
          }

          .transport-submit-row {
            grid-template-columns: 1fr;

            gap: 13px;
          }

          .transport-submit {
            width: 100%;
          }

          .transport-submit-info {
            text-align: center;

            justify-content: center;

            font-size: 8px;
          }

          .transport-consultation {
            margin-top: 34px;
          }

          .transport-consultation h2 {
            font-size: 23px;
          }

          .transport-consultation-description {
            font-size: 10px;
          }

          .transport-consultation-grid {
            grid-template-columns: 1fr;

            gap: 11px;
          }

          .transport-consultation-card {
            min-height: auto;

            padding: 17px;
          }

          .transport-consultation-card h3 {
            font-size: 16px;
          }

          .transport-consultation-card p {
            font-size: 10px;
          }
        }

        /* =====================================================
           SMALL MOBILE
        ===================================================== */

        @media (max-width: 420px) {

          .transportation-page {
            padding-left: 10px;
            padding-right: 10px;
          }

          .transport-hero h1 {
            font-size: 27px;
          }

          .transport-process-row {
            grid-template-columns: 1fr;
          }

          .transport-process-card {
            min-height: auto;
          }

          .transport-technology-grid,
          .transport-achievement-grid {
            grid-template-columns: 1fr;
          }

          .transport-tech-card {
            min-height: 92px;
          }

          .transport-stage-grid {
            grid-template-columns: 1fr;
          }

          .transport-form-card {
            padding: 19px 13px 22px;
          }

          .transport-form-title {
            font-size: 19px;
          }

          .transport-section-heading h2 {
            font-size: 13px;
          }

          .transport-image-bottom-card {
            right: 7px;
            bottom: 7px;
            left: 7px;

            padding: 7px 8px;
          }

          .transport-image-bottom-title {
            font-size: 6px;
          }

          .transport-image-bottom-card p {
            font-size: 6px;
          }

          .transport-image-top-label {
            top: 7px;
            left: 7px;

            font-size: 6px;
          }

          .transport-alert {
            width: calc(100% - 24px);

            font-size: 10px;
          }
        }


        /* =====================================================
           FOOTER-ALIGNED OUTER PADDING ONLY
           No typography, content, sizing, colors, or functionality changed.
        ===================================================== */

        @media (max-width: 639px) {
          .transportation-page {
            padding-left: 16px;
            padding-right: 16px;
          }
        }

        @media (min-width: 640px) and (max-width: 767px) {
          .transportation-page {
            padding-left: 24px;
            padding-right: 24px;
          }
        }

        @media (min-width: 768px) and (max-width: 1023px) {
          .transportation-page {
            padding-left: 40px;
            padding-right: 40px;
          }
        }

        @media (min-width: 1024px) {
          .transportation-page {
            padding-left: 100px;
            padding-right: 100px;
          }
        }

      `}),S&&t.jsxs("div",{className:"transport-alert",children:[t.jsx(M,{size:16}),t.jsx("span",{children:"Inquiry submitted successfully!"}),t.jsx("button",{type:"button",className:"transport-alert-close",onClick:()=>m(!1),children:t.jsx(q,{size:14})})]}),t.jsxs("main",{className:"transportation-container",children:[t.jsxs("section",{className:"transport-hero",children:[t.jsxs("div",{className:"transport-hero-content",children:[t.jsx("div",{className:"transport-eyebrow",children:"GET IN TOUCH · TRANSPORTATION PRACTICE"}),t.jsxs("h1",{children:["Discuss Your Transportation",t.jsx("br",{}),"Technology Requirements"]}),t.jsx("p",{className:"transport-hero-description",children:"Connect with the TechTorch team to discuss your transportation business requirements across ERP, operations management, supply chain, software, cloud infrastructure and digital solutions."}),t.jsxs("div",{className:"transport-process-row",children:[t.jsxs("div",{className:"transport-process-card",children:[t.jsxs("h3",{children:["01 — BUSINESS-",t.jsx("br",{}),"FOCUSED"]}),t.jsx("p",{children:"Technology discussions based on your business requirements."})]}),t.jsxs("div",{className:"transport-process-card",children:[t.jsxs("h3",{children:["02 — CONNECTED",t.jsx("br",{}),"SOLUTIONS"]}),t.jsx("p",{children:"Explore solutions across business applications and technology services."})]}),t.jsxs("div",{className:"transport-process-card",children:[t.jsxs("h3",{children:["03 — FLEXIBLE",t.jsx("br",{}),"REQUIREMENTS"]}),t.jsx("p",{children:"Discuss new systems, existing technology or improvement needs."})]}),t.jsxs("div",{className:"transport-process-card",children:[t.jsxs("h3",{children:["04 — CLEAR NEXT",t.jsx("br",{}),"STEPS"]}),t.jsx("p",{children:"Understand the relevant capabilities and possible way forward."})]})]})]}),t.jsx("div",{className:"transport-hero-image-card",children:t.jsxs("div",{className:"transport-image-wrapper",children:[t.jsx("img",{loading:"lazy",decoding:"async",className:"transport-image",src:"/TransportationGetInTouch.webp",alt:"Transportation technology consultation"}),t.jsxs("div",{className:"transport-image-top-label",children:[t.jsx("span",{className:"transport-label-dot"}),"TRANSPORTATION TECHNOLOGY"]}),t.jsxs("div",{className:"transport-image-bottom-card",children:[t.jsxs("div",{className:"transport-image-bottom-title",children:[t.jsx(v,{size:13}),"BUSINESS-FOCUSED TECHNOLOGY CONSULTATION"]}),t.jsx("p",{children:"Discuss your business processes, technology requirements and digital initiatives with the TechTorch team."})]})]})})]}),t.jsxs("section",{className:"transport-form-card",children:[t.jsx("div",{className:"transport-form-eyebrow",children:"TECHNOLOGY CONSULTATION"}),t.jsx("h2",{className:"transport-form-title",children:"Tell Us About Your Transportation Requirements"}),t.jsx("p",{className:"transport-form-description",children:"Share a few details about your business or technology requirement. Our team can review your enquiry and connect with you to discuss the appropriate next steps."}),t.jsxs("form",{onSubmit:k,children:[t.jsxs("div",{className:"transport-section",children:[t.jsxs("div",{className:"transport-section-heading",children:[t.jsx("span",{className:"transport-section-number",children:"1"}),t.jsx("h2",{children:"1. What Can We Help You With?"}),t.jsx("span",{className:"transport-section-helper",children:"Select the technology or business area you would like to discuss. (Multi-select allowed)"})]}),t.jsx("div",{className:"transport-technology-grid",children:J.map(r=>{const e=r.icon,i=p.includes(r.title);return t.jsxs("button",{type:"button",className:`transport-tech-card ${i?"active":""}`,onClick:()=>z(r.title),children:[t.jsx("span",{className:"transport-tech-icon",children:t.jsx(e,{size:17})}),t.jsx("span",{className:"transport-card-indicator",children:i&&t.jsx(Y,{size:9})}),t.jsx("h3",{children:r.title}),t.jsx("p",{children:r.description})]},r.title)})})]}),t.jsxs("div",{className:"transport-section",children:[t.jsxs("div",{className:"transport-section-heading",children:[t.jsx("span",{className:"transport-section-number",children:"2"}),t.jsx("h2",{children:"2. What Are You Looking to Achieve?"})]}),t.jsx("div",{className:"transport-achievement-grid",children:$.map(r=>{const e=c===r.title;return t.jsxs("button",{type:"button",className:`transport-achievement-card ${e?"active":""}`,onClick:()=>g(e?"":r.title),children:[t.jsx("span",{className:"transport-achievement-dot"}),t.jsxs("span",{children:[t.jsx("h3",{children:r.title}),t.jsx("p",{children:r.description})]})]},r.title)})})]}),t.jsxs("div",{className:"transport-section",children:[t.jsxs("div",{className:"transport-section-heading",children:[t.jsx("span",{className:"transport-section-number",children:"3"}),t.jsx("h2",{children:"3. Current Project Stage"})]}),t.jsx("div",{className:"transport-stage-grid",children:K.map(r=>{const e=l===r;return t.jsxs("button",{type:"button",className:`transport-stage-option ${e?"active":""}`,onClick:()=>f(e?"":r),children:[t.jsx("span",{className:"transport-stage-dot"}),r]},r)})})]}),t.jsxs("div",{className:"transport-section",children:[t.jsxs("div",{className:"transport-section-heading",children:[t.jsx("span",{className:"transport-section-number",children:"4"}),t.jsx("h2",{children:"4. Tell Us About Your Requirement"})]}),t.jsx("textarea",{className:"transport-textarea",name:"requirements",value:a.requirements,onChange:n,placeholder:"Briefly describe your business requirement, current technology environment, project objectives or the challenge you would like to discuss."})]}),t.jsxs("div",{className:"transport-section",children:[t.jsxs("div",{className:"transport-section-heading",children:[t.jsx("span",{className:"transport-section-number",children:"5"}),t.jsx("h2",{children:"5. Your Contact Information"})]}),t.jsxs("div",{className:"transport-contact-grid",children:[t.jsxs("div",{className:"transport-field",children:[t.jsxs("label",{children:["Full Name"," ",t.jsx("span",{className:"transport-required",children:"*"})]}),t.jsx("input",{className:"transport-input",type:"text",name:"fullName",value:a.fullName,onChange:n,placeholder:"Enter your full name",required:!0})]}),t.jsxs("div",{className:"transport-field",children:[t.jsxs("label",{children:["Business Email"," ",t.jsx("span",{className:"transport-required",children:"*"})]}),t.jsx("input",{className:"transport-input",type:"email",name:"email",value:a.email,onChange:n,placeholder:"name@company.com",required:!0})]}),t.jsxs("div",{className:"transport-field",children:[t.jsxs("label",{children:["Company / Organization"," ",t.jsx("span",{className:"transport-required",children:"*"})]}),t.jsx("input",{className:"transport-input",type:"text",name:"company",value:a.company,onChange:n,placeholder:"Enter your company or organization",required:!0})]}),t.jsxs("div",{className:"transport-field",children:[t.jsx("label",{children:"Phone Number"}),t.jsx("input",{className:"transport-input",type:"tel",name:"phone",value:a.phone,onChange:n,placeholder:"Enter your phone number"})]})]}),t.jsxs("div",{className:"transport-contact-method",children:[t.jsx("span",{className:"transport-contact-method-title",children:"Preferred Contact Method:"}),t.jsxs("label",{className:"transport-radio",children:[t.jsx("input",{type:"radio",name:"contactMethod",value:"Email",checked:d==="Email",onChange:r=>x(r.target.value)}),t.jsx(F,{size:12}),"Email"]}),t.jsxs("label",{className:"transport-radio",children:[t.jsx("input",{type:"radio",name:"contactMethod",value:"Phone",checked:d==="Phone",onChange:r=>x(r.target.value)}),t.jsx(W,{size:12}),"Phone"]})]}),t.jsxs("label",{className:"transport-consent",children:[t.jsx("input",{type:"checkbox",name:"consent",checked:a.consent,onChange:n}),t.jsx("span",{children:"I agree to be contacted by TechTorch regarding my enquiry and technology requirements."})]}),t.jsxs("div",{className:"transport-submit-row",children:[t.jsx(A,{error:T}),t.jsxs("button",{type:"submit",disabled:b,className:"transport-submit",children:["SUBMIT ENQUIRY",t.jsx(j,{size:14})]}),t.jsxs("div",{className:"transport-submit-info",children:[t.jsx(Q,{size:13}),t.jsx("span",{children:"Your information will be used to respond to your enquiry and discuss your requirements. Our team will review your enquiry and connect with you regarding the next steps."})]})]})]})]})]}),t.jsxs("section",{className:"transport-consultation",children:[t.jsx("div",{className:"transport-consultation-eyebrow",children:"ENGAGEMENT OVERVIEW"}),t.jsx("h2",{children:"Consultation Process"}),t.jsx("p",{className:"transport-consultation-description",children:"A simple process to understand your requirements and discuss the appropriate technology approach."}),t.jsxs("div",{className:"transport-consultation-grid",children:[t.jsxs("div",{className:"transport-consultation-card",children:[t.jsxs("div",{className:"transport-consultation-top",children:[t.jsx("span",{className:"transport-stage-label",children:"STAGE 01"}),t.jsx("span",{className:"transport-tag",children:"BUSINESS REQUIREMENTS"})]}),t.jsx("h3",{children:"01 — Understand Your Requirement"}),t.jsx("p",{children:"We review your business objectives, existing technology environment and requirements."}),t.jsxs("div",{className:"transport-consultation-footer",children:[t.jsx(X,{size:11}),"REQUIREMENT REVIEW"]})]}),t.jsxs("div",{className:"transport-consultation-card",children:[t.jsxs("div",{className:"transport-consultation-top",children:[t.jsx("span",{className:"transport-stage-label",children:"STAGE 02"}),t.jsx("span",{className:"transport-tag",children:"SOLUTION DISCUSSION"})]}),t.jsx("h3",{children:"02 — Discuss Relevant Solutions"}),t.jsx("p",{children:"Our team discusses relevant TechTorch solutions and technology capabilities based on your requirements."}),t.jsxs("div",{className:"transport-consultation-footer",children:[t.jsx(V,{size:11}),"SOLUTION EXPLORATION"]})]}),t.jsxs("div",{className:"transport-consultation-card",children:[t.jsxs("div",{className:"transport-consultation-top",children:[t.jsx("span",{className:"transport-stage-label",children:"STAGE 03"}),t.jsx("span",{className:"transport-tag",children:"NEXT STEPS"})]}),t.jsx("h3",{children:"03 — Define Next Steps"}),t.jsx("p",{children:"Based on the discussion, we identify the appropriate approach and next steps for your requirement."}),t.jsxs("div",{className:"transport-consultation-footer",children:[t.jsx(j,{size:11}),"PLANNED PROGRESSION"]})]})]})]})]})]})}export{mt as default};
