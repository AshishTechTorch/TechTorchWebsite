import{j as e}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";function a(){return e.jsxs("section",{className:"perspective-analysis",children:[e.jsxs("div",{className:"perspective-container",children:[e.jsxs("div",{className:"perspective-left",children:[e.jsxs("div",{className:"perspective-badge",children:[e.jsx("span",{}),"PERSPECTIVE & ANALYSIS"]}),e.jsxs("h2",{children:["When More Data",e.jsx("br",{}),"Creates More Complexity"]}),e.jsxs("div",{className:"executive-card",children:[e.jsx("div",{className:"card-label",children:"EXECUTIVE REALIZATION"}),e.jsx("h3",{children:"The challenge is no longer about finding data."}),e.jsxs("p",{children:["The challenge is understanding what the data",e.jsx("br",{}),"is telling you in real business context."]})]}),e.jsxs("div",{className:"thesis-card",children:[e.jsx("div",{className:"card-label",children:"CORE OPERATING THESIS"}),e.jsx("p",{children:"Data volume provides zero competitive advantage without context, coherence, and decision velocity."})]})]}),e.jsxs("div",{className:"perspective-right",children:[e.jsx("h3",{className:"right-heading",children:"Data has become part of almost every business decision."}),e.jsx("p",{className:"right-description",children:"Sales generate customer records. Finance generates ledger entries. Operations track throughput. Supply chains monitor inventory and freight. Customer touchpoints continuously stream new signals."}),e.jsxs("div",{className:"friction-section",children:[e.jsx("div",{className:"friction-title",children:"SYSTEMIC FRICTION POINTS"}),e.jsxs("div",{className:"friction-grid",children:[e.jsxs("div",{className:"friction-card",children:[e.jsx("span",{children:"•"}),e.jsx("p",{children:"Information fragmented across isolated systems & silos"})]}),e.jsxs("div",{className:"friction-card",children:[e.jsx("span",{children:"•"}),e.jsx("p",{children:"Teams waste hours manually collecting & comparing reports"})]}),e.jsxs("div",{className:"friction-card",children:[e.jsx("span",{children:"•"}),e.jsx("p",{children:"Numbers arrive without context, stalling confident action"})]}),e.jsxs("div",{className:"friction-card",children:[e.jsx("span",{children:"•"}),e.jsx("p",{children:"Operational bottlenecks emerge before leadership detects them"})]})]})]}),e.jsxs("div",{className:"enterprise-card",children:[e.jsx("div",{className:"enterprise-label",children:"THE ENTERPRISE DILEMMA"}),e.jsx("h3",{children:"More data does not always mean more clarity."}),e.jsx("p",{children:"The real value comes when information is connected, organized and presented in a way that helps leaders understand what is truly happening across their business."})]}),e.jsx("p",{className:"bottom-description",children:"A strong digital environment moves beyond passive record-keeping. It identifies patterns, benchmarks operational performance, surfaces hidden risks, and empowers leaders to act with decisive clarity."}),e.jsx("p",{className:"bottom-bold",children:"This is the role of data-driven technology across modern ERP, Operations, Supply Chain, and Financial ecosystems."}),e.jsxs("div",{className:"goal-card",children:[e.jsx("p",{children:"The goal is not to collect more information."}),e.jsx("h3",{children:"The goal is to make better use of the information already available."})]})]})]}),e.jsx("style",{children:`
        /* ================= SECTION (padding same as other sections) ================= */

        .perspective-analysis {
          width: 100%;
          padding: 40px 16px;
          margin: 0;
          background: #ffffff;
          color: #730042;
          font-family: "Inter", sans-serif;
          overflow: hidden;
        }

        @media (min-width: 640px) {
          .perspective-analysis {
            padding: 48px 24px;
          }
        }

        @media (min-width: 768px) {
          .perspective-analysis {
            padding: 56px 40px;
          }
        }

        @media (min-width: 1024px) {
          .perspective-analysis {
            padding: 64px 100px;
          }
        }

        @media (min-width: 1280px) {
          .perspective-analysis {
            padding: 80px 100px;
          }
        }

        .perspective-container {
          width: 100%;
          display: grid;
          grid-template-columns: 0.95fr 1.4fr;
          gap: 55px;
          align-items: start;
        }

        /* LEFT */

        .perspective-left {
          min-width: 0;
          padding-top: 2px;
        }

        .perspective-badge {
          width: fit-content;
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 7px 12px;
          border: 1px solid #ecc7d8;
          border-radius: 20px;
          background: #fff8fb;
<<<<<<< HEAD
          color: #8f0050;
=======

          color: #730042;

>>>>>>> 386a3c761377b5c513cd6d475ffed43457664c16
          font-size: 9px;
          font-weight: 800;
          letter-spacing: 0.7px;
          margin-bottom: 23px;
        }

        .perspective-badge span {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #730042;
        }

        .perspective-left h2 {
          margin: 0 0 24px;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 26px;
          line-height: 1.18;
          letter-spacing: -1px;
          font-weight: 600;
          color: #151a2a;
        }

        /* EXECUTIVE */

        .executive-card {
          width: 100%;
          padding: 24px 22px 23px;
          background: #f7f9fb;
          border-left: 2px solid #e5ebf1;
          border-radius: 10px;
          margin-bottom: 21px;
        }

        .card-label {
          margin-bottom: 11px;
<<<<<<< HEAD
          color: #970052;
=======

          color: #730042;
>>>>>>> 386a3c761377b5c513cd6d475ffed43457664c16
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 9.5px;
          font-weight: 800;
          letter-spacing: 0.5px;
        }

        .executive-card h3 {
          margin: 0 0 11px;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 15px;
          line-height: 1.35;
          font-weight: 700;
          color: #172033;
        }

        .executive-card p {
          margin: 0;
          color: #596579;
          font-size: 13.5px;
          font-family: "Inter", sans-serif;
          font-weight: 500;
          line-height: 1.7;
        }

        /* THESIS */

        .thesis-card {
          width: 100%;
          padding: 19px 20px;
          border: 1px solid #eed7e1;
          border-radius: 10px;
          background: #fffafd;
        }

        .thesis-card p {
          margin: 0;
          color: #5d6574;
          font-size: 13.5px;
          font-family: "Inter", sans-serif;
          font-weight: 500;
          line-height: 1.65;
        }

        /* RIGHT */

        .perspective-right {
          min-width: 0;
          padding-top: 2px;
        }

        .right-heading {
          margin: 0 0 14px;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 17px;
          line-height: 1.4;
          font-weight: 600;
          color: #171d2c;
        }

        .right-description {
          margin: 0 0 21px;
          color: #596579;
          font-family: "Inter", sans-serif;
          font-size: 13.5px;
          line-height: 1.7;
        }

        /* FRICTION */

        .friction-section {
          margin-bottom: 26px;
        }

        .friction-title {
          margin-bottom: 9px;
          color: #68748a;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.55px;
        }

        .friction-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 8px;
        }

        .friction-card {
          min-height: 53px;
          display: flex;
          align-items: flex-start;
          gap: 9px;
          padding: 11px 12px;
          background: #f7f9fb;
          border: 1px solid #e4e9ef;
          border-radius: 8px;
        }

        .friction-card span {
          flex: 0 0 auto;
<<<<<<< HEAD
          color: #970052;
=======

          color: #730042;

>>>>>>> 386a3c761377b5c513cd6d475ffed43457664c16
          font-size: 15px;
          line-height: 1;
        }

        .friction-card p {
          margin: 0;
          color: #354054;
          font-family: "Inter", sans-serif;
          font-size: 12.5px;
          line-height: 1.5;
          font-weight: 600;
        }

        /* ENTERPRISE DILEMMA */

        .enterprise-card {
          width: 100%;
          padding: 18px 19px;
          background: #060b20;
          border-radius: 9px;
          box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
          margin-bottom: 20px;
        }

        .enterprise-label {
          margin-bottom: 9px;
          color: #ef9bb9;
          font-size: 8px;
          font-weight: 700;
          letter-spacing: 0.5px;
        }

        .enterprise-card h3 {
          margin: 0 0 10px;
          color: #ffffff;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 16px;
          line-height: 1.3;
          font-weight: 700;
        }

        .enterprise-card p {
          max-width: 520px;
          margin: 0;
          color: rgba(239, 243, 250, 0.75);
          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.6;
        }

        /* BOTTOM */

        .bottom-description {
          margin: 0 0 14px;
          color: #596579;
          font-family: "Inter", sans-serif;
          font-size: 13.5px;
          line-height: 1.7;
        }

        .bottom-bold {
          margin: 0 0 22px;
          color: #2e3749;
          font-family: "Inter", sans-serif;
          font-size: 13.5px;
          line-height: 1.6;
          font-weight: 600;
        }

        /* GOAL */

        .goal-card {
          width: 100%;
          padding: 19px 21px;
          border: 1px solid #e7c8d6;
          border-radius: 10px;
          background: #fff9fc;
        }

        .goal-card p {
          margin: 0 0 7px;
          color: #41495a;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          line-height: 1.5;
        }

        .goal-card h3 {
          margin: 0;
<<<<<<< HEAD
          color: #8c0750;
=======

          color: #730042;

>>>>>>> 386a3c761377b5c513cd6d475ffed43457664c16
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 15px;
          line-height: 1.4;
          font-weight: 700;
        }

        /* XL & DESKTOP */

        @media (min-width: 1201px) {
          .perspective-container {
            gap: 65px;
          }
        }

        /* TABLET */

        @media (max-width: 900px) {
          .perspective-container {
            grid-template-columns: 1fr 1.25fr;
            gap: 35px;
          }

          .perspective-left h2 {
            font-size: 25px;
          }

          .right-heading {
            font-size: 16px;
          }

          .enterprise-card h3 {
            font-size: 15px;
          }
        }

        /* MOBILE */

        @media (max-width: 700px) {
          .perspective-container {
            grid-template-columns: 1fr;
            gap: 32px;
          }

          .perspective-left h2 {
            font-size: 25px;
          }

          .right-heading {
            font-size: 16px;
          }

          .right-description,
          .bottom-description {
            font-size: 12px;
          }

          .friction-grid {
            grid-template-columns: 1fr;
          }

          .executive-card {
            padding: 21px 19px;
          }

          .enterprise-card {
            padding: 18px 17px;
          }
        }

        /* SMALL MOBILE */

        @media (max-width: 420px) {
          .perspective-left h2 {
            font-size: 22px;
          }

          .executive-card h3 {
            font-size: 14px;
          }

          .enterprise-card h3 {
            font-size: 15px;
          }
        }
      `})]})}export{a as default};
