import{j as t}from"./vendor-query-PraSc8EQ.js";import{L as n}from"./vendor-router-L4ZCoGSs.js";import{T as c}from"./target-CywCxRzC.js";import{L as h}from"./link-2-WSmG37JH.js";import{S as s}from"./sliders-horizontal-CGLDIiLF.js";import{r as d,A as p}from"./index-BThRNyH6.js";const e="#7A1F3D",i="#1B1B2A",l="#5b5a63",x=[{icon:c,title:"Business-Aligned",body:"Solutions shaped around your business requirements."},{icon:h,title:"Connected",body:"Bring business processes and information together."},{icon:s,title:"Flexible",body:"Technology that can adapt to changing requirements."},{icon:d,title:"Supported",body:"Support across implementation, training and ongoing maintenance."}];function w(){return t.jsxs("section",{className:"why-techtorch-section",children:[t.jsx("style",{children:`

        * {
          box-sizing: border-box;
        }

        .why-techtorch-section {
          width: 100%;
          background: #f5f6f8;
          color: ${i};
          font-family: "Inter", Arial, sans-serif;
          overflow: hidden;
        }

        /* =====================================================
           MAIN CONTAINER
           Desktop: 100px
           Tablet: 40px
           Mobile: 24px
           Small Mobile: 16px
        ===================================================== */

        .why-techtorch-container {
          width: 100%;
          max-width: 1440px;
          margin: 0 auto;
          padding: 80px 100px;
        }

        /* =====================================================
           WHY TECHTORCH HEADER
        ===================================================== */

        .why-techtorch-header {
          width: 100%;
          text-align: center;
          margin-bottom: 42px;
        }

        .why-techtorch-label {
          margin: 0 0 12px;
          color: ${e};
          font-family: "Inter", Arial, sans-serif;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
        }

        .why-techtorch-heading {
          margin: 0;
          color: ${i};
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 36px;
          line-height: 1.3;
          font-weight: 700;
          letter-spacing: -0.025em;
        }

        /* =====================================================
           REASONS GRID
        ===================================================== */

        .why-techtorch-grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 18px;
          margin-bottom: 64px;
        }

        .why-techtorch-card {
          min-width: 0;
          background: #ffffff;
          border-radius: 16px;
          padding: 24px;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
          border: 1px solid transparent;

          transition:
            transform 0.25s ease,
            box-shadow 0.25s ease,
            border-color 0.25s ease;
        }

        .why-techtorch-card:hover {
          transform: translateY(-4px);
          border-color: #eadde1;
          box-shadow: 0 12px 28px rgba(122, 31, 61, 0.08);
        }

        .why-techtorch-icon {
          width: 38px;
          height: 38px;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 17px;
          border-radius: 9px;
          background: #fbeef1;
          color: ${e};
        }

        .why-techtorch-card-title {
          margin: 0 0 8px;
          color: ${i};
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 14px;
          line-height: 1.45;
          font-weight: 700;
        }

        .why-techtorch-card-body {
          margin: 0;
          color: ${l};
          font-family: "Inter", Arial, sans-serif;
          font-size: 12px;
          line-height: 1.65;
          font-weight: 400;
        }

        /* =====================================================
           BUILD CTA
        ===================================================== */

        .build-cta {
          width: 100%;
          padding: 64px 60px;
          border-radius: 28px;
          background: ${e};
          text-align: center;
        }

        .build-cta-heading {
          margin: 0 0 17px;
          color: #ffffff;
          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 36px;
          line-height: 1.3;
          font-weight: 700;
          letter-spacing: -0.025em;
        }

        .build-cta-description {
          max-width: 680px;
          margin: 0 auto 30px;
          color: #e3c3cf;
          font-family: "Inter", Arial, sans-serif;
          font-size: 14px;
          line-height: 1.75;
          font-weight: 400;
        }

        /* =====================================================
           CTA BUTTON
        ===================================================== */

        .build-cta-button {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;

          min-height: 50px;
          padding: 0 26px;

          border: none;

          /* UPDATED: 999px -> 6px */
          border-radius: 6px;

          background: #ffffff;
          color: ${e};

          font-family: "Inter", Arial, sans-serif;
          font-size: 13px;
          font-weight: 600;

          cursor: pointer;

          transition:
            transform 0.25s ease,
            box-shadow 0.25s ease;
        }

        .build-cta-button:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        .build-cta-button:active {
          transform: translateY(0);
        }

        /* =====================================================
           LARGE TABLET
        ===================================================== */

        @media (max-width: 1100px) {
          .why-techtorch-container {
            padding: 68px 40px;
          }

          .why-techtorch-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .why-techtorch-heading,
          .build-cta-heading {
            font-size: 32px;
          }

          .build-cta {
            padding: 58px 48px;
          }
        }

        /* =====================================================
           TABLET
        ===================================================== */

        @media (max-width: 800px) {
          .why-techtorch-container {
            padding: 58px 40px;
          }

          .why-techtorch-header {
            margin-bottom: 34px;
          }

          .why-techtorch-heading {
            font-size: 29px;
          }

          .why-techtorch-grid {
            gap: 14px;
            margin-bottom: 48px;
          }

          .why-techtorch-card {
            padding: 20px;
          }

          .build-cta {
            padding: 50px 32px;
            border-radius: 24px;
          }

          .build-cta-heading {
            font-size: 29px;
          }

          .build-cta-description {
            font-size: 13.5px;
          }
        }

        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 600px) {
          .why-techtorch-container {
            padding: 44px 24px;
          }

          .why-techtorch-header {
            margin-bottom: 30px;
          }

          .why-techtorch-label {
            font-size: 10px;
            margin-bottom: 10px;
          }

          .why-techtorch-heading {
            font-size: 25px;
            line-height: 1.3;
          }

          .why-techtorch-grid {
            grid-template-columns: 1fr;
            gap: 12px;
            margin-bottom: 36px;
          }

          .why-techtorch-card {
            padding: 19px;
            border-radius: 14px;
          }

          .why-techtorch-icon {
            width: 36px;
            height: 36px;
            margin-bottom: 15px;
          }

          .why-techtorch-card-title {
            font-size: 14px;
          }

          .why-techtorch-card-body {
            font-size: 12px;
            line-height: 1.65;
          }

          .build-cta {
            padding: 40px 20px;
            border-radius: 20px;
          }

          .build-cta-heading {
            font-size: 25px;
            line-height: 1.3;
          }

          .build-cta-description {
            font-size: 13px;
            line-height: 1.7;
            margin-bottom: 26px;
          }

          .build-cta-button {
            width: 100%;
            min-height: 48px;
            padding: 0 20px;
            font-size: 12.5px;

            /* SAME RADIUS ON MOBILE */
            border-radius: 6px;
          }

          .desktop-break {
            display: none;
          }
        }

        /* =====================================================
           SMALL MOBILE
        ===================================================== */

        @media (max-width: 400px) {
          .why-techtorch-container {
            padding: 36px 16px;
          }

          .why-techtorch-heading {
            font-size: 22px;
          }

          .why-techtorch-card {
            padding: 17px;
          }

          .why-techtorch-card-title {
            font-size: 13.5px;
          }

          .why-techtorch-card-body {
            font-size: 11.5px;
          }

          .build-cta {
            padding: 34px 16px;
            border-radius: 18px;
          }

          .build-cta-heading {
            font-size: 22px;
          }

          .build-cta-description {
            font-size: 12px;
          }

          .build-cta-button {
            border-radius: 6px;
          }
        }

        /* =====================================================
           VERY SMALL MOBILE
        ===================================================== */

        @media (max-width: 340px) {
          .why-techtorch-container {
            padding: 30px 16px;
          }

          .why-techtorch-heading {
            font-size: 20px;
          }

          .why-techtorch-grid {
            gap: 10px;
          }

          .why-techtorch-card {
            padding: 15px;
          }

          .build-cta {
            padding: 30px 14px;
          }

          .build-cta-heading {
            font-size: 20px;
          }

          .build-cta-description {
            font-size: 11.5px;
          }

          .build-cta-button {
            border-radius: 6px;
          }
        }

        /* =====================================================
           REDUCED MOTION
        ===================================================== */

        @media (prefers-reduced-motion: reduce) {
          .why-techtorch-card,
          .build-cta-button {
            transition: none;
          }

          .why-techtorch-card:hover,
          .build-cta-button:hover {
            transform: none;
          }
        }
      `}),t.jsxs("div",{className:"why-techtorch-container",children:[t.jsxs("div",{className:"why-techtorch-header",children:[t.jsx("p",{className:"why-techtorch-label",children:"WHY TECHTORCH"}),t.jsxs("h2",{className:"why-techtorch-heading",children:["Technology With a Clear Business",t.jsx("br",{className:"desktop-break"}),"Focus"]})]}),t.jsx("div",{className:"why-techtorch-grid",children:x.map(({icon:a,title:r,body:o})=>t.jsxs("div",{className:"why-techtorch-card",children:[t.jsx("span",{className:"why-techtorch-icon",children:t.jsx(a,{size:16,strokeWidth:1.8})}),t.jsx("h3",{className:"why-techtorch-card-title",children:r}),t.jsx("p",{className:"why-techtorch-card-body",children:o})]},r))}),t.jsxs("div",{className:"build-cta",children:[t.jsxs("h2",{className:"build-cta-heading",children:["Build a More Connected",t.jsx("br",{className:"desktop-break"}),"Manufacturing Business"]}),t.jsx("p",{className:"build-cta-description",children:"Bring your business processes, supply chain and technology environment together with solutions designed around your requirements."}),t.jsxs(n,{to:"/talk-to-expert",className:"build-cta-button",children:["Talk to Our Experts",t.jsx(p,{size:16})]})]})]})]})}export{w as default};
