import{j as e}from"./vendor-query-PraSc8EQ.js";import{d as h}from"./vendor-router-L4ZCoGSs.js";function j(){const r=h(),a=[{number:"01",title:"Pre-Assessment Legal & NDA Sealing",timeline:"Hour 00 – 04 · Mutual Execution",status:"Ready for Seal",statusType:"green",description:"Instant mutual MNDA execution establishing attorney-client-adjacent architectural privilege. Cryptographic privilege keys are provisioned for all telemetry handshakes, locking stakeholder authorization rosters into immutable auditable logs.",tags:[["Bilateral Non-Disclosure Execution","shield"],["ECDSA P-384 Privilege Keys Generated","key"]]},{number:"02",title:"Zero-Intrusion Passive Reconnaissance",timeline:"Hour 04 – 24 · Read-Only Telemetry",status:"Passive Mode",statusType:"gray",description:"Non-intrusive surface telemetry and perimeter configuration parsing via read-only APIs and external DNS/egress surface mapping. Absolutely no credential injection, zero active credential harvesting, and an ironclad SLA guaranteeing 0.00% production latency degradation.",tags:[["Non-Agentic Read-Only API Ingestion","api"],["Zero Downtime SLA Binding","clock"]]},{number:"03",title:"Diagnostic Gap Synthesis & Modeling",timeline:"Hour 24 – 48 · Advanced Correlation",status:"Synthesis",statusType:"gray",description:"Cross-referencing multi-cloud IAM privilege graphs, autonomous AI agent execution boundaries, and microservice mesh configurations against known CVE databases and sovereign zero-day registries without touching customer payloads.",tags:[["Multi-Cloud Graph Privilege Traversal","graph"],["AI Agent Prompt-Injection Boundary Test","ai"]]},{number:"04",title:"Executive Debrief & Telemetry Handoff",timeline:"Hour 48+ · Board-Ready Reporting",status:"Encrypted Egress",statusType:"green",description:"Delivery of the classified 30-60-90 day remediation matrix and board-ready executive security portfolio. All temporary telemetry scratchspaces are cryptographically shredded in accordance with DoD 5220.22-M zero-footprint directives.",tags:[["End-to-End PGP Armor Distribution","lock"],["Zero Retained Telemetry Certificate","certificate"]]}],i=[{title:"Zero Production Disruption Guarantee",text:"SLA backed 100% passive query limits. Diagnostic tools operate below 0.5% system ceiling."},{title:"Strict Read-Only Probing",text:"Zero write permissions requested. Zero database mutation or privileged customer record traversal."},{title:"Data Privacy & 7-Day Purge SLA",text:"All configuration hashes and architectural metadata fully expunged within 168 hours of presentation."},{title:"Sovereign Data Boundary Enforced",text:"Diagnostic telemetry strictly restricted to specified cloud regions (US-East/EU-West as mandated)."}];return e.jsxs("div",{className:"protocol-page",children:[e.jsxs("header",{className:"protocol-header",children:[e.jsxs("div",{className:"protocol-badge",children:[e.jsx("span",{className:"badge-dot"}),"TECHTORCH SECURITY GOVERNANCE & LEGAL COMPLIANCE · INSTITUTIONAL PROTOCOL"]}),e.jsxs("div",{className:"protocol-meta",children:[e.jsxs("span",{className:"protocol-id",children:[e.jsx(t,{name:"dot",size:13}),"PROTOCOL ID: TT-ENG-2024-SEC-09"]}),e.jsx("span",{className:"version-badge",children:"V4.2 CERTIFIED"})]})]}),e.jsxs("section",{className:"protocol-hero",children:[e.jsxs("div",{className:"hero-content",children:[e.jsx("h1",{children:"Enterprise Security Engagement Protocol"}),e.jsx("p",{children:"A formal, zero-disruption operating agreement establishing non-intrusive diagnostic boundaries, mutual non-disclosure privilege, and institutional security governance before engagement."})]}),e.jsxs("div",{className:"hero-actions",children:[e.jsxs("button",{className:"export-btn",onClick:()=>r("/export-protocol"),children:[e.jsx(t,{name:"download",size:14}),"Export Protocol Package"]}),e.jsxs("button",{className:"accept-btn",onClick:()=>r("/accept-proceed"),children:["Accept & Proceed",e.jsx(t,{name:"arrow-right",size:15})]})]})]}),e.jsxs("section",{className:"certification-strip",children:[e.jsx(o,{icon:"award",title:"ISO/IEC 27001",subtitle:"Global Certified"}),e.jsx(o,{icon:"shield",title:"SOC 2 Type II",subtitle:"Continuous Audit"}),e.jsx(o,{icon:"at",title:"FedRAMP High",subtitle:"Control Alignment"}),e.jsx(o,{icon:"key",title:"Tier-IV NDA",subtitle:"Privileged Sealing"}),e.jsx(o,{icon:"retention",title:"Zero Retention",subtitle:"Ephemeral Storage",green:!0})]}),e.jsxs("main",{className:"protocol-main",children:[e.jsxs("div",{className:"roadmap-column",children:[e.jsxs("div",{className:"section-heading-row",children:[e.jsxs("div",{children:[e.jsx("div",{className:"eyebrow",children:"SEQUENTIAL ROADMAP"}),e.jsx("h2",{children:"Protocol Execution Stages"})]}),e.jsxs("div",{className:"lifecycle",children:[e.jsx(t,{name:"clock",size:14}),"48h Full Lifecycle"]})]}),e.jsx("div",{className:"stage-list",children:a.map(s=>e.jsx(m,{...s},s.number))})]}),e.jsxs("aside",{className:"sidebar",children:[e.jsxs("section",{className:"side-card",children:[e.jsxs("div",{className:"side-title",children:[e.jsx("div",{className:"side-icon green-icon",children:e.jsx(t,{name:"shield-check",size:23})}),e.jsxs("div",{children:[e.jsx("div",{className:"side-eyebrow",children:"STRICT WARRANTIES"}),e.jsx("h3",{children:"Operational Guardrails"})]})]}),e.jsx("div",{className:"guardrail-list",children:i.map((s,n)=>e.jsxs("div",{className:"guardrail",children:[e.jsx("div",{className:"check",children:e.jsx(t,{name:"check",size:11})}),e.jsxs("div",{children:[e.jsx("strong",{children:s.title}),e.jsx("p",{children:s.text})]})]},n))})]}),e.jsxs("section",{className:"side-card personnel-card",children:[e.jsxs("div",{className:"side-title",children:[e.jsx("div",{className:"side-icon purple-icon",children:e.jsx(t,{name:"badge",size:23})}),e.jsxs("div",{children:[e.jsx("div",{className:"side-eyebrow",children:"GOVERNANCE & PERSONNEL"}),e.jsx("h3",{children:"Assigned Lead Architects"})]})]}),e.jsx(c,{image:"/EvelynVance.webp",name:"Dr. Evelyn Vance",role:"LEAD PARTNER",credential:"CISSP, CISM · ex-DRPA Cyber Fellow",specialty:"Lead Defense & Cryptographic Architecture"}),e.jsx(c,{image:"/MarcusChen.webp",name:"Marcus Chen",role:"PRINCIPAL",credential:"Cloud Security Alliance (CSA) Fellow",specialty:"Zero-Trust & Infrastructure Synthesis"}),e.jsxs("div",{className:"legal-section",children:[e.jsx("h4",{children:"LEGAL JURISDICTION & VENUE"}),e.jsx("p",{children:"Engagement subject to standard Delaware bilateral choice of law with expedited arbitration under the American Arbitration Association (AAA) Commercial Rules."})]})]})]})]}),e.jsxs("section",{className:"package-card",children:[e.jsxs("div",{className:"package-info",children:[e.jsxs("h2",{children:[e.jsx(t,{name:"file",size:19}),"Institutional Protocol Package (v4.2)"]}),e.jsx("p",{children:"Complete non-disclosure covenants, bilateral non-liability guarantees, passive probing technical manifests, and incident response liability boundaries."}),e.jsxs("div",{className:"hash",children:["SHA-256:",e.jsx("br",{}),"8f3d198a24c55e9ed91f9bc9a7702f54a8b79d612e4b85c13e4e9f7832ad5106"]})]}),e.jsxs("div",{className:"package-actions",children:[e.jsxs("button",{className:"clarification-btn",children:[e.jsx(t,{name:"phone",size:15}),"Schedule Clarification Call"]}),e.jsxs("button",{className:"package-accept",children:["Accept Protocol & Proceed to Intake",e.jsx(t,{name:"arrow-right",size:15})]})]})]}),e.jsxs("footer",{className:"protocol-footer",children:[e.jsxs("div",{className:"footer-item",children:[e.jsx("span",{className:"footer-icon",children:e.jsx(t,{name:"support",size:19})}),e.jsxs("div",{className:"footer-text",children:[e.jsx("strong",{children:"Security Governance Desk:"}),e.jsx("br",{}),e.jsx("a",{href:"mailto:legal@techtorch.solutions",className:"footer-link",children:"legal@techtorch.solutions"})]})]}),e.jsxs("div",{className:"footer-item",children:[e.jsx("span",{className:"footer-icon",children:e.jsx(t,{name:"phone",size:18})}),e.jsxs("div",{className:"footer-text",children:[e.jsx("strong",{children:"Priority Line:"}),e.jsx("br",{}),e.jsx("a",{href:"tel:+915813500381",className:"footer-link",children:"+91 581 350 0381"})]})]}),e.jsxs("div",{className:"footer-item footer-copyright",children:[e.jsx("span",{className:"footer-icon",children:e.jsx(t,{name:"certificate",size:17})}),e.jsx("div",{className:"footer-text",children:"© 2024–2026 TechTorch Solutions. All engagements protected under bilateral legal privilege."})]})]}),e.jsx("style",{children:`

        * {
          box-sizing: border-box;
        }

        body {
          margin: 0;
        }

        .protocol-page {
          width: 100%;
          min-height: 100vh;

          /* INCREASED DESKTOP PADDING */
          padding: 50px 130px 35px;

          background: #f7f8fa;
          color: #172033;
          font-family: "Inter", Arial, sans-serif;
        }

        /* HEADER */

        .protocol-header {
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 20px;
        }

        .protocol-badge {
          display: inline-flex;
          align-items: center;
          gap: 9px;
          min-height: 27px;
          padding: 0 12px;
          border: 1px solid #dfc8d5;
          border-radius: 20px;
          background: #f4edf1;
          color: #71123f;
          font-size: 9px;
          font-weight: 800;
          letter-spacing: .7px;
        }

        .badge-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #76003d;
          flex-shrink: 0;
        }

        .protocol-meta {
          display: flex;
          align-items: center;
          gap: 12px;
          color: #6c778b;
          font-size: 11px;
          font-weight: 800;
          letter-spacing: 1.4px;
        }

        .protocol-id {
          display: flex;
          align-items: center;
          gap: 5px;
          white-space: nowrap;
        }

        .version-badge {
          padding: 5px 8px;
          border-radius: 4px;
          background: #e8ebef;
          color: #4d586a;
          font-size: 10px;
          letter-spacing: .3px;
        }

        /* HERO */

        .protocol-hero {
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
          gap: 30px;
          padding: 29px 0 26px;
        }

        .hero-content {
          max-width: 690px;
          min-width: 0;
        }

        .hero-content h1 {
          margin: 0 0 12px;
          font-family: "Plus Jakarta Sans", "Inter", Arial, sans-serif;
          font-size: 30px;
          line-height: 1.16;
          letter-spacing: -1.5px;
          font-weight: 600;
          color: #111a2c;
        }

        .hero-content p {
          margin: 0;
          max-width: 720px;
          color: #657389;
          font-size: 14px;
          line-height: 1.55;
        }

        .hero-actions {
          display: flex;
          align-items: center;
          gap: 9px;
          padding-bottom: 1px;
          flex-shrink: 0;
        }

        button {
          font-family: inherit;
          cursor: pointer;
        }

        .export-btn,
        .accept-btn {
          min-height: 35px;
          padding: 0 15px;
          border-radius: 6px;
          font-size: 12.5px;
          font-weight: 700;
          white-space: nowrap;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 7px;
        }

        .export-btn {
          border: 1px solid #e2e5e9;
          background: #e9ebee;
          color: #475367;
        }

        .accept-btn {
          border: 1px solid #75003e;
          background: #75003e;
          color: white;
          box-shadow: 0 5px 12px rgba(117, 0, 62, .14);
        }

        /* CERTIFICATIONS */

        .certification-strip {
          width: 100%;
          min-height: 74px;
          padding: 12px 20px;
          display: grid;
          grid-template-columns: repeat(5, 1fr);
          align-items: center;
          gap: 20px;
          background: white;
          border: 1px solid #e4e7eb;
          border-radius: 9px;
          box-shadow: 0 2px 7px rgba(20, 30, 45, .025);
        }

        .certification {
          display: flex;
          align-items: center;
          gap: 10px;
          min-width: 0;
        }

        .cert-icon {
          width: 31px;
          height: 31px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 6px;
          background: #f1f2f4;
          color: #72003e;
          flex-shrink: 0;
        }

        .cert-icon.green {
          color: #21875e;
        }

        .certification strong {
          display: block;
          color: #263045;
          font-size: 12.5px;
          font-weight: 800;
          margin-bottom: 3px;
        }

        .certification span {
          display: block;
          color: #718096;
          font-size: 10.5px;
        }

        /* MAIN */

        .protocol-main {
          display: grid;
          grid-template-columns: minmax(0, 1.55fr) minmax(320px, 1fr);
          gap: 24px;
          margin-top: 29px;
        }

        .section-heading-row {
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          gap: 15px;
          margin-bottom: 15px;
        }

        .eyebrow,
        .side-eyebrow {
          color: #741040;
          font-size: 10.5px;
          font-weight: 900;
        }

        .section-heading-row h2 {
          margin: 3px 0 0;
          font-family: "Plus Jakarta Sans", "Inter", Arial, sans-serif;
          font-size: 22px;
          font-weight: 700;
          line-height: 1.1;
          letter-spacing: -.8px;
          color: #151e31;
        }

        .lifecycle {
          padding: 5px 9px;
          border-radius: 15px;
          background: #e9ebed;
          color: #647084;
          font-size: 10.5px;
          font-weight: 700;
          white-space: nowrap;
          display: inline-flex;
          align-items: center;
          gap: 5px;
        }

        /* STAGES */

        .stage-list {
          display: flex;
          flex-direction: column;
          gap: 15px;
        }

        .stage-card {
          padding: 20px;
          background: white;
          border: 1px solid #e4e7eb;
          border-radius: 9px;
          box-shadow: 0 2px 7px rgba(20, 30, 45, .025);
        }

        .stage-top {
          display: flex;
          align-items: center;
          gap: 11px;
        }

        .stage-number {
          width: 31px;
          height: 31px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 6px;
          background: #73003e;
          color: white;
          font-size: 12px;
          font-weight: 800;
          flex-shrink: 0;
        }

        .stage-title-box {
          flex: 1;
          min-width: 0;
        }

        .stage-title-box h3 {
          margin: 0 0 3px;
          color: #202a3e;
          font-size: 15px;
          font-weight: 800;
          letter-spacing: -.25px;
        }

        .timeline {
          color: #748096;
          font-size: 11px;
          font-weight: 600;
        }

        .stage-status {
          padding: 5px 9px;
          border-radius: 14px;
          font-size: 10.5px;
          font-weight: 750;
          white-space: nowrap;
        }

        .status-green {
          color: #159368;
          border: 1px solid #a5ebd2;
          background: #effcf7;
        }

        .status-gray {
          color: #617086;
          background: #e8ebee;
        }

        .stage-description {
          margin: 13px 0 15px;
          color: #647187;
          font-size: 13.5px;
          line-height: 1.52;
        }

        .stage-tags {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 8px;
        }

        .stage-tag {
          min-height: 29px;
          display: flex;
          align-items: center;
          gap: 7px;
          padding: 0 10px;
          border-radius: 6px;
          background: #f0f1f3;
          color: #4e5b6e;
          font-size: 10.5px;
          font-weight: 750;
          min-width: 0;
        }

        .stage-tag-icon {
          color: #741040;
          display: flex;
          align-items: center;
          flex-shrink: 0;
        }

        /* SIDEBAR */

        .sidebar {
          display: flex;
          flex-direction: column;
          gap: 19px;
          min-width: 0;
        }

        .side-card {
          padding: 20px;
          background: white;
          border: 1px solid #e4e7eb;
          border-radius: 9px;
          box-shadow: 0 2px 7px rgba(20, 30, 45, .025);
        }

        .side-title {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 15px;
        }

        .side-icon {
          width: 39px;
          height: 39px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 7px;
          flex-shrink: 0;
        }

        .green-icon {
          color: white;
          background: #08644d;
        }

        .purple-icon {
          color: #7a174e;
          background: #f1e8ee;
        }

        .side-title h3 {
          margin: 2px 0 0;
          color: #182237;
          font-family: "Plus Jakarta Sans", "Inter", Arial, sans-serif;
          font-size: 16px;
          font-weight: 700;
          line-height: 1.1;
          letter-spacing: -.35px;
        }

        .guardrail-list {
          display: flex;
          flex-direction: column;
          gap: 9px;
        }

        .guardrail {
          display: flex;
          gap: 9px;
          padding: 12px 10px;
          border-radius: 6px;
          background: #f0f1f3;
        }

        .check {
          width: 20px;
          height: 20px;
          display: flex;
          align-items: center;
          justify-content: center;
          border: 2px solid #1aa176;
          border-radius: 50%;
          color: #15956e;
          flex-shrink: 0;
          margin-top: 1px;
        }

        .guardrail strong {
          display: block;
          color: #344056;
          font-size: 13px;
          margin-bottom: 4px;
        }

        .guardrail p {
          margin: 0;
          color: #6d7889;
          font-size: 11px;
          line-height: 1.45;
        }

        /* PERSONNEL */

        .personnel-card {
          padding-bottom: 17px;
        }

        .person {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 9px;
          margin-bottom: 9px;
          border-radius: 6px;
          background: #f0f1f3;
        }

        .person img {
          width: 39px;
          height: 39px;
          object-fit: cover;
          border-radius: 50%;
          background: #d9dce1;
          flex-shrink: 0;
        }

        .person-info {
          min-width: 0;
        }

        .person-name {
          display: flex;
          align-items: center;
          gap: 5px;
          color: #273247;
          font-size: 13px;
          font-weight: 800;
          flex-wrap: wrap;
        }

        .person-role {
          padding: 2px 4px;
          background: #e4e6e9;
          color: #7b8493;
          font-size: 9px;
          font-weight: 900;
        }

        .person-credential {
          margin-top: 3px;
          color: #741040;
          font-size: 10px;
          font-weight: 700;
        }

        .person-specialty {
          margin-top: 2px;
          color: #6e7889;
          font-size: 10px;
          font-weight: 700;
        }

        .legal-section {
          padding-top: 11px;
          border-top: 1px solid #e3e5e8;
        }

        .legal-section h4 {
          margin: 0 0 6px;
          color: #182237;
          font-size: 12px;
          font-weight: 900;
          letter-spacing: .4px;
        }

        .legal-section p {
          margin: 0;
          color: #727d8f;
          font-size: 12px;
          line-height: 1.5;
        }

        /* PACKAGE */

        .package-card {
          margin-top: 54px;
          padding: 25px 24px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 25px;
          background: white;
          border: 1px solid #e4e7eb;
          border-radius: 9px;
          box-shadow: 0 2px 7px rgba(20, 30, 45, .035);
        }

        .package-info {
          min-width: 0;
          max-width: 570px;
        }

        .package-info h2 {
          margin: 0 0 9px;
          display: flex;
          align-items: center;
          gap: 9px;
          color: #1b2538;
          font-family: "Plus Jakarta Sans", "Inter", Arial, sans-serif;
          font-size: 17px;
          font-weight: 700;
          letter-spacing: -.4px;
        }

        .package-info h2 svg {
          color: #72003e;
          flex-shrink: 0;
        }

        .package-info p {
          margin: 0 0 14px;
          color: #69758a;
          font-size: 13px;
          line-height: 1.45;
        }

        .hash {
          padding: 7px 10px;
          border-radius: 5px;
          background: #e9ebee;
          color: #6d7788;
          font-family: monospace;
          font-size: 11px;
          line-height: 1.4;
          word-break: break-all;
        }

        .package-actions {
          display: flex;
          align-items: center;
          gap: 9px;
          flex-shrink: 0;
        }

        .clarification-btn,
        .package-accept {
          min-height: 37px;
          padding: 0 14px;
          border-radius: 6px;
          font-size: 11.5px;
          font-weight: 750;
          white-space: nowrap;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 7px;
        }

        .clarification-btn {
          border: 1px solid #e1e4e8;
          background: #e8eaed;
          color: #536075;
        }

        .package-accept {
          border: 1px solid #73003e;
          background: #73003e;
          color: white;
        }

        /* PURPLE FOOTER */

        .protocol-footer {
          min-height: 68px;
          margin-top: 29px;
          padding: 15px 32px;

          display: grid;
          grid-template-columns: 1fr 1fr 1.5fr;
          align-items: center;
          gap: 35px;

          border-radius: 8px;
          background: #58002f;
          color: #f6dfea;

          font-size: 12px;
          line-height: 1.45;
          letter-spacing: .7px;
        }

        .footer-item {
          display: flex;
          align-items: center;
          gap: 11px;
          min-width: 0;
        }

        .footer-icon {
          width: 25px;
          height: 25px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          color: #f8e8f0;
        }

        .footer-text {
          min-width: 0;
        }

        .protocol-footer strong {
          font-size: 10px;
          letter-spacing: 1px;
          color: #f8e8f0;
        }

        .footer-link {
          color: #f6dfea;
          text-decoration: none;
          transition: color .2s ease;
          overflow-wrap: anywhere;
        }

        .footer-link:hover {
          color: #ffffff;
          text-decoration: underline;
        }

        .footer-copyright {
          align-items: center;
        }

        .footer-copyright .footer-text {
          line-height: 1.45;
        }

        /* =========================================
           LARGE LAPTOP
        ========================================= */

        @media (max-width: 1400px) {

          .protocol-page {
            padding-left: 110px;
            padding-right: 110px;
          }

        }

        /* =========================================
           LAPTOP / SMALL DESKTOP
        ========================================= */

        @media (max-width: 1200px) {

          .protocol-page {
            padding-left: 80px;
            padding-right: 80px;
          }

          .protocol-main {
            grid-template-columns: minmax(0, 1.35fr) minmax(300px, 1fr);
            gap: 20px;
          }

          .certification-strip {
            gap: 14px;
          }

          .protocol-hero {
            gap: 20px;
          }

          .hero-content h1 {
            font-size: 28px;
          }

          .package-card {
            gap: 18px;
          }

        }

        /* =========================================
           TABLET
        ========================================= */

        @media (max-width: 1000px) {

          .protocol-page {
            padding-left: 60px;
            padding-right: 60px;
          }

          .protocol-main {
            grid-template-columns: 1fr;
          }

          .sidebar {
            display: grid;
            grid-template-columns: 1fr 1fr;
            align-items: start;
          }

          .package-card {
            flex-direction: column;
            align-items: stretch;
          }

          .package-info {
            max-width: none;
          }

          .package-actions {
            width: 100%;
          }

          .package-actions button {
            flex: 1;
          }

        }

        /* =========================================
           SMALL TABLET
        ========================================= */

        @media (max-width: 768px) {

          .protocol-page {
            padding-left: 45px;
            padding-right: 45px;
          }

          .protocol-header {
            align-items: flex-start;
            flex-direction: column;
          }

          .protocol-meta {
            width: 100%;
            justify-content: space-between;
          }

          .protocol-hero {
            flex-direction: column;
            align-items: flex-start;
            gap: 20px;
          }

          .hero-content {
            max-width: 100%;
          }

          .hero-content h1 {
            font-size: 27px;
          }

          .hero-actions {
            width: 100%;
          }

          .hero-actions button {
            flex: 1;
          }

          .certification-strip {
            grid-template-columns: repeat(2, 1fr);
          }

          .sidebar {
            grid-template-columns: 1fr;
          }

          .protocol-footer {
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            padding: 14px 20px;
          }

          .footer-copyright {
            grid-column: 1 / -1;
          }

        }

        /* =========================================
           MOBILE
        ========================================= */

        @media (max-width: 600px) {

          .protocol-page {
            padding: 20px 20px 22px;
          }

          .protocol-badge {
            width: 100%;
            height: auto;
            min-height: 28px;
            padding: 6px 10px;
            font-size: 8.5px;
            line-height: 1.3;
          }

          .protocol-meta {
            flex-wrap: wrap;
            gap: 7px;
            font-size: 9px;
          }

          .protocol-hero {
            padding: 23px 0 20px;
            gap: 20px;
          }

          .hero-content h1 {
            font-size: 25px;
            letter-spacing: -1px;
          }

          .hero-content p {
            font-size: 13px;
            line-height: 1.55;
          }

          .hero-actions {
            flex-direction: column;
            width: 100%;
          }

          .hero-actions button {
            width: 100%;
            flex: none;
          }

          .certification-strip {
            grid-template-columns: 1fr;
            gap: 13px;
            padding: 15px;
          }

          .protocol-main {
            margin-top: 23px;
          }

          .section-heading-row {
            align-items: flex-start;
            flex-direction: column;
          }

          .section-heading-row h2 {
            font-size: 20px;
          }

          .stage-card {
            padding: 16px;
          }

          .stage-top {
            align-items: flex-start;
          }

          .stage-title-box h3 {
            font-size: 13px;
            line-height: 1.3;
          }

          .timeline {
            font-size: 9.5px;
          }

          .stage-status {
            font-size: 9px;
          }

          .stage-description {
            font-size: 12.5px;
          }

          .stage-tags {
            grid-template-columns: 1fr;
          }

          .sidebar {
            display: flex;
          }

          .package-card {
            margin-top: 30px;
            padding: 19px 16px;
          }

          .package-info h2 {
            font-size: 15px;
          }

          .package-info p {
            font-size: 11.5px;
          }

          .package-actions {
            flex-direction: column;
          }

          .package-actions button {
            width: 100%;
          }

          .protocol-footer {
            grid-template-columns: 1fr;
            gap: 13px;
            min-height: 68px;
            padding: 16px;
          }

          .footer-copyright {
            grid-column: auto;
          }

          .footer-item {
            align-items: center;
          }

        }

        /* =========================================
           EXTRA SMALL MOBILE
        ========================================= */

        @media (max-width: 400px) {

          .protocol-page {
            padding: 15px 15px 18px;
          }

          .protocol-badge {
            font-size: 8px;
          }

          .protocol-id {
            white-space: normal;
          }

          .hero-content h1 {
            font-size: 22px;
          }

          .hero-content p {
            font-size: 12px;
          }

          .certification-strip {
            padding: 13px;
          }

          .stage-card {
            padding: 14px;
          }

          .stage-number {
            width: 29px;
            height: 29px;
          }

          .stage-title-box h3 {
            font-size: 12.5px;
          }

          .stage-description {
            font-size: 12px;
          }

          .side-card {
            padding: 16px;
          }

          .package-card {
            padding: 17px 14px;
          }

          .package-info h2 {
            font-size: 14px;
          }

          .protocol-footer {
            padding: 14px;
            font-size: 11px;
          }

        }

      `})]})}function t({name:r,size:a=18}){const i={width:a,height:a,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:1.9,strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":!0};switch(r){case"award":return e.jsxs("svg",{...i,children:[e.jsx("circle",{cx:"12",cy:"8",r:"5.2"}),e.jsx("path",{d:"M8.8 12.1 7.5 21l4.5-2.4 4.5 2.4-1.3-8.9"}),e.jsx("path",{d:"m12 5.5.8 1.6 1.8.3-1.3 1.3.3 1.8-1.6-.8-1.6.8.3-1.8-1.3-1.3 1.8-.3L12 5.5Z"})]});case"shield":return e.jsxs("svg",{...i,children:[e.jsx("path",{d:"M12 3 20 6v5.5c0 5.1-3.2 8.3-8 9.5-4.8-1.2-8-4.4-8-9.5V6l8-3Z"}),e.jsx("path",{d:"m8.5 12 2.2 2.2 4.8-4.8"})]});case"shield-check":return e.jsxs("svg",{...i,children:[e.jsx("path",{d:"M12 3 20 6v5.5c0 5.1-3.2 8.3-8 9.5-4.8-1.2-8-4.4-8-9.5V6l8-3Z"}),e.jsx("path",{d:"m8.3 12 2.3 2.3 5.1-5.1"})]});case"at":return e.jsxs("svg",{...i,children:[e.jsx("circle",{cx:"12",cy:"12",r:"4"}),e.jsx("path",{d:"M16 12v1.5a2.5 2.5 0 0 0 5 0V12a9 9 0 1 0-3 6.7"})]});case"key":return e.jsxs("svg",{...i,children:[e.jsx("circle",{cx:"8",cy:"15",r:"4"}),e.jsx("path",{d:"m11 12 9-9"}),e.jsx("path",{d:"m17 6 2 2"}),e.jsx("path",{d:"m14.5 8.5 2 2"})]});case"retention":return e.jsxs("svg",{...i,children:[e.jsx("path",{d:"M12 5a7 7 0 1 1-6.2 3.7"}),e.jsx("path",{d:"M5 5v4h4"}),e.jsx("path",{d:"M12 8v4l2.5 1.5"})]});case"clock":return e.jsxs("svg",{...i,children:[e.jsx("circle",{cx:"12",cy:"12",r:"8.5"}),e.jsx("path",{d:"M12 7.5v4.8l3 1.8"})]});case"dot":return e.jsx("svg",{width:a,height:a,viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true",children:e.jsx("circle",{cx:"12",cy:"12",r:"4"})});case"download":return e.jsxs("svg",{...i,children:[e.jsx("path",{d:"M12 3v11"}),e.jsx("path",{d:"m7.5 9.5 4.5 4.5 4.5-4.5"}),e.jsx("path",{d:"M5 20h14"})]});case"arrow-right":return e.jsxs("svg",{...i,children:[e.jsx("path",{d:"M5 12h14"}),e.jsx("path",{d:"m13 6 6 6-6 6"})]});case"check":return e.jsx("svg",{...i,children:e.jsx("path",{d:"m5 12.5 4.2 4.2L19 7"})});case"badge":return e.jsxs("svg",{...i,children:[e.jsx("rect",{x:"5",y:"4",width:"14",height:"16",rx:"2"}),e.jsx("path",{d:"M9 4V2h6v2"}),e.jsx("circle",{cx:"12",cy:"10",r:"2"}),e.jsx("path",{d:"M8.5 16c1.2-1.8 5.8-1.8 7 0"})]});case"api":return e.jsxs("svg",{...i,children:[e.jsx("circle",{cx:"6",cy:"12",r:"2"}),e.jsx("circle",{cx:"18",cy:"6",r:"2"}),e.jsx("circle",{cx:"18",cy:"18",r:"2"}),e.jsx("path",{d:"m8 11 8-4"}),e.jsx("path",{d:"m8 13 8 4"})]});case"graph":return e.jsxs("svg",{...i,children:[e.jsx("circle",{cx:"6",cy:"7",r:"2"}),e.jsx("circle",{cx:"18",cy:"6",r:"2"}),e.jsx("circle",{cx:"12",cy:"18",r:"2"}),e.jsx("path",{d:"m7.8 7.5 8.4-1"}),e.jsx("path",{d:"m7.2 8.7 3.6 7.2"}),e.jsx("path",{d:"m16.8 7.7-3.6 8.4"})]});case"ai":return e.jsxs("svg",{...i,children:[e.jsx("circle",{cx:"12",cy:"12",r:"7"}),e.jsx("path",{d:"M12 5V3"}),e.jsx("path",{d:"M12 21v-2"}),e.jsx("path",{d:"M5 12H3"}),e.jsx("path",{d:"M21 12h-2"}),e.jsx("path",{d:"m7 7-1.5-1.5"}),e.jsx("path",{d:"m18.5 18.5-1.5-1.5"}),e.jsx("path",{d:"m17 7 1.5-1.5"}),e.jsx("path",{d:"m6.5 18.5 1.5-1.5"}),e.jsx("circle",{cx:"12",cy:"12",r:"2"})]});case"lock":return e.jsxs("svg",{...i,children:[e.jsx("rect",{x:"5",y:"10",width:"14",height:"10",rx:"2"}),e.jsx("path",{d:"M8 10V7a4 4 0 0 1 8 0v3"})]});case"certificate":return e.jsxs("svg",{...i,children:[e.jsx("circle",{cx:"12",cy:"10",r:"5"}),e.jsx("path",{d:"m9.5 14 1 7 1.5-2 1.5 2 1-7"}),e.jsx("path",{d:"m12 7 .8 1.5 1.7.3-1.2 1.2.3 1.7-1.6-.8-1.6.8.3-1.7-1.2-1.2 1.7-.3L12 7Z"})]});case"file":return e.jsxs("svg",{...i,children:[e.jsx("path",{d:"M6 3h8l4 4v14H6z"}),e.jsx("path",{d:"M14 3v5h4"}),e.jsx("path",{d:"M9 13h6"}),e.jsx("path",{d:"M9 17h6"})]});case"phone":return e.jsx("svg",{...i,children:e.jsx("path",{d:"M7 4h3l1.5 4-2 1.5a14 14 0 0 0 5 5l1.5-2 4 1.5v3c0 1-1 2-2 2C11 19.5 4.5 13 4.5 6c0-1 1-2 2.5-2Z"})});case"support":return e.jsxs("svg",{...i,children:[e.jsx("path",{d:"M4 13a8 8 0 0 1 16 0"}),e.jsx("path",{d:"M4 13v3a2 2 0 0 0 2 2h2v-5H6"}),e.jsx("path",{d:"M20 13v3a2 2 0 0 1-2 2h-2v-5h2"}),e.jsx("path",{d:"M9 19h6"})]});default:return null}}function o({icon:r,title:a,subtitle:i,green:s=!1}){return e.jsxs("div",{className:"certification",children:[e.jsx("div",{className:`cert-icon ${s?"green":""}`,children:e.jsx(t,{name:r,size:18})}),e.jsxs("div",{children:[e.jsx("strong",{children:a}),e.jsx("span",{children:i})]})]})}function m({number:r,title:a,timeline:i,status:s,statusType:n,description:l,tags:d}){return e.jsxs("article",{className:"stage-card",children:[e.jsxs("div",{className:"stage-top",children:[e.jsx("div",{className:"stage-number",children:r}),e.jsxs("div",{className:"stage-title-box",children:[e.jsx("h3",{children:a}),e.jsxs("div",{className:"timeline",children:["Timeline: ",i]})]}),e.jsxs("div",{className:`stage-status ${n==="green"?"status-green":"status-gray"}`,children:[e.jsx("span",{children:"●"}),s]})]}),e.jsx("p",{className:"stage-description",children:l}),e.jsx("div",{className:"stage-tags",children:d.map(([p,x],g)=>e.jsxs("div",{className:"stage-tag",children:[e.jsx("span",{className:"stage-tag-icon",children:e.jsx(t,{name:x,size:14})}),p]},g))})]})}function c({image:r,name:a,role:i,credential:s,specialty:n}){return e.jsxs("div",{className:"person",children:[e.jsx("img",{loading:"lazy",decoding:"async",src:r,alt:a}),e.jsxs("div",{className:"person-info",children:[e.jsxs("div",{className:"person-name",children:[a,e.jsx("span",{className:"person-role",children:i})]}),e.jsx("div",{className:"person-credential",children:s}),e.jsx("div",{className:"person-specialty",children:n})]})]})}export{j as default};
