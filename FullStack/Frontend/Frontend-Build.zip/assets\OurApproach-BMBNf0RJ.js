import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as t}from"./vendor-router-L4ZCoGSs.js";const l=[{number:"01",title:"Protect",description:"Establish appropriate security controls around systems, applications, users and data."},{number:"02",title:"Detect",description:"Identify suspicious activity and potential security issues before they become larger business problems."},{number:"03",title:"Respond",description:"Create clear processes for dealing with security incidents and limiting their potential impact."},{number:"04",title:"Improve",description:"Use lessons, assessments and changing threat patterns to continuously strengthen your security posture."}];function m(){const s=t.useRef(null),[a,i]=t.useState(!1);return t.useEffect(()=>{const r=s.current;if(!r)return;const n=new IntersectionObserver(([o])=>{o.isIntersecting?i(!0):i(!1)},{threshold:.2});return n.observe(r),()=>{n.disconnect()}},[]),e.jsxs("section",{ref:s,className:`\r
        approach-section\r
        w-full\r
        overflow-hidden\r
        bg-white\r
        px-4 py-10\r
        sm:px-6 sm:py-12\r
        md:px-10 md:py-14\r
        lg:px-[100px] lg:py-16\r
        xl:py-20\r
      `,children:[e.jsxs("div",{className:"w-full text-center",children:[e.jsx("span",{className:"inline-flex items-center rounded-full bg-rose-50 px-3 py-1 text-[9px] font-semibold tracking-[0.15em] text-[#730042] sm:text-[10px]",style:{fontFamily:"'Inter', sans-serif"},children:"OUR APPROACH"}),e.jsx("h1",{className:`\r
            mx-auto\r
            mt-4\r
            w-full\r
            max-w-[340px]\r
            text-[22px]\r
            font-bold\r
            leading-[1.3]\r
            text-slate-900\r
            sm:max-w-xl\r
            sm:text-[25px]\r
            md:max-w-2xl\r
            md:text-[28px]\r
            lg:max-w-3xl\r
            lg:text-[30px]\r
            xl:text-[32px]\r
          `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Protect. Detect. Respond. Improve."}),e.jsx("p",{className:`\r
            mx-auto\r
            mt-4\r
            w-full\r
            max-w-[320px]\r
            text-[13px]\r
            leading-[1.7]\r
            text-slate-500\r
            sm:max-w-lg\r
            sm:text-[14px]\r
            md:max-w-xl\r
            md:text-[15px]\r
            md:leading-[1.8]\r
          `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"We believe cybersecurity should be an ongoing process rather than a one-time implementation."}),e.jsx("div",{className:`\r
            mt-8\r
            grid\r
            grid-cols-1\r
            gap-4\r
            text-left\r
            sm:mt-10\r
            sm:grid-cols-2\r
            sm:gap-5\r
            md:mt-12\r
            md:gap-6\r
            lg:grid-cols-4\r
            lg:gap-5\r
            xl:gap-6\r
          `,children:l.map((r,n)=>e.jsxs("div",{className:`
                approach-card
                group
                relative
                w-full
                min-w-0
                overflow-hidden
                rounded-lg
                bg-slate-50
                p-5
                sm:p-6
                md:p-6
                lg:p-5
                xl:p-6
                ${a?"approach-card-show":"approach-card-hide"}
              `,style:{transitionDelay:a?`${n*180}ms`:"0ms"},children:[e.jsx("span",{className:`\r
                  text-[22px]\r
                  font-bold\r
                  leading-none\r
                  text-slate-300\r
                  sm:text-[24px]\r
                  md:text-[26px]\r
                `,style:{fontFamily:"'Inter', sans-serif"},children:r.number}),e.jsx("h3",{className:`\r
                  mt-3\r
                  text-[15px]\r
                  font-semibold\r
                  leading-[1.4]\r
                  text-[#730042]\r
                  sm:text-[16px]\r
                  md:text-[17px]\r
                `,style:{fontFamily:"'Inter', sans-serif"},children:r.title}),e.jsx("p",{className:`\r
                  mt-2\r
                  text-[13px]\r
                  leading-[1.7]\r
                  text-slate-500\r
                  sm:text-[14px]\r
                  sm:leading-[1.75]\r
                `,style:{fontFamily:"'Inter', sans-serif"},children:r.description}),e.jsx("div",{className:`\r
                  approach-line\r
                  mt-4\r
                  h-0.5\r
                  w-6\r
                  bg-[#730042]\r
                  transition-all\r
                  duration-500\r
                  ease-out\r
                  group-hover:w-full\r
                `})]},r.number))})]}),e.jsx("style",{children:`
        /*
          Initial state:
          Cards hidden + slightly down + small scale
        */
        .approach-card {
          opacity: 0;
          transform: translateY(45px) scale(0.92);
          filter: blur(4px);

          transition:
            opacity 0.7s ease,
            transform 0.7s cubic-bezier(0.22, 1, 0.36, 1),
            filter 0.7s ease,
            box-shadow 0.3s ease;
        }

        /*
          Visible state:
          Cards pop into their original position
        */
        .approach-card-show {
          opacity: 1;
          transform: translateY(0) scale(1);
          filter: blur(0);
        }

        /*
          Hover effect:
          Card moves slightly upward
        */
        .approach-card-show:hover {
          transform: translateY(-6px) scale(1);
          box-shadow: 0 12px 30px rgba(115, 0, 66, 0.08);
        }

        /*
          Bottom line:
          Normal = small line
          Hover = full card width
        */
        .approach-line {
          width: 24px;
        }

        .approach-card:hover .approach-line {
          width: 100%;
        }

        /*
          Mobile touch devices:
          Keep animation but avoid aggressive hover behavior
        */
        @media (hover: none) {
          .approach-card-show:hover {
            transform: translateY(0) scale(1);
            box-shadow: none;
          }
        }

        /*
          Accessibility:
          Users who prefer reduced motion
          won't get the pop-up animation.
        */
        @media (prefers-reduced-motion: reduce) {
          .approach-card {
            opacity: 1;
            transform: none;
            filter: none;
            transition: none !important;
          }

          .approach-line {
            transition: none !important;
          }
        }
      `})]})}export{m as default};
