import{j as i}from"./vendor-query-PraSc8EQ.js";import{d as t,L as n}from"./vendor-router-L4ZCoGSs.js";function r(){const e=t();return i.jsxs("section",{className:"proven-impact-section",children:[i.jsxs("div",{className:"proven-impact-container",children:[i.jsxs("div",{className:"proven-impact-header",children:[i.jsxs("div",{className:"proven-impact-title-wrap",children:[i.jsxs("div",{className:"proven-impact-label",children:[i.jsx("span",{}),i.jsx("p",{children:"PROVEN IMPACT"})]}),i.jsx("h2",{children:"Domain Expertise Applied"}),i.jsxs("p",{className:"proven-impact-subtitle",children:["Precision engineering tailored to the unique regulatory,",i.jsx("br",{className:"desktop-break"}),"scale, and operational demands of distinct industries."]})]}),i.jsx("button",{type:"button",className:"view-industries-btn",onClick:()=>e("/#industries"),children:"View All Industries"})]}),i.jsxs("div",{className:"proven-impact-grid",children:[i.jsxs("div",{className:"impact-card",children:[i.jsxs("div",{className:"impact-image-wrap",children:[i.jsx("img",{loading:"lazy",decoding:"async",src:"/Proven Impact1.webp",alt:"Manufacturing",className:"impact-image"}),i.jsxs("div",{className:"impact-image-label",children:[i.jsx("span",{className:"industry-icon",children:"⚙"}),i.jsx("span",{children:"Manufacturing"})]})]}),i.jsxs("div",{className:"impact-card-content",children:[i.jsx("h3",{children:"IoT-Driven Yield Optimization"}),i.jsx("p",{children:"Implemented real-time edge computing pipelines processing 4M+ telemetry..."}),i.jsxs("div",{className:"impact-tags",children:[i.jsx("span",{children:"Edge Computing"}),i.jsx("span",{children:"Telemetry"})]})]})]}),i.jsxs("div",{className:"impact-card",children:[i.jsxs("div",{className:"impact-image-wrap",children:[i.jsx("img",{loading:"lazy",decoding:"async",src:"/Proven Impact2.webp",alt:"Financial Services",className:"impact-image"}),i.jsxs("div",{className:"impact-image-label",children:[i.jsx("span",{className:"industry-icon",children:"♜"}),i.jsx("span",{children:"Financial Services"})]})]}),i.jsxs("div",{className:"impact-card-content",children:[i.jsxs("h3",{children:["Sub-Millisecond",i.jsx("br",{}),"Reconciliation"]}),i.jsx("p",{children:"Architected a distributed ledger system replacing legacy mainframe batch jobs,"}),i.jsxs("div",{className:"impact-tags",children:[i.jsx("span",{children:"Distributed Ledger"}),i.jsx("span",{children:"Event-Driven"})]})]})]}),i.jsxs("div",{className:"more-industries-card",children:[i.jsxs("div",{className:"more-industries-icon",children:[i.jsx("span",{children:"△"}),i.jsx("span",{children:"○"}),i.jsx("span",{children:"□"})]}),i.jsx("h3",{children:"More Industries"}),i.jsxs("p",{children:["Healthcare, Retail,",i.jsx("br",{}),"Logistics, and Telecom",i.jsx("br",{}),"architectures."]}),i.jsx(n,{to:"/case-studies",children:"Explore Case Studies →"})]})]})]}),i.jsx("style",{children:`

        /* =====================================================
           SECTION
        ===================================================== */

        .proven-impact-section {
          width: 100%;
          background: #730042;
          box-sizing: border-box;
          overflow: hidden;

          /* SAME AS FOOTER */
          padding: 40px 16px;
        }


        /* =====================================================
           FOOTER ALIGNMENT
        ===================================================== */

        @media (min-width: 640px) {
          .proven-impact-section {
            padding: 48px 24px;
          }
        }

        @media (min-width: 768px) {
          .proven-impact-section {
            padding: 56px 40px;
          }
        }

        @media (min-width: 1024px) {
          .proven-impact-section {
            padding: 64px 100px;
          }
        }

        @media (min-width: 1280px) {
          .proven-impact-section {
            padding: 80px 100px;
          }
        }


        /* =====================================================
           CONTAINER
        ===================================================== */

        .proven-impact-container {
          width: 100%;
          margin: 0;
          padding: 0;
        }


        /* =====================================================
           HEADER
        ===================================================== */

        .proven-impact-header {
          width: 100%;

          display: flex;
          align-items: flex-end;
          justify-content: space-between;

          gap: 25px;
          margin-bottom: 20px;
        }

        .proven-impact-title-wrap {
          min-width: 0;
        }


        /* =====================================================
           LABEL
        ===================================================== */

        .proven-impact-label {
          display: flex;
          align-items: center;
          gap: 10px;

          margin-bottom: 8px;
        }

        .proven-impact-label span {
          display: block;

          width: 3px;
          height: 17px;

          background: #ffffff;
        }

        .proven-impact-label p {
          margin: 0;

          color: #ffffff;

          font-size: 12px;
          font-weight: 420;

          letter-spacing: 1.4px;
        }


        /* =====================================================
           HEADING
        ===================================================== */

        .proven-impact-title-wrap h2 {
          margin: 0;

          color: #ffffff;

          font-family: "Plus Jakarta Sans", sans-serif;

          font-size: 34px;
          line-height: 1.05;

          font-weight: 500;

          letter-spacing: -1.4px;

          opacity: 0.9;
        }


        /* =====================================================
           DESCRIPTION
        ===================================================== */

        .proven-impact-subtitle {
          margin: 8px 0 0;

          color: #ffffff;

          font-family: "Inter", sans-serif;

          font-size: 16px;
          line-height: 1.4;

          font-weight: 400;

          opacity: 0.9;
        }


        /* =====================================================
           BUTTON
        ===================================================== */

        .view-industries-btn {
          flex-shrink: 0;

          min-width: 180px;
          height: 44px;

          padding: 0 22px;

          background: transparent;

          border: 1px solid rgba(255, 255, 255, 0.28);

          color: #ffffff;

          font-family: "Inter", sans-serif;

          font-size: 13px;
          font-weight: 500;

          cursor: pointer;

          transition:
            background 0.25s ease,
            border-color 0.25s ease;
        }

        .view-industries-btn:hover {
          background: rgba(255, 255, 255, 0.08);

          border-color: rgba(255, 255, 255, 0.5);
        }


        /* =====================================================
           CARD GRID
           
           EXACT SAME LEFT/RIGHT ALIGNMENT AS FOOTER
           
           Footer:
           mobile  = 16px
           sm       = 24px
           md       = 40px
           lg       = 100px
           
           Grid = 100%
        ===================================================== */

        .proven-impact-grid {
          width: 100%;
          margin: 0;

          display: grid;

          grid-template-columns:
            minmax(0, 1fr)
            minmax(0, 1fr)
            minmax(0, 0.92fr);

          column-gap: 30px;
          row-gap: 40px;
        }


        /* =====================================================
           NORMAL CARD
        ===================================================== */

        .impact-card {
          min-width: 0;

          overflow: hidden;

          border: 1px solid rgba(255, 255, 255, 0.18);

          border-radius: 8px;

          background: #951554;

          box-sizing: border-box;
        }


        /* =====================================================
           IMAGE
        ===================================================== */

        .impact-image-wrap {
          position: relative;

          width: 100%;
          height: 200px;

          overflow: hidden;
        }

        .impact-image {
          display: block;

          width: 100%;
          height: 100%;

          object-fit: cover;
          object-position: center;

          margin: 0;
          padding: 0;

          border: 0;
        }

        .impact-image-wrap::after {
          content: "";

          position: absolute;

          inset: 0;

          background: linear-gradient(
            to bottom,
            transparent 45%,
            rgba(0, 0, 0, 0.52) 100%
          );

          pointer-events: none;
        }


        /* =====================================================
           IMAGE LABEL
        ===================================================== */

        .impact-image-label {
          position: absolute;

          left: 16px;
          bottom: 13px;

          z-index: 2;

          display: flex;
          align-items: center;

          gap: 8px;

          color: #ffffff;

          font-family: "Inter", sans-serif;

          font-size: 13px;
          font-weight: 500;
        }

        .industry-icon {
          color: #ffffff;

          font-size: 17px;
          line-height: 1;
        }


        /* =====================================================
           CARD CONTENT
        ===================================================== */

        .impact-card-content {
          min-height: 200px;

          padding: 15px 16px 13px;

          box-sizing: border-box;
        }

        .impact-card-content h3 {
          margin: 0;

          color: #ffffff;

          font-family: "Plus Jakarta Sans", sans-serif;

          font-size: 20px;
          line-height: 1.23;

          font-weight: 500;

          letter-spacing: -0.3px;

          opacity: 0.9;
        }

        .impact-card-content p {
          margin: 8px 0 0;

          color: #ffffff;

          font-family: "Inter", sans-serif;

          font-size: 16px;
          line-height: 1.42;

          font-weight: 400;

          opacity: 0.9;
        }


        /* =====================================================
           TAGS
        ===================================================== */

        .impact-tags {
          display: flex;
          flex-wrap: wrap;

          gap: 6px;

          margin-top: 12px;
        }

        .impact-tags span {
          padding: 5px 8px;

          background: rgba(255, 255, 255, 0.12);

          color: #ffffff;

          font-family: "Inter", sans-serif;

          font-size: 10px;
          line-height: 1;

          border-radius: 2px;
        }


        /* =====================================================
           MORE INDUSTRIES
        ===================================================== */

        .more-industries-card {
          min-height: 400px;

          display: flex;
          flex-direction: column;

          align-items: center;
          justify-content: center;

          text-align: center;

          padding: 24px 18px;

          border: 1px solid rgba(255, 255, 255, 0.18);

          border-radius: 8px;

          background: linear-gradient(
            to bottom right,
            #70154f 0%,
            #4a123d 50%,
            #241126 100%
          );

          box-sizing: border-box;
        }

        .more-industries-icon {
          position: relative;

          width: 56px;
          height: 56px;

          display: flex;
          align-items: center;
          justify-content: center;

          margin-bottom: 14px;

          border-radius: 10px;

          background: rgba(255, 255, 255, 0.08);

          border: 1px solid rgba(255, 255, 255, 0.12);

          color: #ffffff;
        }

        .more-industries-icon span:nth-child(1) {
          position: absolute;

          top: 10px;
          left: 21px;

          font-size: 14px;
        }

        .more-industries-icon span:nth-child(2) {
          position: absolute;

          bottom: 10px;
          left: 13px;

          font-size: 11px;
        }

        .more-industries-icon span:nth-child(3) {
          position: absolute;

          bottom: 10px;
          right: 12px;

          font-size: 11px;
        }

        .more-industries-card h3 {
          margin: 0;

          color: #ffffff;

          font-family: "Plus Jakarta Sans", sans-serif;

          font-size: 24px;
          line-height: 1.2;

          font-weight: 500;
        }

        .more-industries-card p {
          margin: 9px 0 0;

          color: #ffffff;

          font-family: "Inter", sans-serif;

          font-size: 17px;
          line-height: 1.5;

          font-weight: 400;
        }

        .more-industries-card a {
          margin-top: 17px;

          color: #ffffff;

          font-family: "Inter", sans-serif;

          text-decoration: none;

          font-size: 13px;
          font-weight: 500;
        }

        .more-industries-card a:hover {
          text-decoration: underline;
        }


        /* =====================================================
           1100px
        ===================================================== */

        @media (max-width: 1100px) {

          .proven-impact-grid {
            width: 100%;
            margin: 0;

            grid-template-columns:
              minmax(0, 1fr)
              minmax(0, 1fr)
              minmax(0, 0.92fr);

            column-gap: 24px;
            row-gap: 30px;
          }

          .proven-impact-title-wrap h2 {
            font-size: 39px;
          }

          .proven-impact-subtitle {
            font-size: 16px;
          }

          .impact-image-wrap {
            height: 190px;
          }

          .impact-card-content {
            min-height: 190px;
          }

          .impact-card-content h3 {
            font-size: 20px;
          }

          .impact-card-content p {
            font-size: 15px;
          }

          .more-industries-card {
            min-height: 380px;
          }
        }


        /* =====================================================
           TABLET
        ===================================================== */

        @media (max-width: 950px) and (min-width: 701px) {

          .proven-impact-header {
            flex-direction: row;

            align-items: flex-end;
            justify-content: space-between;

            gap: 18px;
          }

          .view-industries-btn {
            align-self: flex-end;

            margin-left: auto;
          }

          .proven-impact-grid {
            width: 100%;
            margin: 0;

            grid-template-columns:
              minmax(0, 1fr)
              minmax(0, 1fr)
              minmax(0, 1fr);

            column-gap: 18px;
            row-gap: 0;
          }

          .impact-image-wrap {
            height: 175px;
          }

          .impact-card-content {
            min-height: 190px;

            padding: 14px;
          }

          .impact-card-content h3 {
            font-size: 18px;

            line-height: 1.2;
          }

          .impact-card-content p {
            font-size: 14px;

            line-height: 1.4;
          }

          .impact-tags {
            gap: 5px;

            margin-top: 10px;
          }

          .impact-tags span {
            font-size: 9px;

            padding: 5px 6px;
          }

          .impact-image-label {
            left: 12px;
            bottom: 11px;

            font-size: 11px;
          }

          .industry-icon {
            font-size: 15px;
          }

          .more-industries-card {
            min-height: 365px;

            padding: 20px 12px;
          }

          .more-industries-card h3 {
            font-size: 20px;
          }

          .more-industries-card p {
            font-size: 14px;

            line-height: 1.45;
          }

          .more-industries-card a {
            font-size: 12px;

            margin-top: 14px;
          }

          .more-industries-icon {
            width: 50px;
            height: 50px;

            margin-bottom: 12px;
          }
        }


        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 700px) {

          .proven-impact-header {
            flex-direction: column;

            align-items: stretch;
            justify-content: flex-start;

            gap: 18px;
          }

          .proven-impact-title-wrap {
            width: 100%;
          }

          .proven-impact-title-wrap h2 {
            font-size: 34px;

            overflow-wrap: break-word;
          }

          .proven-impact-subtitle {
            font-size: 15px;

            line-height: 1.45;

            max-width: 100%;
          }

          .desktop-break {
            display: none;
          }

          .view-industries-btn {
            width: 100%;

            min-width: 0;
          }

          .proven-impact-grid {
            width: 100%;
            margin: 0;

            grid-template-columns: 1fr;

            column-gap: 0;
            row-gap: 20px;
          }

          .impact-image-wrap {
            width: 100%;

            height: auto;

            aspect-ratio: 16 / 10;
          }

          .impact-image {
            width: 100%;
            height: 100%;

            object-fit: cover;
          }

          .impact-card-content {
            min-height: auto;

            padding: 16px;
          }

          .impact-card-content h3 {
            font-size: 22px;
          }

          .impact-card-content p {
            font-size: 15px;
          }

          .more-industries-card {
            min-height: 270px;
          }
        }


        /* =====================================================
           SMALL MOBILE
        ===================================================== */

        @media (max-width: 480px) {

          .proven-impact-title-wrap h2 {
            font-size: 30px;

            letter-spacing: -0.8px;
          }

          .proven-impact-subtitle {
            font-size: 14px;
          }

          .proven-impact-label p {
            font-size: 10px;

            letter-spacing: 1.1px;
          }

          .impact-image-wrap {
            width: 100%;

            height: auto;

            aspect-ratio: 16 / 10;
          }

          .impact-image {
            width: 100%;
            height: 100%;

            object-fit: cover;
          }

          .impact-image-label {
            left: 12px;
            bottom: 10px;

            font-size: 11px;
          }

          .industry-icon {
            font-size: 15px;
          }

          .impact-card-content {
            padding: 14px;
          }

          .impact-card-content h3 {
            font-size: 20px;
          }

          .impact-card-content p {
            font-size: 14px;
          }

          .impact-tags span {
            font-size: 10px;
          }

          .more-industries-card {
            min-height: 250px;

            padding: 20px 15px;
          }

          .more-industries-card h3 {
            font-size: 22px;
          }

          .more-industries-card p {
            font-size: 15px;
          }

          .more-industries-icon {
            width: 52px;
            height: 52px;
          }
        }


        /* =====================================================
           VERY SMALL MOBILE
        ===================================================== */

        @media (max-width: 360px) {

          .proven-impact-header {
            gap: 16px;
          }

          .proven-impact-title-wrap h2 {
            font-size: 27px;

            line-height: 1.08;
          }

          .proven-impact-subtitle {
            font-size: 13px;

            line-height: 1.45;
          }

          .impact-image-wrap {
            width: 100%;

            height: auto;

            aspect-ratio: 16 / 10;
          }

          .impact-image {
            width: 100%;
            height: 100%;

            object-fit: cover;
          }

          .impact-image-label {
            left: 12px;
            bottom: 10px;

            font-size: 11px;
          }

          .industry-icon {
            font-size: 15px;
          }

          .impact-card-content {
            padding: 14px;
          }

          .impact-card-content h3 {
            font-size: 18px;

            line-height: 1.2;
          }

          .impact-card-content p {
            font-size: 13px;

            line-height: 1.4;
          }
        }

      `})]})}export{r as default};
