import{j as a}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";function i(){return a.jsxs("div",{className:"data-orchestration-page",children:[a.jsxs("section",{className:"data-orchestration-hero",children:[a.jsx("img",{loading:"lazy",decoding:"async",src:"/DataOrchestration.webp",alt:"Advanced Data Orchestration",className:"data-orchestration-hero-image"}),a.jsx("div",{className:"data-orchestration-hero-overlay"}),a.jsxs("div",{className:"data-orchestration-hero-content",children:[a.jsxs("div",{className:"data-orchestration-eyebrow",children:[a.jsx("span",{}),"CORE CAPABILITY"]}),a.jsxs("h1",{children:["Advanced Data",a.jsx("br",{}),"Orchestration:",a.jsx("br",{}),a.jsxs("strong",{children:["Turning Information into",a.jsx("br",{}),"Intelligence"]})]})]})]}),a.jsxs("section",{className:"data-single-source",children:[a.jsxs("div",{className:"data-single-title",children:[a.jsx("div",{className:"data-title-line"}),a.jsxs("h2",{children:["The Single",a.jsx("br",{}),"Source",a.jsx("br",{}),"of Truth"]})]}),a.jsx("div",{className:"data-single-text",children:a.jsx("p",{children:"At TechTorch, we believe data should not merely exist; it must flow, connect, and illuminate. Our advanced data orchestration engine dismantles legacy silos, weaving disparate data streams into a unified, crystalline architecture. This rigorous approach to data governance ensures that every piece of information across your enterprise is accurate, synchronized, and actionable in real-time."})})]}),a.jsxs("section",{className:"data-capability-cards",children:[a.jsxs("div",{className:"data-capability-card",children:[a.jsx("div",{className:"data-card-icon",children:a.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.7",children:[a.jsx("rect",{x:"4",y:"4",width:"6",height:"6"}),a.jsx("rect",{x:"14",y:"14",width:"6",height:"6"}),a.jsx("path",{d:"M10 7h4a2 2 0 0 1 2 2v5"}),a.jsx("path",{d:"M14 17h-4a2 2 0 0 1-2-2v-5"})]})}),a.jsxs("h3",{children:["Crystalline",a.jsx("br",{}),"Architecture"]}),a.jsx("p",{children:"Our proprietary pillar concept treats data entities as faceted nodes within a rigid, yet highly elastic network. This ensures absolute structural integrity while permitting fluid querying across immense datasets."})]}),a.jsxs("div",{className:"data-capability-card",children:[a.jsx("div",{className:"data-card-icon",children:a.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.7",children:[a.jsx("path",{d:"M5 15a7 7 0 1 1 14 0"}),a.jsx("path",{d:"M12 12l4-4"}),a.jsx("path",{d:"M5 15h3"}),a.jsx("path",{d:"M16 15h3"})]})}),a.jsxs("h3",{children:["Real-Time",a.jsx("br",{}),"Processing"]}),a.jsx("p",{children:"Latency is the enemy of intelligence. TechTorch employs event-driven streaming architectures to ingest, transform, and route millions of records per second, powering split-second decision-making."})]}),a.jsxs("div",{className:"data-capability-card",children:[a.jsx("div",{className:"data-card-icon",children:a.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.7",children:[a.jsx("path",{d:"M12 3l7 3v5c0 4.5-2.8 8-7 10-4.2-2-7-5.5-7-10V6l7-3z"}),a.jsx("path",{d:"M9.5 12a2.5 2.5 0 1 0 5 0"}),a.jsx("path",{d:"M12 9.5v5"})]})}),a.jsx("h3",{children:"Strict Governance"}),a.jsx("p",{children:"Security and compliance are built into the bedrock of our platform. Automated lineage tracking, role-based access control, and continuous auditing ensure your data remains pristine and protected."})]})]}),a.jsxs("section",{className:"data-flow-section",children:[a.jsxs("div",{className:"data-flow-content",children:[a.jsx("h2",{children:"Visualizing the Flow"}),a.jsx("p",{children:"We don't just move data; we orchestrate it. Watch as raw inputs are cleansed, validated, and aligned into the crystalline pillar structure, ready for enterprise consumption."}),a.jsxs("div",{className:"data-metric",children:[a.jsxs("div",{className:"data-metric-left",children:[a.jsx("span",{className:"data-metric-icon",children:a.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[a.jsx("path",{d:"M7 5v14"}),a.jsx("path",{d:"M17 5v14"}),a.jsx("path",{d:"M7 5l4 4"}),a.jsx("path",{d:"M7 19l4-4"}),a.jsx("path",{d:"M17 5l-4 4"}),a.jsx("path",{d:"M17 19l-4-4"})]})}),a.jsx("span",{children:"Ingestion Rate"})]}),a.jsx("strong",{children:"4.2M / sec"})]}),a.jsxs("div",{className:"data-metric",children:[a.jsxs("div",{className:"data-metric-left",children:[a.jsx("span",{className:"data-metric-icon",children:a.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.8",children:[a.jsx("circle",{cx:"12",cy:"12",r:"8"}),a.jsx("path",{d:"m9 12 2 2 4-4"})]})}),a.jsx("span",{children:"Data Purity"})]}),a.jsx("strong",{children:"99.99%"})]})]}),a.jsx("div",{className:"data-flow-image-box",children:a.jsx("img",{loading:"lazy",decoding:"async",src:"/DataOrchestration1.webp",alt:"Enterprise Data Flow",className:"data-flow-image"})})]}),a.jsx("style",{children:`

        * {
          box-sizing: border-box;
        }


        .data-orchestration-page {
          width: 100%;
          min-height: 100vh;
          background: #f7f8fa;
          color: #171717;
          font-family: "Inter", sans-serif;
          padding: 0 28px 60px;
        }


        /* ================= HERO ================= */

        .data-orchestration-hero {
          position: relative;
          width: 100%;
          max-width: 1100px;
          height: 500px;
          margin: 0 auto;
          overflow: hidden;
          border-radius: 0 0 7px 7px;
        }


        .data-orchestration-hero-image {
          position: absolute;
          inset: 0;
          width: 100%;
          height: 100%;
          object-fit: cover;
          object-position: center;
        }


        .data-orchestration-hero-overlay {
          position: absolute;
          inset: 0;
          background:
            linear-gradient(
              90deg,
              rgba(30, 12, 25, 0.85) 0%,
              rgba(30, 12, 25, 0.62) 50%,
              rgba(20, 20, 22, 0.68) 100%
            );
        }


        .data-orchestration-hero-content {
          position: relative;
          z-index: 2;
          height: 100%;
          padding: 80px 48px;
          display: flex;
          flex-direction: column;
          justify-content: center;
        }


        .data-orchestration-eyebrow {
          display: flex;
          align-items: center;
          gap: 12px;
          color: #f0dce7;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 1.3px;
        }


        .data-orchestration-eyebrow span {
          display: block;
          width: 25px;
          height: 2px;
          background: #f0dce7;
        }


        .data-orchestration-hero h1 {
          margin: 28px 0 0;
          color: #ffffff;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: clamp(44px, 5.2vw, 72px);
          line-height: 1.05;
          letter-spacing: -2.5px;
          font-weight: 800;
        }


        .data-orchestration-hero h1 strong {
          color: #f39abd;
          font-weight: 800;
        }


        /* ================= SINGLE SOURCE ================= */

        .data-single-source {
          width: 100%;
          max-width: 850px;
          margin: 42px auto 75px;
          display: grid;
          grid-template-columns: 190px 1fr;
          gap: 25px;
        }


        .data-single-title {
          display: flex;
          align-items: flex-start;
          gap: 10px;
        }


        .data-title-line {
          width: 4px;
          min-height: 85px;
          background: #8a0050;
          border-radius: 2px;
        }


        .data-single-title h2 {
          margin: 0;
          color: #760044;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 25px;
          line-height: 1.15;
          font-weight: 750;
          letter-spacing: -0.7px;
        }


        .data-single-text p {
          margin: 0;
          color: #786a70;
          font-size: 18px;
          line-height: 1.5;
        }


        /* ================= CARDS ================= */

        .data-capability-cards {
          width: 100%;
          max-width: 850px;
          margin: 0 auto 60px;
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 20px;
        }


        .data-capability-card {
          min-height: 340px;
          padding: 28px 25px;
          background: #ffffff;
          border: 1px solid #e4e8ec;
          border-radius: 7px;
          box-shadow: 0 4px 18px rgba(20, 15, 20, 0.025);
        }


        .data-card-icon {
          width: 40px;
          height: 40px;
          margin-bottom: 22px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #fbf0f6;
          border-radius: 3px;
          color: #87004c;
        }


        .data-card-icon svg {
          width: 21px;
          height: 21px;
        }


        .data-capability-card h3 {
          margin: 0 0 17px;
          color: #202020;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 18px;
          line-height: 1.2;
          font-weight: 750;
          letter-spacing: -0.4px;
        }


        .data-capability-card p {
          margin: 0;
          color: #76696e;
          font-size: 13px;
          line-height: 1.52;
        }


        /* ================= FLOW ================= */

        .data-flow-section {
          width: 100%;
          max-width: 850px;
          min-height: 385px;
          margin: 0 auto;
          padding: 38px 30px;
          display: grid;
          grid-template-columns: 1fr 300px;
          gap: 28px;
          align-items: center;
          background: #eef0f2;
          border-radius: 14px;
          border: 1px solid #e5e7e9;
        }


        .data-flow-content {
          min-width: 0;
        }


        .data-flow-content h2 {
          margin: 0 0 16px;
          color: #202020;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 26px;
          line-height: 1.2;
          font-weight: 750;
          letter-spacing: -0.8px;
        }


        .data-flow-content p {
          max-width: 390px;
          margin: 0 0 27px;
          color: #76696e;
          font-size: 15px;
          line-height: 1.5;
        }


        .data-metric {
          min-height: 55px;
          border-bottom: 1px solid #dce0e3;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 15px;
        }


        .data-metric-left {
          display: flex;
          align-items: center;
          gap: 10px;
          color: #343034;
          font-size: 11px;
          font-weight: 700;
        }


        .data-metric-icon {
          width: 18px;
          height: 18px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #8b0050;
        }


        .data-metric-icon svg {
          width: 17px;
          height: 17px;
        }


        .data-metric strong {
          color: #252225;
          font-size: 14px;
          white-space: nowrap;
        }


        .data-flow-image-box {
          width: 100%;
          height: 300px;
          overflow: hidden;
          border-radius: 5px;
          background: #ffffff;
          border: 1px solid #e4e7e9;
        }


        .data-flow-image {
          width: 100%;
          height: 100%;
          display: block;
          object-fit: cover;
          object-position: center;
        }


        /* ================= TABLET ================= */

        @media (max-width: 900px) {

          .data-orchestration-page {
            padding-left: 20px;
            padding-right: 20px;
          }


          .data-orchestration-hero {
            height: 450px;
          }


          .data-orchestration-hero-content {
            padding: 70px 40px;
          }


          .data-orchestration-hero h1 {
            font-size: clamp(39px, 6vw, 58px);
          }


          .data-single-source {
            max-width: 800px;
          }


          .data-capability-cards {
            max-width: 800px;
          }


          .data-flow-section {
            max-width: 800px;
            grid-template-columns: 1fr 270px;
          }


          .data-flow-image-box {
            height: 270px;
          }

        }


        /* ================= MOBILE ================= */

        @media (max-width: 650px) {

          .data-orchestration-page {
            padding: 0 14px 40px;
          }


          .data-orchestration-hero {
            height: 500px;
          }


          .data-orchestration-hero-content {
            padding: 55px 25px;
          }


          .data-orchestration-eyebrow {
            font-size: 9px;
          }


          .data-orchestration-eyebrow span {
            width: 20px;
          }


          .data-orchestration-hero h1 {
            margin-top: 23px;
            font-size: clamp(34px, 9vw, 48px);
            line-height: 1.07;
            letter-spacing: -1.5px;
          }


          .data-single-source {
            display: flex;
            flex-direction: column;
            gap: 20px;
            margin: 35px auto 55px;
          }


          .data-single-title h2 {
            font-size: 24px;
          }


          .data-title-line {
            min-height: 82px;
          }


          .data-single-text p {
            font-size: 15px;
            line-height: 1.55;
          }


          .data-capability-cards {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-bottom: 35px;
          }


          .data-capability-card {
            min-height: auto;
            padding: 25px 22px;
          }


          .data-card-icon {
            margin-bottom: 18px;
          }


          .data-capability-card h3 {
            font-size: 19px;
          }


          .data-capability-card p {
            font-size: 13px;
          }


          .data-flow-section {
            display: flex;
            flex-direction: column;
            align-items: stretch;
            gap: 25px;
            padding: 28px 22px;
            min-height: auto;
          }


          .data-flow-content h2 {
            font-size: 25px;
          }


          .data-flow-content p {
            font-size: 14px;
          }


          .data-flow-image-box {
            width: 100%;
            height: 290px;
          }

        }


        /* ================= SMALL MOBILE ================= */

        @media (max-width: 420px) {

          .data-orchestration-page {
            padding-left: 10px;
            padding-right: 10px;
          }


          .data-orchestration-hero {
            height: 450px;
          }


          .data-orchestration-hero-content {
            padding-left: 20px;
            padding-right: 20px;
          }


          .data-orchestration-hero h1 {
            font-size: 31px;
            letter-spacing: -1px;
          }


          .data-single-title h2 {
            font-size: 22px;
          }


          .data-single-text p {
            font-size: 14px;
          }


          .data-capability-card {
            padding: 22px 19px;
          }


          .data-flow-section {
            padding: 25px 18px;
          }


          .data-flow-image-box {
            height: 250px;
          }

        }

      `})]})}export{i as default};
