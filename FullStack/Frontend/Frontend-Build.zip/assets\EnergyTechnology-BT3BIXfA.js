import{j as e}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";import{y as c,r as o}from"./index-BThRNyH6.js";import{E as p}from"./eye-BWH2ZhD-.js";import{A as l}from"./arrow-left-right-USaLLYUb.js";const i="#7A1F3D",n="#1B1B2A",t="#5b5a63",h=[{icon:p,title:"Operational Visibility",body:"Real-time visibility across energy operations, telemetry data, and critical assets."},{icon:l,title:"Process Synchronization",body:"Unified workflows linking ERP, finance, supply chain, and field workforce management."},{icon:o,title:"Resilient Architecture",body:"Robust cloud infrastructure, cyber defense, and tailored enterprise software support."}];function f(){return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:`

        /* =================================================
           SECTION
        ================================================= */

        .energy-tech-section,
        .energy-tech-section * {
          box-sizing: border-box;
        }

        .energy-tech-section {
          width: 100%;
          background: #f7f5f2;
          color: ${n};
          font-family: "Inter", Arial, sans-serif;
          overflow: hidden;
        }

        /* =================================================
           CONTAINER
           Desktop  : 100px
           Tablet   : 40px
           Mobile   : 24px
           Small    : 16px
        ================================================= */

        .energy-tech-container {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;

          padding: 78px 100px;

          display: grid;
          grid-template-columns:
            minmax(0, 1.1fr)
            minmax(320px, 0.9fr);

          gap: 70px;
          align-items: center;
        }

        /* =================================================
           LEFT CONTENT
        ================================================= */

        .energy-tech-content {
          min-width: 0;
        }

        .energy-tech-eyebrow {
          margin: 0 0 13px;

          color: ${i};

          font-family: "Inter", Arial, sans-serif;
          font-size: 12px;
          font-weight: 700;
          line-height: 1.4;
          letter-spacing: 0.12em;
          text-transform: uppercase;
        }

        .energy-tech-heading {
          max-width: 800px;

          margin: 0 0 27px;

          color: ${n};

          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 40px;
          line-height: 1.2;
          font-weight: 700;
          letter-spacing: -0.035em;
        }

        .energy-tech-copy {
          max-width: 900px;

          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .energy-tech-description {
          margin: 0;

          color: ${t};

          font-family: "Inter", Arial, sans-serif;
          font-size: 14px;
          line-height: 1.8;
          font-weight: 400;
        }

        /* =================================================
           RIGHT PANEL
        ================================================= */

        .energy-tech-panel {
          width: 100%;

          padding: 30px;

          background: #ffffff;

          border-radius: 20px;

          box-shadow:
            0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .energy-tech-panel-header {
          display: flex;
          align-items: center;
          gap: 13px;

          margin-bottom: 28px;
        }

        .energy-tech-panel-icon {
          width: 42px;
          height: 42px;
          min-width: 42px;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 10px;

          background: #fbeef1;
          color: ${i};
        }

        .energy-tech-panel-title {
          margin: 0 0 4px;

          color: ${n};

          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 16px;
          line-height: 1.35;
          font-weight: 700;
        }

        .energy-tech-panel-subtitle {
          margin: 0;

          color: ${t};

          font-family: "Inter", Arial, sans-serif;
          font-size: 11px;
          line-height: 1.5;
        }

        /* =================================================
           PILLARS
        ================================================= */

        .energy-tech-pillars {
          display: flex;
          flex-direction: column;
          gap: 23px;
        }

        .energy-tech-pillar {
          display: flex;
          align-items: flex-start;
          gap: 13px;
        }

        .energy-tech-pillar-icon {
          flex-shrink: 0;

          margin-top: 3px;

          color: ${i};
        }

        .energy-tech-pillar-title {
          margin: 0 0 5px;

          color: ${n};

          font-family: "Plus Jakarta Sans", Arial, sans-serif;
          font-size: 14px;
          line-height: 1.4;
          font-weight: 700;
        }

        .energy-tech-pillar-body {
          margin: 0;

          color: ${t};

          font-family: "Inter", Arial, sans-serif;
          font-size: 12px;
          line-height: 1.65;
        }

        /* =================================================
           LARGE LAPTOP
        ================================================= */

        @media (max-width: 1200px) {
          .energy-tech-container {
            padding-left: 60px;
            padding-right: 60px;

            gap: 50px;
          }

          .energy-tech-heading {
            font-size: 38px;
          }

          .energy-tech-panel {
            padding: 28px;
          }
        }

        /* =================================================
           TABLET
           Exact spacing: 40px
        ================================================= */

        @media (max-width: 1000px) {
          .energy-tech-container {
            padding: 62px 40px;

            grid-template-columns:
              minmax(0, 1fr)
              minmax(280px, 0.85fr);

            gap: 38px;
          }

          .energy-tech-heading {
            font-size: 35px;
          }

          .energy-tech-description {
            font-size: 13.5px;
            line-height: 1.75;
          }

          .energy-tech-panel {
            padding: 25px;
          }
        }

        /* =================================================
           STACKED TABLET
        ================================================= */

        @media (max-width: 850px) {
          .energy-tech-container {
            padding: 55px 40px;

            grid-template-columns: 1fr;
            gap: 36px;
          }

          .energy-tech-heading {
            max-width: 750px;
            font-size: 34px;
          }

          .energy-tech-copy {
            max-width: 900px;
          }

          .energy-tech-panel {
            width: 100%;
            max-width: 900px;
          }
        }

        /* =================================================
           MOBILE
           Exact spacing: 24px
        ================================================= */

        @media (max-width: 600px) {
          .energy-tech-container {
            padding: 48px 24px;
            gap: 28px;
          }

          .energy-tech-eyebrow {
            margin-bottom: 10px;
            font-size: 10px;
          }

          .energy-tech-heading {
            margin-bottom: 21px;

            font-size: 28px;
            line-height: 1.25;
            letter-spacing: -0.025em;
          }

          .energy-tech-copy {
            gap: 14px;
          }

          .energy-tech-description {
            font-size: 13px;
            line-height: 1.7;
          }

          .energy-tech-panel {
            padding: 22px 20px;
            border-radius: 15px;
          }

          .energy-tech-panel-header {
            margin-bottom: 23px;
          }

          .energy-tech-panel-icon {
            width: 39px;
            height: 39px;
            min-width: 39px;
          }

          .energy-tech-panel-title {
            font-size: 15px;
          }

          .energy-tech-pillars {
            gap: 21px;
          }

          .energy-tech-pillar-title {
            font-size: 13px;
          }

          .energy-tech-pillar-body {
            font-size: 11.5px;
            line-height: 1.65;
          }
        }

        /* =================================================
           SMALL MOBILE
           Exact spacing: 16px
        ================================================= */

        @media (max-width: 480px) {
          .energy-tech-container {
            padding: 42px 16px;
          }

          .energy-tech-heading {
            font-size: 25px;
            line-height: 1.27;
          }

          .energy-tech-description {
            font-size: 12px;
            line-height: 1.65;
          }

          .energy-tech-panel {
            padding: 20px 17px;
          }

          .energy-tech-panel-icon {
            width: 37px;
            height: 37px;
            min-width: 37px;
          }

          .energy-tech-panel-title {
            font-size: 14px;
          }

          .energy-tech-panel-subtitle {
            font-size: 10px;
          }

          .energy-tech-pillar {
            gap: 11px;
          }

          .energy-tech-pillar-title {
            font-size: 12.5px;
          }

          .energy-tech-pillar-body {
            font-size: 11px;
          }
        }

        /* =================================================
           VERY SMALL DEVICES
        ================================================= */

        @media (max-width: 340px) {
          .energy-tech-container {
            padding: 36px 16px;
          }

          .energy-tech-heading {
            font-size: 23px;
          }

          .energy-tech-description {
            font-size: 11.5px;
          }

          .energy-tech-panel {
            padding: 18px 15px;
          }

          .energy-tech-panel-title {
            font-size: 13px;
          }

          .energy-tech-pillar-body {
            font-size: 10.5px;
          }
        }

        /* =================================================
           DESKTOP BREAK
        ================================================= */

        .desktop-break {
          display: block;
        }

        @media (max-width: 850px) {
          .desktop-break {
            display: none;
          }
        }

        /* =================================================
           REDUCED MOTION
        ================================================= */

        @media (prefers-reduced-motion: reduce) {
          .energy-tech-section {
            scroll-behavior: auto;
          }
        }
      `}),e.jsx("section",{className:"energy-tech-section",children:e.jsxs("div",{className:"energy-tech-container",children:[e.jsxs("div",{className:"energy-tech-content",children:[e.jsx("p",{className:"energy-tech-eyebrow",children:"ENERGY TECHNOLOGY"}),e.jsxs("h2",{className:"energy-tech-heading",children:["Connecting Technology With Business",e.jsx("br",{className:"desktop-break"}),"Operations"]}),e.jsxs("div",{className:"energy-tech-copy",children:[e.jsx("p",{className:"energy-tech-description",children:"Modern energy businesses work across multiple departments, applications and business processes. A connected technology environment can help organizations manage these areas more effectively and maintain better visibility across their business."}),e.jsx("p",{className:"energy-tech-description",children:"TechTorch Solutions brings together digital solutions including ERP, Operations Management, Supply Chain Management, People Resources, Web Portals, Financial Management, Payment Management, CRM, E-Commerce and Project Management. Its technology services include IT Consultancy, Artificial Intelligence, Cloud Infrastructure, Cyber Security, Software Engineering, Software Development & Support, BPO and Resource & Staffing."}),e.jsx("p",{className:"energy-tech-description",children:"The focus is on understanding the organization's requirements and providing technology that fits its existing environment. This can include developing software, connecting systems, improving business processes or supporting the technology infrastructure required for day-to-day operations."})]})]}),e.jsxs("div",{className:"energy-tech-panel",children:[e.jsxs("div",{className:"energy-tech-panel-header",children:[e.jsx("span",{className:"energy-tech-panel-icon",children:e.jsx(c,{size:18,strokeWidth:1.8})}),e.jsxs("div",{children:[e.jsx("h3",{className:"energy-tech-panel-title",children:"Core Focus Pillars"}),e.jsx("p",{className:"energy-tech-panel-subtitle",children:"Technology Integration Principles"})]})]}),e.jsx("div",{className:"energy-tech-pillars",children:h.map(({icon:a,title:r,body:s})=>e.jsxs("div",{className:"energy-tech-pillar",children:[e.jsx(a,{size:17,strokeWidth:1.8,className:"energy-tech-pillar-icon"}),e.jsxs("div",{children:[e.jsx("h4",{className:"energy-tech-pillar-title",children:r}),e.jsx("p",{className:"energy-tech-pillar-body",children:s})]})]},r))})]})]})})]})}export{f as default};
