import{j as t}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";function o(){return t.jsxs("section",{className:"integrated-automation",children:[t.jsxs("div",{className:"automation-container",children:[t.jsxs("div",{className:"automation-badge",children:[t.jsx("span",{className:"automation-badge-dot"}),"INTEGRATED AUTOMATION"]}),t.jsxs("h2",{className:"automation-heading",children:["Better Decisions Start With Better",t.jsx("br",{}),"Processes"]}),t.jsxs("p",{className:"automation-subheading",children:["Good decisions depend on good information. And good information depends on",t.jsx("br",{className:"desktop-break"}),"good processes."]}),t.jsxs("div",{className:"automation-cards",children:[t.jsxs("div",{className:"automation-card manual-card",children:[t.jsxs("div",{className:"automation-card-title",children:[t.jsx("span",{className:"card-title-dot manual-dot"}),t.jsx("h3",{children:"THE COST OF MANUAL FRICTION"})]}),t.jsx("p",{className:"automation-card-description",children:"When business information is created through disconnected or highly manual workflows, organizations face unavoidable delays, inconsistencies, repetitive reconciliation, and unnecessary administrative burden."}),t.jsxs("div",{className:"automation-points",children:[t.jsx("div",{children:"• Stale spreadsheets hindering real-time decisions"}),t.jsx("div",{children:"• Human transcription errors across siloed databases"}),t.jsx("div",{children:"• High operational drag on high-value employees"})]})]}),t.jsxs("div",{className:"automation-card intelligent-card",children:[t.jsxs("div",{className:"automation-card-title",children:[t.jsx("span",{className:"card-title-dot intelligent-dot"}),t.jsx("h3",{children:"INTELLIGENT PROCESS AUTOMATION"})]}),t.jsx("p",{className:"automation-card-description",children:"Automation reduces repetitive tasks, improves consistency, and frees operational teams to focus on strategic work that requires judgment, creativity, and human problem-solving."}),t.jsxs("div",{className:"automation-points",children:[t.jsx("div",{children:"• Unified cross-functional workflows with guaranteed integrity"}),t.jsx("div",{children:"• Instant notification and routing of mission-critical tasks"}),t.jsx("div",{children:"• Embedded AI, cloud infrastructure, and modern software support"})]})]})]}),t.jsxs("div",{className:"automation-bottom",children:[t.jsx("div",{className:"automation-bottom-main",children:"Less manual effort. Better visibility. More reliable information. Faster decisions."}),t.jsx("div",{className:"automation-bottom-small",children:"TECHTORCH ERP & AUTOMATION ARCHITECTURE"})]})]}),t.jsx("style",{children:`
        /* ================================
           MAIN SECTION (padding same as other sections)
        ================================= */

        .integrated-automation {
          width: 100%;
          margin: 0;
          padding: 40px 16px;
          background: #faf9f4;
          color: #11172b;
          font-family: "Inter", sans-serif;
          overflow: hidden;
        }

        @media (min-width: 640px) {
          .integrated-automation {
            padding: 48px 24px;
          }
        }

        @media (min-width: 768px) {
          .integrated-automation {
            padding: 56px 40px;
          }
        }

        @media (min-width: 1024px) {
          .integrated-automation {
            padding: 64px 100px;
          }
        }

        @media (min-width: 1280px) {
          .integrated-automation {
            padding: 80px 100px;
          }
        }

        .automation-container {
          width: 100%;
          display: flex;
          flex-direction: column;
          align-items: center;
        }

        /* ================================
           BADGE
        ================================= */

        .automation-badge {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          height: 25px;
          padding: 0 13px;
          border: 1px solid #e6c8d8;
          border-radius: 20px;
          background: #fffafd;
<<<<<<< HEAD
          color: #8c0750;
          font-size: 9px;
          font-weight: 900;
=======

          color: #730042;

          font-size: 10px;

          font-weight: 800;

>>>>>>> 386a3c761377b5c513cd6d475ffed43457664c16
          letter-spacing: 0.65px;
          margin-bottom: 17px;
        }

        .automation-badge-dot {
          width: 6px;
          height: 6px;
          flex: 0 0 auto;
          border-radius: 50%;
          background: #970052;
        }

        /* ================================
           HEADING
        ================================= */

        .automation-heading {
          width: 100%;
          margin: 0;
          text-align: center;
          color: #11172b;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 32px;
          line-height: 1.12;
          letter-spacing: -1.2px;
          font-weight: 600;
        }

        /* ================================
           SUBHEADING
        ================================= */

        .automation-subheading {
          margin: 13px 0 0;
          width: 100%;
          text-align: center;
<<<<<<< HEAD
          color: #8d0750;
          font-size: 15px;
          line-height: 1.55;
=======

          color: #65738a;
          font-family: "Inter", sans-serif;
          font-size: 13.5px;

          line-height: 1.6;

          font-weight: 500;
        }

        /* =====================================
           CONNECTION BOX
        ====================================== */

        .connection-wrapper {
          width: 100%;

          max-width: 1050px;

          margin-top: 31px;

          padding: 32px 42px 27px;

          background: #ffffff;

          border: 1px solid #e5eaf0;

          border-radius: 14px;

          box-shadow:
            0 4px 14px rgba(20, 30, 50, 0.025);

          display: flex;
          flex-direction: column;
          align-items: center;
        }

        .connection-list {
          width: 100%;

          max-width: 690px;

          display: flex;
          flex-direction: column;
          align-items: center;
        }

        /* =====================================
           CONNECTION ITEM
        ====================================== */

        .connection-item {
          width: 100%;

          min-height: 42px;

          padding: 0 14px;

          display: flex;

          align-items: center;

          gap: 10px;

          background: #f7f9fb;

          border: 1px solid #e4eaf0;

          border-radius: 7px;
        }

        .connection-item-dot {
          width: 7px;
          height: 7px;

          flex: 0 0 auto;

          border-radius: 50%;

          background: #730042;
        }

        .connection-item-text {
          color: #293448;
          font-family: "Inter", sans-serif;
          font-size: 13px;

          line-height: 1.45;

          font-weight: 600;
        }

        /* =====================================
           ARROWS
        ====================================== */

        .connection-arrow {
          height: 24px;

          display: flex;

          align-items: center;
          justify-content: center;

          color: #bd6b91;

          font-size: 16px;

          line-height: 1;

          font-weight: 700;
        }

        /* =====================================
           EVERYTHING CONNECTED
        ====================================== */

        .everything-connected {
          min-height: 34px;

          margin-top: 20px;

          padding: 0 17px;

          display: inline-flex;

          align-items: center;
          justify-content: center;

          gap: 8px;

          border: 1px solid #e2bdd0;

          border-radius: 20px;

          background: #fffafd;

          color: #730042;

          font-size: 10px;

          font-weight: 900;

          letter-spacing: 0.4px;
        }

        .everything-dot {
          width: 7px;
          height: 7px;

          flex: 0 0 auto;

          border-radius: 50%;

          background: #970052;
        }

        /* =====================================
           DESCRIPTION
        ====================================== */

        .cross-functional-description {
          width: 100%;

          max-width: 920px;

          margin-top: 28px;

          padding: 0 10px;

          color: #52627a;

          font-size: 13.5px;

          line-height: 1.7;

>>>>>>> 386a3c761377b5c513cd6d475ffed43457664c16
          font-weight: 500;
        }

        /* ================================
           MAIN CARDS
        ================================= */

        .automation-cards {
          width: 100%;
          margin: 38px 0 0;
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 24px;
          align-items: stretch;
        }

        /* ================================
           CARD
        ================================= */

        .automation-card {
          min-width: 0;
          min-height: 313px;
          padding: 29px 27px 25px;
          border-radius: 16px;
          display: flex;
          flex-direction: column;
          background: #f7fafc;
          border: 1px solid #e3e9ef;
          transition:
            transform 0.3s ease,
            background 0.3s ease,
            border-color 0.3s ease,
            box-shadow 0.3s ease;
        }

        .automation-card:hover {
          transform: translateY(-7px);
          background: #fcf8f8;
          border-color: #e8d1dd;
          box-shadow: 0 12px 28px rgba(151, 0, 82, 0.10);
        }

        /* ================================
           CARD TITLE
        ================================= */

        .automation-card-title {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 20px;
        }

        .automation-card-title h3 {
          margin: 0;
          color: #202a3e;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 15px;
          line-height: 1.3;
          font-weight: 700;
          letter-spacing: -0.2px;
          transition: color 0.3s ease;
        }

        .automation-card:hover .automation-card-title h3 {
          color: #8d0750;
        }

        /* ================================
           DOT
        ================================= */

        .card-title-dot {
          width: 9px;
          height: 9px;
          flex: 0 0 auto;
          border-radius: 50%;
          background: #91a4bb;
          transition: background 0.3s ease;
        }

        .automation-card:hover .card-title-dot {
          background: #970052;
        }

        /* ================================
           CARD DESCRIPTION
        ================================= */

        .automation-card-description {
          margin: 0;
          max-width: 560px;
          color: #627188;
          font-family: "Inter", sans-serif;
          font-size: 13.5px;
          line-height: 1.65;
          font-weight: 500;
        }

        /* ================================
           POINTS BOX
        ================================= */

        .automation-points {
          width: 100%;
          margin-top: 20px;
          padding: 13px 13px;
          border: 1px solid #e4e9ee;
          border-radius: 9px;
          background: #ffffff;
          color: #617087;
          font-family: "Inter", sans-serif;
          font-size: 12.5px;
          line-height: 1.65;
          font-weight: 600;
          transition:
            border-color 0.3s ease,
            box-shadow 0.3s ease;
        }

        .automation-card:hover .automation-points {
          border-color: #ead6df;
        }

        .automation-points div + div {
          margin-top: 3px;
        }

        /* ================================
           BOTTOM MESSAGE
        ================================= */

        .automation-bottom {
          width: 100%;
          min-height: 97px;
          margin-top: 38px;
          padding: 20px 30px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          text-align: center;
          border: 1px solid #e3bdd0;
          border-radius: 12px;
          background: #fff8fb;
        }

        .automation-bottom-main {
          color: #8d0750;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 17px;
          line-height: 1.35;
          font-weight: 720;
          letter-spacing: -0.3px;
        }

        .automation-bottom-small {
          margin-top: 6px;
          color: #7d8da4;
          font-size: 10px;
          line-height: 1.3;
          font-weight: 600;
          letter-spacing: 0.25px;
        }

        /* ================================
           LARGE DESKTOP
        ================================= */

        @media (min-width: 1600px) {
          .automation-heading {
            font-size: 38px;
          }

          .automation-subheading {
            font-size: 14px;
          }

          .automation-cards {
            gap: 26px;
            margin-top: 40px;
          }

          .automation-card {
            min-height: 325px;
            padding: 31px 29px 27px;
          }

          .automation-card-title h3 {
            font-size: 16px;
          }

          .automation-card-description {
            font-size: 11.5px;
          }

          .automation-points {
            font-size: 10px;
          }

          .automation-bottom-main {
            font-size: 18px;
          }
        }

        /* ================================
           SMALL DESKTOP / TABLET
        ================================= */

        @media (max-width: 1100px) {
          .automation-heading {
            font-size: 31px;
          }

          .automation-subheading {
            font-size: 12px;
          }

          .automation-cards {
            gap: 18px;
          }

          .automation-card {
            min-height: 300px;
            padding: 25px 22px 22px;
          }

          .automation-card-title h3 {
            font-size: 14px;
          }

          .automation-card-description {
            font-size: 10px;
          }

          .automation-points {
            font-size: 9px;
          }

          .automation-bottom-main {
            font-size: 15px;
          }
        }

        /* ================================
           TABLET
        ================================= */

        @media (max-width: 800px) {
          .automation-heading {
            font-size: 28px;
          }

          .automation-subheading {
            font-size: 11px;
          }

          .automation-cards {
            grid-template-columns: 1fr;
            gap: 16px;
          }

          .automation-card {
            min-height: auto;
            padding: 25px 23px 23px;
          }

          .automation-bottom {
            margin-top: 30px;
          }
        }

        /* ================================
           MOBILE
        ================================= */

        @media (max-width: 600px) {
          .automation-badge {
            height: 24px;
            padding: 0 11px;
            font-size: 7.5px;
          }

          .automation-heading {
            font-size: 25px;
            line-height: 1.13;
            letter-spacing: -0.8px;
          }

          .automation-subheading {
            margin-top: 12px;
            font-size: 10px;
            line-height: 1.6;
          }

          .desktop-break {
            display: none;
          }

          .automation-cards {
            margin-top: 28px;
            gap: 13px;
          }

          .automation-card {
            width: 100%;
            min-height: 0;
            padding: 21px 18px 19px;
            border-radius: 13px;
          }

          .automation-card:hover {
            transform: translateY(-5px);
          }

          .automation-card-title {
            gap: 8px;
            margin-bottom: 15px;
          }

          .card-title-dot {
            width: 8px;
            height: 8px;
          }

          .automation-card-title h3 {
            font-size: 13px;
            line-height: 1.35;
          }

          .automation-card-description {
            font-size: 10px;
            line-height: 1.65;
          }

          .automation-points {
            margin-top: 17px;
            padding: 12px 11px;
            font-size: 9px;
            line-height: 1.65;
          }

          .automation-bottom {
            min-height: 0;
            margin-top: 27px;
            padding: 18px 16px;
            border-radius: 11px;
          }

          .automation-bottom-main {
            font-size: 13px;
            line-height: 1.45;
          }

          .automation-bottom-small {
            margin-top: 7px;
            font-size: 7px;
          }
        }

        /* ================================
           SMALL MOBILE
        ================================= */

        @media (max-width: 380px) {
          .automation-heading {
            font-size: 22px;
          }

          .automation-subheading {
            font-size: 9.5px;
          }

          .automation-card {
            padding: 19px 16px 17px;
          }

          .automation-card-title h3 {
            font-size: 12px;
          }

          .automation-card-description {
            font-size: 9.5px;
          }

          .automation-points {
            font-size: 8.5px;
            padding: 11px 10px;
          }

          .automation-bottom-main {
            font-size: 11.5px;
          }

          .automation-bottom-small {
            font-size: 6.5px;
          }
        }
      `})]})}export{o as default};
