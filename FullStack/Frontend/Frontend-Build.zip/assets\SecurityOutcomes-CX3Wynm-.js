import{j as e}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";const n=[{number:"01",code:"EXPOSURE_CTRL",title:"Reduce Exposure",description:"Identify weaknesses and address potential security gaps before they become larger problems.",tagLeft:"RISK MINIMIZATION",tagRight:"PROACTIVE"},{number:"02",code:"DATA_SHIELD",title:"Protect Sensitive Information",description:"Apply appropriate controls around important business and customer data.",tagLeft:"DATA SAFEGUARD",tagRight:"PROTECTED"},{number:"03",code:"TELEMETRY",title:"Improve Visibility",description:"Gain a clearer understanding of activity across your digital environment.",tagLeft:"SIGNAL DETECT",tagRight:"COMPLETE"},{number:"04",code:"ALERT_ACC",title:"Strengthen Response",description:"Be better prepared to identify and respond to security incidents.",tagLeft:"CONTAINMENT",tagRight:"READY"},{number:"05",code:"UPTIME_OPS",title:"Support Business Continuity",description:"Reduce the operational impact of security-related disruptions.",tagLeft:"RESILIENCE",tagRight:"SUSTAINED"},{number:"06",code:"TRUST_INDEX",title:"Build Customer Confidence",description:"Demonstrate that security and responsible handling of information are taken seriously.",tagLeft:"REPUTATION",tagRight:"VALIDATED"}];function a(){return e.jsx("section",{className:`\r
        w-full\r
        overflow-hidden\r
        bg-[#F4F4F7]\r
        px-4 py-10\r
        sm:px-6 sm:py-12\r
        md:px-10 md:py-14\r
        lg:px-[100px] lg:py-16\r
        xl:py-20\r
      `,children:e.jsxs("div",{className:"w-full",children:[e.jsxs("div",{className:`\r
            flex\r
            flex-col\r
            gap-5\r
            sm:gap-6\r
            lg:flex-row\r
            lg:items-start\r
            lg:justify-between\r
          `,children:[e.jsxs("div",{className:"min-w-0",children:[e.jsxs("span",{className:"inline-flex items-center gap-1.5 text-[9px] font-semibold tracking-[0.15em] text-[#730042] sm:text-[10px]",style:{fontFamily:"'Inter', sans-serif"},children:[e.jsx("span",{className:"h-1.5 w-1.5 rounded-full bg-[#730042]"}),"SECURITY OUTCOMES"]}),e.jsx("h1",{className:`\r
                mt-3\r
                w-full\r
                max-w-[350px]\r
                text-[22px]\r
                font-bold\r
                leading-[1.3]\r
                text-slate-900\r
                sm:max-w-xl\r
                sm:text-[25px]\r
                md:max-w-2xl\r
                md:text-[28px]\r
                lg:max-w-2xl\r
                lg:text-[30px]\r
                xl:text-[32px]\r
              `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"What Stronger Security Can Help You Achieve"})]}),e.jsxs("p",{className:`\r
              w-full\r
              max-w-[340px]\r
              text-left\r
              text-[13px]\r
              leading-[1.7]\r
              text-slate-500\r
              sm:max-w-md\r
              sm:text-[14px]\r
              sm:leading-[1.75]\r
              lg:max-w-md\r
              xl:max-w-lg\r
            `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:["Measurable operational resilience and strategic",e.jsx("br",{}),"confidence delivered across every tier of the enterprise."]})]}),e.jsx("div",{className:`\r
            mt-8\r
            grid\r
            grid-cols-1\r
            gap-4\r
            sm:mt-10\r
            sm:grid-cols-2\r
            sm:gap-5\r
            lg:mt-12\r
            lg:grid-cols-3\r
            lg:gap-6\r
          `,children:n.map(t=>e.jsxs("div",{className:`\r
                group\r
                relative\r
                flex\r
                w-full\r
                min-w-0\r
                flex-col\r
                justify-between\r
                overflow-hidden\r
                rounded-lg\r
                bg-white\r
                p-5\r
                transition-all\r
                duration-300\r
                hover:-translate-y-1\r
                hover:bg-rose-50\r
                hover:shadow-md\r
                sm:p-6\r
              `,children:[e.jsx("div",{className:`\r
                  pointer-events-none\r
                  absolute\r
                  right-0\r
                  top-0\r
                  h-24\r
                  w-24\r
                  rounded-bl-[80px]\r
                  bg-gradient-to-bl\r
                  from-rose-100\r
                  via-rose-50/70\r
                  to-transparent\r
                  opacity-80\r
                  transition-all\r
                  duration-500\r
                  group-hover:h-full\r
                  group-hover:w-full\r
                  group-hover:rounded-none\r
                  group-hover:from-rose-100\r
                  group-hover:via-rose-50\r
                  group-hover:to-rose-50/30\r
                  group-hover:opacity-100\r
                `}),e.jsxs("div",{className:"relative z-10",children:[e.jsxs("div",{className:"flex items-center justify-between gap-3",children:[e.jsx("span",{className:"inline-flex shrink-0 items-center rounded-full bg-rose-50 px-2.5 py-1 text-[10px] font-semibold text-[#730042]",style:{fontFamily:"'Inter', sans-serif"},children:t.number}),e.jsx("span",{className:"min-w-0 truncate text-[8px] font-medium tracking-[0.08em] text-slate-400 sm:text-[9px] md:text-[10px]",style:{fontFamily:"'Inter', sans-serif"},children:t.code})]}),e.jsx("h3",{className:"mt-4 text-[15px] font-semibold leading-[1.4] text-slate-900 sm:text-[16px] md:text-[17px]",style:{fontFamily:"'Inter', sans-serif"},children:t.title}),e.jsx("p",{className:"mt-2 text-[13px] leading-[1.7] text-slate-500 sm:text-[14px] sm:leading-[1.75]",style:{fontFamily:"'Inter', sans-serif"},children:t.description})]}),e.jsxs("div",{className:"relative z-10 mt-6 flex items-center justify-between gap-3 border-t border-slate-100 pt-4",children:[e.jsx("span",{className:"min-w-0 truncate text-[8px] font-medium tracking-[0.08em] text-slate-400 sm:text-[9px] md:text-[10px]",style:{fontFamily:"'Inter', sans-serif"},children:t.tagLeft}),e.jsx("span",{className:"shrink-0 text-[8px] font-semibold tracking-[0.08em] text-[#730042] sm:text-[9px] md:text-[10px]",style:{fontFamily:"'Inter', sans-serif"},children:t.tagRight})]})]},t.number))})]})})}export{a as default};
