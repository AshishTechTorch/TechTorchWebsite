import{j as e}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";import{t as r,r as o}from"./index-BThRNyH6.js";import{G as s}from"./gauge-3hwrYA9q.js";const a={name:"cloud-off",size:24,node:[["path",{d:"M10.94 5.274A7 7 0 0 1 15.71 10h1.79a4.5 4.5 0 0 1 4.222 6.057",key:"1uxyv8"}],["path",{d:"M18.796 18.81A4.5 4.5 0 0 1 17.5 19H9A7 7 0 0 1 5.79 5.78",key:"99tcn7"}],["path",{d:"m2 2 20 20",key:"1ooewy"}]]};a.node;const d=r(a),t="#730024",c=[{icon:d,title:"Zero Capital Infrastructure Burden",description:"Bypass multi-million dollar hardware procurement cycles, specialized GPU cluster maintenance, and specialized data-center cooling overhead."},{icon:s,title:"Rapid Enterprise Model Deployment",description:"Integrate advanced cognitive workflows, LLM orchestration, and enterprise predictive models immediately into your operational stack without delay.",featured:!0,badge:"CORE BENEFIT"},{icon:o,title:"Governed & Scalable Operations",description:"Benefit from institutional-grade model safety, compliance isolation, continuous data privacy protocols, and automatic capacity auto-scaling."}];function w(){return e.jsxs("section",{className:"why-section",children:[e.jsxs("div",{className:"why-container",children:[e.jsxs("div",{className:"why-header",children:[e.jsxs("div",{className:"why-eyebrow",children:[e.jsx("span",{className:"why-eyebrow-line"}),e.jsx("span",{className:"why-eyebrow-text",children:"Architectural Advantage"})]}),e.jsx("h2",{className:"why-heading",children:"Why Artificial Intelligence as a Service?"}),e.jsx("h3",{className:"why-subtitle",children:"Access AI Without Building the Entire Infrastructure"}),e.jsx("p",{className:"why-text",children:"Building and maintaining technology infrastructure can add complexity to an organization's technology environment. TechTorch's Artificial Intelligence as a Service approach enables businesses to harness AI capabilities without taking on the complete responsibility of building and maintaining their own infrastructure."})]}),e.jsx("div",{className:"why-grid",children:c.map(i=>{const n=i.icon;return e.jsxs("div",{className:`why-card ${i.featured?"is-featured":""}`,children:[e.jsxs("div",{className:"why-card-top",children:[e.jsx("div",{className:"why-icon-wrapper",children:e.jsx(n,{className:"why-icon"})}),i.badge&&e.jsx("span",{className:"why-badge",children:i.badge})]}),e.jsx("h3",{className:"why-card-title",children:i.title}),e.jsx("p",{className:"why-card-description",children:i.description})]},i.title)})})]}),e.jsx("style",{children:`
        .why-section { width: 100%; overflow: hidden; background: #f2f0ee; }

        .why-container {
          width: 100%;
          box-sizing: border-box;
          padding: 70px 100px;
        }

        /* HEADER */
        .why-header { max-width: 1050px; margin-bottom: 52px; }

        .why-eyebrow { display: flex; align-items: center; gap: 10px; margin-bottom: 14px; }
        .why-eyebrow-line { width: 40px; height: 1px; flex-shrink: 0; background: ${t}; }
        .why-eyebrow-text {
          font-family: "Inter", sans-serif;
          font-size: 12px; font-weight: 600; letter-spacing: 0.08em; color: ${t};
        }

        .why-heading {
          margin: 0 0 12px 0;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 44px; font-weight: 700; line-height: 1.15;
          letter-spacing: -0.03em; color: #1c1c1c;
        }
        .why-subtitle {
          margin: 0 0 16px 0;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 24px; font-weight: 500; line-height: 1.3;
          letter-spacing: -0.01em; color: ${t};
        }
        .why-text {
          margin: 0;
          font-family: "Inter", sans-serif;
          font-size: 15px; font-weight: 400; line-height: 1.75; color: #737373;
        }

        /* GRID */
        .why-grid {
          min-width: 0;
          height: 100%;
          box-sizing: border-box;
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 30px;
          align-items: start;
        }

        /* CARD: static, not clickable */
        .why-card {
          min-width: 0;
          min-height: 250px;
          box-sizing: border-box;
          padding: 30px;
          border: 1px solid #e5e5e5;
          border-radius: 14px;
          background: #fff;
          cursor: default;
        }
        .why-card.is-featured {
          margin-top: -4px;
          box-shadow: 0 14px 34px rgba(0, 0, 0, 0.08);
        }

        .why-card-top {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 10px;
          margin-bottom: 26px;
        }

        .why-icon-wrapper {
          width: 50px; height: 50px;
          display: flex; align-items: center; justify-content: center;
          flex-shrink: 0; box-sizing: border-box;
          border: 1px solid #ecd5de; border-radius: 10px; background: #fbeff3;
        }
        .why-icon { width: 22px; height: 22px; color: ${t}; }

        .why-badge {
          padding: 6px 12px; border-radius: 999px;
          font-family: "Inter", sans-serif;
          font-size: 9px; font-weight: 700; letter-spacing: 0.06em;
          white-space: nowrap; color: #fff; background: ${t};
        }

        .why-card-title {
          margin: 0 0 12px 0;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 18px; font-weight: 600; line-height: 1.35; color: #1c1c1c;
        }
        .why-card-description {
          margin: 0;
          font-family: "Inter", sans-serif;
          font-size: 15px; font-weight: 400; line-height: 1.7; color: #737373;
        }

        /* <= 1200px */
        @media (max-width: 1200px) {
          .why-container { padding: 60px 40px; }
          .why-heading { font-size: 38px; }
          .why-grid { gap: 20px; }
          .why-card { padding: 24px; }
        }

        /* <= 900px */
        @media (max-width: 900px) {
          .why-container { padding: 52px 40px; }
          .why-header { margin-bottom: 36px; }
          .why-heading { font-size: 34px; }
          .why-subtitle { font-size: 20px; }
          .why-text { font-size: 14px; }
          .why-grid { grid-template-columns: 1fr; gap: 18px; }
          .why-card { min-height: auto; }
          .why-card.is-featured { margin-top: 0; }
        }

        /* <= 700px */
        @media (max-width: 700px) {
          .why-container { padding: 44px 24px; }
          .why-heading { font-size: 28px; }
          .why-subtitle { font-size: 18px; }
          .why-card { padding: 20px; }
          .why-card-top { margin-bottom: 18px; }
          .why-card-title { font-size: 16px; }
          .why-card-description { font-size: 13.5px; }
        }

        /* <= 480px */
        @media (max-width: 480px) {
          .why-container { padding: 36px 16px; }
          .why-heading { font-size: 25px; }
          .why-subtitle { font-size: 16px; }
          .why-text { font-size: 13px; }
          .why-eyebrow-line { width: 28px; }
          .why-eyebrow-text { font-size: 10px; }
          .why-icon-wrapper { width: 44px; height: 44px; }
          .why-icon { width: 20px; height: 20px; }
          .why-badge { font-size: 8px; padding: 5px 10px; }
        }
      `})]})}export{w as default};
