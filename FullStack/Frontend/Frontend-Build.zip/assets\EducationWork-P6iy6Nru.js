import{j as o}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";import{t as r,I as c,T as d,w as u,D as p}from"./index-BThRNyH6.js";import{U as x}from"./user-BaVexer9.js";import{C as g}from"./clipboard-list-IBvDLiD3.js";import{M as m}from"./message-square-tRi_lmBc.js";import{C as h}from"./chart-column-4WxSCpbG.js";const e={name:"hexagon",size:24,node:[["path",{d:"M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z",key:"yt0hxn"}]]};e.node;const f=r(e),n="#7A1F3D",i="#1B1B2A",t="#5b5a63",b="#fbeef1",w=[{icon:x,title:"Student Management",body:"Keep records, progression pathways, and student profiles unified across faculties and semesters."},{icon:g,title:"Admissions & Enrollment",body:"Streamline digital applications, document verification, and registration queues end-to-end."},{icon:f,title:"Academic Scheduling",body:"Coordinate modular timetables, room allocation, faculty workloads, and examination tracks."},{icon:d,title:"Smart Attendance",body:"Capture real-time participation across lecture halls, laboratory sections, and virtual classrooms."},{icon:u,title:"Digital Learning",body:"Centralize rich course content, collaborative assignments, and assessment rubrics in one portal."},{icon:m,title:"Connected Communication",body:"Deliver immediate alerts, institutional announcements, and direct advisor touchpoints."},{icon:p,title:"Finance & Tuition",body:"Manage fee structures, automated installment tracking, scholarships, and departmental budgets."},{icon:h,title:"Executive Analytics",body:"Generate compliance reporting, accreditation analytics, and retention intelligence instantly."}];function A(){return o.jsxs("section",{className:"solutions-section",children:[o.jsx("style",{children:`

        .solutions-section {
          --solutions-sticky-top: 100px;
          --solutions-icon-bg: ${b};

          width: 100%;
          background: #f3f1ec;
          color: ${i};
          font-family: "Inter", sans-serif;
          overflow: visible;
        }

        .solutions-section,
        .solutions-section *,
        .solutions-section *::before,
        .solutions-section *::after {
          box-sizing: border-box;
        }

        .solutions-section .solutions-container {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;
          padding: 80px 100px;

          display: grid;
          grid-template-columns:
            minmax(300px, 0.85fr)
            minmax(0, 1.45fr);

          gap: 64px;
          align-items: start;
          overflow: visible;
        }

        /* Sticky is bounded by this section's grid container. */
        .solutions-section .solutions-copy {
          position: sticky;
          top: var(--solutions-sticky-top);
          align-self: start;
          width: 100%;
          min-width: 0;
          height: fit-content;
        }

        .solutions-section .solutions-eyebrow {
          display: flex;
          align-items: center;
          gap: 4px;
          margin-bottom: 16px;
          color: ${n};
          font-size: 12px;
          font-weight: 600;
          letter-spacing: 0.04em;
          line-height: 1.4;
        }

        .solutions-section .solutions-eyebrow svg {
          flex-shrink: 0;
        }

        .solutions-section .solutions-heading {
          max-width: 560px;
          margin: 0 0 20px;
          color: ${i};
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 38px;
          font-weight: 700;
          line-height: 1.17;
          letter-spacing: -0.65px;
          overflow-wrap: break-word;
        }

        .solutions-section .solutions-subheading {
          max-width: 580px;
          margin: 0 0 30px;
          color: ${t};
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 16px;
          font-weight: 500;
          line-height: 1.75;
        }

        .solutions-section .solutions-label {
          max-width: 500px;
          margin: 0;
          color: #8a8378;
          font-size: 11px;
          font-weight: 600;
          line-height: 1.5;
          letter-spacing: 0.06em;
        }

        /* Normal page scrolling, without an inner scrollbar. */
        .solutions-section .solutions-grid {
          width: 100%;
          min-width: 0;
          height: auto;
          max-height: none;
          overflow: visible;
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 20px;
        }

        .solutions-section .solution-card {
          --card-padding: 24px;
          --icon-size: 44px;
          --color-origin: calc(
            var(--card-padding) + var(--icon-size) / 2
          );

          position: relative;
          isolation: isolate;
          overflow: hidden;

          min-width: 0;
          padding: var(--card-padding);

          display: flex;
          flex-direction: column;
          gap: 16px;

          background: #ffffff;
          border: 1px solid rgba(0, 0, 0, 0.035);
          border-radius: 16px;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.06);

          transition:
            transform 0.3s ease,
            box-shadow 0.3s ease,
            border-color 0.3s ease;
        }

        /* Background expands outward from the icon center. */
        .solutions-section .solution-card::before {
          content: "";
          position: absolute;
          inset: 0;
          z-index: 0;
          pointer-events: none;
          background: var(--solutions-icon-bg);

          clip-path: circle(
            0% at var(--color-origin) var(--color-origin)
          );

          transition:
            clip-path 650ms cubic-bezier(0.22, 1, 0.36, 1);
        }

        .solutions-section .solution-card > * {
          position: relative;
          z-index: 1;
        }

        .solutions-section .solution-icon {
          width: var(--icon-size);
          height: var(--icon-size);
          flex-shrink: 0;

          display: flex;
          align-items: center;
          justify-content: center;

          border-radius: 12px;
          background: var(--solutions-icon-bg);
          color: ${n};
        }

        .solutions-section .solution-content {
          min-width: 0;
        }

        .solutions-section .solution-title {
          margin: 0 0 7px;
          color: ${i};
          font-size: 15px;
          font-weight: 600;
          line-height: 1.4;
          overflow-wrap: break-word;
        }

        .solutions-section .solution-body {
          margin: 0;
          color: ${t};
          font-size: 14px;
          font-weight: 400;
          line-height: 1.65;
        }

        @media (hover: hover) {
          .solutions-section .solution-card:hover {
            transform: translateY(-4px);
            border-color: rgba(122, 31, 61, 0.12);
            box-shadow: 0 12px 28px rgba(0, 0, 0, 0.08);
          }

          .solutions-section .solution-card:hover::before {
            clip-path: circle(
              150% at var(--color-origin) var(--color-origin)
            );
          }
        }

        @media (min-width: 1400px) {
          .solutions-section .solutions-container {
            padding-top: 88px;
            padding-bottom: 88px;
            gap: 76px;
          }

          .solutions-section .solutions-heading {
            font-size: 40px;
          }

          .solutions-section .solutions-subheading {
            font-size: 16.5px;
          }

          .solutions-section .solutions-grid {
            gap: 22px;
          }

          .solutions-section .solution-card {
            --card-padding: 26px;
          }
        }

        @media (min-width: 768px) and (max-width: 1199px) {
          .solutions-section .solutions-container {
            padding: 70px 40px;
            grid-template-columns:
              minmax(270px, 0.85fr)
              minmax(0, 1.35fr);
            gap: 42px;
          }

          .solutions-section .solutions-heading {
            font-size: 33px;
          }

          .solutions-section .solutions-subheading {
            font-size: 15px;
          }

          .solutions-section .solutions-grid {
            gap: 16px;
          }

          .solutions-section .solution-card {
            --card-padding: 21px;
          }
        }

        /* Tablet: stack the introduction above the cards. */
        @media (max-width: 900px) {
          .solutions-section .solutions-container {
            grid-template-columns: minmax(0, 1fr);
          }

          .solutions-section .solutions-copy {
            position: static;
            top: auto;
          }
        }

        @media (min-width: 768px) and (max-width: 900px) {
          .solutions-section .solutions-container {
            gap: 42px;
          }

          .solutions-section .solutions-heading,
          .solutions-section .solutions-subheading {
            max-width: 760px;
          }

          .solutions-section .solutions-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
          }

          .solutions-section .solution-card {
            --card-padding: 22px;
          }
        }

        @media (max-width: 767px) {
          .solutions-section .solutions-container {
            padding: 56px 24px;
            gap: 32px;
          }

          .solutions-section .solutions-eyebrow {
            gap: 3px;
            margin-bottom: 13px;
            font-size: 11px;
            line-height: 1.5;
          }

          .solutions-section .solutions-heading {
            max-width: 680px;
            margin-bottom: 16px;
            font-size: 29px;
            line-height: 1.2;
            letter-spacing: -0.5px;
          }

          .solutions-section .solutions-subheading {
            max-width: 680px;
            margin-bottom: 24px;
            font-size: 14px;
            line-height: 1.7;
          }

          .solutions-section .solutions-label {
            font-size: 10px;
            line-height: 1.55;
          }

          .solutions-section .solutions-grid {
            grid-template-columns: minmax(0, 1fr);
            gap: 14px;
          }

          .solutions-section .solution-card {
            --card-padding: 20px;
            --icon-size: 42px;
            gap: 14px;
            border-radius: 14px;
          }

          .solutions-section .solution-icon {
            border-radius: 11px;
          }

          .solutions-section .solution-body {
            font-size: 13px;
          }
        }

        @media (max-width: 480px) {
          .solutions-section .solutions-container {
            padding: 48px 16px;
            gap: 28px;
          }

          .solutions-section .solutions-heading {
            font-size: 26px;
            line-height: 1.21;
            letter-spacing: -0.4px;
          }

          .solutions-section .solutions-subheading {
            font-size: 13px;
          }

          .solutions-section .solutions-label {
            font-size: 9.5px;
          }

          .solutions-section .solutions-grid {
            gap: 11px;
          }

          .solutions-section .solution-card {
            --card-padding: 17px;
            --icon-size: 40px;
            border-radius: 13px;
            gap: 13px;
          }

          .solutions-section .solution-icon {
            border-radius: 10px;
          }

          .solutions-section .solution-title {
            margin-bottom: 6px;
            font-size: 14px;
          }

          .solutions-section .solution-body {
            font-size: 12.5px;
          }
        }

        @media (max-width: 360px) {
          .solutions-section .solutions-container {
            padding: 42px 16px;
          }

          .solutions-section .solutions-heading {
            font-size: 24px;
            line-height: 1.22;
          }

          .solutions-section .solutions-subheading {
            font-size: 12.5px;
          }

          .solutions-section .solution-card {
            --card-padding: 16px;
          }

          .solutions-section .solution-body {
            font-size: 12px;
          }
        }

        @media (prefers-reduced-motion: reduce) {
          .solutions-section .solution-card,
          .solutions-section .solution-card::before {
            transition: none;
          }

          .solutions-section .solution-card:hover {
            transform: none;
          }
        }
      `}),o.jsxs("div",{className:"solutions-container",children:[o.jsxs("div",{className:"solutions-copy",children:[o.jsxs("div",{className:"solutions-eyebrow",children:[o.jsx(c,{size:14,strokeWidth:3}),o.jsx("span",{children:"BUILT AROUND THE WAY EDUCATION WORKS"})]}),o.jsx("h2",{className:"solutions-heading",children:"Technology that supports real institutional needs."}),o.jsx("p",{className:"solutions-subheading",children:"We believe education technology should adapt to the organization using it. Instead of treating every institution the same, our approach considers its existing processes, people, systems and future requirements."}),o.jsx("p",{className:"solutions-label",children:"OUR SOLUTIONS CAN SUPPORT KEY AREAS SUCH AS:"})]}),o.jsx("div",{className:"solutions-grid",children:w.map(({icon:a,title:s,body:l})=>o.jsxs("article",{className:"solution-card",children:[o.jsx("span",{className:"solution-icon",children:o.jsx(a,{size:20,strokeWidth:1.8})}),o.jsxs("div",{className:"solution-content",children:[o.jsx("h3",{className:"solution-title",children:s}),o.jsx("p",{className:"solution-body",children:l})]})]},s))})]})]})}export{A as default};
