import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as d}from"./vendor-router-L4ZCoGSs.js";function m(){const[t,n]=d.useState([]),[s,a]=d.useState("readonly"),o=["Multi-Cloud (AWS / Azure / GCP)","Hybrid Enterprise & On-Prem","Kubernetes & Container Mesh","Enterprise SaaS & Identity (Okta / Entra ID)","AI Agent & LLM Pipelines"],x=i=>{n(l=>l.includes(i)?l.filter(h=>h!==i):[...l,i])};return e.jsxs("div",{className:"security-intake",children:[e.jsxs("header",{className:"intake-header",children:[e.jsxs("div",{className:"intake-top-row",children:[e.jsx("div",{className:"intake-label",children:"TECHTORCH SECURITY ENGAGEMENT · PHASE 01 INTAKE"}),e.jsxs("div",{className:"intake-security",children:[e.jsxs("span",{children:["◉ MNDA REF: ",e.jsx("b",{children:"TT-SEC-2026-V4"})]}),e.jsx("span",{children:"◉ E2E Encrypted"})]})]}),e.jsxs("div",{className:"intake-heading",children:[e.jsx("h1",{children:"Enterprise Security Intake & Scope Authorization"}),e.jsx("p",{children:"Formalize technical perimeter boundaries, assign verified executive liaisons, and authorize zero-impact diagnostic telemetry ahead of technical assessment."})]})]}),e.jsxs("section",{className:"progress-bar",children:[e.jsxs("div",{className:"progress-step completed",children:[e.jsx("span",{className:"step-number",children:"01"}),e.jsxs("div",{children:[e.jsx("small",{children:"STEP 01 · COMPLETE"}),e.jsx("strong",{children:"Protocol Acceptance"})]})]}),e.jsxs("div",{className:"progress-step active",children:[e.jsx("span",{className:"step-number",children:"02"}),e.jsxs("div",{children:[e.jsx("small",{children:"STEP 02 · CURRENT"}),e.jsx("strong",{children:"Scope & Telemetry Config"})]})]}),e.jsxs("div",{className:"progress-step next",children:[e.jsx("span",{className:"step-number",children:"03"}),e.jsxs("div",{children:[e.jsx("small",{children:"STEP 03 · NEXT"}),e.jsx("strong",{children:"Architect Dispatch"})]})]})]}),e.jsxs("main",{className:"intake-grid",children:[e.jsxs("div",{className:"intake-left",children:[e.jsxs("section",{className:"intake-card",children:[e.jsxs("div",{className:"section-top",children:[e.jsxs("div",{children:[e.jsx("span",{className:"section-label",children:"SECTION 01"}),e.jsx("h2",{children:"Primary Infrastructure Perimeter"})]}),e.jsx("div",{className:"section-icon",children:"✣"})]}),e.jsx("p",{className:"section-description",children:"Select production enclaves eligible for read-only cryptographic interrogation. Scopes remain strictly bounded by mutual authorization."}),e.jsx("label",{className:"field-label",children:"TARGET ENCLAVES & SUBSYSTEMS"}),e.jsx("div",{className:"scope-options",children:o.map(i=>e.jsxs("button",{type:"button",className:`scope-pill ${t.includes(i)?"selected":""}`,onClick:()=>x(i),children:[e.jsx("span",{children:t.includes(i)?"⊙":"○"}),i]},i))}),e.jsx("label",{className:"field-label",children:"PRIMARY / ROOT CIDR RANGE"}),e.jsxs("div",{className:"input-box",children:[e.jsx("span",{children:"▤"}),e.jsx("input",{type:"text",defaultValue:"corp.fintech-global.internal, 10.240.0.0/16"})]}),e.jsx("p",{className:"field-note",children:"Accepts apex domain records, staging VPC CIDR subnets, or Cloudflare DNS zone anchors."})]}),e.jsxs("section",{className:"intake-card",children:[e.jsxs("div",{className:"section-top",children:[e.jsxs("div",{children:[e.jsx("span",{className:"section-label",children:"SECTION 02"}),e.jsx("h2",{children:"Designated Security Authority"})]}),e.jsx("div",{className:"section-icon",children:"♢"})]}),e.jsx("p",{className:"section-description",children:"Specify the verified corporate officer authorized to approve telemetry handshakes and inspect confidential findings."}),e.jsxs("div",{className:"form-grid",children:[e.jsxs("div",{className:"form-field",children:[e.jsx("label",{children:"LEAD AUTHORIZED EXECUTIVE"}),e.jsxs("div",{className:"input-box",children:[e.jsx("span",{children:"♙"}),e.jsx("input",{type:"text",defaultValue:"Katherine Montgomery"})]})]}),e.jsxs("div",{className:"form-field",children:[e.jsx("label",{children:"WORK EMAIL ADDRESS"}),e.jsxs("div",{className:"input-box",children:[e.jsx("span",{children:"✉"}),e.jsx("input",{type:"email",defaultValue:"k.montgomery@fintech-global.corp"})]})]})]}),e.jsxs("div",{className:"form-field emergency-field",children:[e.jsxs("label",{children:["EMERGENCY ESCALATION LINE"," ",e.jsx("span",{children:"(optional · 24/7 incident hotline)"})]}),e.jsxs("div",{className:"input-box",children:[e.jsx("span",{children:"♧"}),e.jsx("input",{type:"text",defaultValue:"+1 (555) 839-2041"})]})]})]}),e.jsxs("section",{className:"intake-card telemetry-card",children:[e.jsxs("div",{className:"section-top",children:[e.jsxs("div",{children:[e.jsx("span",{className:"section-label",children:"SECTION 03"}),e.jsx("h2",{children:"Diagnostic Telemetry Mode"})]}),e.jsx("div",{className:"section-icon",children:"◉"})]}),e.jsx("p",{className:"section-description",children:"All diagnostics are strictly non-disruptive, authenticated via ephemeral keys, and operate under zero-write protocols."}),e.jsxs("div",{className:"telemetry-options",children:[e.jsx(c,{value:"readonly",selected:s==="readonly",onClick:()=>a("readonly"),title:"Read-Only Cloud IAM & Policy Scan",recommended:!0,description:"Zero agent, zero downtime. Evaluates cross-account trust configurations, privilege escalation vectors, and KMS encryption policies."}),e.jsx(c,{value:"external",selected:s==="external",onClick:()=>a("external"),title:"Passive External Attack Surface Mapping",description:"Automated OSINT perimeter analysis, SPF/DKIM validation, and exposed subservice inventory without requiring credentials."}),e.jsx(c,{value:"comprehensive",selected:s==="comprehensive",onClick:()=>a("comprehensive"),title:"Comprehensive Architecture & Agentic Code Review",description:"Read-only repository access for LLM pipeline orchestration, autonomous agent prompt-injection testing, and Terraform/IaC compliance."})]})]}),e.jsxs("button",{className:"authorize-button",children:["AUTHORIZE SCOPE & DISPATCH INTAKE DOSSIER",e.jsx("span",{children:"→"})]}),e.jsx("div",{className:"authorize-note",children:"♧ Cryptographically sealed under bilateral MNDA. Zero data storage beyond diagnostic session."})]}),e.jsxs("aside",{className:"intake-right",children:[e.jsxs("section",{className:"side-card",children:[e.jsxs("div",{className:"side-card-header",children:[e.jsx("h3",{children:"Active Protocol Recap"}),e.jsx("span",{className:"validated",children:"VALIDATED"})]}),e.jsxs("div",{className:"recap-list",children:[e.jsx(r,{label:"Protocol Reference",value:"TT-SEC-2026-V4"}),e.jsx(r,{label:"Legal Framework",value:"Mutual MNDA Sealed"}),e.jsx(r,{label:"Diagnostic Window",value:"48-Hour Non-Intrusive"}),e.jsx(r,{label:"Production Guarantee",value:"100% Zero-Impact SLA"})]}),e.jsxs("div",{className:"handshake",children:[e.jsxs("div",{className:"handshake-header",children:[e.jsx("strong",{children:"Telemetry Handshake Node"}),e.jsx("span",{children:"READY FOR PING"})]}),e.jsxs("div",{className:"handshake-grid",children:[e.jsxs("div",{children:[e.jsx("small",{children:"LATENCY"}),e.jsx("strong",{children:"< 14ms"})]}),e.jsxs("div",{children:[e.jsx("small",{children:"PROTOCOL"}),e.jsx("strong",{children:"mTLS 1.3"})]}),e.jsxs("div",{children:[e.jsx("small",{children:"ENCLAVE"}),e.jsx("strong",{children:"us-east-1"})]})]})]})]}),e.jsxs("section",{className:"side-card",children:[e.jsxs("div",{className:"side-card-header",children:[e.jsx("h3",{children:"Assigned Principal Architects"}),e.jsx("span",{className:"tier-badge",children:"TIER-1 CLEARED"})]}),e.jsx(p,{image:"/EvelynVance.webp",name:"Dr. Evelyn Vance",title:"Principal Director · Chief Cyber Architect",credential:"CISSP · ex-DRPA Fellow · Cloud Enclave Lead"}),e.jsx(p,{image:"/MarcusChen.webp",name:"Marcus Chen",title:"VP, Autonomous Threat Defense",credential:"Zero-Trust Mesh · AI Agent Red Teaming"})]}),e.jsxs("section",{className:"side-card retention-card",children:[e.jsxs("div",{className:"retention-title",children:[e.jsx("span",{className:"retention-icon",children:"♢"}),e.jsx("h3",{children:"Zero-Retention Cryptographic Guarantee"})]}),e.jsx("p",{children:"Diagnostic telemetry executes strictly in volatile memory. All temporary diagnostic artifacts are securely expunged with SHA-256 verification upon dossier transmission. No customer credentials or persistent payloads are ever stored."}),e.jsxs("div",{className:"retention-certificates",children:[e.jsx("span",{children:"◉ SOC 2 Type II Certified"}),e.jsx("span",{children:"◉ ISO/IEC 27001"})]})]})]})]}),e.jsxs("section",{className:"incident-banner",children:[e.jsxs("div",{className:"incident-content",children:[e.jsx("div",{className:"incident-icon",children:"◉"}),e.jsxs("div",{children:[e.jsx("h2",{children:"Facing an Active Incident or Suspected Breach?"}),e.jsx("p",{children:"Bypass standard intake queues for immediate zero-day rapid response triage and architect assignment."})]})]}),e.jsxs("div",{className:"incident-actions",children:[e.jsx("a",{href:"tel:+919999366708",className:"incident-phone",children:"♧   +91 99933 66708"}),e.jsx("a",{href:"mailto:advisory@techtorch.solutions",className:"incident-email",children:"✉   advisory@techtorch.solutions"})]})]}),e.jsx("style",{children:`

        * {
          box-sizing: border-box;
        }

        .security-intake {
          width: 100%;
          min-height: 100vh;
          padding: 50px 28px 35px;
          background: #f7f8f9;
          color: #20242b;
          font-family: "Inter", Arial, sans-serif;
        }


        /* ================= HEADER ================= */

        .intake-header {
          max-width: 1180px;
          margin: 0 auto;
        }

        .intake-top-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 20px;
        }

        .intake-label {
          padding: 5px 20px;
          border-radius: 4px;
          background: #ffffff;
          color: #5c6068;
          font-size: 9px;
          font-weight: 800;
          letter-spacing: .5px;
          box-shadow: 0 1px 4px rgba(0,0,0,.04);
        }

        .intake-security {
          display: flex;
          align-items: center;
          gap: 18px;
          color: #666b74;
          font-size: 9px;
          font-weight: 700;
          letter-spacing: 1px;
        }

        .intake-security b {
          color: #4b5059;
        }

        .intake-heading {
          margin-top: 27px;
        }

        .intake-heading h1 {
          margin: 0;
          color: #202327;
          font-family: "Plus Jakarta Sans", "Inter", Arial, sans-serif;
          font-size: 36px;
          line-height: 1.12;
          letter-spacing: -1.6px;
          font-weight: 650;
        }

        .intake-heading p {
          max-width: 800px;
          margin: 10px 0 0;
          color: #454b54;
          font-size: 15px;
          line-height: 1.55;
        }


        /* ================= PROGRESS ================= */

        .progress-bar {
          max-width: 1180px;
          margin: 27px auto 0;
          display: grid;
          grid-template-columns: 1fr 1fr 1fr;
          gap: 12px;
        }

        .progress-step {
          min-height: 51px;
          display: flex;
          align-items: center;
          gap: 11px;
          padding: 8px 15px;
          border-radius: 5px;
          background: #ffffff;
          border: 1px solid #e9eaec;
        }

        /* STEP 02 IS NOW NORMAL */
        .progress-step.active {
          background: #ffffff;
          border-color: #e9eaec;
          color: #20242b;
        }

        .progress-step.next {
          background: #f0f1f2;
        }

        .step-number {
          width: 25px;
          height: 25px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 4px;
          background: #f1f2f3;
          color: #666b72;
          font-size: 11px;
          font-weight: 800;
        }

        /* STEP 02 NUMBER ALSO NORMAL */
        .active .step-number {
          background: #f1f2f3;
          color: #666b72;
        }

        .progress-step small {
          display: block;
          margin-bottom: 3px;
          color: #8a8e95;
          font-size: 9px;
          font-weight: 800;
          letter-spacing: .5px;
        }

        /* STEP 02 SMALL TEXT NORMAL */
        .active small {
          color: #8a8e95;
        }

        .progress-step strong {
          display: block;
          color: #292d32;
          font-size: 12px;
          font-weight: 800;
        }

        /* STEP 02 STRONG TEXT NORMAL */
        .active strong {
          color: #292d32;
        }


        /* ================= MAIN ================= */

        .intake-grid {
          max-width: 1180px;
          margin: 27px auto 0;
          display: grid;
          grid-template-columns: minmax(0, 1.55fr) minmax(300px, 1fr);
          gap: 22px;
          align-items: start;
        }

        .intake-left {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .intake-card,
        .side-card {
          background: #ffffff;
          border: 1px solid #e7e8ea;
          border-radius: 8px;
          box-shadow: 0 2px 7px rgba(20, 25, 30, .025);
        }

        .intake-card {
          padding: 25px 21px;
        }


        /* ================= SECTION ================= */

        .section-top {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 15px;
          padding-bottom: 14px;
          border-bottom: 1px solid #eeeeef;
        }

        .section-label {
          display: block;
          margin-bottom: 5px;
          color: #701040;
          font-size: 11px;
          font-weight: 850;
          letter-spacing: .8px;
        }

        .section-top h2 {
          margin: 0;
          color: #22262c;
          font-family: "Plus Jakarta Sans", "Inter", Arial, sans-serif;
          font-size: 25px;
          line-height: 1.1;
          letter-spacing: -.8px;
          font-weight: 600;
        }

        .section-icon {
          color: #72003e;
          font-size: 22px;
          padding-top: 2px;
        }

        .section-description {
          margin: 16px 0 17px;
          max-width: 680px;
          color: #565d66;
          font-size: 14px;
          line-height: 1.55;
        }

        .field-label,
        .form-field label {
          display: block;
          margin-bottom: 7px;
          color: #383d45;
          font-size: 11px;
          font-weight: 850;
          letter-spacing: .25px;
        }


        /* ================= SCOPES ================= */

        .scope-options {
          display: flex;
          flex-wrap: wrap;
          gap: 9px;
          margin-bottom: 18px;
        }

        .scope-pill {
          height: 28px;
          padding: 0 10px;
          display: inline-flex;
          align-items: center;
          gap: 5px;
          border: 1px solid #e2e3e5;
          border-radius: 4px;
          background: #f7f7f8;
          color: #4d535c;
          font-size: 11.5px;
          font-weight: 700;
          cursor: pointer;
        }

        /* ONLY USER-SELECTED SCOPE BECOMES BEETROOT */
        .scope-pill.selected {
          background: #650033;
          border-color: #650033;
          color: #ffffff;
        }


        /* ================= INPUTS ================= */

        .input-box {
          height: 31px;
          width: 100%;
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 0 10px;
          border: 1px solid #e6e7e9;
          border-radius: 6px;
          background: #ffffff;
        }

        .input-box > span {
          color: #7a7f87;
          font-size: 15px;
        }

        .input-box input {
          width: 100%;
          border: 0;
          outline: none;
          background: transparent;
          color: #444a52;
          font-family: inherit;
          font-size: 12.5px;
        }

        .field-note {
          margin: 9px 0 0;
          color: #8a6f7e;
          font-family: monospace;
          font-size: 10px;
          letter-spacing: .8px;
        }


        /* ================= FORM ================= */

        .form-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
        }

        .emergency-field {
          margin-top: 15px;
        }

        .form-field label span {
          color: #765968;
          font-weight: 600;
        }


        /* ================= TELEMETRY ================= */

        .telemetry-options {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .telemetry-option {
          display: flex;
          align-items: flex-start;
          gap: 10px;
          padding: 12px 10px;
          border: 1px solid #ececee;
          border-radius: 6px;
          cursor: pointer;
          transition: .2s ease;
        }

        .telemetry-option.selected {
          border: 2px solid #72003e;
          padding: 11px 9px;
        }

        .radio {
          width: 12px;
          height: 12px;
          margin-top: 2px;
          border: 1px solid #a5a8ad;
          border-radius: 50%;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .selected .radio {
          border-color: #72003e;
        }

        .selected .radio::after {
          content: "";
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #72003e;
        }

        .telemetry-content {
          flex: 1;
        }

        .telemetry-title {
          display: flex;
          align-items: center;
          gap: 7px;
          color: #33383f;
          font-size: 13px;
          font-weight: 800;
        }

        .recommended {
          padding: 3px 5px;
          border-radius: 3px;
          background: #72003e;
          color: white;
          font-size: 9px;
          letter-spacing: .3px;
        }

        .telemetry-description {
          margin: 6px 0 0;
          color: #60666f;
          font-size: 12px;
          line-height: 1.5;
        }


        /* ================= AUTHORIZE ================= */

        .authorize-button {
          width: 100%;
          height: 42px;
          border: 1px solid #650033;
          border-radius: 6px;
          background: #650033;
          color: #ffffff;
          font-size: 13px;
          font-weight: 800;
          letter-spacing: .2px;
          box-shadow: 0 5px 12px rgba(101, 0, 51, .12);
        }

        .authorize-button span {
          margin-left: 7px;
          font-size: 16px;
        }

        .authorize-note {
          margin-top: -12px;
          padding-left: 2px;
          color: #806b76;
          font-family: monospace;
          font-size: 8px;
          letter-spacing: .7px;
        }


        /* ================= SIDEBAR ================= */

        .intake-right {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .side-card {
          padding: 20px;
        }

        .side-card-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 10px;
          margin-bottom: 13px;
        }

        .side-card-header h3 {
          margin: 0;
          color: #282c31;
          font-family: "Plus Jakarta Sans", "Inter", Arial, sans-serif;
          font-size: 16px;
          font-weight: 650;
          letter-spacing: -.3px;
        }

        .validated {
          padding: 4px 7px;
          border-radius: 3px;
          background: #b9f2ad;
          color: #24652b;
          font-size: 9px;
          font-weight: 850;
        }

        .tier-badge {
          padding: 4px 6px;
          border-radius: 3px;
          background: #eceeef;
          color: #60656c;
          font-size: 8px;
          font-weight: 850;
        }


        /* ================= RECAP ================= */

        .recap-list {
          display: flex;
          flex-direction: column;
          gap: 7px;
        }

        .recap-row {
          min-height: 27px;
          padding: 0 10px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 15px;
          border-radius: 5px;
          background: #f0f1f2;
        }

        .recap-row span {
          color: #5e646d;
          font-size: 12px;
          font-weight: 600;
        }

        .recap-row strong {
          color: #373c44;
          font-size: 11px;
          text-align: right;
        }

        .handshake {
          margin-top: 13px;
          padding: 10px;
          border-radius: 6px;
          background: #f0f1f2;
        }

        .handshake-header {
          display: flex;
          justify-content: space-between;
          margin-bottom: 9px;
        }

        .handshake-header strong {
          color: #474d55;
          font-family: monospace;
          font-size: 12px;
          letter-spacing: 1px;
        }

        .handshake-header span {
          color: #4d535b;
          font-size: 11px;
          font-weight: 800;
        }

        .handshake-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 4px;
        }

        .handshake-grid div {
          padding: 7px 4px;
          text-align: center;
          background: #ffffff;
          border-radius: 3px;
        }

        .handshake-grid small {
          display: block;
          margin-bottom: 3px;
          color: #858990;
          font-size: 10px;
          font-weight: 700;
        }

        .handshake-grid strong {
          color: #3d424a;
          font-size: 10px;
        }


        /* ================= ARCHITECTS ================= */

        .architect {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 9px;
          margin-bottom: 8px;
          border: 1px solid #e9eaec;
          border-radius: 6px;
        }

        .architect:last-child {
          margin-bottom: 0;
        }

        .architect img {
          width: 36px;
          height: 36px;
          object-fit: cover;
          border-radius: 50%;
          background: #d9dde2;
        }

        .architect-info {
          min-width: 0;
        }

        .architect-name {
          color: #30353d;
          font-size: 12.5px;
          font-weight: 800;
        }

        .architect-title {
          margin-top: 2px;
          color: #711040;
          font-size: 10.5px;
          font-weight: 800;
        }

        .architect-credential {
          margin-top: 2px;
          color: #727881;
          font-size: 10px;
        }


        /* ================= RETENTION ================= */

        .retention-title {
          display: flex;
          align-items: flex-start;
          gap: 9px;
          padding-bottom: 13px;
          border-bottom: 1px solid #eeeeef;
        }

        .retention-icon {
          color: #72003e;
          font-size: 15px;
        }

        .retention-title h3 {
          margin: 0;
          color: #30343b;
          font-family: "Plus Jakarta Sans", "Inter", Arial, sans-serif;
          font-size: 16px;
          line-height: 1.25;
        }

        .retention-card > p {
          margin: 13px 0 15px;
          color: #555b64;
          font-size: 12.5px;
          line-height: 1.55;
        }

        .retention-certificates {
          display: flex;
          justify-content: space-between;
          gap: 10px;
          color: #4b5159;
          font-size: 10px;
          font-weight: 800;
          letter-spacing: .8px;
        }


        /* ================= INCIDENT ================= */

        .incident-banner {
          max-width: 1180px;
          min-height: 104px;
          margin: 37px auto 0;
          padding: 18px 25px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 25px;
          border-radius: 8px;
          background: #5e0030;
          color: white;
          box-shadow: 0 7px 18px rgba(60, 0, 32, .12);
        }

        .incident-content {
          display: flex;
          align-items: center;
          gap: 15px;
        }

        .incident-icon {
          width: 35px;
          height: 35px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          background: #ffd6dc;
          color: #9b2941;
          flex-shrink: 0;
        }

        .incident-content h2 {
          margin: 0;
          font-family: "Plus Jakarta Sans", "Inter", Arial, sans-serif;
          font-size: 20px;
          line-height: 1.1;
          letter-spacing: -.5px;
        }

        .incident-content p {
          margin: 7px 0 0;
          color: #e8cdd9;
          font-size: 12px;
        }

        .incident-actions {
          display: flex;
          align-items: center;
          gap: 10px;
          flex-shrink: 0;
        }

        .incident-phone,
        .incident-email {
          height: 37px;
          display: flex;
          align-items: center;
          padding: 0 13px;
          border-radius: 5px;
          text-decoration: none;
          font-size: 12px;
          font-weight: 800;
          white-space: nowrap;
        }

        .incident-phone {
          background: white;
          color: #5d1637;
        }

        .incident-email {
          background: #771044;
          color: white;
        }


        /* ================= LAPTOP ================= */

        @media (max-width: 1050px) {

          .security-intake {
            padding-left: 20px;
            padding-right: 20px;
          }

          .intake-heading h1 {
            font-size: 30px;
          }

          .intake-grid {
            grid-template-columns: 1.45fr 1fr;
          }

          .incident-banner {
            flex-direction: column;
            align-items: flex-start;
          }

          .incident-actions {
            width: 100%;
          }

          .incident-actions a {
            flex: 1;
          }

        }


        /* ================= TABLET ================= */

        @media (max-width: 800px) {

          .intake-top-row {
            flex-direction: column;
            align-items: flex-start;
          }

          .intake-security {
            width: 100%;
            justify-content: space-between;
          }

          .progress-bar {
            grid-template-columns: 1fr;
          }

          .intake-grid {
            grid-template-columns: 1fr;
          }

          .intake-right {
            display: grid;
            grid-template-columns: 1fr 1fr;
            align-items: start;
          }

          .retention-card {
            grid-column: 1 / -1;
          }

        }


        /* ================= MOBILE ================= */

        @media (max-width: 600px) {

          .security-intake {
            padding: 25px 12px;
          }

          .intake-label {
            font-size: 7px;
            line-height: 1.3;
            padding: 6px 10px;
          }

          .intake-security {
            flex-wrap: wrap;
            font-size: 7px;
            gap: 7px;
          }

          .intake-heading {
            margin-top: 22px;
          }

          .intake-heading h1 {
            font-size: 25px;
            letter-spacing: -1px;
          }

          .intake-heading p {
            font-size: 10.5px;
          }

          .progress-bar {
            margin-top: 21px;
          }

          .intake-grid {
            margin-top: 20px;
          }

          .intake-card,
          .side-card {
            padding: 18px 15px;
          }

          .section-label {
            font-size: 10.5px;
          }

          .section-top h2 {
            font-size: 22px;
          }

          .section-icon {
            font-size: 20px;
          }

          .section-description {
            font-size: 12.5px;
          }

          .field-label,
          .form-field label {
            font-size: 10px;
          }

          .scope-options {
            gap: 7px;
          }

          .scope-pill {
            height: auto;
            min-height: 28px;
            padding: 6px 8px;
            font-size: 10.5px;
          }

          .input-box > span {
            font-size: 14px;
          }

          .input-box input {
            font-size: 12px;
          }

          .field-note {
            font-size: 9px;
          }

          .form-grid {
            grid-template-columns: 1fr;
            gap: 13px;
          }

          .telemetry-title {
            font-size: 11px;
            line-height: 1.35;
          }

          .telemetry-description {
            font-size: 10px;
          }

          .recommended {
            font-size: 8px;
          }

          .architect-name {
            font-size: 11.5px;
          }

          .architect-title {
            font-size: 9.5px;
          }

          .architect-credential {
            font-size: 9px;
          }

          .retention-card > p {
            font-size: 11px;
          }

          .retention-certificates {
            font-size: 9px;
          }

          .recap-row span {
            font-size: 10px;
          }

          .recap-row strong {
            font-size: 10px;
          }

          .handshake-header strong {
            font-size: 9px;
          }

          .handshake-header span {
            font-size: 9px;
          }

          .handshake-grid small {
            font-size: 8px;
          }

          .handshake-grid strong {
            font-size: 9px;
          }

          .intake-right {
            display: flex;
          }

          .incident-banner {
            margin-top: 28px;
            padding: 18px 15px;
          }

          .incident-content {
            align-items: flex-start;
          }

          .incident-content h2 {
            font-size: 17px;
          }

          .incident-content p {
            line-height: 1.4;
          }

          .incident-actions {
            flex-direction: column;
            width: 100%;
          }

          .incident-actions a {
            width: 100%;
            justify-content: center;
          }

        }

      `})]})}function r({label:t,value:n}){return e.jsxs("div",{className:"recap-row",children:[e.jsx("span",{children:t}),e.jsx("strong",{children:n})]})}function c({selected:t,onClick:n,title:s,description:a,recommended:o}){return e.jsxs("div",{className:`telemetry-option ${t?"selected":""}`,onClick:n,children:[e.jsx("div",{className:"radio"}),e.jsxs("div",{className:"telemetry-content",children:[e.jsxs("div",{className:"telemetry-title",children:[s,o&&e.jsx("span",{className:"recommended",children:"RECOMMENDED"})]}),e.jsx("p",{className:"telemetry-description",children:a})]})]})}function p({image:t,name:n,title:s,credential:a}){return e.jsxs("div",{className:"architect",children:[e.jsx("img",{loading:"lazy",decoding:"async",src:t,alt:n}),e.jsxs("div",{className:"architect-info",children:[e.jsx("div",{className:"architect-name",children:n}),e.jsx("div",{className:"architect-title",children:s}),e.jsx("div",{className:"architect-credential",children:a})]})]})}export{m as default};
