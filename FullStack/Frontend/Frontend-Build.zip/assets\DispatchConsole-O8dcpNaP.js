import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as n}from"./vendor-router-L4ZCoGSs.js";function N(){const[d,p]=n.useState(null),[c,x]=n.useState(null),[s,m]=n.useState({email:"",name:"",vector:"",meetingFormat:""}),[a,r]=n.useState({}),h=[{day:"MON",date:"14 Oct",open:"2 Open"},{day:"TUE",date:"15 Oct",open:"3 Open"},{day:"WED",date:"16 Oct",open:"3 Open"},{day:"THU",date:"17 Oct",open:"1 Open"},{day:"FRI",date:"18 Oct",open:"4 Open"}],f=["10:00 AM","11:30 AM","02:00 PM","04:30 PM","06:00 PM"],o=(i,t)=>{m(l=>({...l,[i]:t})),r(l=>({...l,[i]:""}))},g=i=>{p(i),r(t=>({...t,date:""}))},v=i=>{x(i),r(t=>({...t,time:""}))},u=()=>{const i={};d===null&&(i.date="Please select a business day"),c===null&&(i.time="Please select a 45-minute window"),s.email.trim()?/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s.email)||(i.email="Please enter a valid email address"):i.email="Please enter your corporate work email",s.name.trim()||(i.name="Please enter your full name and executive title"),s.vector.trim()||(i.vector="Please enter your primary vector of focus"),s.meetingFormat.trim()||(i.meetingFormat="Please enter your meeting format"),r(i),!(Object.keys(i).length>0)&&(window.location.href="/advisory-confirmation")};return e.jsxs("section",{className:"advisory-booking-section",children:[e.jsxs("div",{className:"advisory-booking-container",children:[e.jsxs("div",{className:"advisory-left-column",children:[e.jsxs("div",{className:"advisory-card leadership-card",children:[e.jsxs("div",{className:"card-top-row",children:[e.jsx("span",{className:"small-heading",children:"LEADERSHIP ROSTER"}),e.jsx("span",{className:"active-advisors",children:"ACTIVE ADVISORS"})]}),e.jsx("div",{className:"card-divider"}),e.jsxs("div",{className:"advisor-row",children:[e.jsx("div",{className:"advisor-photo",children:e.jsx("img",{loading:"lazy",decoding:"async",src:"https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=100&q=80",alt:"Advisor"})}),e.jsxs("div",{className:"advisor-info",children:[e.jsxs("div",{className:"advisor-name",children:["Dr. Evelyn Vance",e.jsx("span",{className:"verified",children:"✿"})]}),e.jsx("div",{className:"advisor-role",children:"Principal Director & Chief Cyber Architect"}),e.jsx("div",{className:"advisor-detail",children:"CISSP · CISM · ex-DARPA Cyber Fellow"})]})]}),e.jsx("div",{className:"advisor-divider"}),e.jsxs("div",{className:"advisor-row",children:[e.jsx("div",{className:"advisor-initials",children:"MC"}),e.jsxs("div",{className:"advisor-info",children:[e.jsxs("div",{className:"advisor-name",children:["Marcus Chen",e.jsx("span",{className:"verified",children:"✿"})]}),e.jsx("div",{className:"advisor-role",children:"VP, Autonomous Threat Defense & Zero-Trust"}),e.jsxs("div",{className:"advisor-detail",children:["Cloud Security Alliance Fellow · Former Red",e.jsx("br",{}),"Team Lead"]})]})]})]}),e.jsxs("div",{className:"advisory-card receive-card",children:[e.jsxs("h2",{className:"receive-title",children:[e.jsx("span",{className:"receive-title-icon",children:"▣"}),"What You Will Receive"]}),e.jsxs("div",{className:"receive-list",children:[e.jsxs("div",{className:"receive-item",children:[e.jsx("span",{className:"receive-icon",children:"◎"}),e.jsxs("div",{children:[e.jsx("div",{className:"receive-item-title",children:"Custom Threat Perimeter Diagnostic"}),e.jsx("div",{className:"receive-item-text",children:"Real-time analysis of attack surface telemetry and exposed endpoints."})]})]}),e.jsxs("div",{className:"receive-item",children:[e.jsx("span",{className:"receive-icon",children:"✣"}),e.jsxs("div",{children:[e.jsx("div",{className:"receive-item-title",children:"Vector Squad Mobilization Blueprint"}),e.jsx("div",{className:"receive-item-text",children:"Targeted technical allocation plan tailored to your infrastructure stack."})]})]}),e.jsxs("div",{className:"receive-item",children:[e.jsx("span",{className:"receive-icon",children:"▣"}),e.jsxs("div",{children:[e.jsx("div",{className:"receive-item-title",children:"Executive Board-Ready Summary Deck"}),e.jsxs("div",{className:"receive-item-text",children:["High-impact executive-ready slides framing institutional exposure",e.jsx("br",{}),"risk."]})]})]}),e.jsxs("div",{className:"receive-item",children:[e.jsx("span",{className:"receive-icon",children:"☑"}),e.jsxs("div",{children:[e.jsx("div",{className:"receive-item-title",children:"Remediation Priority Index (30-60-90 Days)"}),e.jsxs("div",{className:"receive-item-text",children:["Chronological priority matrix resolving foundational vulnerabilities",e.jsx("br",{}),"first."]})]})]})]})]})]}),e.jsxs("div",{className:"advisory-card dispatch-card",children:[e.jsxs("div",{className:"dispatch-header",children:[e.jsxs("div",{children:[e.jsx("div",{className:"small-heading",children:"LIVE DISPATCH CONSOLE"}),e.jsx("h2",{className:"dispatch-title",children:"Select Date & Transmission Details"})]}),e.jsx("div",{className:"calendar-icon",children:"▣"})]}),e.jsx("div",{className:"card-divider"}),e.jsxs("div",{className:"form-step",children:[e.jsx("div",{className:"step-title",children:"Step 1 · Confirm Regional Timezone"}),e.jsx("div",{className:"timezone-box",children:"IST — India Standard Time (UTC+05:30)"})]}),e.jsxs("div",{className:"form-step date-step",children:[e.jsxs("div",{className:"step-heading-row",children:[e.jsx("div",{className:"step-title",children:"Step 2 · Select Business Day"}),e.jsx("span",{className:"slots-available",children:"3 slots available"})]}),e.jsx("div",{className:"date-grid",children:h.map((i,t)=>e.jsxs("button",{type:"button",className:`date-box ${d===t?"selected":""}`,onClick:()=>g(t),children:[e.jsx("span",{className:"date-day",children:i.day}),e.jsx("span",{className:"date-number",children:i.date}),e.jsx("span",{className:"date-open",children:d===t?"Selected":i.open})]},t))}),a.date&&e.jsx("div",{className:"field-error",children:a.date})]}),e.jsxs("div",{className:"form-step time-step",children:[e.jsx("div",{className:"step-title",children:"Step 3 · Select 45-Minute Window"}),e.jsx("div",{className:"time-grid",children:f.map((i,t)=>e.jsx("button",{type:"button",className:`time-box ${c===t?"selected":""}`,onClick:()=>v(t),children:i},i))}),a.time&&e.jsx("div",{className:"field-error",children:a.time})]}),e.jsxs("div",{className:"dispatch-form",children:[e.jsxs("div",{className:"form-grid",children:[e.jsxs("div",{className:"field-group",children:[e.jsx("label",{children:"Corporate Work Email *"}),e.jsxs("div",{className:"input-with-icon",children:[e.jsx("input",{type:"email",value:s.email,onChange:i=>o("email",i.target.value),placeholder:"ciso@organization.com",className:a.email?"input-error":""}),s.email&&!a.email&&e.jsx("span",{className:"input-check",children:"✓"})]}),a.email&&e.jsx("div",{className:"field-error",children:a.email})]}),e.jsxs("div",{className:"field-group",children:[e.jsx("label",{children:"Full Name & Executive Title *"}),e.jsx("input",{type:"text",value:s.name,onChange:i=>o("name",i.target.value),placeholder:"e.g., Katherine Montgomery, CISO",className:a.name?"input-error":""}),a.name&&e.jsx("div",{className:"field-error",children:a.name})]}),e.jsxs("div",{className:"field-group",children:[e.jsx("label",{children:"Primary Vector of Focus *"}),e.jsx("input",{type:"text",value:s.vector,onChange:i=>o("vector",i.target.value),placeholder:"Select your primary security focus...",className:a.vector?"input-error":""}),a.vector&&e.jsx("div",{className:"field-error",children:a.vector})]}),e.jsxs("div",{className:"field-group",children:[e.jsx("label",{children:"Meeting Format *"}),e.jsx("input",{type:"text",value:s.meetingFormat,onChange:i=>o("meetingFormat",i.target.value),placeholder:"Select meeting format...",className:a.meetingFormat?"input-error":""}),a.meetingFormat&&e.jsx("div",{className:"field-error",children:a.meetingFormat})]})]}),e.jsxs("button",{type:"button",className:"confirm-button",onClick:u,children:["CONFIRM & DISPATCH ADVISORY CALENDAR INVITE",e.jsx("span",{children:"→"})]}),e.jsxs("div",{className:"security-note",children:[e.jsx("span",{className:"lock-icon",children:"♙"}),e.jsx("span",{children:"Instant calendar invitation sent via 256-bit encrypted channel. Strictly non-sales technical advisory."})]})]})]})]}),e.jsx("style",{children:`

        * {
          box-sizing: border-box;
        }


        /* =========================================
           MAIN SECTION
        ========================================= */

        .advisory-booking-section {
          width: 100%;
          min-height: 720px;

          padding: 32px 20px 40px;

          background: #ffffff;

          font-family: "Inter", Arial, sans-serif;

          color: #273047;
        }


        .advisory-booking-container {
          width: 100%;
          max-width: 1080px;

          margin: 0 auto;

          display: grid;

          grid-template-columns: 1fr 1.72fr;

          gap: 22px;

          align-items: start;
        }


        /* =========================================
           COMMON CARD
        ========================================= */

        .advisory-card {
          background: #f8f9fb;

          border: 1px solid #e2e7ee;

          border-radius: 15px;

          box-shadow:
            0 5px 15px rgba(26, 36, 55, 0.06);

          overflow: hidden;
        }


        /* =========================================
           LEFT COLUMN
        ========================================= */

        .advisory-left-column {
          display: flex;

          flex-direction: column;

          gap: 20px;
        }


        .leadership-card {
          padding: 27px 29px 25px;
        }


        .card-top-row {
          display: flex;

          align-items: center;

          justify-content: space-between;
        }


        .small-heading {
          color: #731044;

          font-size: 11px;

          font-weight: 800;

          letter-spacing: 1.25px;
        }


        .active-advisors {
          display: inline-flex;

          align-items: center;

          height: 21px;

          padding: 0 10px;

          border-radius: 4px;

          background: #dce7df;

          color: #315c43;

          font-size: 9px;

          font-weight: 700;
        }


        .card-divider {
          width: 100%;

          height: 1px;

          margin: 14px 0;

          background: #e1e6ed;
        }


        /* =========================================
           ADVISORS
        ========================================= */

        .advisor-row {
          display: flex;

          align-items: flex-start;

          gap: 14px;
        }


        .advisor-photo {
          width: 50px;

          height: 50px;

          flex-shrink: 0;

          border-radius: 7px;

          overflow: hidden;

          background: #ddd;
        }


        .advisor-photo img {
          width: 100%;

          height: 100%;

          object-fit: cover;
        }


        .advisor-initials {
          width: 50px;

          height: 50px;

          flex-shrink: 0;

          display: flex;

          align-items: center;

          justify-content: center;

          border-radius: 9px;

          background: #68003a;

          color: #ffffff;

          font-size: 16px;

          font-weight: 700;
        }


        .advisor-info {
          min-width: 0;

          padding-top: 1px;
        }


        .advisor-name {
          color: #263046;

          font-size: 15px;

          font-weight: 750;

          line-height: 1.2;
        }


        .verified {
          margin-left: 5px;

          color: #7c0b4d;

          font-size: 12px;
        }


        .advisor-role {
          margin-top: 4px;

          color: #657187;

          font-size: 12px;

          line-height: 1.3;

          font-weight: 500;
        }


        .advisor-detail {
          margin-top: 3px;

          color: #8090a4;

          font-size: 11px;

          line-height: 1.35;
        }


        .advisor-divider {
          width: 100%;

          height: 1px;

          margin: 13px 0;

          background: #e3e7ed;
        }


        /* =========================================
           RECEIVE CARD
        ========================================= */

        .receive-card {
          padding: 27px 29px 25px;
        }


        .receive-title {
          display: flex;

          align-items: center;

          gap: 9px;

          margin: 0 0 19px;

          color: #273047;

          font-size: 18px;

          line-height: 1.2;

          font-weight: 750;
        }


        .receive-title-icon {
          color: #7b0b4d;

          font-size: 19px;
        }


        .receive-list {
          display: flex;

          flex-direction: column;

          gap: 14px;
        }


        .receive-item {
          display: flex;

          align-items: flex-start;

          gap: 11px;
        }


        .receive-icon {
          width: 18px;

          flex-shrink: 0;

          color: #7e0a4d;

          font-size: 17px;

          line-height: 1.2;

          text-align: center;
        }


        .receive-item-title {
          color: #2f374b;

          font-size: 13px;

          font-weight: 750;

          line-height: 1.25;
        }


        .receive-item-text {
          margin-top: 2px;

          color: #738197;

          font-size: 11px;

          line-height: 1.3;
        }


        /* =========================================
           DISPATCH CARD
        ========================================= */

        .dispatch-card {
          padding: 34px 36px 29px;
        }


        .dispatch-header {
          display: flex;

          align-items: flex-start;

          justify-content: space-between;
        }


        .dispatch-title {
          margin: 4px 0 0;

          color: #263047;

          font-size: 18px;

          line-height: 1.2;

          font-weight: 750;
        }


        .calendar-icon {
          color: #790b4d;

          font-size: 21px;

          line-height: 1;

          margin-top: 8px;
        }


        .dispatch-card > .card-divider {
          margin: 17px 0 22px;
        }


        /* =========================================
           FORM STEPS
        ========================================= */

        .form-step {
          margin-bottom: 21px;
        }


        .step-title {
          margin-bottom: 8px;

          color: #30394d;

          font-size: 13px;

          font-weight: 750;
        }


        .step-heading-row {
          display: flex;

          align-items: center;

          justify-content: space-between;
        }


        .slots-available {
          color: #741044;

          font-size: 10px;

          font-weight: 750;
        }


        .timezone-box {
          width: 100%;

          height: 37px;

          display: flex;

          align-items: center;

          padding: 0 17px;

          background: #ffffff;

          border: 1px solid #d9e0e9;

          border-radius: 7px;

          color: #5e697c;

          font-size: 12px;

          font-weight: 600;
        }


        /* =========================================
           DATE SELECTOR
        ========================================= */

        .date-grid {
          display: grid;

          grid-template-columns:
            repeat(5, 1fr);

          gap: 8px;

          margin-top: 8px;
        }


        .date-box {
          height: 82px;

          display: flex;

          flex-direction: column;

          align-items: center;

          justify-content: center;

          gap: 5px;

          border: 1px solid #e0e6ee;

          border-radius: 9px;

          background: #ffffff;

          cursor: pointer;

          font-family: inherit;

          transition:
            border-color 0.2s ease,
            box-shadow 0.2s ease,
            background 0.2s ease;
        }


        .date-box:hover {
          border-color: #a8326d;
        }


        .date-box.selected {
          border: 2px solid #85034a;

          background: #fff9fc;

          box-shadow:
            0 0 0 1px rgba(133, 3, 74, 0.04);
        }


        .date-day {
          color: #657187;

          font-size: 10px;

          font-weight: 700;
        }


        .date-number {
          color: #2c3549;

          font-size: 14px;

          font-weight: 750;
        }


        .date-open {
          color: #8793a6;

          font-size: 9px;
        }


        .date-box.selected .date-day,
        .date-box.selected .date-number,
        .date-box.selected .date-open {
          color: #7d0848;
        }


        .date-box.selected .date-open {
          font-weight: 700;
        }


        /* =========================================
           TIME SELECTOR
        ========================================= */

        .time-step {
          margin-bottom: 17px;
        }


        .time-grid {
          display: grid;

          grid-template-columns:
            repeat(5, 1fr);

          gap: 8px;

          margin-top: 8px;
        }


        .time-box {
          height: 35px;

          border: 1px solid #dfe5ed;

          border-radius: 7px;

          background: #ffffff;

          color: #556176;

          font-family: inherit;

          font-size: 11px;

          font-weight: 650;

          cursor: pointer;

          transition: 0.2s ease;
        }


        .time-box:hover {
          border-color: #9d2762;
        }


        .time-box.selected {
          border-color: #85034a;

          background: #85034a;

          color: #ffffff;
        }


        /* =========================================
           FORM
        ========================================= */

        .dispatch-form {
          border-top: 1px solid #e1e6ed;

          padding-top: 9px;
        }


        .form-grid {
          display: grid;

          grid-template-columns:
            1fr 1fr;

          gap: 14px 15px;
        }


        .field-group {
          min-width: 0;
        }


        .field-group label {
          display: block;

          margin-bottom: 6px;

          color: #30394c;

          font-size: 12px;

          font-weight: 750;
        }


        .field-group input {
          width: 100%;

          height: 38px;

          padding: 0 13px;

          border: 1px solid #d7dfe9;

          border-radius: 7px;

          outline: none;

          background: #ffffff;

          color: #4e5b70;

          font-family: inherit;

          font-size: 12px;

          transition:
            border-color 0.2s ease,
            box-shadow 0.2s ease;
        }


        .field-group input:focus {
          border-color: #8b1757;
        }


        .field-group input::placeholder {
          color: #aab3c0;
        }


        .input-with-icon {
          position: relative;
        }


        .input-with-icon input {
          padding-right: 35px;
        }


        .input-check {
          position: absolute;

          right: 11px;

          top: 50%;

          transform: translateY(-50%);

          color: #54755d;

          font-size: 15px;

          font-weight: 700;
        }


        /* =========================================
           VALIDATION
        ========================================= */

        .input-error {
          border-color: #ff4b4b !important;

          box-shadow:
            0 0 0 1px rgba(255, 75, 75, 0.08);
        }


        .field-error {
          margin-top: 5px;

          color: #ff3b3b;

          font-size: 10px;

          line-height: 1.3;

          font-weight: 500;
        }


        /* =========================================
           CONFIRM BUTTON
        ========================================= */

        .confirm-button {
          width: 100%;

          height: 43px;

          margin-top: 14px;

          border: none;

          border-radius: 7px;

          background: #85004a;

          color: #ffffff;

          font-family: inherit;

          font-size: 12px;

          font-weight: 800;

          letter-spacing: 0.45px;

          cursor: pointer;

          box-shadow:
            0 4px 10px rgba(133, 0, 74, 0.14);

          transition:
            background 0.2s ease,
            transform 0.2s ease;
        }


        .confirm-button span {
          margin-left: 5px;

          font-size: 15px;
        }


        .confirm-button:hover {
          background: #6f003e;

          transform: translateY(-1px);
        }


        /* =========================================
           SECURITY NOTE
        ========================================= */

        .security-note {
          display: flex;

          align-items: center;

          justify-content: center;

          gap: 6px;

          margin-top: 16px;

          color: #98a5b7;

          font-size: 11.5px;
          font-weight: 500;
          line-height: 1.3;

          text-align: center;
        }


        .lock-icon {
          color: #8a2058;

          font-size: 11px;
        }


        /* =========================================
           TABLET
        ========================================= */

        @media (max-width: 900px) {

          .advisory-booking-container {
            grid-template-columns: 1fr;

            max-width: 680px;
          }

          .advisory-left-column {
            order: 2;
          }

          .dispatch-card {
            order: 1;
          }
        }


        /* =========================================
           MOBILE
        ========================================= */

        @media (max-width: 600px) {

          .advisory-booking-section {
            padding: 20px 12px 30px;
          }

          .advisory-booking-container {
            gap: 16px;
          }

          .leadership-card,
          .receive-card {
            padding: 22px 19px;
          }

          .dispatch-card {
            padding: 24px 18px 22px;
          }

          .dispatch-title {
            font-size: 17px;
          }

          .date-grid {
            gap: 5px;
          }

          .date-box {
            height: 75px;
          }

          .date-number {
            font-size: 12px;
          }

          .time-grid {
            grid-template-columns:
              repeat(2, 1fr);
          }

          .form-grid {
            grid-template-columns: 1fr;

            gap: 12px;
          }

          .confirm-button {
            height: 45px;

            font-size: 10px;
          }

          .security-note {
            font-size: 8px;
          }
        }


        /* =========================================
           SMALL MOBILE
        ========================================= */

        @media (max-width: 420px) {

          .small-heading {
            font-size: 9px;
          }

          .active-advisors {
            font-size: 7px;

            padding: 0 7px;
          }

          .advisor-name {
            font-size: 13px;
          }

          .advisor-role,
          .advisor-detail {
            font-size: 9px;
          }

          .receive-title {
            font-size: 16px;
          }

          .receive-item-title {
            font-size: 11px;
          }

          .receive-item-text {
            font-size: 9px;
          }

          .date-grid {
            grid-template-columns:
              repeat(5, minmax(0, 1fr));
          }

          .date-box {
            height: 70px;

            padding: 3px;
          }

          .date-day {
            font-size: 8px;
          }

          .date-number {
            font-size: 10px;
          }

          .date-open {
            font-size: 7px;
          }

          .dispatch-title {
            font-size: 16px;
          }
        }

      `})]})}export{N as default};
