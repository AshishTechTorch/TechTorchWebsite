import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as a}from"./vendor-router-L4ZCoGSs.js";import{g as t}from"./vendor-gsap-I1jVCVBc.js";import{S as m}from"./ScrollTrigger-DIOrBQLF.js";t.registerPlugin(m);const d=[{number:"01",title:"Data Foundation & Readiness Assessment",description:"Before a single model is trained, we audit your existing data architecture. We identify siloes, clean historical datasets, and establish the robust data pipelines necessary for accurate, hallucination-free AI outputs."},{number:"02",title:"Strategic Model Selection & Fine-Tuning",description:"We match the right architecture to your specific use case, prioritizing smaller, highly-specialized models over monolithic generic solutions to ensure efficiency and cost-effectiveness. Models are then fine-tuned on your proprietary data."},{number:"03",title:"Controlled Deployment & Continuous Monitoring",description:"Rollout begins in controlled, shadow-mode environments. Once performance benchmarks are met, models are deployed to production with persistent monitoring for concept drift and performance degradation, ensuring long-term reliability."}];function f(){const o=a.useRef(null),l=a.useRef([]),i=a.useRef([]);return a.useLayoutEffect(()=>{const r=t.context(()=>{t.set(l.current,{yPercent:-120,opacity:0}),t.set(i.current,{opacity:0,y:25});const n=t.timeline({scrollTrigger:{trigger:o.current,start:"top 75%",end:"bottom 20%",toggleActions:"play none none reverse",invalidateOnRefresh:!0}});d.forEach((s,c)=>{n.to(l.current[c],{yPercent:0,opacity:1,duration:.7,ease:"power3.out"},c===0?0:">-0.15").to(i.current[c],{opacity:1,y:0,duration:.55,ease:"power2.out"},"<0.1")})},o);return()=>{r.revert()}},[]),e.jsx("section",{ref:o,className:`\r
        w-full\r
        overflow-hidden\r
        bg-slate-50\r
        py-10\r
        sm:py-12\r
        md:py-16\r
        lg:py-20\r
      `,children:e.jsxs("div",{className:`\r
          grid\r
          w-full\r
          grid-cols-1\r
          gap-10\r
          px-4\r
          sm:gap-12\r
          sm:px-6\r
          md:px-10\r
          lg:grid-cols-[1fr_1.4fr]\r
          lg:gap-14\r
          lg:px-[100px]\r
        `,children:[e.jsxs("div",{className:`\r
            w-full\r
            lg:sticky\r
            lg:top-[4px]\r
            lg:self-start\r
          `,children:[e.jsx("h2",{className:`\r
              mb-4\r
              text-[22px]\r
              font-bold\r
              leading-[1.25]\r
              text-slate-900\r
              sm:text-[24px]\r
              md:text-[26px]\r
              lg:text-[28px]\r
            `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"The Deployment Methodology"}),e.jsx("p",{className:`\r
              mb-5\r
              max-w-md\r
              text-[14px]\r
              leading-[1.7]\r
              text-slate-600\r
              sm:mb-6\r
              sm:text-[15px]\r
            `,style:{fontFamily:"'Plus Jakarta Sans', sans-serif"},children:"Our three-phased approach guarantees that AI implementation is treated as a strategic business transformation rather than an isolated IT experiment."}),e.jsx("div",{className:"w-full overflow-hidden rounded-lg sm:rounded-xl",children:e.jsx("img",{src:"/DeploymentMethodology.webp",alt:"Team collaborating around a model architecture presentation",loading:"lazy",className:`\r
                block\r
                h-auto\r
                w-full\r
                object-cover\r
                aspect-[16/10]\r
                sm:aspect-[16/10]\r
                md:aspect-[16/10]\r
                lg:aspect-[16/10]\r
              `})})]}),e.jsx("div",{className:"flex w-full min-w-0 flex-col",children:d.map((r,n)=>e.jsxs("div",{className:`
                grid
                grid-cols-[38px_1fr]
                gap-3
                py-5

                sm:grid-cols-[48px_1fr]
                sm:gap-4
                sm:py-6

                md:grid-cols-[56px_1fr]
                md:gap-4
                md:py-7

                lg:grid-cols-[56px_1fr]
                lg:gap-4
                lg:py-7

                ${n!==d.length-1?"border-b border-slate-200":""}

                ${n===0?"pt-0":""}
              `,children:[e.jsx("div",{className:`\r
                  h-[30px]\r
                  overflow-hidden\r
                  sm:h-[34px]\r
                  md:h-[38px]\r
                `,children:e.jsx("span",{ref:s=>l.current[n]=s,className:`\r
                    block\r
                    text-[23px]\r
                    font-bold\r
                    leading-none\r
                    text-slate-300\r
                    sm:text-[27px]\r
                    md:text-[32px]\r
                  `,style:{fontFamily:"'Inter', sans-serif"},children:r.number})}),e.jsxs("div",{ref:s=>i.current[n]=s,className:"min-w-0",children:[e.jsx("h3",{className:`\r
                    mb-2\r
                    text-[15px]\r
                    font-semibold\r
                    leading-[1.4]\r
                    text-slate-900\r
                    sm:text-[16px]\r
                    md:text-[17px]\r
                  `,style:{fontFamily:"'Inter', sans-serif"},children:r.title}),e.jsx("p",{className:`\r
                    text-[13px]\r
                    leading-[1.7]\r
                    text-slate-600\r
                    sm:text-[14px]\r
                    md:text-[14px]\r
                    lg:text-[15px]\r
                  `,style:{fontFamily:"'Inter', sans-serif"},children:r.description})]})]},r.number))})]})})}export{f as default};
