const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/AdminLayout-Bm_4SjDw.js","assets/vendor-query-PraSc8EQ.js","assets/vendor-router-L4ZCoGSs.js","assets/useResource-DD7HWhpz.js","assets/useQueries-DYgTg7QU.js","assets/calendar-NAAeCnJq.js","assets/folder-open-CFJqHBiP.js","assets/megaphone-BiSJ5lJj.js","assets/book-open-BO7FIfpV.js","assets/user-check-CZQgQ3d8.js","assets/user-cog-DJ-wId8C.js","assets/Overview-DzxM7lnW.js","assets/india-BMBYFGPg.js","assets/download-tto1bib7.js","assets/Account-CEcObHXa.js","assets/Admins-CaaqJPke.js","assets/trash-DNXJcwKe.js","assets/Login-DCIVEgh2.js","assets/AccessPage-C_NCWN7m.js","assets/eye-BWH2ZhD-.js","assets/Signup-DsDANmpo.js","assets/ForgotPassword-CsuuI0OS.js","assets/CandidateBlogs-BbSnZ5Nn.js","assets/check-Cj2_y9Sm.js","assets/CandidateInterests-MBIVOJlD.js","assets/ContentPages-CTvWXHOp.js","assets/plus-CTWMKPAz.js","assets/pencil-CCdi9bEo.js","assets/Queries-OYz9cZ2x.js","assets/phone-B3rJcDGo.js","assets/chevron-left-BgtRXmaB.js","assets/mail-3Flp59qD.js","assets/CandidateDashboard-9Atca06f.js","assets/Careers-F9cTpkWY.js","assets/map-pin-1B7qH9Hm.js","assets/Blogs-CI4LwJxq.js","assets/pen-line-C-nQf5I2.js","assets/clock-mGZ0mVau.js","assets/BlogDetail-D-PQxSL3.js","assets/PrivacyPolicy-Bu6oIHTe.js","assets/TalkToExpert-Hmnv84n_.js","assets/TechTorchWay-0a9AkzkY.js","assets/target-CywCxRzC.js","assets/code-hHw_u4Tc.js","assets/box-DfjKeGa2.js","assets/sliders-vertical-CDxa6KJT.js","assets/CaseStudies-DYDiG--N.js","assets/layers-hDcYMYAe.js","assets/OpManagement-DH3eflM6.js","assets/CultureInclusion-CZvodXKe.js","assets/gauge-3hwrYA9q.js","assets/star-DLrGQxjX.js","assets/PeopleManagement-CxTz2WGN.js","assets/user-BaVexer9.js","assets/banknote-4jVf57vK.js","assets/settings-Dm05DpDI.js","assets/WebPortal-C54UIYFQ.js","assets/activity-BBAyi7CR.js","assets/link-2-WSmG37JH.js","assets/PaymentManagement-CEoLh8b6.js","assets/calendar-days-u_cmp8dG.js","assets/chart-line-B_0B5Rbj.js","assets/shopping-bag-D6A6VFV7.js","assets/share-2-Ceim1j9X.js","assets/headphones-BBpbbgVA.js","assets/cloud-DZemR4H4.js","assets/HealthcareHospitalManagementPage-BaMeJ-kI.js","assets/dollar-sign-DIYVpd9y.js","assets/flask-conical-MvLANONi.js","assets/face-slightly-smiling-7YKPLJ1O.js","assets/CrmSolutionsPage-B8X4q0gQ.js","assets/funnel-BHTGezsu.js","assets/cpu-Ck-KdWdO.js","assets/database-Dq2-QkKw.js","assets/clipboard-list-IBvDLiD3.js","assets/EcommerceSolutionsPage-BzSjj2bU.js","assets/sparkles-y22GUl0e.js","assets/wrench-DPA1ctY5.js","assets/ProjectManagementSolutionsPage-Cl_Dsxey.js","assets/AviationManagement-cNmtU5dl.js","assets/repeat-BO6fpr6B.js","assets/SupplyChainManagement-B-MGFQAs.js","assets/trending-down-By1Jtg_6.js","assets/presentation-APq4Nxoy.js","assets/chart-column-4WxSCpbG.js","assets/SoftwareDevelopmentSupportPage-Bd_w8Ex7.js","assets/smartphone-p6bJo9dM.js","assets/ResourceStaffingPage-DsO9KNEG.js","assets/CloudInfrastructurePage-BSy4zSb0.js","assets/server-CFlBJMp5.js","assets/SoftwareEngineeringOutsourcingPage-BaPmr_t7.js","assets/globe-B6UvVB5H.js","assets/puzzle-C3zZqws7.js","assets/infinity-CGaQy0RC.js","assets/cloud-upload-BDTn7g9m.js","assets/wifi-ByT-mdN5.js","assets/ITConsultancyPage-BAjBehdA.js","assets/rocket-B5rY7cnH.js","assets/NotFound-B89QEctI.js","assets/ExploreSolutions-Ji9bVEp8.js","assets/arrow-up-right-BppImEly.js","assets/ERP-DH7RZsIH.js","assets/vendor-gsap-I1jVCVBc.js","assets/ScrollTrigger-DIOrBQLF.js","assets/settings-2-D9uA5HLI.js","assets/contact-BfKB-NM2.js","assets/ErpSolutions-CfhBnVTF.js","assets/BuildTechTorch-kdOkkfDZ.js","assets/code-xml-DcjisM7r.js","assets/TechnologyServices-BfZZBhO6.js","assets/brain-circuit-_vGZgfNz.js","assets/id-card-D8Kr7upQ.js","assets/TorchXSuite-6oaDaTsB.js","assets/PhilosophySection-729VSvxr.js","assets/EnterpriseReadiness-BMvandCZ.js","assets/ScaleAtSpeed-douBbsY2.js","assets/badge-check-Ce5jPJWp.js","assets/CoreFoundation-toHT84hX.js","assets/StrategicCapabilities-USbDkn5N.js","assets/TransformationForm-Ny8Er47G.js","assets/FormNotice-DRy7EQ_d.js","assets/EnterpriseAcceleration-dxCX6wL7.js","assets/PracticalIntelligence-Iy5fasDC.js","assets/ProvenImpact-B4K_Tw-E.js","assets/TransformationReady-QZHBMkGo.js","assets/TechTorchView-BIREg2io.js","assets/Philosophy-cEY45yOS.js","assets/Capabilities-C6L8bt8o.js","assets/DeploymentMethodology-Bx4w11Hg.js","assets/Banner-GZippcXm.js","assets/TechnologySection-Bp3CZ70z.js","assets/ConnectSection-BI3g4Zkm.js","assets/OperationalAdvantage-DxnJOHSX.js","assets/IntegratedCapabilities-DqLDFREp.js","assets/IntegratedCapLayout-B3bsjVJG.js","assets/ERPIntegration-BSvJ3Zly.js","assets/DataOrchestration-Ck8jX8zV.js","assets/Legacy-Chf-9jVY.js","assets/ReadSection-CRGMOmia.js","assets/Technologyarticlesection-D-0Owz7R.js","assets/Ecosystem-DUlq6UEU.js","assets/Perspectivesection-DzfliHCa.js","assets/WhatNextSection-Cd_tlYH6.js","assets/CyberSecurityHeroSection-Bs4xKdWH.js","assets/SecurityCapabilities-x_dbd0vd.js","assets/Resiliencepillarssection-QAsk3dyN.js","assets/SecurityOutcomes-CX3Wynm-.js","assets/Securityperspectivesection-C8t0LHx_.js","assets/AboutSecurity-DrdM_Css.js","assets/SecurityChallenge-DoU_o9UL.js","assets/EditorialReflection-CyUFAS1X.js","assets/OurApproach-BMBNf0RJ.js","assets/WhyTechtorch-Co1F265-.js","assets/SecurityInitiative-DZMpSvKl.js","assets/ProtocolDelivery-CoJKjZFz.js","assets/SelectionEngine-CKCewz_G.js","assets/AdvisoryFramework-DAIK2lO8.js","assets/ViewEngagementProtocol-DOq-45Vq.js","assets/AcceptProceed-CiFounzl.js","assets/ExportProtocolPackage-DxH6DO73.js","assets/shield-B_34gOBp.js","assets/file-check-corner-B2WXpt3k.js","assets/lock-keyhole-qgr5czx6.js","assets/clock-3-D3KlVi6Z.js","assets/circle-question-mark-qtdJEbSs.js","assets/AdvisoryDesk-Cvxv9qYH.js","assets/DispatchConsole-O8dcpNaP.js","assets/TimeboxProtocol-pyxTmAqd.js","assets/GrowwTechnology-BYUDtIGd.js","assets/PurspectiveSection-svgiLC0A.js","assets/ArchitectureSection-Dul5OHwZ.js","assets/maximize-2-C1S3cU3D.js","assets/message-square-tRi_lmBc.js","assets/MethodologySection-B9SMvmzQ.js","assets/EcosystemCapabilities-B3u-Ohad.js","assets/plane-Ck-9sxIk.js","assets/monitor-smartphone-BFvZfIbY.js","assets/circle-user-round-C0yQqOzM.js","assets/tag-B_7W0cUZ.js","assets/TechnologyCapabilties-DnaanLId.js","assets/CoreEngineering-DcF3349A.js","assets/MarketExpertise-BwANhUby.js","assets/InstitutionalCommitment-DoelrMKY.js","assets/ParadigmSection-QQ9RqVnw.js","assets/DataDecisions-CuTEm-sR.js","assets/PerspectiveAnalysis-D6zQ_Xzb.js","assets/StrategicInquiry-UZhH5kpi.js","assets/StructuredMethodology-DjJZy2hk.js","assets/OperationalImpact-B53NXc7G.js","assets/Automation-Cp-9PiAy.js","assets/CrossFunctional-DY52o5Y4.js","assets/Discipline-5xfr6PWW.js","assets/ExecutiveStrategy-BLpyiM87.js","assets/Enterprisesolution-_ShPUlbB.js","assets/SystemicAgility-DHx6JoeW.js","assets/workflow-69tH2pJ3.js","assets/clipboard-check-DbnyUuV_.js","assets/ArchitectureLifecycle-DVmyyWUf.js","assets/git-branch-OrFEKSE3.js","assets/ValidatedSystem-BoeDu8sY.js","assets/network-Bh2G015s.js","assets/Businessplatformshero-BaULfw5K.js","assets/OurAproach-BHszDxe9.js","assets/OurPlatforms-pLPrdryJ.js","assets/TechTorchPlatform-B48L0jHj.js","assets/sliders-horizontal-CGLDIiLF.js","assets/DirectEnterprise-b3Od8kXq.js","assets/DigitalSolutionHero-CUGrQVhv.js","assets/DigitalTransformation-DPIXUbRF.js","assets/arrow-down-DweTAvO0.js","assets/OurDigitalSolution-DmssqTnn.js","assets/arrow-left-right-USaLLYUb.js","assets/DiffrentIndustries-C9iUUtTP.js","assets/ConnectedBusiness-B_CGgoVp.js","assets/TechTorchTechnology-DBe4_Eef.js","assets/RequirementReality-BD_Gax97.js","assets/OurServiceHero-B14sQU_z.js","assets/StrategicPerspective-m7jl0SgS.js","assets/PortfolioArchitecture-COUM5Crg.js","assets/DeliveryBlueprint-CKRf7hrb.js","assets/TechnologyRoadmap-BIR-yN8X.js","assets/AiService-BRBgRlDQ.js","assets/AiStrategic-oQ4td8yz.js","assets/radio-DpU8JJLz.js","assets/AiAdvantage-OQtV4anz.js","assets/AiEcosystem-CAMbVoeq.js","assets/AiEcosystemIntegration-DKqTYmRD.js","assets/ItWorkforceVelocity-DzaR74qY.js","assets/ItStrategicperspective-BPmKR4Ph.js","assets/quote-CBjPEsmS.js","assets/ItFlexibleEngagement-CKIcaOYk.js","assets/ItOperational-DXkYZBuJ.js","assets/contracthero-C0atVo6r.js","assets/award-B1x5MxU3.js","assets/CapabilityAnalysis-BGkb6NRs.js","assets/Pipeline-Xr1Rtqkt.js","assets/ContractToHireHero-3tdPDq9g.js","assets/sparkle-Dv8biG0b.js","assets/CthFramework-C1xWjZMg.js","assets/BuildConfidence-DfZK3aQI.js","assets/DdHero-CvAOYFu6.js","assets/users-round-zqzrZbB5.js","assets/DdOverview-EO4LjQSk.js","assets/DdStrenghten-DbtmS--1.js","assets/ReHero-44IoL9BJ.js","assets/CapabilityOverview-Cyr-vxkk.js","assets/ReStrengthen-CcrlKf5X.js","assets/PbhHero-DPyTEPZL.js","assets/PbhExecutive-4jkp5cWa.js","assets/PbhSpecialized-D8RfBHB5.js","assets/route-D9l7JLv1.js","assets/PbhProjectForward-BUF1BWfL.js","assets/RrMain-D8l2qq0x.js","assets/BhMain-BHR6RV_N.js","assets/VpMain-BpO9kYJi.js","assets/BecomePartner-C9AUclEN.js","assets/boxes-npytnxKy.js","assets/briefcase-business-RV2PnsxV.js","assets/MSP1-CW3sFpU7.js","assets/MSP2-B3bJbBPw.js","assets/MSP3-sTV3UIRQ.js","assets/DiscussPriorities-BtwNZimH.js","assets/ConnectMSP-CqQyDbhc.js","assets/video-CZgeA4To.js","assets/list-checks-Fq7zp7z0.js","assets/OffshoreStrategy-CqDHhm-5.js","assets/EngagementArchitecture-X4t4zEZh.js","assets/LifecycleGovernance-bxbdgahR.js","assets/DevelopmentTeam-BPjIgWdT.js","assets/DevelopmentRequirements-KxMS7vsM.js","assets/EducationHero-BUxAqzyb.js","assets/EducationWork-P6iy6Nru.js","assets/EducationTechnology-4dr9Ryfz.js","assets/EducationGrowth-DEdE_KQU.js","assets/EducationMethodology-DGdzuKPq.js","assets/EducationSolutions-B9kQdiu8.js","assets/scale-OZoywk_6.js","assets/ScheduleDiscovery-HBBk3b6l.js","assets/InsuranceHero-00GvdGR8.js","assets/InsuranceSolution-aDwx2viN.js","assets/ConnectedOperations-DoNwCD2L.js","assets/square-B-q76kwd.js","assets/InsuranceDigitalTransformation-cYHN4yeU.js","assets/InsuranceCustomer-C31mzUHP.js","assets/InsuranceWhyTt-B6Ee-P2q.js","assets/arrow-up-B9WqKs8r.js","assets/GetInTouch-BTrrhJ29.js","assets/FinanceHero-BY4RqV1t.js","assets/FinanceArchitecture-DyDpANCZ.js","assets/FinanceTechnology-9Xv2cjFy.js","assets/FinanceKeyBusiness-DQtTOh6r.js","assets/chart-no-axes-column-CxiFapeT.js","assets/circle-dollar-sign-DIuDmbNM.js","assets/FinanceFintech-DSXT0QLy.js","assets/FinanceNextStep-D2G7gn55.js","assets/refresh-ccw-D8YnUzXd.js","assets/FinanceGetInTouch-cpOPN6I_.js","assets/HealthcareHero-I9z5vj6s.js","assets/HealthcareExplore-B-xzxO-F.js","assets/HealthcareTechnology-D9LHGU5b.js","assets/HealthcareOperation-B9Oclbpv.js","assets/ExperianceSecurity-DVx2lhIe.js","assets/InsightOperations-C4ZKO0Xn.js","assets/HealthcareApproach-CCa5XZmu.js","assets/TransformationDesk-BsCQBP3F.js","assets/HealthcareGetInTouch-3sZRH5mP.js","assets/ItHero-B3TJ8_aX.js","assets/ItBusiness-AHCX_wJf.js","assets/ItService-6UnxRByN.js","assets/square-check-big-cnHrFQzE.js","assets/ItSoftware-By1Qfoqr.js","assets/ItDigitalSolution-KcVPjs4s.js","assets/ItInfrastructure-LaLr3RvW.js","assets/ItApproach-uTBHFjH7.js","assets/ItTechTorch-BeNRypD4.js","assets/ItFoundation-VaJlaycJ.js","assets/ITGetInTouch-CFwib9rv.js","assets/ManufacturingHero-DndhiNDl.js","assets/ManufacturingTechnology-CdDEjb_M.js","assets/ManufacturingSolution-BOnCiKUY.js","assets/ManufacturingErp-C2_5rhbs.js","assets/SoftwareEngineering-DVVXyuR7.js","assets/ManufacturingApproach-4LFaNKT1.js","assets/ManufacturingTechTorch-SwHkMLiA.js","assets/ManufacturingGetInTouch-DBalkq1R.js","assets/TcHero-BqAXMsYu.js","assets/TcTechnology-BPBV-iK1.js","assets/TcKeySolution-DJDhIGKO.js","assets/TcSoftwareEngineer-6Zn1O2EC.js","assets/file-code-_VUfQATT.js","assets/TcService-DXLvKHRc.js","assets/TcApproach-BPzTxY-j.js","assets/TcGetInTouch-CDX65QL0.js","assets/EnergyHero-Cd00gdlZ.js","assets/EnergyTechnology-BT3BIXfA.js","assets/EnergyKeySolution-Dq78ve__.js","assets/EnergySoftwareEngineering-Cc01S05P.js","assets/EnergyTechnologyService-DKBm5z1q.js","assets/EnergyApproach-BBgCqMDI.js","assets/EnergyGetInTouch-CI0-Y5mS.js","assets/TransHero-BiudayuU.js","assets/TransportationConnected-qdduw68T.js","assets/TransportationSolution-CDB0knmv.js","assets/TransportationSupplyChain-D1E6_uka.js","assets/TransportationSoftware-Da77jKZM.js","assets/TransportationApproach-DPkqBUGP.js","assets/TransportationEnterprise-Db_x84tC.js","assets/TransportationGetInTouch-CoL_yGmb.js","assets/FmcgHero-D4W1LQ6L.js","assets/FmcgSolution-CxbrSMDN.js","assets/FmcgOurSolution-C-LlNRET.js","assets/FmcgManagement-BSXenbyL.js","assets/FmcgBusiness-XBuKNOKI.js","assets/FmcgSoftwareEngineering-uCO0DI1z.js","assets/FmcgTechnologyService-CI_uWyUG.js","assets/FmcgApproach-7C5qpnja.js","assets/FmcgGetInTouch-E5xwbU2H.js","assets/EcommerceHero-CEAsEiay.js","assets/EcommerceEnterprise-BJmkKlKc.js","assets/EcommerceCapabilities-cZ1R3xA8.js","assets/EcommerceFrontend-73NHsxqr.js","assets/EcommerceSynergy-oBZ0OUch.js","assets/EcommerceCustom-DNcDxSeU.js","assets/EcommerceIntelligence-CzuQ_JaV.js","assets/EcommerceApproach-CVjN6hgr.js","assets/EcommerceNextPhase-BO78NzTM.js","assets/ECommerceGetInTouch-CZn7ZbQW.js","assets/StartConversation-KsxspF6e.js","assets/ExploreQuestions-Cn4y_2Kq.js","assets/ConversationToggle-DySpSvdY.js","assets/Leadership-_svp66Vy.js","assets/CompanyOverview-sBa5I6aA.js","assets/Idea-DliZ_Y7T.js","assets/PartnersEcosystem-Ddyzj0FK.js","assets/Investors-BQm5W54x.js","assets/Media-D61xxtBk.js","assets/OperationsManagementPage-B6zYdHwB.js"])))=>i.map(i=>d[i]);
import{u as Pt,a as Xe,b as Ge,j as i,Q as ay,c as ly}from"./vendor-query-PraSc8EQ.js";import{a as iy,b as oy,g as ry,r as c,c as $m,u as gn,N as ja,O as ep,R as j,d as El,L as ve,e as hn,f as sy,B as cy}from"./vendor-router-L4ZCoGSs.js";(function(){const d=document.createElement("link").relList;if(d&&d.supports&&d.supports("modulepreload"))return;for(const y of document.querySelectorAll('link[rel="modulepreload"]'))f(y);new MutationObserver(y=>{for(const E of y)if(E.type==="childList")for(const S of E.addedNodes)S.tagName==="LINK"&&S.rel==="modulepreload"&&f(S)}).observe(document,{childList:!0,subtree:!0});function x(y){const E={};return y.integrity&&(E.integrity=y.integrity),y.referrerPolicy&&(E.referrerPolicy=y.referrerPolicy),y.crossOrigin==="use-credentials"?E.credentials="include":y.crossOrigin==="anonymous"?E.credentials="omit":E.credentials="same-origin",E}function f(y){if(y.ep)return;y.ep=!0;const E=x(y);fetch(y.href,E)}})();var Pc={exports:{}},Ei={},Jc={exports:{}},Fc={};var km;function uy(){return km||(km=1,(function(s){function d(k,G){var I=k.length;k.push(G);e:for(;0<I;){var ye=I-1>>>1,he=k[ye];if(0<y(he,G))k[ye]=G,k[I]=he,I=ye;else break e}}function x(k){return k.length===0?null:k[0]}function f(k){if(k.length===0)return null;var G=k[0],I=k.pop();if(I!==G){k[0]=I;e:for(var ye=0,he=k.length,_n=he>>>1;ye<_n;){var Aa=2*(ye+1)-1,Sl=k[Aa],St=Aa+1,Oa=k[St];if(0>y(Sl,I))St<he&&0>y(Oa,Sl)?(k[ye]=Oa,k[St]=I,ye=St):(k[ye]=Sl,k[Aa]=I,ye=Aa);else if(St<he&&0>y(Oa,I))k[ye]=Oa,k[St]=I,ye=St;else break e}}return G}function y(k,G){var I=k.sortIndex-G.sortIndex;return I!==0?I:k.id-G.id}if(s.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var E=performance;s.unstable_now=function(){return E.now()}}else{var S=Date,C=S.now();s.unstable_now=function(){return S.now()-C}}var M=[],N=[],R=1,O=null,D=3,ie=!1,K=!1,ae=!1,P=!1,qe=typeof setTimeout=="function"?setTimeout:null,jt=typeof clearTimeout=="function"?clearTimeout:null,xn=typeof setImmediate<"u"?setImmediate:null;function yn(k){for(var G=x(N);G!==null;){if(G.callback===null)f(N);else if(G.startTime<=k)f(N),G.sortIndex=G.expirationTime,d(M,G);else break;G=x(N)}}function vn(k){if(ae=!1,yn(k),!K)if(x(M)!==null)K=!0,pt||(pt=!0,Jt());else{var G=x(N);G!==null&&Je(vn,G.startTime-k)}}var pt=!1,te=-1,Sa=5,Fn=-1;function bn(){return P?!0:!(s.unstable_now()-Fn<Sa)}function Mt(){if(P=!1,pt){var k=s.unstable_now();Fn=k;var G=!0;try{e:{K=!1,ae&&(ae=!1,jt(te),te=-1),ie=!0;var I=D;try{t:{for(yn(k),O=x(M);O!==null&&!(O.expirationTime>k&&bn());){var ye=O.callback;if(typeof ye=="function"){O.callback=null,D=O.priorityLevel;var he=ye(O.expirationTime<=k);if(k=s.unstable_now(),typeof he=="function"){O.callback=he,yn(k),G=!0;break t}O===x(M)&&f(M),yn(k)}else f(M);O=x(M)}if(O!==null)G=!0;else{var _n=x(N);_n!==null&&Je(vn,_n.startTime-k),G=!1}}break e}finally{O=null,D=I,ie=!1}G=void 0}}finally{G?Jt():pt=!1}}}var Jt;if(typeof xn=="function")Jt=function(){xn(Mt)};else if(typeof MessageChannel<"u"){var za=new MessageChannel,zi=za.port2;za.port1.onmessage=Mt,Jt=function(){zi.postMessage(null)}}else Jt=function(){qe(Mt,0)};function Je(k,G){te=qe(function(){k(s.unstable_now())},G)}s.unstable_IdlePriority=5,s.unstable_ImmediatePriority=1,s.unstable_LowPriority=4,s.unstable_NormalPriority=3,s.unstable_Profiling=null,s.unstable_UserBlockingPriority=2,s.unstable_cancelCallback=function(k){k.callback=null},s.unstable_forceFrameRate=function(k){0>k||125<k?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):Sa=0<k?Math.floor(1e3/k):5},s.unstable_getCurrentPriorityLevel=function(){return D},s.unstable_next=function(k){switch(D){case 1:case 2:case 3:var G=3;break;default:G=D}var I=D;D=G;try{return k()}finally{D=I}},s.unstable_requestPaint=function(){P=!0},s.unstable_runWithPriority=function(k,G){switch(k){case 1:case 2:case 3:case 4:case 5:break;default:k=3}var I=D;D=k;try{return G()}finally{D=I}},s.unstable_scheduleCallback=function(k,G,I){var ye=s.unstable_now();switch(typeof I=="object"&&I!==null?(I=I.delay,I=typeof I=="number"&&0<I?ye+I:ye):I=ye,k){case 1:var he=-1;break;case 2:he=250;break;case 5:he=1073741823;break;case 4:he=1e4;break;default:he=5e3}return he=I+he,k={id:R++,callback:G,priorityLevel:k,startTime:I,expirationTime:he,sortIndex:-1},I>ye?(k.sortIndex=I,d(N,k),x(M)===null&&k===x(N)&&(ae?(jt(te),te=-1):ae=!0,Je(vn,I-ye))):(k.sortIndex=he,d(M,k),K||ie||(K=!0,pt||(pt=!0,Jt()))),k},s.unstable_shouldYield=bn,s.unstable_wrapCallback=function(k){var G=D;return function(){var I=D;D=G;try{return k.apply(this,arguments)}finally{D=I}}}})(Fc)),Fc}var Vm;function dy(){return Vm||(Vm=1,Jc.exports=uy()),Jc.exports}var Um;function fy(){if(Um)return Ei;Um=1;var s=dy(),d=iy(),x=oy();function f(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function y(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function E(e){for(var t=e,n=t;n&&!n.alternate;)t=n,(t.flags&4098)!==0&&(e=t.return),n=t.return;for(;t.return;)t=t.return;return t.tag===3?e:null}function S(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function C(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function M(e){if(E(e)!==e)throw Error(f(188))}function N(e){var t=e.alternate;if(!t){if(t=E(e),t===null)throw Error(f(188));return t!==e?null:e}for(var n=e,a=t;;){var l=n.return;if(l===null)break;var o=l.alternate;if(o===null){if(a=l.return,a!==null){n=a;continue}break}if(l.child===o.child){for(o=l.child;o;){if(o===n)return M(l),e;if(o===a)return M(l),t;o=o.sibling}throw Error(f(188))}if(n.return!==a.return)n=l,a=o;else{for(var r=!1,u=l.child;u;){if(u===n){r=!0,n=l,a=o;break}if(u===a){r=!0,a=l,n=o;break}u=u.sibling}if(!r){for(u=o.child;u;){if(u===n){r=!0,n=o,a=l;break}if(u===a){r=!0,a=o,n=l;break}u=u.sibling}if(!r)throw Error(f(189))}}if(n.alternate!==a)throw Error(f(190))}if(n.tag!==3)throw Error(f(188));return n.stateNode.current===n?e:t}function R(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=R(e),t!==null)return t;e=e.sibling}return null}function O(e,t,n,a,l,o){for(;e!==null;){if((e.tag===5||e.tag===27||e.tag===6)&&n(e,a,l,o)||(e.tag!==22||e.memoizedState===null)&&(t||e.tag!==5&&e.tag!==27)&&O(e.child,t,n,a,l,o))return!0;e=e.sibling}return!1}function D(e){for(e=e.return;e!==null;){if(e.tag===3||e.tag===5||e.tag===27)return e;e=e.return}return null}function ie(e){var t=!1;for(e=e.return;e!==null&&(e.tag===4&&(t=!0),!(e.tag===3||e.tag===5||e.tag===27));)e=e.return;return t}function K(e){var t=[null,null],n=D(e);return n===null||ae(t,e,n.child,{foundSelf:!1}),t}function ae(e,t,n,a){for(;n!==null;){if(n===t)a.foundSelf=!0;else if(n.tag===5||n.tag===27||n.tag===6){if(a.foundSelf)return e[1]=n,!0;e[0]=n}else if((n.tag!==22||n.memoizedState===null)&&ae(e,t,n.child,a))return!0;n=n.sibling}return!1}function P(e){switch(e.tag){case 5:case 27:case 6:return e.stateNode;case 3:return e.stateNode.containerInfo;default:throw Error(f(559))}}var qe=null,jt=null;function xn(e,t,n){return e===n?!0:e===t?(qe=e,!0):!1}function yn(e,t,n){return e===n?(jt=e,!1):e===t?(jt!==null&&(qe=e),!0):!1}function vn(e){if(e===null)return null;do e=e===null?null:e.return;while(e&&e.tag!==5&&e.tag!==27&&e.tag!==3);return e||null}function pt(e,t,n){for(var a=0,l=e;l;l=n(l))a++;l=0;for(var o=t;o;o=n(o))l++;for(;0<a-l;)e=n(e),a--;for(;0<l-a;)t=n(t),l--;for(;a--;){if(e===t||t!==null&&e===t.alternate)return e;e=n(e),t=n(t)}return null}var te=Object.assign,Sa=Symbol.for("react.element"),Fn=Symbol.for("react.transitional.element"),bn=Symbol.for("react.portal"),Mt=Symbol.for("react.fragment"),Jt=Symbol.for("react.strict_mode"),za=Symbol.for("react.profiler"),zi=Symbol.for("react.consumer"),Je=Symbol.for("react.context"),k=Symbol.for("react.forward_ref"),G=Symbol.for("react.suspense"),I=Symbol.for("react.suspense_list"),ye=Symbol.for("react.memo"),he=Symbol.for("react.lazy"),_n=Symbol.for("react.activity"),Aa=Symbol.for("react.legacy_hidden"),Sl=Symbol.for("react.memo_cache_sentinel"),St=Symbol.for("react.view_transition"),Oa=Symbol.for("react.recoverable"),uu=Symbol.iterator;function zl(e){return e===null||typeof e!="object"?null:(e=uu&&e[uu]||e["@@iterator"],typeof e=="function"?e:null)}var o0=Symbol.for("react.client.reference");function hr(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===o0?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case Mt:return"Fragment";case za:return"Profiler";case Jt:return"StrictMode";case G:return"Suspense";case I:return"SuspenseList";case _n:return"Activity";case St:return"ViewTransition"}if(typeof e=="object")switch(e.$$typeof){case bn:return"Portal";case Je:return e.displayName||"Context";case zi:return(e._context.displayName||"Context")+".Consumer";case k:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case ye:return t=e.displayName||null,t!==null?t:hr(e.type)||"Memo";case he:t=e._payload,e=e._init;try{return hr(e(t))}catch{}}return null}var Al=Array.isArray,q=d.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,oe=x.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,Wn={pending:!1,data:null,method:null,action:null},mr=[],Na=-1;function kt(e){return{current:e}}function Le(e){0>Na||(e.current=mr[Na],mr[Na]=null,Na--)}function pe(e,t){Na++,mr[Na]=e.current,e.current=t}var Vt=kt(null),Ol=kt(null),Tn=kt(null),Ai=kt(null);function Oi(e,t){switch(pe(Tn,t),pe(Ol,e),pe(Vt,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?Gh(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=Gh(t),e=Qh(t,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}Le(Vt),pe(Vt,e)}function Da(){Le(Vt),Le(Ol),Le(Tn)}function pr(e){var t=e.memoizedState;t!==null&&(yl._currentValue=t.memoizedState,pe(Ai,e)),t=Vt.current;var n=Qh(t,e.type);t!==n&&(pe(Ol,e),pe(Vt,n))}function Ni(e){Ol.current===e&&(Le(Vt),Le(Ol)),Ai.current===e&&(Le(Ai),yl._currentValue=Wn)}var gr,du;function En(e){if(gr===void 0)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);gr=t&&t[1]||"",du=-1<n.stack.indexOf(`
    at`)?" (<anonymous>)":-1<n.stack.indexOf("@")?"@unknown:0:0":""}return`
`+gr+e+du}var xr=!1;function yr(e,t){if(!e||xr)return"";xr=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var a={DetermineComponentFrameRoot:function(){try{if(t){var A=function(){throw Error()};if(Object.defineProperty(A.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(A,[])}catch(L){var g=L}Reflect.construct(e,[],A)}else{try{A.call()}catch(L){g=L}A=!1;try{var T=Object.getOwnPropertyDescriptor(e.prototype,"props");Object.defineProperty(e.prototype,"props",{configurable:!0,set:function(){throw Error()}}),A=!0,new e}finally{A&&(T!==void 0?Object.defineProperty(e.prototype,"props",T):delete e.prototype.props)}}}else{try{throw Error()}catch(L){g=L}(A=e())&&typeof A.catch=="function"&&A.catch(function(){})}}catch(L){if(L&&g&&typeof L.stack=="string")return[L.stack,g.stack]}return[null,null]}};a.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var l=Object.getOwnPropertyDescriptor(a.DetermineComponentFrameRoot,"name");l&&l.configurable&&Object.defineProperty(a.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var o=a.DetermineComponentFrameRoot(),r=o[0],u=o[1];if(r&&u){var m=r.split(`
`),b=u.split(`
`);for(l=a=0;a<m.length&&!m[a].includes("DetermineComponentFrameRoot");)a++;for(;l<b.length&&!b[l].includes("DetermineComponentFrameRoot");)l++;if(a===m.length||l===b.length)for(a=m.length-1,l=b.length-1;1<=a&&0<=l&&m[a]!==b[l];)l--;for(;1<=a&&0<=l;a--,l--)if(m[a]!==b[l]){if(a!==1||l!==1)do if(a--,l--,0>l||m[a]!==b[l]){var w=`
`+m[a].replace(" at new "," at ");return e.displayName&&w.includes("<anonymous>")&&(w=w.replace("<anonymous>",e.displayName)),w}while(1<=a&&0<=l);break}}}finally{xr=!1,Error.prepareStackTrace=n}return(n=e?e.displayName||e.name:"")?En(n):""}function r0(e,t){switch(e.tag){case 26:case 27:case 5:return En(e.type);case 16:return En("Lazy");case 13:return e.child!==t&&t!==null?En("Suspense Fallback"):En("Suspense");case 19:return En("SuspenseList");case 0:case 15:return yr(e.type,!1);case 11:return yr(e.type.render,!1);case 1:return yr(e.type,!0);case 31:return En("Activity");case 30:return En("ViewTransition");default:return""}}function fu(e){try{var t="",n=null;do t+=r0(e,n),n=e,e=e.return;while(e);return t}catch(a){return`
Error generating stack: `+a.message+`
`+a.stack}}var vr=Object.prototype.hasOwnProperty,br=s.unstable_scheduleCallback,_r=s.unstable_cancelCallback,s0=s.unstable_shouldYield,c0=s.unstable_requestPaint,at=s.unstable_now,u0=s.unstable_getCurrentPriorityLevel,hu=s.unstable_ImmediatePriority,mu=s.unstable_UserBlockingPriority,Di=s.unstable_NormalPriority,d0=s.unstable_LowPriority,pu=s.unstable_IdlePriority,f0=s.log,h0=s.unstable_setDisableYieldValue,Nl=null,lt=null;function wn(e){if(typeof f0=="function"&&h0(e),lt&&typeof lt.setStrictMode=="function")try{lt.setStrictMode(Nl,e)}catch{}}var it=Math.clz32?Math.clz32:g0,m0=Math.log,p0=Math.LN2;function g0(e){return e>>>=0,e===0?32:31-(m0(e)/p0|0)|0}var Ci=256,Ri=262144,Li=4194304;function $n(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&-e;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function Mi(e,t,n){var a=e.pendingLanes;if(a===0)return 0;var l=0,o=e.suspendedLanes,r=e.pingedLanes;e=e.warmLanes;var u=a&134217727;return u!==0?(a=u&~o,a!==0?l=$n(a):(r&=u,r!==0?l=$n(r):n||(n=u&~e,n!==0&&(l=$n(n))))):(u=a&~o,u!==0?l=$n(u):r!==0?l=$n(r):n||(n=a&~e,n!==0&&(l=$n(n)))),l===0?0:t!==0&&t!==l&&(t&o)===0&&(o=l&-l,n=t&-t,o>=n||o===32&&(n&4194048)!==0)?t:l}function Dl(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function gu(e,t){(t&8)!==0&&(t|=t&32);var n=e.entangledLanes;if(n!==0)for(e=e.entanglements,n&=t;0<n;){var a=31-it(n),l=1<<a;t|=e[a],n&=~l}return t}function x0(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function xu(){var e=Li;return Li<<=1,(Li&62914560)===0&&(Li=4194304),e}function Tr(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function Cl(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function y0(e,t,n,a,l,o){var r=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var u=e.entanglements,m=e.expirationTimes,b=e.hiddenUpdates;for(n=r&~n;0<n;){var w=31-it(n),A=1<<w;u[w]=0,m[w]=-1;var g=b[w];if(g!==null)for(b[w]=null,w=0;w<g.length;w++){var T=g[w];T!==null&&(T.lane&=-536870913)}n&=~A}a!==0&&yu(e,a,0),o!==0&&l===0&&e.tag!==0&&(e.suspendedLanes|=o&~(r&~t))}function yu(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var a=31-it(t);e.entangledLanes|=t,e.entanglements[a]=e.entanglements[a]|1073741824|n&261930}function vu(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var a=31-it(n),l=1<<a;l&t|e[a]&t&&(e[a]|=t),n&=~l}}function bu(e,t){var n=t&-t;return n=(n&42)!==0?1:Er(n),(n&(e.suspendedLanes|t))!==0?0:n}function Er(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function wr(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function _u(){var e=oe.p;return e!==0?e:(e=window.event,e===void 0?32:Om(e.type))}function Tu(e,t){var n=oe.p;try{return oe.p=e,t()}finally{oe.p=n}}var Ft=Math.random().toString(36).slice(2),Me="__reactFiber$"+Ft,Fe="__reactProps$"+Ft,Ca="__reactContainer$"+Ft,Eu="__reactEvents$"+Ft,v0="__reactListeners$"+Ft,b0="__reactHandles$"+Ft,wu="__reactResources$"+Ft,Rl="__reactMarker$"+Ft,ki="__reactLoad$"+Ft;function Vi(e){delete e[Me],delete e[Fe],delete e[v0],delete e[b0]}function ea(e){var t;if(t=e[Me])return t;for(var n=e.parentNode;n;){if(t=n[Ca]||n[Me]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=cm(e);e!==null;){if(n=e[Me])return n;e=cm(e)}return t}e=n,n=e.parentNode}return null}function Ra(e){if(e=e[Me]||e[Ca]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function Ll(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(f(33))}function La(e){var t=e[wu];return t||(t=e[wu]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function Ne(e){e[Rl]=!0}function ju(e){e[ki]=void 0}var Su=new Set,zu={};function ta(e,t){Ma(e,t),Ma(e+"Capture",t)}function Ma(e,t){for(zu[e]=t,e=0;e<t.length;e++)Su.add(t[e])}var _0=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),Au={},Ou={};function T0(e){return vr.call(Ou,e)?!0:vr.call(Au,e)?!1:_0.test(e)?Ou[e]=!0:(Au[e]=!0,!1)}var le=!1;function Nu(){var e=le;return le=!1,e}function Ui(e,t,n){if(T0(t))if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var a=t.toLowerCase().slice(0,5);if(a!=="data-"&&a!=="aria-"){e.removeAttribute(t);return}}e.setAttribute(t,n)}}function Bi(e,t,n){if(n===null)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,n)}}function Wt(e,t,n,a){if(a===null)e.removeAttribute(n);else{switch(typeof a){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(n);return}e.setAttributeNS(t,n,a)}}function ot(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Du(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function E0(e,t,n){var a=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&typeof a<"u"&&typeof a.get=="function"&&typeof a.set=="function"){var l=a.get,o=a.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return l.call(this)},set:function(r){n=""+r,o.call(this,r)}}),Object.defineProperty(e,t,{enumerable:a.enumerable}),{getValue:function(){return n},setValue:function(r){n=""+r},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function jr(e){if(!e._valueTracker){var t=Du(e)?"checked":"value";e._valueTracker=E0(e,t,""+e[t])}}function Cu(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),a="";return e&&(a=Du(e)?e.checked?"true":"false":e.value),e=a,e!==n?(t.setValue(e),!0):!1}var w0=/[\n"\\]/g;function gt(e){return e.replace(w0,function(t){return"\\"+t.charCodeAt(0).toString(16)+" "})}function Sr(e,t,n,a,l,o,r,u){e.name="",r!=null&&typeof r!="function"&&typeof r!="symbol"&&typeof r!="boolean"?e.type=r:e.removeAttribute("type"),t!=null?r==="number"?(t===0&&e.value===""||e.value!=t)&&(e.value=""+ot(t)):e.value!==""+ot(t)&&(e.value=""+ot(t)):r!=="submit"&&r!=="reset"||e.removeAttribute("value"),t!=null?r==="number"&&e.value==t?zr(e,ot(e.value)):zr(e,ot(t)):n!=null?zr(e,ot(n)):a!=null&&e.removeAttribute("value"),l==null&&o!=null&&(e.defaultChecked=!!o),l!=null&&(e.checked=l&&typeof l!="function"&&typeof l!="symbol"),u!=null&&typeof u!="function"&&typeof u!="symbol"&&typeof u!="boolean"?e.name=""+ot(u):e.removeAttribute("name")}function Ru(e,t,n,a,l,o,r,u){if(o!=null&&typeof o!="function"&&typeof o!="symbol"&&typeof o!="boolean"&&(e.type=o),t!=null||n!=null){if(!(o!=="submit"&&o!=="reset"||t!=null)){jr(e);return}n=n!=null?""+ot(n):"",t=t!=null?""+ot(t):n,u||t===e.value||(e.value=t),e.defaultValue=t}a=a??l,a=typeof a!="function"&&typeof a!="symbol"&&!!a,e.checked=u?e.checked:!!a,e.defaultChecked=!!a,r!=null&&typeof r!="function"&&typeof r!="symbol"&&typeof r!="boolean"&&(e.name=r),jr(e)}function zr(e,t){e.defaultValue!==""+t&&(e.defaultValue=""+t)}function ka(e,t,n,a){if(e=e.options,t){t={};for(var l=0;l<n.length;l++)t["$"+n[l]]=!0;for(n=0;n<e.length;n++)l=t.hasOwnProperty("$"+e[n].value),e[n].selected!==l&&(e[n].selected=l),l&&a&&(e[n].defaultSelected=!0)}else{for(n=""+ot(n),t=null,l=0;l<e.length;l++){if(e[l].value===n){e[l].selected=!0,a&&(e[l].defaultSelected=!0);return}t!==null||e[l].disabled||(t=e[l])}t!==null&&(t.selected=!0)}}function Lu(e,t,n){if(t!=null&&(t=""+ot(t),t!==e.value&&(e.value=t),n==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=n!=null?""+ot(n):""}function Mu(e,t,n,a){if(t==null){if(a!=null){if(n!=null)throw Error(f(92));if(Al(a)){if(1<a.length)throw Error(f(93));a=a[0]}n=a}n==null&&(n=""),t=n}n=ot(t),e.defaultValue=n,a=e.textContent,a===n&&a!==""&&a!==null&&(e.value=a),jr(e)}function Va(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var j0=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function ku(e,t,n){var a=t.indexOf("--")===0;n==null||typeof n=="boolean"||n===""?a?e.setProperty(t,""):t==="float"?e.cssFloat="":e[t]="":a?e.setProperty(t,n):typeof n!="number"||n===0||j0.has(t)?t==="float"?e.cssFloat=n:e[t]=(""+n).trim():e[t]=n+"px"}function Vu(e,t,n){if(t!=null&&typeof t!="object")throw Error(f(62));if(e=e.style,n!=null){for(var a in n)!n.hasOwnProperty(a)||t!=null&&t.hasOwnProperty(a)||(a.indexOf("--")===0?e.setProperty(a,""):a==="float"?e.cssFloat="":e[a]="",le=!0);for(var l in t)a=t[l],t.hasOwnProperty(l)&&n[l]!==a&&(ku(e,l,a),le=!0)}else for(var o in t)t.hasOwnProperty(o)&&ku(e,o,t[o])}function Ar(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var S0=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["maskType","mask-type"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),z0=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Hi(e){return z0.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function Ut(){}var Or=null;function Nr(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var Ua=null,Ba=null;function Uu(e){var t=Ra(e);if(t&&(e=t.stateNode)){var n=e[Fe]||null;e:switch(e=t.stateNode,t.type){case"input":if(Sr(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name),t=n.name,n.type==="radio"&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll('input[name="'+gt(""+t)+'"][type="radio"]'),t=0;t<n.length;t++){var a=n[t];if(a!==e&&a.form===e.form){var l=a[Fe]||null;if(!l)throw Error(f(90));Sr(a,l.value,l.defaultValue,l.defaultValue,l.checked,l.defaultChecked,l.type,l.name)}}for(t=0;t<n.length;t++)a=n[t],a.form===e.form&&Cu(a)}break e;case"textarea":Lu(e,n.value,n.defaultValue);break e;case"select":t=n.value,t!=null&&ka(e,!!n.multiple,t,!1)}}}var Dr=!1;function Bu(e,t,n){if(Dr)return e(t,n);Dr=!0;try{var a=e(t);return a}finally{if(Dr=!1,(Ua!==null||Ba!==null)&&(qo(),Ua&&(t=Ua,e=Ba,Ba=Ua=null,Uu(t),e)))for(t=0;t<e.length;t++)Uu(e[t])}}function Ml(e,t){var n=e.stateNode;if(n===null)return null;var a=n[Fe]||null;if(a===null)return null;n=a[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(a=!a.disabled)||(e=e.type,a=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!a;break e;default:e=!1}if(e)return null;if(n&&typeof n!="function")throw Error(f(231,t,typeof n));return n}var $t=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Cr=!1;if($t)try{var kl={};Object.defineProperty(kl,"passive",{get:function(){Cr=!0}}),window.addEventListener("test",kl,kl),window.removeEventListener("test",kl,kl)}catch{Cr=!1}var jn=null,Rr=null,qi=null;function Hu(){if(qi)return qi;var e,t=Rr,n=t.length,a,l="value"in jn?jn.value:jn.textContent,o=l.length;for(e=0;e<n&&t[e]===l[e];e++);var r=n-e;for(a=1;a<=r&&t[n-a]===l[o-a];a++);return qi=l.slice(e,1<a?1-a:void 0)}function Ii(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function Yi(){return!0}function qu(){return!1}function Qe(e){function t(n,a,l,o,r){this._reactName=n,this._targetInst=l,this.type=a,this.nativeEvent=o,this.target=r,this.currentTarget=null;for(var u in e)e.hasOwnProperty(u)&&(n=e[u],this[u]=n?n(o):o[u]);return this.isDefaultPrevented=(o.defaultPrevented!=null?o.defaultPrevented:o.returnValue===!1)?Yi:qu,this.isPropagationStopped=qu,this}return te(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=Yi)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=Yi)},persist:function(){},isPersistent:Yi}),t}var Sn={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Xi=Qe(Sn),Vl=te({},Sn,{view:0,detail:0}),A0=Qe(Vl),Lr,Mr,Ul,Gi=te({},Vl,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Vr,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==Ul&&(Ul&&e.type==="mousemove"?(Lr=e.screenX-Ul.screenX,Mr=e.screenY-Ul.screenY):Mr=Lr=0,Ul=e),Lr)},movementY:function(e){return"movementY"in e?e.movementY:Mr}}),Iu=Qe(Gi),O0=te({},Gi,{dataTransfer:0}),N0=Qe(O0),D0=te({},Vl,{relatedTarget:0}),kr=Qe(D0),C0=te({},Sn,{animationName:0,elapsedTime:0,pseudoElement:0}),R0=Qe(C0),L0=te({},Sn,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),M0=Qe(L0),k0=te({},Sn,{data:0}),Yu=Qe(k0),V0={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},U0={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},B0={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function H0(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=B0[e])?!!t[e]:!1}function Vr(){return H0}var q0=te({},Vl,{key:function(e){if(e.key){var t=V0[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=Ii(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?U0[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Vr,charCode:function(e){return e.type==="keypress"?Ii(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?Ii(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),I0=Qe(q0),Y0=te({},Gi,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Xu=Qe(Y0),X0=te({},Sn,{submitter:0}),G0=Qe(X0),Q0=te({},Vl,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Vr}),Z0=Qe(Q0),K0=te({},Sn,{propertyName:0,elapsedTime:0,pseudoElement:0}),P0=Qe(K0),J0=te({},Gi,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),F0=Qe(J0),W0=te({},Sn,{newState:0,oldState:0,source:0}),$0=Qe(W0),eg=[9,13,27,32],Ur=$t&&"CompositionEvent"in window,Bl=null;$t&&"documentMode"in document&&(Bl=document.documentMode);var tg=$t&&"TextEvent"in window&&!Bl,Gu=$t&&(!Ur||Bl&&8<Bl&&11>=Bl),Qu=" ",Zu=!1;function Ku(e,t){switch(e){case"keyup":return eg.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Pu(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var Ha=!1;function ng(e,t){switch(e){case"compositionend":return Pu(t);case"keypress":return t.which!==32?null:(Zu=!0,Qu);case"textInput":return e=t.data,e===Qu&&Zu?null:e;default:return null}}function ag(e,t){if(Ha)return e==="compositionend"||!Ur&&Ku(e,t)?(e=Hu(),qi=Rr=jn=null,Ha=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return Gu&&t.locale!=="ko"?null:t.data;default:return null}}var lg={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Ju(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!lg[e.type]:t==="textarea"}function Fu(e,t,n,a){Ua?Ba?Ba.push(a):Ba=[a]:Ua=a,t=Zo(t,"onChange"),0<t.length&&(n=new Xi("onChange","change",null,n,a),e.push({event:n,listeners:t}))}var Hl=null,ql=null;function ig(e){Bh(e,0)}function Qi(e){var t=Ll(e);if(Cu(t))return e}function Wu(e,t){if(e==="change")return t}var $u=!1;if($t){var Br;if($t){var Hr="oninput"in document;if(!Hr){var ed=document.createElement("div");ed.setAttribute("oninput","return;"),Hr=typeof ed.oninput=="function"}Br=Hr}else Br=!1;$u=Br&&(!document.documentMode||9<document.documentMode)}function td(){Hl&&(Hl.detachEvent("onpropertychange",nd),ql=Hl=null)}function nd(e){if(e.propertyName==="value"&&Qi(ql)){var t=[];Fu(t,ql,e,Nr(e)),Bu(ig,t)}}function og(e,t,n){e==="focusin"?(td(),Hl=t,ql=n,Hl.attachEvent("onpropertychange",nd)):e==="focusout"&&td()}function rg(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return Qi(ql)}function sg(e,t){if(e==="click")return Qi(t)}function cg(e,t){if(e==="input"||e==="change")return Qi(t)}function ug(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var rt=typeof Object.is=="function"?Object.is:ug;function Il(e,t){if(rt(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var n=Object.keys(e),a=Object.keys(t);if(n.length!==a.length)return!1;for(a=0;a<n.length;a++){var l=n[a];if(!vr.call(t,l)||!rt(e[l],t[l]))return!1}return!0}function qr(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function ad(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function ld(e,t){var n=ad(e);e=0;for(var a;n;){if(n.nodeType===3){if(a=e+n.textContent.length,e<=t&&a>=t)return{node:n,offset:t-e};e=a}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=ad(n)}}function id(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?id(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function od(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=qr(e.document);t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href=="string"}catch{n=!1}if(n)e=t.contentWindow;else break;t=qr(e.document)}return t}function Ir(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}var dg=$t&&"documentMode"in document&&11>=document.documentMode,qa=null,Yr=null,Yl=null,Xr=!1;function rd(e,t,n){var a=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;Xr||qa==null||qa!==qr(a)||(a=qa,"selectionStart"in a&&Ir(a)?a={start:a.selectionStart,end:a.selectionEnd}:(a=(a.ownerDocument&&a.ownerDocument.defaultView||window).getSelection(),a={anchorNode:a.anchorNode,anchorOffset:a.anchorOffset,focusNode:a.focusNode,focusOffset:a.focusOffset}),Yl&&Il(Yl,a)||(Yl=a,a=Zo(Yr,"onSelect"),0<a.length&&(t=new Xi("onSelect","select",null,t,n),e.push({event:t,listeners:a}),t.target=qa)))}function na(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var Ia={animationend:na("Animation","AnimationEnd"),animationiteration:na("Animation","AnimationIteration"),animationstart:na("Animation","AnimationStart"),transitionrun:na("Transition","TransitionRun"),transitionstart:na("Transition","TransitionStart"),transitioncancel:na("Transition","TransitionCancel"),transitionend:na("Transition","TransitionEnd")},Gr={},sd={};$t&&(sd=document.createElement("div").style,"AnimationEvent"in window||(delete Ia.animationend.animation,delete Ia.animationiteration.animation,delete Ia.animationstart.animation),"TransitionEvent"in window||delete Ia.transitionend.transition);function aa(e){if(Gr[e])return Gr[e];if(!Ia[e])return e;var t=Ia[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in sd)return Gr[e]=t[n];return e}var cd=aa("animationend"),ud=aa("animationiteration"),dd=aa("animationstart"),fg=aa("transitionrun"),hg=aa("transitionstart"),mg=aa("transitioncancel"),fd=aa("transitionend"),hd=new Map,Qr="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");Qr.push("scrollEnd");function zt(e,t){hd.set(e,t),ta(t,[e])}var pg=0;function en(e,t){if(e.name!=null&&e.name!=="auto")return e.name;if(t.autoName!==null)return t.autoName;e=Dt.identifierPrefix;var n=pg++;return e="_"+e+"t_"+n.toString(32)+"_",t.autoName=e}function md(e){if(e==null||typeof e=="string")return e;var t=null,n=sl;if(n!==null)for(var a=0;a<n.length;a++){var l=e[n[a]];if(l!=null){if(l==="none")return"none";t=t==null?l:t+(" "+l)}}return t??e.default}function tn(e,t){return e=md(e),t=md(t),t==null?e==="auto"?null:e:t==="auto"?null:t}var Zi=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},xt=[],Ya=0,Zr=0;function Ki(){for(var e=Ya,t=Zr=Ya=0;t<e;){var n=xt[t];xt[t++]=null;var a=xt[t];xt[t++]=null;var l=xt[t];xt[t++]=null;var o=xt[t];if(xt[t++]=null,a!==null&&l!==null){var r=a.pending;r===null?l.next=l:(l.next=r.next,r.next=l),a.pending=l}o!==0&&pd(n,l,o)}}function Pi(e,t,n,a){xt[Ya++]=e,xt[Ya++]=t,xt[Ya++]=n,xt[Ya++]=a,Zr|=a,e.lanes|=a,e=e.alternate,e!==null&&(e.lanes|=a)}function Kr(e,t,n,a){return Pi(e,t,n,a),Ji(e)}function la(e,t){return Pi(e,null,null,t),Ji(e)}function pd(e,t,n){e.lanes|=n;var a=e.alternate;a!==null&&(a.lanes|=n);for(var l=!1,o=e.return;o!==null;)o.childLanes|=n,a=o.alternate,a!==null&&(a.childLanes|=n),o.tag===22&&(e=o.stateNode,e===null||e._visibility&1||(l=!0)),e=o,o=o.return;return e.tag===3?(o=e.stateNode,l&&t!==null&&(l=31-it(n),e=o.hiddenUpdates,a=e[l],a===null?e[l]=[t]:a.push(t),t.lane=n|536870912),o):null}function Ji(e){if(50<di)throw di=0,Ho=null,Error(f(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var Xa={};function gg(e,t,n,a){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=a,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function We(e,t,n,a){return new gg(e,t,n,a)}function Pr(e){return e=e.prototype,!(!e||!e.isReactComponent)}function nn(e,t){var n=e.alternate;return n===null?(n=We(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&1206910976,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n.refCleanup=e.refCleanup,n}function gd(e,t){e.flags&=1206910978;var n=e.alternate;return n===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,t=n.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function Fi(e,t,n,a,l,o){var r=0;if(a=e,typeof a=="function")Pr(a)&&(r=1);else if(typeof a=="string")r=Xx(e,n,Vt.current)?26:e==="html"||e==="head"||e==="body"?27:5;else e:switch(a){case _n:return e=We(31,n,t,l),e.elementType=_n,e.lanes=o,e;case Mt:return ia(n.children,l,o,t);case Jt:r=8,l|=24;break;case za:return e=We(12,n,t,l|2),e.elementType=za,e.lanes=o,e;case G:return e=We(13,n,t,l),e.elementType=G,e.lanes=o,e;case I:return e=We(19,n,t,l),e.elementType=I,e.lanes=o,e;case Aa:case St:return e=l|32,e=We(30,n,t,e),e.elementType=St,e.lanes=o,e.stateNode={autoName:null,paired:null,clones:null,ref:null},e;default:if(typeof a=="object"&&a!==null)switch(a.$$typeof){case Je:r=10;break e;case zi:r=9;break e;case k:r=11;break e;case ye:r=14;break e;case he:r=16,a=null;break e}r=29,n=Error(f(130,e===null?"null":typeof e,"")),a=null}return t=We(r,n,t,l),t.elementType=e,t.type=a,t.lanes=o,t}function ia(e,t,n,a){return e=We(7,e,a,t),e.lanes=n,e}function Jr(e,t,n){return e=We(6,e,null,t),e.lanes=n,e}function xd(e){var t=We(18,null,null,0);return t.stateNode=e,t}function Fr(e,t,n){return t=We(4,e.children!==null?e.children:[],e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var yd=new WeakMap;function yt(e,t){if(typeof e=="object"&&e!==null){var n=yd.get(e);return n!==void 0?n:(t={value:e,source:t,stack:fu(t)},yd.set(e,t),t)}return{value:e,source:t,stack:fu(t)}}var Ga=[],Qa=0,Wi=null,Xl=0,vt=[],bt=0,zn=null,Bt=1,Ht="";function an(e,t){Ga[Qa++]=Xl,Ga[Qa++]=Wi,Wi=e,Xl=t}function vd(e,t,n){vt[bt++]=Bt,vt[bt++]=Ht,vt[bt++]=zn,zn=e;var a=Bt;e=Ht;var l=32-it(a)-1;a&=~(1<<l),n+=1;var o=32-it(t)+l;if(30<o){var r=l-l%5;o=(a&(1<<r)-1).toString(32),a>>=r,l-=r,Bt=1<<32-it(t)+l|n<<l|a,Ht=o+e}else Bt=1<<o|n<<l|a,Ht=e}function $i(e){e.return!==null&&(an(e,1),vd(e,1,0))}function Wr(e){for(;e===Wi;)Wi=Ga[--Qa],Ga[Qa]=null,Xl=Ga[--Qa],Ga[Qa]=null;for(;e===zn;)zn=vt[--bt],vt[bt]=null,Ht=vt[--bt],vt[bt]=null,Bt=vt[--bt],vt[bt]=null}function bd(e,t){vt[bt++]=Bt,vt[bt++]=Ht,vt[bt++]=zn,Bt=t.id,Ht=t.overflow,zn=e}var De=null,ge=null,J=!1,An=null,_t=!1,$r=Error(f(519));function On(e){var t=Error(f(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw Gl(yt(t,e)),$r}function _d(e){var t=e.stateNode,n=e.type,a=e.memoizedProps;switch(t[Me]=e,t[Fe]=a,n){case"dialog":W("cancel",t),W("close",t);break;case"iframe":case"object":case"embed":W("load",t);break;case"video":case"audio":for(n=0;n<hi.length;n++)W(hi[n],t);break;case"source":W("error",t);break;case"img":case"image":case"link":W("error",t),W("load",t);break;case"details":W("toggle",t);break;case"input":W("invalid",t),Ru(t,a.value,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name,!0);break;case"select":W("invalid",t);break;case"textarea":W("invalid",t),Mu(t,a.value,a.defaultValue,a.children)}n=a.children,typeof n!="string"&&typeof n!="number"&&typeof n!="bigint"||t.textContent===""+n||a.suppressHydrationWarning===!0||Yh(t.textContent,n)?(a.popover!=null&&(W("beforetoggle",t),W("toggle",t)),a.onScroll!=null&&W("scroll",t),a.onScrollEnd!=null&&W("scrollend",t),a.onClick!=null&&(t.onclick=Ut),t=!0):t=!1,t||On(e,!0)}function eo(e){for(De=e.return;De;)switch(De.tag){case 5:case 31:case 13:_t=!1;return;case 27:case 3:_t=!0;return;default:De=De.return}}function Za(e){if(e!==De)return!1;if(!J)return eo(e),J=!0,!1;var t=e.tag,n;if((n=t!==3&&t!==27)&&((n=t===5)&&(n=e.type,n=!(n!=="form"&&n!=="button")||Oc(e.type,e.memoizedProps)),n=!n),n&&ge&&On(e),eo(e),t===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(f(317));ge=sm(e)}else if(t===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(f(317));ge=sm(e)}else t===27?(t=ge,Gn(e.type)?(e=Uc,Uc=null,ge=e):ge=t):ge=De?Et(e.stateNode.nextSibling):null;return!0}function oa(){ge=De=null,J=!1}function es(){var e=An;return e!==null&&(tt===null?tt=e:tt.push.apply(tt,e),An=null),e}function Gl(e){An===null?An=[e]:An.push(e)}var ts=kt(null),ra=null,ln=null;function Nn(e,t,n){pe(ts,t._currentValue),t._currentValue=n}function on(e){e._currentValue=ts.current,Le(ts)}function to(e,t,n){for(;e!==null;){var a=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,a!==null&&(a.childLanes|=t)):a!==null&&(a.childLanes&t)!==t&&(a.childLanes|=t),e===n)break;e=e.return}}function ns(e,t,n,a){var l=e.child;for(l!==null&&(l.return=e);l!==null;){var o=l.dependencies;if(o!==null){var r=l.child;o=o.firstContext;e:for(;o!==null;){var u=o;o=l;for(var m=0;m<t.length;m++)if(u.context===t[m]){o.lanes|=n,u=o.alternate,u!==null&&(u.lanes|=n),to(o.return,n,e),a||(r=null);break e}o=u.next}}else if(l.tag===18){if(r=l.return,r===null)throw Error(f(341));r.lanes|=n,o=r.alternate,o!==null&&(o.lanes|=n),to(r,n,e),r=null}else l.tag===13&&l.memoizedState!==null&&l.memoizedState.dehydrated===null?(l.lanes|=n,r=l.alternate,r!==null&&(r.lanes|=n),to(l.return,n,e),r=l.child,r=r!==null?r.sibling:null):r=l.child;if(r!==null)r.return=l;else for(r=l;r!==null;){if(r===e){r=null;break}if(l=r.sibling,l!==null){l.return=r.return,r=l;break}r=r.return}l=r}}function sa(e,t,n,a){e=null;for(var l=t,o=!1;l!==null;){if(!o){if((l.flags&524288)!==0)o=!0;else if((l.flags&262144)!==0)break}if(l.tag===10){var r=l.alternate;if(r===null)throw Error(f(387));if(r=r.memoizedProps,r!==null){var u=l.type;rt(l.pendingProps.value,r.value)||(e!==null?e.push(u):e=[u])}}else if(l===Ai.current){if(r=l.alternate,r===null)throw Error(f(387));r.memoizedState.memoizedState!==l.memoizedState.memoizedState&&(e!==null?e.push(yl):e=[yl])}l=l.return}return e!==null&&ns(t,e,n,a),t.flags|=262144,e!==null}function no(e){for(e=e.firstContext;e!==null;){if(!rt(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function ca(e){ra=e,ln=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function ke(e){return Td(ra,e)}function ao(e,t){return ra===null&&ca(e),Td(e,t)}function Td(e,t){var n=t._currentValue;if(t={context:t,memoizedValue:n,next:null},ln===null){if(e===null)throw Error(f(308));ln=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else ln=ln.next=t;return n}var xg=typeof AbortController<"u"?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(n,a){e.push(a)}};this.abort=function(){t.aborted=!0,e.forEach(function(n){return n()})}},yg=s.unstable_scheduleCallback,vg=s.unstable_NormalPriority,je={$$typeof:Je,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function as(){return{controller:new xg,data:new Map,refCount:0}}function Ql(e){e.refCount--,e.refCount===0&&yg(vg,function(){e.controller.abort()})}function Ed(e,t){if((e.pendingLanes&4194048)!==0){var n=e.transitionTypes;for(n===null&&(n=e.transitionTypes=[]),e=0;e<t.length;e++){var a=t[e];n.indexOf(a)===-1&&n.push(a)}}}var Zl=null;function bg(e){var t=e.transitionTypes;return e.transitionTypes=null,t}var Kl=null,ls=0,ua=0,Ka=null;function _g(e,t){if(Kl===null){var n=Kl=[];ls=0,ua=bc(),Ka={status:"pending",value:void 0,then:function(a){n.push(a)}}}return ls++,t.then(wd,wd),t}function wd(){if(--ls===0&&(Zl=null,Kl!==null)){Ka!==null&&(Ka.status="fulfilled");var e=Kl;Kl=null,ua=0,Ka=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function Tg(e,t){var n=[],a={status:"pending",value:null,reason:null,then:function(l){n.push(l)}};return e.then(function(){a.status="fulfilled",a.value=t;for(var l=0;l<n.length;l++)(0,n[l])(t)},function(l){for(a.status="rejected",a.reason=l,l=0;l<n.length;l++)(0,n[l])(void 0)}),a}var jd=q.S;q.S=function(e,t){if(yh=at(),typeof t=="object"&&t!==null&&typeof t.then=="function"&&_g(e,t),Zl!==null)for(var n=fl;n!==null;)Ed(n,Zl),n=n.next;if(n=e.types,n!==null){for(var a=fl;a!==null;)Ed(a,n),a=a.next;if(ua!==0){a=Zl,a===null&&(a=Zl=[]);for(var l=0;l<n.length;l++){var o=n[l];a.indexOf(o)===-1&&a.push(o)}}}jd!==null&&jd(e,t)};var da=kt(null);function is(){var e=da.current;return e!==null?e:me.pooledCache}function lo(e,t){t===null?pe(da,da.current):pe(da,t.pool)}function Sd(){var e=is();return e===null?null:{parent:je._currentValue,pool:e}}var Pa=Error(f(460)),os=Error(f(474)),io=Error(f(542)),oo={then:function(){}};function zd(e){return e=e.status,e==="fulfilled"||e==="rejected"}function Ad(e,t,n){switch(n=e[n],n===void 0?e.push(t):n!==t&&(t.then(Ut,Ut),t=n),t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,Nd(e),e===void 0&&!("reason"in t)?Error(f(600)):e;default:if(typeof t.status=="string")t.then(Ut,Ut);else{if(e=me,e!==null&&100<e.shellSuspendCounter)throw Error(f(482));e=t,e.status="pending",e.then(function(a){if(t.status==="pending"){var l=t;l.status="fulfilled",l.value=a}},function(a){if(t.status==="pending"){var l=t;l.status="rejected",l.reason=a}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,Nd(e),e}throw ha=t,Pa}}function fa(e){try{var t=e._init;return t(e._payload)}catch(n){throw n!==null&&typeof n=="object"&&typeof n.then=="function"?(ha=n,Pa):n}}var ha=null;function Od(){if(ha===null)throw Error(f(459));var e=ha;return ha=null,e}function Nd(e){if(e===Pa||e===io)throw Error(f(483))}var Ja=null,Pl=0;function ro(e){var t=Pl;return Pl+=1,Ja===null&&(Ja=[]),Ad(Ja,e,t)}function Dn(e,t){t=t.props.ref,e.ref=t!==void 0?t:null}function so(e,t){throw t.$$typeof===Sa?Error(f(525)):(e=Object.prototype.toString.call(t),Error(f(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)))}function Dd(e){function t(v,p){if(e){var _=v.deletions;_===null?(v.deletions=[p],v.flags|=16):_.push(p)}}function n(v,p){if(!e)return null;for(;p!==null;)t(v,p),p=p.sibling;return null}function a(v){for(var p=new Map;v!==null;)v.key===null?p.set(v.index,v):p.set(v.key,v),v=v.sibling;return p}function l(v,p){return v=nn(v,p),v.index=0,v.sibling=null,v}function o(v,p,_){return v.index=_,e?(_=v.alternate,_!==null?(_=_.index,_<p?(v.flags|=2,p):_):(v.flags|=134217730,p)):(v.flags|=1048576,p)}function r(v){return e&&v.alternate===null&&(v.flags|=134217730),v}function u(v,p,_,z){return p===null||p.tag!==6?(p=Jr(_,v.mode,z),p.return=v,p):(p=l(p,_),p.return=v,p)}function m(v,p,_,z){var V=_.type;return V===Mt?(v=w(v,p,_.props.children,z,_.key),Dn(v,_),v):p!==null&&(p.elementType===V||typeof V=="object"&&V!==null&&V.$$typeof===he&&fa(V)===p.type)?(p=l(p,_.props),Dn(p,_),p.return=v,p):(p=Fi(_.type,_.key,_.props,null,v.mode,z),Dn(p,_),p.return=v,p)}function b(v,p,_,z){return p===null||p.tag!==4||p.stateNode.containerInfo!==_.containerInfo||p.stateNode.implementation!==_.implementation?(p=Fr(_,v.mode,z),p.return=v,p):(p=l(p,_.children||[]),p.return=v,p)}function w(v,p,_,z,V){return p===null||p.tag!==7?(p=ia(_,v.mode,z,V),p.return=v,p):(p=l(p,_),p.return=v,p)}function A(v,p,_){if(typeof p=="string"&&p!==""||typeof p=="number"||typeof p=="bigint")return p=Jr(""+p,v.mode,_),p.return=v,p;if(typeof p=="object"&&p!==null){switch(p.$$typeof){case Fn:return _=Fi(p.type,p.key,p.props,null,v.mode,_),Dn(_,p),_.return=v,_;case bn:return p=Fr(p,v.mode,_),p.return=v,p;case he:return p=fa(p),A(v,p,_)}if(Al(p)||zl(p))return p=ia(p,v.mode,_,null),p.return=v,p;if(typeof p.then=="function")return A(v,ro(p),_);if(p.$$typeof===Je)return A(v,ao(v,p),_);so(v,p)}return null}function g(v,p,_,z){var V=p!==null?p.key:null;if(typeof _=="string"&&_!==""||typeof _=="number"||typeof _=="bigint")return V!==null?null:u(v,p,""+_,z);if(typeof _=="object"&&_!==null){switch(_.$$typeof){case Fn:return _.key===V?m(v,p,_,z):null;case bn:return _.key===V?b(v,p,_,z):null;case he:return _=fa(_),g(v,p,_,z)}if(Al(_)||zl(_))return V!==null?null:w(v,p,_,z,null);if(typeof _.then=="function")return g(v,p,ro(_),z);if(_.$$typeof===Je)return g(v,p,ao(v,_),z);so(v,_)}return null}function T(v,p,_,z,V){if(typeof z=="string"&&z!==""||typeof z=="number"||typeof z=="bigint")return v=v.get(_)||null,u(p,v,""+z,V);if(typeof z=="object"&&z!==null){switch(z.$$typeof){case Fn:return v=v.get(z.key===null?_:z.key)||null,m(p,v,z,V);case bn:return v=v.get(z.key===null?_:z.key)||null,b(p,v,z,V);case he:return z=fa(z),T(v,p,_,z,V)}if(Al(z)||zl(z))return v=v.get(_)||null,w(p,v,z,V,null);if(typeof z.then=="function")return T(v,p,_,ro(z),V);if(z.$$typeof===Je)return T(v,p,_,ao(p,z),V);so(p,z)}return null}function L(v,p,_,z){for(var V=null,ee=null,B=p,H=p=0,Ae=null;B!==null&&H<_.length;H++){B.index>H?(Ae=B,B=null):Ae=B.sibling;var ne=g(v,B,_[H],z);if(ne===null){B===null&&(B=Ae);break}e&&B&&ne.alternate===null&&t(v,B),p=o(ne,p,H),ee===null?V=ne:ee.sibling=ne,ee=ne,B=Ae}if(H===_.length)return n(v,B),J&&an(v,H),V;if(B===null){for(;H<_.length;H++)B=A(v,_[H],z),B!==null&&(p=o(B,p,H),ee===null?V=B:ee.sibling=B,ee=B);return J&&an(v,H),V}for(B=a(B);H<_.length;H++)Ae=T(B,v,H,_[H],z),Ae!==null&&(e&&(ne=Ae.alternate,ne!==null&&B.delete(ne.key===null?H:ne.key)),p=o(Ae,p,H),ee===null?V=Ae:ee.sibling=Ae,ee=Ae);return e&&B.forEach(function(Jn){return t(v,Jn)}),J&&an(v,H),V}function U(v,p,_,z){if(_==null)throw Error(f(151));for(var V=null,ee=null,B=p,H=p=0,Ae=null,ne=_.next();B!==null&&!ne.done;H++,ne=_.next()){B.index>H?(Ae=B,B=null):Ae=B.sibling;var Jn=g(v,B,ne.value,z);if(Jn===null){B===null&&(B=Ae);break}e&&B&&Jn.alternate===null&&t(v,B),p=o(Jn,p,H),ee===null?V=Jn:ee.sibling=Jn,ee=Jn,B=Ae}if(ne.done)return n(v,B),J&&an(v,H),V;if(B===null){for(;!ne.done;H++,ne=_.next())ne=A(v,ne.value,z),ne!==null&&(p=o(ne,p,H),ee===null?V=ne:ee.sibling=ne,ee=ne);return J&&an(v,H),V}for(B=a(B);!ne.done;H++,ne=_.next())ne=T(B,v,H,ne.value,z),ne!==null&&(e&&(Ae=ne.alternate,Ae!==null&&B.delete(Ae.key===null?H:Ae.key)),p=o(ne,p,H),ee===null?V=ne:ee.sibling=ne,ee=ne);return e&&B.forEach(function(ny){return t(v,ny)}),J&&an(v,H),V}function X(v,p,_,z){if(typeof _=="object"&&_!==null&&_.type===Mt&&_.key===null&&_.props.ref===void 0&&(_=_.props.children),typeof _=="object"&&_!==null){switch(_.$$typeof){case Fn:e:{for(var V=_.key;p!==null;){if(p.key===V){if(V=_.type,V===Mt){if(p.tag===7){n(v,p.sibling),z=l(p,_.props.children),Dn(z,_),z.return=v,v=z;break e}}else if(p.elementType===V||typeof V=="object"&&V!==null&&V.$$typeof===he&&fa(V)===p.type){n(v,p.sibling),z=l(p,_.props),Dn(z,_),z.return=v,v=z;break e}n(v,p);break}else t(v,p);p=p.sibling}_.type===Mt?(z=ia(_.props.children,v.mode,z,_.key),Dn(z,_),z.return=v,v=z):(z=Fi(_.type,_.key,_.props,null,v.mode,z),Dn(z,_),z.return=v,v=z)}return r(v);case bn:e:{for(V=_.key;p!==null;){if(p.key===V)if(p.tag===4&&p.stateNode.containerInfo===_.containerInfo&&p.stateNode.implementation===_.implementation){n(v,p.sibling),z=l(p,_.children||[]),z.return=v,v=z;break e}else{n(v,p);break}else t(v,p);p=p.sibling}z=Fr(_,v.mode,z),z.return=v,v=z}return r(v);case he:return _=fa(_),X(v,p,_,z)}if(Al(_))return L(v,p,_,z);if(zl(_)){if(V=zl(_),typeof V!="function")throw Error(f(150));return _=V.call(_),U(v,p,_,z)}if(typeof _.then=="function")return X(v,p,ro(_),z);if(_.$$typeof===Je)return X(v,p,ao(v,_),z);so(v,_)}return typeof _=="string"&&_!==""||typeof _=="number"||typeof _=="bigint"?(_=""+_,p!==null&&p.tag===6?(n(v,p.sibling),z=l(p,_),z.return=v,v=z):(n(v,p),z=Jr(_,v.mode,z),z.return=v,v=z),r(v)):n(v,p)}return function(v,p,_,z){try{Pl=0;var V=X(v,p,_,z);return Ja=null,V}catch(B){if(B===Pa||B===io)throw B;var ee=We(29,B,null,v.mode);return ee.lanes=z,ee.return=v,ee}}}var ma=Dd(!0),Cd=Dd(!1),Cn=!1;function rs(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function ss(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function Rn(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function Ln(e,t,n){var a=e.updateQueue;if(a===null)return null;if(a=a.shared,(re&2)!==0){var l=a.pending;return l===null?t.next=t:(t.next=l.next,l.next=t),a.pending=t,t=Ji(e),pd(e,null,n),t}return Pi(e,a,t,n),Ji(e)}function Jl(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,(n&4194048)!==0)){var a=t.lanes;a&=e.pendingLanes,n|=a,t.lanes=n,vu(e,n)}}function cs(e,t){var n=e.updateQueue,a=e.alternate;if(a!==null&&(a=a.updateQueue,n===a)){var l=null,o=null;if(n=n.firstBaseUpdate,n!==null){do{var r={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};o===null?l=o=r:o=o.next=r,n=n.next}while(n!==null);o===null?l=o=t:o=o.next=t}else l=o=t;n={baseState:a.baseState,firstBaseUpdate:l,lastBaseUpdate:o,shared:a.shared,callbacks:a.callbacks},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}var us=!1;function Fl(){if(us){var e=Ka;if(e!==null)throw e}}function Wl(e,t,n,a){us=!1;var l=e.updateQueue;Cn=!1;var o=l.firstBaseUpdate,r=l.lastBaseUpdate,u=l.shared.pending;if(u!==null){l.shared.pending=null;var m=u,b=m.next;m.next=null,r===null?o=b:r.next=b,r=m;var w=e.alternate;w!==null&&(w=w.updateQueue,u=w.lastBaseUpdate,u!==r&&(u===null?w.firstBaseUpdate=b:u.next=b,w.lastBaseUpdate=m))}if(o!==null){var A=l.baseState;r=0,w=b=m=null,u=o;do{var g=u.lane&-536870913,T=g!==u.lane;if(T?($&g)===g:(a&g)===g){g!==0&&g===ua&&(us=!0),w!==null&&(w=w.next={lane:0,tag:u.tag,payload:u.payload,callback:null,next:null});e:{var L=e,U=u;g=t;var X=n;switch(U.tag){case 1:if(L=U.payload,typeof L=="function"){A=L.call(X,A,g);break e}A=L;break e;case 3:L.flags=L.flags&-65537|128;case 0:if(L=U.payload,g=typeof L=="function"?L.call(X,A,g):L,g==null)break e;A=te({},A,g);break e;case 2:Cn=!0}}g=u.callback,g!==null&&(e.flags|=64,T&&(e.flags|=8192),T=l.callbacks,T===null?l.callbacks=[g]:T.push(g))}else T={lane:g,tag:u.tag,payload:u.payload,callback:u.callback,next:null},w===null?(b=w=T,m=A):w=w.next=T,r|=g;if(u=u.next,u===null){if(u=l.shared.pending,u===null)break;T=u,u=T.next,T.next=null,l.lastBaseUpdate=T,l.shared.pending=null}}while(!0);w===null&&(m=A),l.baseState=m,l.firstBaseUpdate=b,l.lastBaseUpdate=w,o===null&&(l.shared.lanes=0),qn|=r,e.lanes=r,e.memoizedState=A}}function Rd(e,t){if(typeof e!="function")throw Error(f(191,e));e.call(t)}function Ld(e,t){var n=e.callbacks;if(n!==null)for(e.callbacks=null,e=0;e<n.length;e++)Rd(n[e],t)}var Mn=kt(null),co=kt(0);function Md(e,t){e=dn,pe(co,e),pe(Mn,t),dn=e|t.baseLanes}function ds(){pe(co,dn),pe(Mn,Mn.current)}function fs(){dn=co.current,Le(Mn),Le(co)}var Ve=kt(null),Ie=null;function kn(e){var t=e.alternate;pe(Ue,Ue.current&1),pe(Ve,e),Ie===null&&(t===null||Mn.current!==null||t.memoizedState!==null)&&(Ie=e)}function hs(e){pe(Ue,Ue.current),pe(Ve,e),Ie===null&&(Ie=e)}function kd(e){e.tag===22?(pe(Ue,Ue.current),pe(Ve,e),Ie===null&&(Ie=e)):Vn()}function Vn(){pe(Ue,Ue.current),pe(Ve,Ve.current)}function st(e){Le(Ve),Ie===e&&(Ie=null),Le(Ue)}var Ue=kt(0);function $l(e,t){pe(Ve,Ve.current),pe(Ue,t)}function ms(e){Le(Ue),Le(Ve),Ie===e&&(Ie=null)}function uo(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||kc(n)||Vc(n)))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!=="independent"){if((t.flags&128)!==0)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var rn=0,Y=null,fe=null,Se=null,fo=!1,Fa=!1,pa=!1,ho=0,ei=0,Wa=null,Eg=0;function Te(){throw Error(f(321))}function ps(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!rt(e[n],t[n]))return!1;return!0}function gs(e,t,n,a,l,o){return rn=o,Y=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,q.H=e===null||e.memoizedState===null?bf:_f,pa=!1,o=n(a,l),pa=!1,Fa&&(o=Ud(t,n,a,l)),Vd(e),o}function Vd(e){q.H=bo;var t=fe!==null&&fe.next!==null;if(rn=0,Se=fe=Y=null,fo=!1,ei=0,Wa=null,t)throw Error(f(300));e===null||ze||(e=e.dependencies,e!==null&&no(e)&&(ze=!0))}function Ud(e,t,n,a){Y=e;var l=0;do{if(Fa&&(Wa=null),ei=0,Fa=!1,25<=l)throw Error(f(301));if(l+=1,Se=fe=null,e.updateQueue!=null){var o=e.updateQueue;o.lastEffect=null,o.events=null,o.stores=null,o.memoCache!=null&&(o.memoCache.index=0)}q.H=Dg,o=t(n,a)}while(Fa);return o}function wg(){var e=q.H,t=e.useState()[0];return t=typeof t.then=="function"?ti(t):t,e=e.useState()[0],(fe!==null?fe.memoizedState:null)!==e&&(Y.flags|=1024),t}function xs(){var e=ho!==0;return ho=0,e}function ys(e,t,n){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n}function vs(e){if(fo){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}fo=!1}rn=0,Se=fe=Y=null,Fa=!1,ei=ho=0,Wa=null}function Ze(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Se===null?Y.memoizedState=Se=e:Se=Se.next=e,Se}function we(){if(fe===null){var e=Y.alternate;e=e!==null?e.memoizedState:null}else e=fe.next;var t=Se===null?Y.memoizedState:Se.next;if(t!==null)Se=t,fe=e;else{if(e===null)throw Y.alternate===null?Error(f(467)):Error(f(310));fe=e,e={memoizedState:fe.memoizedState,baseState:fe.baseState,baseQueue:fe.baseQueue,queue:fe.queue,next:null},Se===null?Y.memoizedState=Se=e:Se=Se.next=e}return Se}function mo(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function ti(e){var t=ei;return ei+=1,Wa===null&&(Wa=[]),e=Ad(Wa,e,t),t=Y,(Se===null?t.memoizedState:Se.next)===null&&(t=t.alternate,q.H=t===null||t.memoizedState===null?bf:_f),e}function po(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return ti(e);if(e.$$typeof===Oa)return;if(e.$$typeof===Je)return ke(e)}throw Error(f(438,String(e)))}function bs(e){var t=null,n=Y.updateQueue;if(n!==null&&(t=n.memoCache),t==null){var a=Y.alternate;a!==null&&(a=a.updateQueue,a!==null&&(a=a.memoCache,a!=null&&(t={data:a.data.map(function(l){return l.slice()}),index:0})))}if(t==null&&(t={data:[],index:0}),n===null&&(n=mo(),Y.updateQueue=n),n.memoCache=t,n=t.data[t.index],n===void 0)for(n=t.data[t.index]=Array(e),a=0;a<e;a++)n[a]=Sl;return t.index++,n}function sn(e,t){return typeof t=="function"?t(e):t}function go(e){var t=we();return _s(t,fe,e)}function _s(e,t,n){var a=e.queue;if(a===null)throw Error(f(311));a.lastRenderedReducer=n;var l=e.baseQueue,o=a.pending;if(o!==null){if(l!==null){var r=l.next;l.next=o.next,o.next=r}t.baseQueue=l=o,a.pending=null}if(o=e.baseState,l===null)e.memoizedState=o;else{t=l.next;var u=r=null,m=null,b=t,w=!1;do{var A=b.lane&-536870913;if(A!==b.lane?($&A)===A:(rn&A)===A){var g=b.revertLane;if(g===0)m!==null&&(m=m.next={lane:0,revertLane:0,gesture:null,action:b.action,hasEagerState:b.hasEagerState,eagerState:b.eagerState,next:null}),A===ua&&(w=!0);else if((rn&g)===g){b=b.next,g===ua&&(w=!0);continue}else A={lane:0,revertLane:b.revertLane,gesture:null,action:b.action,hasEagerState:b.hasEagerState,eagerState:b.eagerState,next:null},m===null?(u=m=A,r=o):m=m.next=A,Y.lanes|=g,qn|=g;A=b.action,pa&&n(o,A),o=b.hasEagerState?b.eagerState:n(o,A)}else g={lane:A,revertLane:b.revertLane,gesture:b.gesture,action:b.action,hasEagerState:b.hasEagerState,eagerState:b.eagerState,next:null},m===null?(u=m=g,r=o):m=m.next=g,Y.lanes|=A,qn|=A;b=b.next}while(b!==null&&b!==t);if(m===null?r=o:m.next=u,!rt(o,e.memoizedState)&&(ze=!0,w&&(n=Ka,n!==null)))throw n;e.memoizedState=o,e.baseState=r,e.baseQueue=m,a.lastRenderedState=o}return l===null&&(a.lanes=0),[e.memoizedState,a.dispatch]}function Ts(e){var t=we(),n=t.queue;if(n===null)throw Error(f(311));n.lastRenderedReducer=e;var a=n.dispatch,l=n.pending,o=t.memoizedState;if(l!==null){n.pending=null;var r=l=l.next;do o=e(o,r.action),r=r.next;while(r!==l);rt(o,t.memoizedState)||(ze=!0),t.memoizedState=o,t.baseQueue===null&&(t.baseState=o),n.lastRenderedState=o}return[o,a]}function Bd(e,t,n){var a=Y,l=we(),o=J;if(o){if(n===void 0)throw Error(f(407));n=n()}else n=t();var r=!rt((fe||l).memoizedState,n);if(r&&(l.memoizedState=n,ze=!0),l=l.queue,js(Id.bind(null,a,l,e),[e]),e=l.getSnapshot!==t||r||Se!==null&&(Se.memoizedState.tag&1)!==0,$a(e?9:8,{destroy:void 0},qd.bind(null,a,l,n,t),null),e){if(a.flags|=2048,me===null)throw Error(f(349));o||(rn&127)!==0||Hd(a,t,n)}return n}function Hd(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=Y.updateQueue,t===null?(t=mo(),Y.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function qd(e,t,n,a){t.value=n,t.getSnapshot=a,Yd(t)&&Xd(e)}function Id(e,t,n){return n(function(){Yd(t)&&Xd(e)})}function Yd(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!rt(e,n)}catch{return!0}}function Xd(e){var t=la(e,2);t!==null&&nt(t,e,2)}function Es(e){var t=Ze();if(typeof e=="function"){var n=e;if(e=n(),pa){wn(!0);try{n()}finally{wn(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:sn,lastRenderedState:e},t}function Gd(e,t,n,a){return e.baseState=n,_s(e,fe,typeof a=="function"?a:sn)}function jg(e,t,n,a,l){if(vo(e))throw Error(f(485));if(e=t.action,e!==null){var o={payload:l,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(r){o.listeners.push(r)}};q.T!==null?n(!0):o.isTransition=!1,a(o),n=t.pending,n===null?(o.next=t.pending=o,Qd(t,o)):(o.next=n.next,t.pending=n.next=o)}}function Qd(e,t){var n=t.action,a=t.payload,l=e.state;if(t.isTransition){var o=q.T,r={};r.types=o!==null?o.types:null,q.T=r;try{var u=n(l,a),m=q.S;m!==null&&m(r,u),Zd(e,t,u)}catch(b){ws(e,t,b)}finally{o!==null&&r.types!==null&&(o.types=r.types),q.T=o}}else try{o=n(l,a),Zd(e,t,o)}catch(b){ws(e,t,b)}}function Zd(e,t,n){n!==null&&typeof n=="object"&&typeof n.then=="function"?n.then(function(a){Kd(e,t,a)},function(a){return ws(e,t,a)}):Kd(e,t,n)}function Kd(e,t,n){t.status="fulfilled",t.value=n,Pd(t),e.state=n,t=e.pending,t!==null&&(n=t.next,n===t?e.pending=null:(n=n.next,t.next=n,Qd(e,n)))}function ws(e,t,n){var a=e.pending;if(e.pending=null,a!==null){a=a.next;do t.status="rejected",t.reason=n,Pd(t),t=t.next;while(t!==a)}e.action=null}function Pd(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function Jd(e,t){return t}function Fd(e,t){if(J){var n=me.formState;if(n!==null){e:{var a=Y;if(J){if(ge){t:{for(var l=ge,o=_t;l.nodeType!==8;){if(!o){l=null;break t}if(l=Et(l.nextSibling),l===null){l=null;break t}}o=l.data,l=o==="F!"||o==="F"?l:null}if(l){ge=Et(l.nextSibling),a=l.data==="F!";break e}}On(a)}a=!1}a&&(t=n[0])}}return n=Ze(),n.memoizedState=n.baseState=t,a={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Jd,lastRenderedState:t},n.queue=a,n=xf.bind(null,Y,a),a.dispatch=n,a=Es(!1),o=Ns.bind(null,Y,!1,a.queue),a=Ze(),l={state:t,dispatch:null,action:e,pending:null},a.queue=l,n=jg.bind(null,Y,l,o,n),l.dispatch=n,a.memoizedState=e,[t,n,!1]}function Wd(e){var t=we();return $d(t,fe,e)}function $d(e,t,n){if(t=_s(e,t,Jd)[0],e=go(sn)[0],typeof t=="object"&&t!==null&&typeof t.then=="function")try{var a=ti(t)}catch(r){throw r===Pa?io:r}else a=t;t=we();var l=t.queue,o=l.dispatch;return n!==t.memoizedState&&(Y.flags|=2048,$a(9,{destroy:void 0},Sg.bind(null,l,n),null)),[a,o,e]}function Sg(e,t){e.action=t}function ef(e){var t=we(),n=fe;if(n!==null)return $d(t,n,e);we(),t=t.memoizedState,n=we();var a=n.queue.dispatch;return n.memoizedState=e,[t,a,!1]}function $a(e,t,n,a){return e={tag:e,create:n,deps:a,inst:t,next:null},t=Y.updateQueue,t===null&&(t=mo(),Y.updateQueue=t),n=t.lastEffect,n===null?t.lastEffect=e.next=e:(a=n.next,n.next=e,e.next=a,t.lastEffect=e),e}function tf(){return we().memoizedState}function xo(e,t,n,a){var l=Ze();Y.flags|=e,l.memoizedState=$a(1|t,{destroy:void 0},n,a===void 0?null:a)}function yo(e,t,n,a){var l=we();a=a===void 0?null:a;var o=l.memoizedState.inst;fe!==null&&a!==null&&ps(a,fe.memoizedState.deps)?l.memoizedState=$a(t,o,n,a):(Y.flags|=e,l.memoizedState=$a(1|t,o,n,a))}function nf(e,t){xo(8390656,8,e,t)}function js(e,t){yo(2048,8,e,t)}function zg(e){Y.flags|=4;var t=Y.updateQueue;if(t===null)t=mo(),Y.updateQueue=t,t.events=[e];else{var n=t.events;n===null?t.events=[e]:n.push(e)}}function af(e){var t=we().memoizedState;return zg({ref:t,nextImpl:e}),function(){if((re&2)!==0)throw Error(f(440));return t.impl.apply(void 0,arguments)}}function lf(e,t){return yo(4,2,e,t)}function of(e,t){return yo(4,4,e,t)}function rf(e,t){if(typeof t=="function"){e=e();var n=t(e);return function(){typeof n=="function"?n():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function sf(e,t,n){n=n!=null?n.concat([e]):null,yo(4,4,rf.bind(null,t,e),n)}function Ss(){}function cf(e,t){var n=we();t=t===void 0?null:t;var a=n.memoizedState;return t!==null&&ps(t,a[1])?a[0]:(n.memoizedState=[e,t],e)}function uf(e,t){var n=we();t=t===void 0?null:t;var a=n.memoizedState;if(t!==null&&ps(t,a[1]))return a[0];if(a=e(),pa){wn(!0);try{e()}finally{wn(!1)}}return n.memoizedState=[a,t],a}function zs(e,t,n){return n===void 0||(rn&1073741824)!==0&&($&261930)===0?e.memoizedState=t:(e.memoizedState=n,e=bh(),Y.lanes|=e,qn|=e,n)}function df(e,t,n,a){return rt(n,t)?n:Mn.current!==null?(e=zs(e,n,a),rt(e,t)||(ze=!0),e):(rn&106)===0||(rn&1073741824)!==0&&($&261930)===0?(ze=!0,e.memoizedState=n):(e=bh(),Y.lanes|=e,qn|=e,t)}function ff(e,t,n,a,l){var o=oe.p;oe.p=o!==0&&8>o?o:8;var r=q.T,u={};u.types=r!==null?r.types:null,q.T=u,Ns(e,!1,t,n);try{var m=l(),b=q.S;if(b!==null&&b(u,m),m!==null&&typeof m=="object"&&typeof m.then=="function"){var w=Tg(m,a);ni(e,t,w,ft(e))}else ni(e,t,a,ft(e))}catch(A){ni(e,t,{then:function(){},status:"rejected",reason:A},ft())}finally{oe.p=o,r!==null&&u.types!==null&&(r.types=u.types),q.T=r}}function Ag(){}function As(e,t,n,a){if(e.tag!==5)throw Error(f(476));var l=hf(e).queue;ff(e,l,t,Wn,n===null?Ag:function(){return mf(e),n(a)})}function hf(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:Wn,baseState:Wn,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:sn,lastRenderedState:Wn},next:null};var n={};return t.next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:sn,lastRenderedState:n},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function mf(e){var t=hf(e);t.next===null&&(t=e.alternate.memoizedState),ni(e,t.next.queue,{},ft())}function Os(){return ke(yl)}function pf(){return we().memoizedState}function gf(){return we().memoizedState}function Og(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var n=ft();e=Rn(n);var a=Ln(t,e,n);a!==null&&(nt(a,t,n),Jl(a,t,n)),t={cache:as()},e.payload=t;return}t=t.return}}function Ng(e,t,n){var a=ft();n={lane:a,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},vo(e)?yf(t,n):(n=Kr(e,t,n,a),n!==null&&(nt(n,e,a),vf(n,t,a)))}function xf(e,t,n){var a=ft();ni(e,t,n,a)}function ni(e,t,n,a){var l={lane:a,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};if(vo(e))yf(t,l);else{var o=e.alternate;if(e.lanes===0&&(o===null||o.lanes===0)&&(o=t.lastRenderedReducer,o!==null))try{var r=t.lastRenderedState,u=o(r,n);if(l.hasEagerState=!0,l.eagerState=u,rt(u,r))return Pi(e,t,l,0),me===null&&Ki(),!1}catch{}if(n=Kr(e,t,l,a),n!==null)return nt(n,e,a),vf(n,t,a),!0}return!1}function Ns(e,t,n,a){if(a={lane:2,revertLane:bc(),gesture:null,action:a,hasEagerState:!1,eagerState:null,next:null},vo(e)){if(t)throw Error(f(479))}else t=Kr(e,n,a,2),t!==null&&nt(t,e,2)}function vo(e){var t=e.alternate;return e===Y||t!==null&&t===Y}function yf(e,t){Fa=fo=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function vf(e,t,n){if((n&4194048)!==0){var a=t.lanes;a&=e.pendingLanes,n|=a,t.lanes=n,vu(e,n)}}var bo={readContext:ke,use:po,useCallback:Te,useContext:Te,useEffect:Te,useImperativeHandle:Te,useLayoutEffect:Te,useInsertionEffect:Te,useMemo:Te,useReducer:Te,useRef:Te,useState:Te,useDebugValue:Te,useDeferredValue:Te,useTransition:Te,useSyncExternalStore:Te,useId:Te,useHostTransitionStatus:Te,useFormState:Te,useActionState:Te,useOptimistic:Te,useMemoCache:Te,useCacheRefresh:Te,useEffectEvent:Te},bf={readContext:ke,use:po,useCallback:function(e,t){return Ze().memoizedState=[e,t===void 0?null:t],e},useContext:ke,useEffect:nf,useImperativeHandle:function(e,t,n){n=n!=null?n.concat([e]):null,xo(4194308,4,rf.bind(null,t,e),n)},useLayoutEffect:function(e,t){return xo(4194308,4,e,t)},useInsertionEffect:function(e,t){xo(4,2,e,t)},useMemo:function(e,t){var n=Ze();t=t===void 0?null:t;var a=e();if(pa){wn(!0);try{e()}finally{wn(!1)}}return n.memoizedState=[a,t],a},useReducer:function(e,t,n){var a=Ze();if(n!==void 0){var l=n(t);if(pa){wn(!0);try{n(t)}finally{wn(!1)}}}else l=t;return a.memoizedState=a.baseState=l,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:l},a.queue=e,e=e.dispatch=Ng.bind(null,Y,e),[a.memoizedState,e]},useRef:function(e){var t=Ze();return e={current:e},t.memoizedState=e},useState:function(e){e=Es(e);var t=e.queue,n=xf.bind(null,Y,t);return t.dispatch=n,[e.memoizedState,n]},useDebugValue:Ss,useDeferredValue:function(e,t){var n=Ze();return zs(n,e,t)},useTransition:function(){var e=Es(!1);return e=ff.bind(null,Y,e.queue,!0,!1),Ze().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,n){var a=Y,l=Ze();if(J){if(n===void 0)throw Error(f(407));n=n()}else{if(n=t(),me===null)throw Error(f(349));($&127)!==0||Hd(a,t,n)}l.memoizedState=n;var o={value:n,getSnapshot:t};return l.queue=o,nf(Id.bind(null,a,o,e),[e]),a.flags|=2048,$a(9,{destroy:void 0},qd.bind(null,a,o,n,t),null),n},useId:function(){var e=Ze(),t=me.identifierPrefix;if(J){var n=Ht,a=Bt;n=(a&~(1<<32-it(a)-1)).toString(32)+n,t="_"+t+"R_"+n,n=ho++,0<n&&(t+="H"+n.toString(32)),t+="_"}else n=Eg++,t="_"+t+"r_"+n.toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:Os,useFormState:Fd,useActionState:Fd,useOptimistic:function(e){var t=Ze();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=Ns.bind(null,Y,!0,n),n.dispatch=t,[e,t]},useMemoCache:bs,useCacheRefresh:function(){return Ze().memoizedState=Og.bind(null,Y)},useEffectEvent:function(e){var t=Ze(),n={impl:e};return t.memoizedState=n,function(){if((re&2)!==0)throw Error(f(440));return n.impl.apply(void 0,arguments)}}},_f={readContext:ke,use:po,useCallback:cf,useContext:ke,useEffect:js,useImperativeHandle:sf,useInsertionEffect:lf,useLayoutEffect:of,useMemo:uf,useReducer:go,useRef:tf,useState:function(){return go(sn)},useDebugValue:Ss,useDeferredValue:function(e,t){var n=we();return df(n,fe.memoizedState,e,t)},useTransition:function(){var e=go(sn)[0],t=we().memoizedState;return[typeof e=="boolean"?e:ti(e),t]},useSyncExternalStore:Bd,useId:pf,useHostTransitionStatus:Os,useFormState:Wd,useActionState:Wd,useOptimistic:function(e,t){var n=we();return Gd(n,fe,e,t)},useMemoCache:bs,useCacheRefresh:gf,useEffectEvent:af},Dg={readContext:ke,use:po,useCallback:cf,useContext:ke,useEffect:js,useImperativeHandle:sf,useInsertionEffect:lf,useLayoutEffect:of,useMemo:uf,useReducer:Ts,useRef:tf,useState:function(){return Ts(sn)},useDebugValue:Ss,useDeferredValue:function(e,t){var n=we();return fe===null?zs(n,e,t):df(n,fe.memoizedState,e,t)},useTransition:function(){var e=Ts(sn)[0],t=we().memoizedState;return[typeof e=="boolean"?e:ti(e),t]},useSyncExternalStore:Bd,useId:pf,useHostTransitionStatus:Os,useFormState:ef,useActionState:ef,useOptimistic:function(e,t){var n=we();return fe!==null?Gd(n,fe,e,t):(n.baseState=e,[e,n.queue.dispatch])},useMemoCache:bs,useCacheRefresh:gf,useEffectEvent:af};function Ds(e,t,n,a){t=e.memoizedState,n=n(a,t),n=n==null?t:te({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var Cs={enqueueSetState:function(e,t,n){e=e._reactInternals;var a=ft(),l=Rn(a);l.payload=t,n!=null&&(l.callback=n),t=Ln(e,l,a),t!==null&&(nt(t,e,a),Jl(t,e,a))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var a=ft(),l=Rn(a);l.tag=1,l.payload=t,n!=null&&(l.callback=n),t=Ln(e,l,a),t!==null&&(nt(t,e,a),Jl(t,e,a))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=ft(),a=Rn(n);a.tag=2,t!=null&&(a.callback=t),t=Ln(e,a,n),t!==null&&(nt(t,e,n),Jl(t,e,n))}};function Tf(e,t,n,a,l,o,r){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(a,o,r):t.prototype&&t.prototype.isPureReactComponent?!Il(n,a)||!Il(l,o):!0}function Ef(e,t,n,a){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(n,a),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(n,a),t.state!==e&&Cs.enqueueReplaceState(t,t.state,null)}function ga(e,t){var n=t;if("ref"in t){n={};for(var a in t)a!=="ref"&&(n[a]=t[a])}if(e=e.defaultProps){n===t&&(n=te({},n));for(var l in e)n[l]===void 0&&(n[l]=e[l])}return n}function wf(e){Zi(e)}function jf(e){console.error(e)}function Sf(e){Zi(e)}function _o(e,t){try{var n=e.onUncaughtError;n(t.value,{componentStack:t.stack})}catch(a){setTimeout(function(){throw a})}}function zf(e,t,n){try{var a=e.onCaughtError;a(n.value,{componentStack:n.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(l){setTimeout(function(){throw l})}}function Rs(e,t,n){return n=Rn(n),n.tag=3,n.payload={element:null},n.callback=function(){_o(e,t)},n}function Af(e){return e=Rn(e),e.tag=3,e}function Of(e,t,n,a){var l=n.type.getDerivedStateFromError;if(typeof l=="function"){var o=a.value;e.payload=function(){return l(o)},e.callback=function(){zf(t,n,a)}}var r=n.stateNode;r!==null&&typeof r.componentDidCatch=="function"&&(e.callback=function(){zf(t,n,a),typeof l!="function"&&(In===null?In=new Set([this]):In.add(this));var u=a.stack;this.componentDidCatch(a.value,{componentStack:u!==null?u:""})})}function Cg(e,t,n,a,l){if(n.flags|=32768,a!==null&&typeof a=="object"&&typeof a.then=="function"){if(t=n.alternate,t!==null&&sa(t,n,l,!0),n=Ve.current,n!==null){switch(n.tag){case 31:case 13:case 19:return Ie===null?Io():n.alternate===null&&Ee===0&&(Ee=3),n.flags&=-257,n.flags|=65536,n.lanes=l,a===oo?n.flags|=16384:(t=n.updateQueue,t===null?n.updateQueue=new Set([a]):t.add(a),xc(e,a,l)),!1;case 22:return n.flags|=65536,a===oo?n.flags|=16384:(t=n.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([a])},n.updateQueue=t):(n=t.retryQueue,n===null?t.retryQueue=new Set([a]):n.add(a)),xc(e,a,l)),!1}throw Error(f(435,n.tag))}return xc(e,a,l),Io(),!1}if(J)return t=Ve.current,t!==null?((t.flags&65536)===0&&(t.flags|=256),t.flags|=65536,t.lanes=l,a!==$r&&(e=Error(f(422),{cause:a}),Gl(yt(e,n)))):(a!==$r&&(t=Error(f(423),{cause:a}),Gl(yt(t,n))),e=e.current.alternate,e.flags|=65536,l&=-l,e.lanes|=l,a=yt(a,n),l=Rs(e.stateNode,a,l),cs(e,l),Ee!==4&&(Ee=2)),!1;var o=Error(f(520),{cause:a});if(o=yt(o,n),ui===null?ui=[o]:ui.push(o),Ee!==4&&(Ee=2),t===null)return!0;a=yt(a,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=l&-l,n.lanes|=e,e=Rs(n.stateNode,a,e),cs(n,e),!1;case 1:if(t=n.type,o=n.stateNode,(n.flags&128)===0&&(typeof t.getDerivedStateFromError=="function"||o!==null&&typeof o.componentDidCatch=="function"&&(In===null||!In.has(o))))return n.flags|=65536,l&=-l,n.lanes|=l,l=Af(l),Of(l,e,n,a),cs(n,l),!1;break;case 22:if(n.memoizedState!==null)return n.flags|=65536,!1}n=n.return}while(n!==null);return!1}var Ls=Error(f(461)),ze=!1;function Oe(e,t,n,a){t.child=e===null?Cd(t,null,n,a):ma(t,e.child,n,a)}function Nf(e,t,n,a,l){n=n.render;var o=t.ref;if("ref"in a){var r={};for(var u in a)u!=="ref"&&(r[u]=a[u])}else r=a;return ca(t),a=gs(e,t,n,r,o,l),u=xs(),e!==null&&!ze?(ys(e,t,l),cn(e,t,l)):(J&&u&&$i(t),t.flags|=1,Oe(e,t,a,l),t.child)}function Df(e,t,n,a,l){if(e===null){var o=n.type;return typeof o=="function"&&!Pr(o)&&o.defaultProps===void 0&&n.compare===null?(t.tag=15,t.type=o,Cf(e,t,o,a,l)):(e=Fi(n.type,null,a,t,t.mode,l),e.ref=t.ref,e.return=t,t.child=e)}if(o=e.child,!Is(e,l)){var r=o.memoizedProps;if(n=n.compare,n=n!==null?n:Il,n(r,a)&&e.ref===t.ref)return cn(e,t,l)}return t.flags|=1,e=nn(o,a),e.ref=t.ref,e.return=t,t.child=e}function Cf(e,t,n,a,l){if(e!==null){var o=e.memoizedProps;if(Il(o,a)&&e.ref===t.ref)if(ze=!1,t.pendingProps=a=o,Is(e,l))(e.flags&131072)!==0&&(ze=!0);else return t.lanes=e.lanes,cn(e,t,l)}return Ms(e,t,n,a,l)}function Rf(e,t,n,a){var l=a.children,o=e!==null?e.memoizedState:null;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),a.mode==="hidden"){if((t.flags&128)!==0){if(o=o!==null?o.baseLanes|n:n,e!==null){for(a=t.child=e.child,l=0;a!==null;)l=l|a.lanes|a.childLanes,a=a.sibling;a=l&~o}else a=0,t.child=null;return Lf(e,t,o,n,a)}if((n&536870912)!==0)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&lo(t,o!==null?o.cachePool:null),o!==null?Md(t,o):ds(),kd(t);else return a=t.lanes=536870912,Lf(e,t,o!==null?o.baseLanes|n:n,n,a)}else o!==null?(lo(t,o.cachePool),Md(t,o),Vn(),t.memoizedState=null):(e!==null&&lo(t,null),ds(),Vn());return Oe(e,t,l,n),t.child}function ai(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function Lf(e,t,n,a,l){var o=is();return o=o===null?null:{parent:je._currentValue,pool:o},t.memoizedState={baseLanes:n,cachePool:o},e!==null&&lo(t,null),ds(),kd(t),e!==null&&sa(e,t,a,!0),t.childLanes=l,null}function To(e,t){return t=Eo({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function Mf(e,t,n){return ma(t,e.child,null,n),e=To(t,t.pendingProps),e.flags|=2,st(t),t.memoizedState=null,e}function Rg(e,t,n){var a=t.pendingProps,l=(t.flags&128)!==0;if(t.flags&=-129,e===null){if(J){if(a.mode==="hidden")return e=To(t,a),t.lanes=536870912,e.memoizedState={baseLanes:0,cachePool:null},ai(null,e);if(hs(t),(e=ge)?(e=rm(e,_t),e=e!==null&&e.data==="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:zn!==null?{id:Bt,overflow:Ht}:null,retryLane:536870912,hydrationErrors:null},n=xd(e),n.return=t,t.child=n,De=t,ge=null)):e=null,e===null)throw On(t);return t.lanes=536870912,null}return To(t,a)}var o=e.memoizedState;if(o!==null){var r=o.dehydrated;if(hs(t),l)if(t.flags&256)t.flags&=-257,t=Mf(e,t,n);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(f(558));else if(ze||sa(e,t,n,!1),l=(n&e.childLanes)!==0,ze||l){if(Mn.current===null){if(a=me,a!==null&&(r=bu(a,n),r!==0&&r!==o.retryLane))throw o.retryLane=r,la(e,r),nt(a,e,r),Ls;Io()}t=Mf(e,t,n)}else e=o.treeContext,ge=Et(r.nextSibling),De=t,J=!0,An=null,_t=!1,e!==null&&bd(t,e),t=To(t,a),t.flags|=134221824;return t}return e=nn(e.child,{mode:a.mode,children:a.children}),e.ref=t.ref,t.child=e,e.return=t,e}function el(e,t){var n=t.ref;if(n===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof n!="function"&&typeof n!="object")throw Error(f(284));(e===null||e.ref!==n)&&(t.flags|=4194816)}}function Ms(e,t,n,a,l){return ca(t),n=gs(e,t,n,a,void 0,l),a=xs(),e!==null&&!ze?(ys(e,t,l),cn(e,t,l)):(J&&a&&$i(t),t.flags|=1,Oe(e,t,n,l),t.child)}function kf(e,t,n,a,l,o){return ca(t),t.updateQueue=null,n=Ud(t,a,n,l),Vd(e),a=xs(),e!==null&&!ze?(ys(e,t,o),cn(e,t,o)):(J&&a&&$i(t),t.flags|=1,Oe(e,t,n,o),t.child)}function Vf(e,t,n,a,l){if(ca(t),t.stateNode===null){var o=Xa,r=n.contextType;typeof r=="object"&&r!==null&&(o=ke(r)),o=new n(a,o),t.memoizedState=o.state!==null&&o.state!==void 0?o.state:null,o.updater=Cs,t.stateNode=o,o._reactInternals=t,o=t.stateNode,o.props=a,o.state=t.memoizedState,o.refs={},rs(t),r=n.contextType,o.context=typeof r=="object"&&r!==null?ke(r):Xa,o.state=t.memoizedState,r=n.getDerivedStateFromProps,typeof r=="function"&&(Ds(t,n,r,a),o.state=t.memoizedState),typeof n.getDerivedStateFromProps=="function"||typeof o.getSnapshotBeforeUpdate=="function"||typeof o.UNSAFE_componentWillMount!="function"&&typeof o.componentWillMount!="function"||(r=o.state,typeof o.componentWillMount=="function"&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount=="function"&&o.UNSAFE_componentWillMount(),r!==o.state&&Cs.enqueueReplaceState(o,o.state,null),Wl(t,a,o,l),Fl(),o.state=t.memoizedState),typeof o.componentDidMount=="function"&&(t.flags|=4194308),a=!0}else if(e===null){o=t.stateNode;var u=t.memoizedProps,m=ga(n,u);o.props=m;var b=o.context,w=n.contextType;r=Xa,typeof w=="object"&&w!==null&&(r=ke(w));var A=n.getDerivedStateFromProps;w=typeof A=="function"||typeof o.getSnapshotBeforeUpdate=="function",u=t.pendingProps!==u,w||typeof o.UNSAFE_componentWillReceiveProps!="function"&&typeof o.componentWillReceiveProps!="function"||(u||b!==r)&&Ef(t,o,a,r),Cn=!1;var g=t.memoizedState;o.state=g,Wl(t,a,o,l),Fl(),b=t.memoizedState,u||g!==b||Cn?(typeof A=="function"&&(Ds(t,n,A,a),b=t.memoizedState),(m=Cn||Tf(t,n,m,a,g,b,r))?(w||typeof o.UNSAFE_componentWillMount!="function"&&typeof o.componentWillMount!="function"||(typeof o.componentWillMount=="function"&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount=="function"&&o.UNSAFE_componentWillMount()),typeof o.componentDidMount=="function"&&(t.flags|=4194308)):(typeof o.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=a,t.memoizedState=b),o.props=a,o.state=b,o.context=r,a=m):(typeof o.componentDidMount=="function"&&(t.flags|=4194308),a=!1)}else{o=t.stateNode,ss(e,t),r=t.memoizedProps,w=ga(n,r),o.props=w,A=t.pendingProps,g=o.context,b=n.contextType,m=Xa,typeof b=="object"&&b!==null&&(m=ke(b)),u=n.getDerivedStateFromProps,(b=typeof u=="function"||typeof o.getSnapshotBeforeUpdate=="function")||typeof o.UNSAFE_componentWillReceiveProps!="function"&&typeof o.componentWillReceiveProps!="function"||(r!==A||g!==m)&&Ef(t,o,a,m),Cn=!1,g=t.memoizedState,o.state=g,Wl(t,a,o,l),Fl();var T=t.memoizedState;r!==A||g!==T||Cn||e!==null&&e.dependencies!==null&&no(e.dependencies)?(typeof u=="function"&&(Ds(t,n,u,a),T=t.memoizedState),(w=Cn||Tf(t,n,w,a,g,T,m)||e!==null&&e.dependencies!==null&&no(e.dependencies))?(b||typeof o.UNSAFE_componentWillUpdate!="function"&&typeof o.componentWillUpdate!="function"||(typeof o.componentWillUpdate=="function"&&o.componentWillUpdate(a,T,m),typeof o.UNSAFE_componentWillUpdate=="function"&&o.UNSAFE_componentWillUpdate(a,T,m)),typeof o.componentDidUpdate=="function"&&(t.flags|=4),typeof o.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof o.componentDidUpdate!="function"||r===e.memoizedProps&&g===e.memoizedState||(t.flags|=4),typeof o.getSnapshotBeforeUpdate!="function"||r===e.memoizedProps&&g===e.memoizedState||(t.flags|=1024),t.memoizedProps=a,t.memoizedState=T),o.props=a,o.state=T,o.context=m,a=w):(typeof o.componentDidUpdate!="function"||r===e.memoizedProps&&g===e.memoizedState||(t.flags|=4),typeof o.getSnapshotBeforeUpdate!="function"||r===e.memoizedProps&&g===e.memoizedState||(t.flags|=1024),a=!1)}return o=a,el(e,t),a=(t.flags&128)!==0,o||a?(o=t.stateNode,n=a&&typeof n.getDerivedStateFromError!="function"?null:o.render(),t.flags|=1,e!==null&&a?(t.child=ma(t,e.child,null,l),t.child=ma(t,null,n,l)):Oe(e,t,n,l),t.memoizedState=o.state,e=t.child):e=cn(e,t,l),e}function Uf(e,t,n,a){return oa(),t.flags|=256,Oe(e,t,n,a),t.child}var ks={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Vs(e){return{baseLanes:e,cachePool:Sd()}}function Us(e,t,n){return e=e!==null?e.childLanes&~n:0,t&&(e|=dt),e}function Bf(e,t,n){var a=t.pendingProps,l=!1,o=(t.flags&128)!==0,r;if((r=o)||(r=e!==null&&e.memoizedState===null?!1:(Ue.current&2)!==0),r&&(l=!0,t.flags&=-129),r=(t.flags&32)!==0,t.flags&=-33,e===null){if(J){if(l?kn(t):Vn(),(e=ge)?(e=rm(e,_t),e=e!==null&&e.data!=="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:zn!==null?{id:Bt,overflow:Ht}:null,retryLane:536870912,hydrationErrors:null},n=xd(e),n.return=t,t.child=n,De=t,ge=null)):e=null,e===null)throw On(t);return Vc(e)?t.lanes=32:t.lanes=536870912,null}return o=a.children,a=a.fallback,l?(Vn(),l=t.mode,o=Eo({mode:"hidden",children:o},l),a=ia(a,l,n,null),o.return=t,a.return=t,o.sibling=a,t.child=o,a=t.child,a.memoizedState=Vs(n),a.childLanes=Us(e,r,n),t.memoizedState=ks,ai(null,a)):(kn(t),Bs(t,o))}var u=e.memoizedState;if(u!==null){var m=u.dehydrated;if(m!==null)return Lg(e,t,o,r,a,m,u,n)}return l?(Vn(),l=a.fallback,o=t.mode,u=e.child,m=u.sibling,a=nn(u,{mode:"hidden",children:a.children}),a.subtreeFlags=u.subtreeFlags&1206910976,m!==null?l=nn(m,l):(l=ia(l,o,n,null),l.flags|=2),l.return=t,a.return=t,a.sibling=l,t.child=a,ai(null,a),a=t.child,l=e.child.memoizedState,l===null?l=Vs(n):(o=l.cachePool,o!==null?(u=je._currentValue,o=o.parent!==u?{parent:u,pool:u}:o):o=Sd(),l={baseLanes:l.baseLanes|n,cachePool:o}),a.memoizedState=l,a.childLanes=Us(e,r,n),t.memoizedState=ks,ai(e.child,a)):(kn(t),n=e.child,e=n.sibling,n=nn(n,{mode:"visible",children:a.children}),n.return=t,n.sibling=null,e!==null&&(r=t.deletions,r===null?(t.deletions=[e],t.flags|=16):r.push(e)),t.child=n,t.memoizedState=null,n)}function Bs(e,t){return t=Eo({mode:"visible",children:t},e.mode),t.return=e,e.child=t}function Eo(e,t){return e=We(22,e,null,t),e.lanes=0,e}function wo(e,t,n){return ma(t,e.child,null,n),e=Bs(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function Lg(e,t,n,a,l,o,r,u){if(n)return t.flags&256?(kn(t),t.flags&=-257,wo(e,t,u)):t.memoizedState!==null?(Vn(),t.child=e.child,t.flags|=128,null):(Vn(),o=l.fallback,r=t.mode,l=Eo({mode:"visible",children:l.children},r),o=ia(o,r,u,null),o.flags|=2,l.return=t,o.return=t,l.sibling=o,t.child=l,ma(t,e.child,null,u),l=t.child,l.memoizedState=Vs(u),l.childLanes=Us(e,a,u),t.memoizedState=ks,ai(null,l));if(kn(t),Vc(o)){if(a=o.nextSibling&&o.nextSibling.dataset,a)var m=a.dgst;return a=m,a!==""&&(l=Error(f(419)),l.stack="",l.digest=a,Gl({value:l,source:null,stack:null})),wo(e,t,u)}if(ze||sa(e,t,u,!1),a=(u&e.childLanes)!==0,ze||a){if(Mn.current!==null)return wo(e,t,u);if(a=me,a!==null&&(l=bu(a,u),l!==0&&l!==r.retryLane))throw r.retryLane=l,la(e,l),nt(a,e,l),Ls;return kc(o)||Io(),wo(e,t,u)}return kc(o)?(t.flags|=192,t.child=e.child,null):(e=r.treeContext,ge=Et(o.nextSibling),De=t,J=!0,An=null,_t=!1,e!==null&&bd(t,e),t=Bs(t,l.children),t.flags|=134221824,t)}function Hf(e,t,n){e.lanes|=t;var a=e.alternate;a!==null&&(a.lanes|=t),to(e.return,t,n)}function qf(e){for(var t=null;e!==null;){var n=e.alternate;n!==null&&uo(n)===null&&(t=e),e=e.sibling}return t}function jo(e,t,n,a,l,o){var r=e.memoizedState;r===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:a,tail:n,tailMode:l,treeForkCount:o}:(r.isBackwards=t,r.rendering=null,r.renderingStartTime=0,r.last=a,r.tail=n,r.tailMode=l,r.treeForkCount=o)}function Hs(e){var t=e.child;for(e.child=null;t!==null;){var n=t.sibling;t.sibling=e.child,e.child=t,t=n}}function qs(e,t,n){var a=t.pendingProps,l=a.revealOrder,o=a.tail;a=a.children;var r=Ue.current;if(t.flags&128)return $l(t,r),null;var u=(r&2)!==0;if(u?(r=r&1|2,t.flags|=128):r&=1,$l(t,r),l==="backwards"&&e!==null?(Hs(e),Oe(e,t,a,n),Hs(e)):Oe(e,t,a,n),a=J?Xl:0,!u&&e!==null&&(e.flags&128)!==0)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Hf(e,n,t);else if(e.tag===19)Hf(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(l){case"backwards":n=qf(t.child),n===null?(l=t.child,t.child=null):(l=n.sibling,n.sibling=null,Hs(t)),jo(t,!0,l,null,o,a);break;case"unstable_legacy-backwards":for(n=null,l=t.child,t.child=null;l!==null;){if(e=l.alternate,e!==null&&uo(e)===null){t.child=l;break}e=l.sibling,l.sibling=n,n=l,l=e}jo(t,!0,n,null,o,a);break;case"together":jo(t,!1,null,null,void 0,a);break;case"independent":t.memoizedState=null;break;default:n=qf(t.child),n===null?(l=t.child,t.child=null):(l=n.sibling,n.sibling=null),jo(t,!1,l,n,o,a)}return t.child}function If(e,t,n){var a=t.pendingProps;return Nn(t,t.type,a.value),Oe(e,t,a.children,n),t.child}function cn(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),qn|=t.lanes,(n&t.childLanes)===0)if(e!==null){if(sa(e,t,n,!1),(n&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(f(153));if(t.child!==null){for(e=t.child,n=nn(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=nn(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function Is(e,t){return(e.lanes&t)!==0?!0:(e=e.dependencies,!!(e!==null&&no(e)))}function Mg(e,t,n){switch(t.tag){case 3:Oi(t,t.stateNode.containerInfo),Nn(t,je,e.memoizedState.cache),oa();break;case 27:case 5:pr(t);break;case 4:Oi(t,t.stateNode.containerInfo);break;case 10:Nn(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,hs(t),null;break;case 13:var a=t.memoizedState;if(a!==null){if(a.dehydrated!==null)return kn(t),t.flags|=128,null;a=sa(e,t,n,!1);var l=t.child.childLanes;return a||(n&l)!==0?Bf(e,t,n):(kn(t),e=cn(e,t,n),e!==null?e.sibling:null)}kn(t);break;case 19:if(t.flags&128)return qs(e,t,n);if(l=(e.flags&128)!==0,a=(n&t.childLanes)!==0,a||(sa(e,t,n,!1),a=(n&t.childLanes)!==0),l){if(a)return qs(e,t,n);t.flags|=128}if(l=t.memoizedState,l!==null&&(l.rendering=null,l.tail=null,l.lastEffect=null),$l(t,Ue.current),a)break;return null;case 22:return t.lanes=0,Rf(e,t,n,t.pendingProps);case 24:Nn(t,je,e.memoizedState.cache)}return cn(e,t,n)}function Yf(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps)ze=!0;else{if(!Is(e,n)&&(t.flags&128)===0)return ze=!1,Mg(e,t,n);ze=(e.flags&131072)!==0}else ze=!1,J&&(t.flags&1048576)!==0&&vd(t,Xl,t.index);switch(t.lanes=0,t.tag){case 16:e:{var a=t.pendingProps;if(e=fa(t.elementType),t.type=e,typeof e=="function")Pr(e)?(a=ga(e,a),t.tag=1,t=Vf(null,t,e,a,n)):(t.tag=0,t=Ms(null,t,e,a,n));else{if(e!=null){var l=e.$$typeof;if(l===k){t.tag=11,t=Nf(null,t,e,a,n);break e}else if(l===ye){t.tag=14,t=Df(null,t,e,a,n);break e}else if(l===Je){t.tag=10,t.type=e,t=If(null,t,n);break e}}throw t=hr(e)||e,Error(f(306,t,""))}}return t;case 0:return Ms(e,t,t.type,t.pendingProps,n);case 1:return a=t.type,l=ga(a,t.pendingProps),Vf(e,t,a,l,n);case 3:e:{if(Oi(t,t.stateNode.containerInfo),e===null)throw Error(f(387));a=t.pendingProps;var o=t.memoizedState;l=o.element,ss(e,t),Wl(t,a,null,n);var r=t.memoizedState;if(a=r.cache,Nn(t,je,a),a!==o.cache&&ns(t,[je],n,!0),Fl(),a=r.element,o.isDehydrated)if(o={element:a,isDehydrated:!1,cache:r.cache},t.updateQueue.baseState=o,t.memoizedState=o,t.flags&256){t=Uf(e,t,a,n);break e}else if(a!==l){l=yt(Error(f(424)),t),Gl(l),t=Uf(e,t,a,n);break e}else for(e=t.stateNode.containerInfo,e.nodeType===9?e=e.body:e=e.nodeName==="HTML"?e.ownerDocument.body:e,ge=Et(e.firstChild),De=t,J=!0,An=null,_t=!0,n=Cd(t,null,a,n),t.child=n;n;)n.flags=n.flags&-3|134221824,n=n.sibling;else{if(oa(),a===l){t=cn(e,t,n);break e}Oe(e,t,a,n)}t=t.child}return t;case 26:return el(e,t),e===null?(n=mm(t.type,null,t.pendingProps,null))?t.memoizedState=n:J||(t.stateNode=Zh(t.type,t.pendingProps,Tn.current,t)):t.memoizedState=mm(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return pr(t),e===null&&J&&(a=t.stateNode=um(t.type,t.pendingProps,Tn.current),De=t,_t=!0,l=ge,Gn(t.type)?(Uc=l,ge=Et(a.firstChild)):ge=l),Oe(e,t,t.pendingProps.children,n),el(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&J&&((l=a=ge)&&(a=Ox(a,t.type,t.pendingProps,_t),a!==null?(t.stateNode=a,De=t,ge=Et(a.firstChild),_t=!1,l=!0):l=!1),l||On(t)),pr(t),l=t.type,o=t.pendingProps,r=e!==null?e.memoizedProps:null,a=o.children,Oc(l,o)?a=null:r!==null&&Oc(l,r)&&(t.flags|=32),t.memoizedState!==null&&(l=gs(e,t,wg,null,null,n),yl._currentValue=l),el(e,t),Oe(e,t,a,n),t.child;case 6:return e===null&&J&&((e=n=ge)&&(n=Nx(n,t.pendingProps,_t),n!==null?(t.stateNode=n,De=t,ge=null,e=!0):e=!1),e||On(t)),null;case 13:return Bf(e,t,n);case 4:return Oi(t,t.stateNode.containerInfo),a=t.pendingProps,e===null?t.child=ma(t,null,a,n):Oe(e,t,a,n),t.child;case 11:return Nf(e,t,t.type,t.pendingProps,n);case 7:return a=t.pendingProps,el(e,t),Oe(e,t,a,n),t.child;case 8:return Oe(e,t,t.pendingProps.children,n),t.child;case 12:return Oe(e,t,t.pendingProps.children,n),t.child;case 10:return If(e,t,n);case 9:return l=t.type._context,a=t.pendingProps.children,ca(t),l=ke(l),a=a(l),t.flags|=1,Oe(e,t,a,n),t.child;case 14:return Df(e,t,t.type,t.pendingProps,n);case 15:return Cf(e,t,t.type,t.pendingProps,n);case 19:return qs(e,t,n);case 31:return Rg(e,t,n);case 22:return Rf(e,t,n,t.pendingProps);case 24:return ca(t),a=ke(je),e===null?(l=is(),l===null&&(l=me,o=as(),l.pooledCache=o,o.refCount++,o!==null&&(l.pooledCacheLanes|=n),l=o),t.memoizedState={parent:a,cache:l},rs(t),Nn(t,je,l)):((e.lanes&n)!==0&&(ss(e,t),Wl(t,null,null,n),Fl()),l=e.memoizedState,o=t.memoizedState,l.parent!==a?(l={parent:a,cache:a},t.memoizedState=l,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=l),Nn(t,je,a)):(a=o.cache,Nn(t,je,a),a!==l.cache&&ns(t,[je],n,!0))),Oe(e,t,t.pendingProps.children,n),t.child;case 30:return t.stateNode===null&&(t.stateNode={autoName:null,paired:null,clones:null,ref:null}),a=t.pendingProps,a.name!=null&&a.name!=="auto"?t.flags|=e===null?18882560:18874368:J&&$i(t),e!==null&&e.memoizedProps.name!==a.name?t.flags|=4194816:el(e,t),Oe(e,t,a.children,n),t.child;case 29:throw t.pendingProps}throw Error(f(156,t.tag))}function un(e){e.flags|=4}function Ys(e,t,n,a,l){var o;if((o=(e.mode&32)!==0)&&(o=n===null?ym(t,a):ym(t,a)&&(a.src!==n.src||a.srcSet!==n.srcSet)),o){if(e.flags|=16777216,(l&335544128)===l)if(e.stateNode.complete)e.flags|=8192;else if(wh())e.flags|=8192;else throw ha=oo,os}else e.flags&=-16777217}function Xf(e,t){if(t.type!=="stylesheet"||(t.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!vm(t))if(wh())e.flags|=8192;else throw ha=oo,os}function So(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag!==22?xu():536870912,e.lanes|=t,il|=t)}function li(e,t){if(!J)switch(e.tailMode){case"visible":break;case"collapsed":for(var n=e.tail,a=null;n!==null;)n.alternate!==null&&(a=n),n=n.sibling;a===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:a.sibling=null;break;default:for(t=e.tail,n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null}}function xe(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,a=0;if(t)for(var l=e.child;l!==null;)n|=l.lanes|l.childLanes,a|=l.subtreeFlags&1206910976,a|=l.flags&1206910976,l.return=e,l=l.sibling;else for(l=e.child;l!==null;)n|=l.lanes|l.childLanes,a|=l.subtreeFlags,a|=l.flags,l.return=e,l=l.sibling;return e.subtreeFlags|=a,e.childLanes=n,t}function kg(e,t,n){var a=t.pendingProps;switch(Wr(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return xe(t),null;case 1:return xe(t),null;case 3:return n=t.stateNode,a=null,e!==null&&(a=e.memoizedState.cache),t.memoizedState.cache!==a&&(t.flags|=2048),on(je),Da(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(e===null||e.child===null)&&(Za(t)?un(t):e===null||e.memoizedState.isDehydrated&&(t.flags&256)===0||(t.flags|=1024,es())),xe(t),null;case 26:var l=t.type,o=t.memoizedState;return e===null?(un(t),o!==null?(xe(t),Xf(t,o)):(xe(t),Ys(t,l,null,a,n))):o?o!==e.memoizedState?(un(t),xe(t),Xf(t,o)):(xe(t),t.flags&=-16777217):(e=e.memoizedProps,e!==a&&un(t),xe(t),Ys(t,l,e,a,n)),null;case 27:if(Ni(t),n=Tn.current,l=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==a&&un(t);else{if(!a){if(t.stateNode===null)throw Error(f(166));return xe(t),t.subtreeFlags&=-33554433,null}e=Vt.current,Za(t)?_d(t):(e=um(l,a,n),t.stateNode=e,un(t))}return xe(t),t.subtreeFlags&=-33554433,null;case 5:if(Ni(t),l=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==a&&un(t);else{if(!a){if(t.stateNode===null)throw Error(f(166));return xe(t),t.subtreeFlags&=-33554433,null}if(o=Vt.current,Za(t))_d(t);else{var r=pi(Tn.current);switch(o){case 1:o=r.createElementNS("http://www.w3.org/2000/svg",l);break;case 2:o=r.createElementNS("http://www.w3.org/1998/Math/MathML",l);break;default:switch(l){case"svg":o=r.createElementNS("http://www.w3.org/2000/svg",l);break;case"math":o=r.createElementNS("http://www.w3.org/1998/Math/MathML",l);break;case"script":o=r.createElement("div"),o.innerHTML="<script><\/script>",o=o.removeChild(o.firstChild);break;case"select":o=typeof a.is=="string"?r.createElement("select",{is:a.is}):r.createElement("select"),a.multiple?o.multiple=!0:a.size&&(o.size=a.size);break;default:o=typeof a.is=="string"?r.createElement(l,{is:a.is}):r.createElement(l)}}o[Me]=t,o[Fe]=a;e:for(r=t.child;r!==null;){if(r.tag===5||r.tag===6)o.appendChild(r.stateNode);else if(r.tag!==4&&r.tag!==27&&r.child!==null){r.child.return=r,r=r.child;continue}if(r===t)break e;for(;r.sibling===null;){if(r.return===null||r.return===t)break e;r=r.return}r.sibling.return=r.return,r=r.sibling}t.stateNode=o;e:switch(He(o,l,a),l){case"button":case"input":case"select":case"textarea":a=!!a.autoFocus;break e;case"img":a=!0;break e;default:a=!1}a&&un(t)}}return xe(t),t.subtreeFlags&=-33554433,Ys(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,n),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==a&&un(t);else{if(typeof a!="string"&&t.stateNode===null)throw Error(f(166));if(e=Tn.current,Za(t)){if(e=t.stateNode,n=t.memoizedProps,a=null,l=De,l!==null)switch(l.tag){case 27:case 5:a=l.memoizedProps}e[Me]=t,e=!!(e.nodeValue===n||a!==null&&a.suppressHydrationWarning===!0||Yh(e.nodeValue,n)),e||On(t,!0)}else e=pi(e).createTextNode(a),e[Me]=t,t.stateNode=e}return xe(t),null;case 31:if(n=t.memoizedState,e===null||e.memoizedState!==null){if(a=Za(t),n!==null){if(e===null){if(!a)throw Error(f(318));if(e=t.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(f(557));e[Me]=t}else oa(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;xe(t),e=!1}else n=es(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=n),e=!0;if(!e)return t.flags&256?(st(t),t):(st(t),null);if((t.flags&128)!==0)throw Error(f(558))}return xe(t),null;case 13:if(a=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(l=Za(t),a!==null&&a.dehydrated!==null){if(e===null){if(!l)throw Error(f(318));if(l=t.memoizedState,l=l!==null?l.dehydrated:null,!l)throw Error(f(317));l[Me]=t}else oa(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;xe(t),l=!1}else l=es(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=l),l=!0;if(!l)return t.flags&256?(st(t),t):(st(t),null)}return st(t),(t.flags&128)!==0?(t.lanes=n,t):(n=a!==null,e=e!==null&&e.memoizedState!==null,n&&(a=t.child,l=null,a.alternate!==null&&a.alternate.memoizedState!==null&&a.alternate.memoizedState.cachePool!==null&&(l=a.alternate.memoizedState.cachePool.pool),o=null,a.memoizedState!==null&&a.memoizedState.cachePool!==null&&(o=a.memoizedState.cachePool.pool),o!==l&&(a.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),So(t,t.updateQueue),xe(t),null);case 4:return Da(),e===null&&wc(t.stateNode.containerInfo),t.flags|=67108864,xe(t),null;case 10:return on(t.type),xe(t),null;case 19:if(ms(t),a=t.memoizedState,a===null)return xe(t),null;if(l=(t.flags&128)!==0,o=a.rendering,o===null)if(l)li(a,!1);else{if(Ee!==0||e!==null&&(e.flags&128)!==0)for(e=t.child;e!==null;){if(o=uo(e),o!==null){for(t.flags|=128,li(a,!1),e=o.updateQueue,t.updateQueue=e,So(t,e),t.subtreeFlags=0,e=n,n=t.child;n!==null;)gd(n,e),n=n.sibling;return $l(t,Ue.current&1|2),J&&an(t,a.treeForkCount),t.child}e=e.sibling}a.tail!==null&&at()>Uo&&(t.flags|=128,l=!0,li(a,!1),t.lanes=4194304)}else{if(!l)if(e=uo(o),e!==null){if(t.flags|=128,l=!0,e=e.updateQueue,t.updateQueue=e,So(t,e),li(a,!0),a.tail===null&&a.tailMode!=="collapsed"&&a.tailMode!=="visible"&&!o.alternate&&!J)return xe(t),null}else 2*at()-a.renderingStartTime>Uo&&n!==536870912&&(t.flags|=128,l=!0,li(a,!1),t.lanes=4194304);a.isBackwards?(o.sibling=t.child,t.child=o):(e=a.last,e!==null?e.sibling=o:t.child=o,a.last=o)}if(a.tail!==null){e=a.tail;e:{for(n=e;n!==null;){if(n.alternate!==null){n=!1;break e}n=n.sibling}n=!0}return a.rendering=e,a.tail=e.sibling,a.renderingStartTime=at(),e.sibling=null,o=Ue.current,o=l?o&1|2:o&1,a.tailMode==="visible"||a.tailMode==="collapsed"||!n||J?$l(t,o):(n=o,pe(Ve,t),pe(Ue,n),Ie===null&&(Ie=t)),J&&an(t,a.treeForkCount),e}return xe(t),null;case 22:case 23:return st(t),fs(),a=t.memoizedState!==null,e!==null?e.memoizedState!==null!==a&&(t.flags|=8192):a&&(t.flags|=8192),a?(n&536870912)!==0&&(t.flags&128)===0&&(xe(t),t.subtreeFlags&6&&(t.flags|=8192)):xe(t),n=t.updateQueue,n!==null&&So(t,n.retryQueue),n=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),a=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(a=t.memoizedState.cachePool.pool),a!==n&&(t.flags|=2048),e!==null&&Le(da),null;case 24:return n=null,e!==null&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),on(je),xe(t),null;case 25:return null;case 30:return t.flags|=33554432,xe(t),null}throw Error(f(156,t.tag))}function Vg(e,t){switch(Wr(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return on(je),Da(),e=t.flags,(e&65536)!==0&&(e&128)===0?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return Ni(t),null;case 31:if(t.memoizedState!==null){if(st(t),t.alternate===null)throw Error(f(340));oa()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(st(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(f(340));oa()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return ms(t),e=t.flags,e&65536?(t.flags=e&-65537|128,e=t.memoizedState,e!==null&&(e.rendering=null,e.tail=null),t.flags|=4,t):null;case 4:return Da(),null;case 10:return on(t.type),null;case 22:case 23:return st(t),fs(),e!==null&&Le(da),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return on(je),null;case 25:return null;default:return null}}function Gf(e,t){switch(Wr(t),t.tag){case 3:on(je),Da();break;case 26:case 27:case 5:Ni(t);break;case 4:Da();break;case 31:t.memoizedState!==null&&st(t);break;case 13:st(t);break;case 19:ms(t);break;case 10:on(t.type);break;case 22:case 23:st(t),fs(),e!==null&&Le(da);break;case 24:on(je)}}function ii(e,t){try{var n=t.updateQueue,a=n!==null?n.lastEffect:null;if(a!==null){var l=a.next;n=l;do{if((n.tag&e)===e){a=void 0;var o=n.create,r=n.inst;a=o(),r.destroy=a}n=n.next}while(n!==l)}}catch(u){ue(t,t.return,u)}}function Un(e,t,n){try{var a=t.updateQueue,l=a!==null?a.lastEffect:null;if(l!==null){var o=l.next;a=o;do{if((a.tag&e)===e){var r=a.inst,u=r.destroy;if(u!==void 0){r.destroy=void 0,l=t;var m=n,b=u;try{b()}catch(w){ue(l,m,w)}}}a=a.next}while(a!==o)}}catch(w){ue(t,t.return,w)}}function Qf(e){var t=e.updateQueue;if(t!==null){var n=e.stateNode;try{Ld(t,n)}catch(a){ue(e,e.return,a)}}}function Zf(e,t,n){n.props=ga(e.type,e.memoizedProps),n.state=e.memoizedState;try{n.componentWillUnmount()}catch(a){ue(e,t,a)}}function qt(e,t){try{var n=e.ref;if(n!==null){switch(e.tag){case 26:case 27:case 5:var a=e.stateNode;break;case 30:var l=e.stateNode,o=en(e.memoizedProps,l);(l.ref===null||l.ref.name!==o)&&(l.ref=em(o)),a=l.ref;break;case 7:if(e.stateNode===null){var r=new ht(e);O(e.child,!1,zx,r,void 0,void 0),e.stateNode=r}a=e.stateNode;break;default:a=e.stateNode}typeof n=="function"?e.refCleanup=n(a):n.current=a}}catch(u){ue(e,t,u)}}function Be(e,t){var n=e.ref,a=e.refCleanup;if(n!==null)if(typeof a=="function")try{a()}catch(l){ue(e,t,l)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof n=="function")try{n(null)}catch(l){ue(e,t,l)}else n.current=null}function zo(e,t){if((e.tag===5||e.tag===27||e.tag===6)&&e.alternate===null&&t!==null)for(var n=0;n<t.length;n++)om(e.stateNode,t[n])}function Kf(e){for(var t=e.return;t!==null&&(Gs(t)&&om(e.stateNode,t.stateNode),!Xs(t));)t=t.return}function oi(e){for(var t=e.return;t!==null&&(Gs(t)&&Ax(e.stateNode,t.stateNode),!Xs(t));)t=t.return}function Xs(e){return e.tag===5||e.tag===3||e.tag===27}function Gs(e){return e&&e.tag===7&&e.stateNode!==null}function Qs(e){var t=e.type,n=e.memoizedProps,a=e.stateNode;try{e:switch(t){case"button":case"input":case"select":case"textarea":n.autoFocus&&a.focus();break e;case"img":n.src?a.src=n.src:n.srcSet&&(a.srcset=n.srcSet)}}catch(l){ue(e,e.return,l)}}function Zs(e,t,n){try{var a=e.stateNode;cx(a,e.type,n,t),a[Fe]=t}catch(l){ue(e,e.return,l)}}function Pf(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Gn(e.type)||e.tag===4}function Ks(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||Pf(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Gn(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Ps(e,t,n,a){var l=e.tag;if(l===5||l===6)l=e.stateNode,t?(n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n).insertBefore(l,t):(t=n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n,t.appendChild(l),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=Ut)),zo(e,a),le=!0;else if(l!==4&&(l===27&&(zo(e,a),a=null,Gn(e.type)&&(n=e.stateNode,t=null)),e=e.child,e!==null))for(Ps(e,t,n,a),e=e.sibling;e!==null;)Ps(e,t,n,a),e=e.sibling}function Ao(e,t,n,a){var l=e.tag;if(l===5||l===6)l=e.stateNode,t?n.insertBefore(l,t):n.appendChild(l),zo(e,a),le=!0;else if(l!==4&&(l===27&&(zo(e,a),a=null,Gn(e.type)&&(n=e.stateNode)),e=e.child,e!==null))for(Ao(e,t,n,a),e=e.sibling;e!==null;)Ao(e,t,n,a),e=e.sibling}function Jf(e){var t=e.stateNode,n=e.memoizedProps;try{for(var a=e.type,l=t.attributes;l.length;)t.removeAttributeNode(l[0]);He(t,a,n),t[Me]=e,t[Fe]=n}catch(o){ue(e,e.return,o)}}var Oo=!1,ct=null;function Ff(e){(e.tag===30||(e.subtreeFlags&33554432)!==0)&&(Oo=!0)}var It=null;function Wf(){var e=It;return It=null,e}var $e=0;function tl(e,t,n,a,l){return $e=0,$f(e.child,t,n,a,l)}function $f(e,t,n,a,l){for(var o=!1;e!==null;){if(e.tag===5){var r=e.stateNode;if(a!==null){var u=Cc(r);a.push(u),u.view&&(o=!0)}else o||Cc(r).view&&(o=!0);Oo=!0,Wh(r,$e===0?t:t+"_"+$e,n),$e++}else(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&l||$f(e.child,t,n,a,l)&&(o=!0));e=e.sibling}return o}function Yt(e,t){for(;e!==null;)e.tag===5?$h(e.stateNode,e.memoizedProps):(e.tag!==22||e.memoizedState===null)&&(e.tag===30&&t||Yt(e.child,t)),e=e.sibling}function No(e){if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if((e.tag!==22||e.memoizedState===null)&&(No(e),e.tag===30&&(e.flags&18874368)!==0&&e.stateNode.paired)){var t=e.memoizedProps;if(t.name==null||t.name==="auto")throw Error(f(544));var n=t.name;t=tn(t.default,t.share),t!=="none"&&(tl(e,n,t,null,!1)||Yt(e.child,!1))}e=e.sibling}}function Js(e,t){if(e.tag===30){var n=e.stateNode,a=e.memoizedProps,l=en(a,n),o=tn(a.default,n.paired?a.share:a.enter);o!=="none"?tl(e,l,o,null,!1)?(No(e),n.paired||t||cl(e,a.onEnter)):Yt(e.child,!1):No(e)}else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)Js(e,t),e=e.sibling;else No(e)}function Fs(e){if(ct!==null&&ct.size!==0){var t=ct;if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&(e.flags&18874368)!==0){var n=e.memoizedProps,a=n.name;if(a!=null&&a!=="auto"){var l=t.get(a);if(l!==void 0){var o=tn(n.default,n.share);if(o!=="none"&&(tl(e,a,o,null,!1)?(o=e.stateNode,l.paired=o,o.paired=l,cl(e,n.onShare)):Yt(e.child,!1)),t.delete(a),t.size===0)break}}}Fs(e)}e=e.sibling}}}function Ws(e){if(e.tag===30){var t=e.memoizedProps,n=en(t,e.stateNode),a=ct!==null?ct.get(n):void 0,l=tn(t.default,a!==void 0?t.share:t.exit);l!=="none"&&(tl(e,n,l,null,!1)?a!==void 0?(l=e.stateNode,a.paired=l,l.paired=a,ct.delete(n),cl(e,t.onShare)):cl(e,t.onExit):Yt(e.child,!1)),ct!==null&&Fs(e)}else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)Ws(e),e=e.sibling;else ct!==null&&Fs(e)}function eh(e){for(e=e.child;e!==null;){if(e.tag===30){var t=e.memoizedProps,n=en(t,e.stateNode);t=tn(t.default,t.update),e.flags&=-5,t!=="none"&&tl(e,n,t,e.memoizedState=[],!1)}else(e.subtreeFlags&33554432)!==0&&eh(e);e=e.sibling}}function $s(e){if((e.subtreeFlags&18874368)!==0)for(e=e.child;e!==null;){if(e.tag!==22||e.memoizedState===null){if(e.tag===30&&(e.flags&18874368)!==0){var t=e.stateNode;t.paired!==null&&(t.paired=null,Yt(e.child,!1))}$s(e)}e=e.sibling}}function Do(e){if(e.tag===30)e.stateNode.paired=null,Yt(e.child,!1),$s(e);else if((e.subtreeFlags&33554432)!==0)for(e=e.child;e!==null;)Do(e),e=e.sibling;else $s(e)}function th(e){for(e=e.child;e!==null;)e.tag===30?Yt(e.child,!1):(e.subtreeFlags&33554432)!==0&&th(e),e=e.sibling}function ec(e,t,n,a,l,o,r){for(var u=!1;t!==null;){if(t.tag===5){var m=t.stateNode;if(o!==null&&$e<o.length){var b=o[$e],w=Cc(m);(b.view||w.view)&&(u=!0);var A;if(A=(e.flags&4)===0)if(w.clip)A=!0;else{A=b.rect;var g=w.rect;A=A.y!==g.y||A.x!==g.x||A.height!==g.height||A.width!==g.width}A&&(e.flags|=4),w.abs?w=!b.abs:(b=b.rect,w=w.rect,w=b.height!==w.height||b.width!==w.width),w&&(e.flags|=32)}else e.flags|=32;(e.flags&4)!==0&&Wh(m,$e===0?n:n+"_"+$e,l),u&&(e.flags&4)!==0||(It===null&&(It=[]),It.push(m,$e===0?a:a+"_"+$e,t.memoizedProps)),$e++}else(t.tag!==22||t.memoizedState===null)&&(t.tag===30&&r?e.flags|=t.flags&32:ec(e,t.child,n,a,l,o,r)&&(u=!0));t=t.sibling}return u}function nh(e,t){for(e=e.child;e!==null;){if(e.tag===30){var n=e.memoizedProps,a=e.stateNode,l=en(n,a),o=tn(n.default,n.update),r;r=e.memoizedState,e.memoizedState=null,a=e;var u=e.child;$e=0,l=ec(a,u,l,l,o,r,!1),(e.flags&4)!==0&&l&&cl(e,n.onUpdate)}else(e.subtreeFlags&33554432)!==0&&nh(e);e=e.sibling}}var Ce=!1,se=!1,Xt=!1,tc=!1,ah=typeof WeakSet=="function"?WeakSet:Set,Re=null,Gt=!1,ri=!1,Co=!1,nc=!1;function Ug(e,t,n){if(e=e.containerInfo,zc=vl,e=od(e),Ir(e)){if("selectionStart"in e)var a={start:e.selectionStart,end:e.selectionEnd};else e:{a=(a=e.ownerDocument)&&a.defaultView||window;var l=a.getSelection&&a.getSelection();if(l&&l.rangeCount!==0){a=l.anchorNode;var o=l.anchorOffset,r=l.focusNode;l=l.focusOffset;try{a.nodeType,r.nodeType}catch{a=null;break e}var u=0,m=-1,b=-1,w=0,A=0,g=e,T=null;t:for(;;){for(var L;g!==a||o!==0&&g.nodeType!==3||(m=u+o),g!==r||l!==0&&g.nodeType!==3||(b=u+l),g.nodeType===3&&(u+=g.nodeValue.length),(L=g.firstChild)!==null;)T=g,g=L;for(;;){if(g===e)break t;if(T===a&&++w===o&&(m=u),T===r&&++A===l&&(b=u),(L=g.nextSibling)!==null)break;g=T,T=g.parentNode}g=L}a=m===-1||b===-1?null:{start:m,end:b}}else a=null}a=a||{start:0,end:0}}else a=null;for(Ac={focusedElem:e,selectionRange:a},vl=!1,n=(n&335544064)===n,Re=t,t=n?9270:1024;Re!==null;){if(e=Re,n&&(a=e.deletions,a!==null))for(o=0;o<a.length;o++)n&&Ws(a[o]);if(e.alternate===null&&(e.flags&2)!==0)n&&Ff(e),Ro(n);else{if(e.tag===22){if(a=e.alternate,e.memoizedState!==null){a!==null&&a.memoizedState===null&&n&&Ws(a),Ro(n);continue}else if(a!==null&&a.memoizedState!==null){n&&Ff(e),Ro(n);continue}}a=e.child,(e.subtreeFlags&t)!==0&&a!==null?(a.return=e,Re=a):(n&&eh(e),Ro(n))}}ct=null}function Ro(e){for(;Re!==null;){var t=Re,n=e,a=t.alternate,l=t.flags;switch(t.tag){case 0:case 11:case 15:break;case 1:if((l&1024)!==0&&a!==null){n=void 0,l=a.memoizedProps,a=a.memoizedState;var o=t.stateNode;try{var r=ga(t.type,l);n=o.getSnapshotBeforeUpdate(r,a),o.__reactInternalSnapshotBeforeUpdate=n}catch(u){ue(t,t.return,u)}}break;case 3:if((l&1024)!==0){if(a=t.stateNode.containerInfo,n=a.nodeType,n===9)Mc(a);else if(n===1)switch(a.nodeName){case"HEAD":case"HTML":case"BODY":Mc(a);break;default:a.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;case 30:n&&a!==null&&(n=en(a.memoizedProps,a.stateNode),l=t.memoizedProps,l=tn(l.default,l.update),l!=="none"&&tl(a,n,l,a.memoizedState=[],!0));break;default:if((l&1024)!==0)throw Error(f(163))}if(a=t.sibling,a!==null){a.return=t.return,Re=a;break}Re=t.return}}function lh(e,t,n){var a=n.flags;switch(n.tag){case 0:case 11:case 15:Qt(e,n),a&4&&ii(5,n);break;case 1:if(Qt(e,n),a&4)if(e=n.stateNode,t===null)try{e.componentDidMount()}catch(r){ue(n,n.return,r)}else{var l=ga(n.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(l,t,e.__reactInternalSnapshotBeforeUpdate)}catch(r){ue(n,n.return,r)}}a&64&&Qf(n),a&512&&qt(n,n.return);break;case 3:if(Qt(e,n),a&64&&(e=n.updateQueue,e!==null)){if(t=null,n.child!==null)switch(n.child.tag){case 27:case 5:t=n.child.stateNode;break;case 1:t=n.child.stateNode}try{Ld(e,t)}catch(r){ue(n,n.return,r)}}break;case 27:t===null&&a&4&&Jf(n);case 26:case 5:Qt(e,n),t===null&&a&4&&Qs(n),a&512&&qt(n,n.return);break;case 12:Qt(e,n);break;case 31:Qt(e,n),a&4&&sh(e,n);break;case 13:Qt(e,n),a&4&&ch(e,n),a&64&&(e=n.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(n=Jg.bind(null,n),Dx(e,n))));break;case 22:if(a=n.memoizedState!==null||Ce,!a){var o=t!==null&&t.memoizedState!==null||se;t=Ce,l=se,Ce=a,(se=o)&&!l?(a=2,(n.subtreeFlags&8772)!==0&&(a|=1),Nt(e,n,a)):Qt(e,n),Ce=t,se=l}break;case 30:Qt(e,n),a&512&&qt(n,n.return);break;case 7:a&512&&qt(n,n.return);default:Qt(e,n)}}function ac(e,t){for(e=e.child;e!==null;)ih(e,t),e=e.sibling}function ih(e,t){switch(e.tag){case 5:case 26:try{var n=e.stateNode;if(t){var a=n.style;typeof a.setProperty=="function"?a.setProperty("display","none","important"):a.display="none"}else{var l=e.stateNode,o=e.memoizedProps.style,r=o!=null&&o.hasOwnProperty("display")?o.display:null;l.style.display=r==null||typeof r=="boolean"?"":(""+r).trim()}}catch(m){ue(e,e.return,m)}lc(e,t);break;case 6:try{e.stateNode.nodeValue=t?"":e.memoizedProps,le=!0}catch(m){ue(e,e.return,m)}break;case 18:try{var u=e.stateNode;t?Fh(u,!0):Fh(e.stateNode,!1)}catch(m){ue(e,e.return,m)}break;case 22:case 23:e.memoizedState===null&&ac(e,t);break;default:ac(e,t)}}function lc(e,t){if(e.subtreeFlags&67108864)for(e=e.child;e!==null;){e:{var n=e,a=t;switch(n.tag){case 4:ih(n,a);break e;case 22:n.memoizedState===null&&lc(n,a);break e;default:lc(n,a)}}e=e.sibling}}function oh(e){var t=e.alternate;t!==null&&(e.alternate=null,oh(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&Vi(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var be=null,et=!1;function At(e,t,n){for(n=n.child;n!==null;)rh(e,t,n),n=n.sibling}function rh(e,t,n){if(lt&&typeof lt.onCommitFiberUnmount=="function")try{lt.onCommitFiberUnmount(Nl,n)}catch{}switch(n.tag){case 26:se||Be(n,t),At(e,t,n),n.memoizedState?n.memoizedState.count--:n.stateNode&&!se&&(n=n.stateNode,n.parentNode.removeChild(n));break;case 27:se||Be(n,t),oi(n);var a=be,l=et;Gn(n.type)&&(be=n.stateNode,et=!1),At(e,t,n),dm(n.stateNode,n.type,n.memoizedProps),be=a,et=l;break;case 5:se||Be(n,t),oi(n);case 6:if(n.tag===6&&oi(n),a=be,l=et,be=null,At(e,t,n),be=a,et=l,be!==null)if(et)try{(be.nodeType===9?be.body:be.nodeName==="HTML"?be.ownerDocument.body:be).removeChild(n.stateNode),le=!0}catch(o){ue(n,t,o)}else try{be.removeChild(n.stateNode),le=!0}catch(o){ue(n,t,o)}break;case 18:be!==null&&(et?(e=be,Jh(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,n.stateNode),bl(e)):Jh(be,n.stateNode));break;case 4:a=be,l=et,be=n.stateNode.containerInfo,et=!0,At(e,t,n),be=a,et=l;break;case 0:case 11:case 14:case 15:Un(2,n,t),se||Un(4,n,t),At(e,t,n);break;case 1:se||(Be(n,t),a=n.stateNode,typeof a.componentWillUnmount=="function"&&Zf(n,t,a)),At(e,t,n);break;case 21:At(e,t,n);break;case 22:se=(a=se)||n.memoizedState!==null,At(e,t,n),se=a;break;case 30:Be(n,t),At(e,t,n);break;case 7:se||Be(n,t),At(e,t,n);break;default:At(e,t,n)}}function sh(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{bl(e)}catch(n){ue(t,t.return,n)}}}function ch(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{bl(e)}catch(n){ue(t,t.return,n)}}function Bg(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new ah),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new ah),t;default:throw Error(f(435,e.tag))}}function Lo(e,t){var n=Bg(e);t.forEach(function(a){if(!n.has(a)){n.add(a);var l=Fg.bind(null,e,a);a.then(l,l)}})}function Ke(e,t,n){var a=t.deletions;if(a!==null)for(var l=0;l<a.length;l++){var o=a[l],r=e,u=t,m=u;e:for(;m!==null;){switch(m.tag){case 27:if(Gn(m.type)){be=m.stateNode,et=!1;break e}break;case 5:be=m.stateNode,et=!1;break e;case 3:case 4:be=m.stateNode.containerInfo,et=!0;break e}m=m.return}if(be===null)throw Error(f(160));rh(r,u,o),be=null,et=!1,r=o.alternate,r!==null&&(r.return=null),o.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)uh(t,e,n),t=t.sibling}var Ot=null;function uh(e,t,n){var a=e.alternate,l=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(l&4&&(a=e.updateQueue,a=a!==null?a.events:null,a!==null))for(var o=0;o<a.length;o++){var r=a[o];r.ref.impl=r.nextImpl}Ke(t,e,n),Pe(e),l&4&&(Un(3,e,e.return),ii(3,e),Un(5,e,e.return));break;case 1:Ke(t,e,n),Pe(e),l&512&&(se||a===null||Be(a,a.return)),l&64&&Ce&&(e=e.updateQueue,e!==null&&(t=e.callbacks,t!==null&&(n=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=n===null?t:n.concat(t))));break;case 26:if(o=Ot,Ke(t,e,n),Pe(e),l&512&&(se||a===null||Be(a,a.return)),l&4)if(l=a!==null?a.memoizedState:null,n=e.memoizedState,a===null)if(n===null)if(e.stateNode===null)if(Ce)e.stateNode=Zh(e.type,e.memoizedProps,t.containerInfo,e);else{e:{t=e.type,n=e.memoizedProps,l=o.ownerDocument||o;t:switch(t){case"title":a=l.getElementsByTagName("title")[0],(!a||a[Rl]||a[Me]||a.namespaceURI==="http://www.w3.org/2000/svg"||a.hasAttribute("itemprop"))&&(a=l.createElement(t),l.head.insertBefore(a,l.querySelector("head > title"))),He(a,t,n),a[Me]=e,Ne(a),t=a;break e;case"link":if(o=xm("link","href",l).get(t+(n.href||""))){for(r=0;r<o.length;r++)if(a=o[r],a.getAttribute("href")===(n.href==null||n.href===""?null:n.href)&&a.getAttribute("rel")===(n.rel==null?null:n.rel)&&a.getAttribute("title")===(n.title==null?null:n.title)&&a.getAttribute("crossorigin")===(n.crossOrigin==null?null:n.crossOrigin)){o.splice(r,1);break t}}a=l.createElement(t),He(a,t,n),l.head.appendChild(a);break;case"meta":if(o=xm("meta","content",l).get(t+(n.content||""))){for(r=0;r<o.length;r++)if(a=o[r],a.getAttribute("content")===(n.content==null?null:""+n.content)&&a.getAttribute("name")===(n.name==null?null:n.name)&&a.getAttribute("property")===(n.property==null?null:n.property)&&a.getAttribute("http-equiv")===(n.httpEquiv==null?null:n.httpEquiv)&&a.getAttribute("charset")===(n.charSet==null?null:n.charSet)){o.splice(r,1);break t}}a=l.createElement(t),He(a,t,n),l.head.appendChild(a);break;default:throw Error(f(468,t))}a[Me]=e,Ne(a),t=a}e.stateNode=t}else Ce||Ic(o,e.type,e.stateNode);else e.stateNode=gm(o,n,e.memoizedProps);else l!==n?(l===null?(t=a.stateNode,t===null||se||t.parentNode.removeChild(t)):l.count--,n===null?Ce||Ic(o,e.type,e.stateNode):gm(o,n,e.memoizedProps)):n===null&&e.stateNode!==null&&Zs(e,e.memoizedProps,a.memoizedProps);break;case 27:Ke(t,e,n),Pe(e),l&512&&(se||a===null||Be(a,a.return)),a!==null&&l&4&&Zs(e,e.memoizedProps,a.memoizedProps);break;case 5:if(o=Xt,Xt=!1,Ke(t,e,n),Xt=o,Pe(e),l&512&&(se||a===null||Be(a,a.return)),e.flags&32){t=e.stateNode;try{Va(t,""),le=!0}catch(w){ue(e,e.return,w)}}l&4&&e.stateNode!=null&&(t=e.memoizedProps,Zs(e,t,a!==null?a.memoizedProps:t)),l&1024&&(tc=!0);break;case 6:if(Ke(t,e,n),Pe(e),l&4){if(e.stateNode===null)throw Error(f(162));t=e.memoizedProps,n=e.stateNode;try{n.nodeValue=t,le=!0}catch(w){ue(e,e.return,w)}}break;case 3:if(le=!1,Po=null,o=Ot,Ot=gi(t.containerInfo),Ke(t,e,n),Ot=o,Pe(e),l&4&&a!==null&&a.memoizedState.isDehydrated)try{bl(t.containerInfo)}catch(w){ue(e,e.return,w)}tc&&(tc=!1,dh(e)),le=!1;break;case 4:l=Xt,Xt=Ce,a=Nu(),o=Ot,Ot=gi(e.stateNode.containerInfo),Ke(t,e,n),Pe(e),Ot=o,le&&ri&&(Co=!0),le=a,Xt=l;break;case 12:Ke(t,e,n),Pe(e);break;case 31:Ke(t,e,n),Pe(e),l&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Lo(e,t)));break;case 13:Ke(t,e,n),Pe(e),e.child.flags&8192&&e.memoizedState!==null!=(a!==null&&a.memoizedState!==null)&&(Vo=at()),l&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Lo(e,t)));break;case 22:o=e.memoizedState!==null,r=a!==null&&a.memoizedState!==null;var u=Ce,m=se,b=Xt;Ce=u||o,Xt=b||o,se=m||r,Ke(t,e,n),se=m,Xt=b,Ce=u,Pe(e),l&8192&&(t=e.stateNode,t._visibility=o?t._visibility&-2:t._visibility|1,!o||a===null||r||Ce||se||(t=r||se,n=Ce,a=se,Ce=o||Ce,se=t,Bn(e,2),Ce=n,se=a),!o&&Xt||ac(e,o)),l&4&&(t=e.updateQueue,t!==null&&(n=t.retryQueue,n!==null&&(t.retryQueue=null,Lo(e,n))));break;case 19:Ke(t,e,n),Pe(e),l&4&&(t=e.updateQueue,t!==null&&(e.updateQueue=null,Lo(e,t)));break;case 30:l&512&&(se||a===null||Be(a,a.return)),l=Nu(),o=ri,r=(n&335544064)===n,u=e.memoizedProps,ri=r&&tn(u.default,u.update)!=="none",Ke(t,e,n),Pe(e),r&&a!==null&&le&&(e.flags|=4),ri=o,le=l;break;case 21:break;case 7:l&512&&(se||a===null||Be(a,a.return)),a&&a.stateNode!==null&&(a.stateNode._fragmentFiber=e);default:Ke(t,e,n),Pe(e)}}function Pe(e){var t=e.flags;if(t&2){try{for(var n,a=e.return;a!==null;){if(Pf(a)){n=a;break}a=a.return}a=null;for(var l=e.return;l!==null;){if(Gs(l)){var o=l.stateNode;a===null?a=[o]:a.push(o)}if(Xs(l))break;l=l.return}var r=a;if(n==null)throw Error(f(160));switch(n.tag){case 27:var u=n.stateNode,m=Ks(e);Ao(e,m,u,r);break;case 5:var b=n.stateNode;n.flags&32&&(Va(b,""),n.flags&=-33);var w=Ks(e);Ao(e,w,b,r);break;case 3:case 4:var A=n.stateNode.containerInfo,g=Ks(e);Ps(e,g,A,r);break;default:throw Error(f(161))}}catch(T){ue(e,e.return,T)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function dh(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;dh(t),t.tag===5&&t.flags&1024&&(t=t.stateNode,vl=!0,t.reset(),vl=!1),e=e.sibling}}function nl(e,t){if(t.subtreeFlags&9270)for(t=t.child;t!==null;)fh(t,e),t=t.sibling;else nh(t)}function fh(e,t){var n=e.alternate;if(n===null)Js(e,!1);else switch(e.tag){case 3:if(nc=Gt=!1,Wf(),nl(t,e),!Gt&&!Co){if(e=It,e!==null)for(var a=0;a<e.length;a+=3){n=e[a];var l=e[a+1];$h(n,e[a+2]),n=n.ownerDocument.documentElement,n!==null&&n.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group("+l+")"})}e=t.containerInfo,e=e.nodeType===9?e.documentElement:e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName===""&&(e.style.viewTransitionName="none",e.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group(root)"}),e.animate({width:[0,0],height:[0,0]},{duration:0,fill:"forwards",pseudoElement:"::view-transition"})),nc=!0}It=null;break;case 5:nl(t,e);break;case 4:a=Gt,Gt=!1,nl(t,e),Gt&&(Co=!0),Gt=a;break;case 22:e.memoizedState===null&&(n.memoizedState!==null?Js(e,!1):nl(t,e));break;case 30:a=Gt,l=Wf(),Gt=!1,nl(t,e),Gt&&(e.flags|=4);var o=e.memoizedProps,r=e.stateNode;t=en(o,r),r=en(n.memoizedProps,r);var u=tn(o.default,o.update);u==="none"?t=!1:(o=n.memoizedState,n.memoizedState=null,n=e.child,$e=0,t=ec(e,n,t,r,u,o,!0),$e!==(o===null?0:o.length)&&(e.flags|=32)),(e.flags&4)!==0&&t?(cl(e,e.memoizedProps.onUpdate),It=l):l!==null&&(l.push.apply(l,It),It=l),Gt=(e.flags&32)!==0?!0:a;break;default:nl(t,e)}}function Qt(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)lh(e,t.alternate,t),t=t.sibling}function Bn(e,t){for(e=e.child;e!==null;){var n=e,a=t;switch(n.tag){case 0:case 11:case 14:case 15:Un(4,n,n.return),Bn(n,a);break;case 1:Be(n,n.return);var l=n.stateNode;typeof l.componentWillUnmount=="function"&&Zf(n,n.return,l),Bn(n,a);break;case 27:(a&2)!==0&&dm(n.stateNode,n.type,n.memoizedProps);case 5:Be(n,n.return),n.tag!==5&&n.tag!==27||oi(n),Bn(n,a);break;case 6:oi(n);break;case 26:Be(n,n.return),l=n.stateNode,n.memoizedState!==null||l===null||se||l.parentNode.removeChild(l),Bn(n,a);break;case 22:n.memoizedState===null&&Bn(n,a);break;case 30:Be(n,n.return),Bn(n,a);break;case 7:Be(n,n.return);default:Bn(n,a)}e=e.sibling}}function Nt(e,t,n){for(n=(t.subtreeFlags&8772)!==0?n:n&-2,t=t.child;t!==null;){var a=t.alternate,l=e,o=t,r=o.flags,u=(n&1)!==0;switch(o.tag){case 0:case 11:case 15:Nt(l,o,n),ii(4,o);break;case 1:if(Nt(l,o,n),a=o,l=a.stateNode,typeof l.componentDidMount=="function")try{l.componentDidMount()}catch(w){ue(a,a.return,w)}if(a=o,l=a.updateQueue,l!==null){var m=a.stateNode;try{var b=l.shared.hiddenCallbacks;if(b!==null)for(l.shared.hiddenCallbacks=null,l=0;l<b.length;l++)Rd(b[l],m)}catch(w){ue(a,a.return,w)}}u&&r&64&&Qf(o),qt(o,o.return);break;case 27:(n&2)!==0&&Jf(o);case 5:o.tag!==5&&o.tag!==27||Kf(o),Nt(l,o,n),u&&a===null&&r&4&&Qs(o),qt(o,o.return);break;case 6:Kf(o);break;case 26:m=o.stateNode,o.memoizedState!==null||m===null||Ce||Ic(gi(m.ownerDocument),o.type,m),Nt(l,o,n),u&&a===null&&r&4&&Qs(o),qt(o,o.return);break;case 12:Nt(l,o,n);break;case 31:Nt(l,o,n),u&&r&4&&sh(l,o);break;case 13:Nt(l,o,n),u&&r&4&&ch(l,o);break;case 22:o.memoizedState===null&&Nt(l,o,n),qt(o,o.return);break;case 30:Nt(l,o,n),qt(o,o.return);break;case 7:qt(o,o.return);default:Nt(l,o,n)}t=t.sibling}}function ic(e,t){var n=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(n=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==n&&(e!=null&&e.refCount++,n!=null&&Ql(n))}function oc(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&Ql(e))}function Tt(e,t,n,a){var l=(n&335544064)===n;if(t.subtreeFlags&(l?10262:10256))for(t=t.child;t!==null;)hh(e,t,n,a),t=t.sibling;else l&&th(t)}function hh(e,t,n,a){var l=(n&335544064)===n;l&&t.alternate===null&&t.return!==null&&t.return.alternate!==null&&Do(t);var o=t.flags;switch(t.tag){case 0:case 11:case 15:Tt(e,t,n,a),o&2048&&ii(9,t);break;case 1:Tt(e,t,n,a);break;case 3:Tt(e,t,n,a),l&&nc&&(e=e.containerInfo,e=e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,e.style.viewTransitionName==="root"&&(e.style.viewTransitionName=""),e=e.ownerDocument.documentElement,e!==null&&e.style.viewTransitionName==="none"&&(e.style.viewTransitionName="")),o&2048&&(o=null,t.alternate!==null&&(o=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==o&&(t.refCount++,o!=null&&Ql(o)));break;case 12:if(o&2048){Tt(e,t,n,a),o=t.stateNode;try{var r=t.memoizedProps,u=r.id,m=r.onPostCommit;typeof m=="function"&&m(u,t.alternate===null?"mount":"update",o.passiveEffectDuration,-0)}catch(b){ue(t,t.return,b)}}else Tt(e,t,n,a);break;case 31:Tt(e,t,n,a);break;case 13:Tt(e,t,n,a);break;case 23:break;case 22:r=t.stateNode,u=t.alternate,t.memoizedState!==null?(l&&u!==null&&u.memoizedState===null&&Do(u),r._visibility&2?Tt(e,t,n,a):si(e,t)):(l&&u!==null&&u.memoizedState!==null&&Do(t),r._visibility&2?Tt(e,t,n,a):(r._visibility|=2,al(e,t,n,a,(t.subtreeFlags&10256)!==0||!1))),o&2048&&ic(u,t);break;case 24:Tt(e,t,n,a),o&2048&&oc(t.alternate,t);break;case 30:l&&(o=t.alternate,o!==null&&(Yt(o.child,!0),Yt(t.child,!0))),Tt(e,t,n,a);break;default:Tt(e,t,n,a)}}function al(e,t,n,a,l){for(l=l&&((t.subtreeFlags&10256)!==0||!1),t=t.child;t!==null;){var o=e,r=t,u=n,m=a,b=r.flags;switch(r.tag){case 0:case 11:case 15:al(o,r,u,m,l),ii(8,r);break;case 23:break;case 22:var w=r.stateNode;r.memoizedState!==null?w._visibility&2?al(o,r,u,m,l):si(o,r):(w._visibility|=2,al(o,r,u,m,l)),l&&b&2048&&ic(r.alternate,r);break;case 24:al(o,r,u,m,l),l&&b&2048&&oc(r.alternate,r);break;default:al(o,r,u,m,l)}t=t.sibling}}function si(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var n=e,a=t,l=a.flags;switch(a.tag){case 22:si(n,a),l&2048&&ic(a.alternate,a);break;case 24:si(n,a),l&2048&&oc(a.alternate,a);break;default:si(n,a)}t=t.sibling}}var xa=8192;function ya(e,t,n){if(e.subtreeFlags&xa)for(e=e.child;e!==null;)mh(e,t,n),e=e.sibling}function mh(e,t,n){switch(e.tag){case 26:ya(e,t,n),e.flags&xa&&(e.memoizedState!==null?Gx(n,Ot,e.memoizedState,e.memoizedProps):(e=e.stateNode,(t&335544128)===t&&_m(n,e)));break;case 5:ya(e,t,n),e.flags&xa&&(e=e.stateNode,(t&335544128)===t&&_m(n,e));break;case 3:case 4:var a=Ot;Ot=gi(e.stateNode.containerInfo),ya(e,t,n),Ot=a;break;case 22:e.memoizedState===null&&(a=e.alternate,a!==null&&a.memoizedState!==null?(a=xa,xa=16777216,ya(e,t,n),xa=a):ya(e,t,n));break;case 30:if((e.flags&xa)!==0&&(a=e.memoizedProps.name,a!=null&&a!=="auto")){var l=e.stateNode;l.paired=null,ct===null&&(ct=new Map),ct.set(a,l)}ya(e,t,n);break;default:ya(e,t,n)}}function ph(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function ci(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var a=t[n];Re=a,xh(a,e)}ph(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)gh(e),e=e.sibling}function gh(e){switch(e.tag){case 0:case 11:case 15:ci(e),e.flags&2048&&Un(9,e,e.return);break;case 3:ci(e);break;case 12:ci(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,Mo(e)):ci(e);break;default:ci(e)}}function Mo(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var n=0;n<t.length;n++){var a=t[n];Re=a,xh(a,e)}ph(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Un(8,t,t.return),Mo(t);break;case 22:n=t.stateNode,n._visibility&2&&(n._visibility&=-3,Mo(t));break;default:Mo(t)}e=e.sibling}}function xh(e,t){for(;Re!==null;){var n=Re;switch(n.tag){case 0:case 11:case 15:Un(8,n,t);break;case 23:case 22:if(n.memoizedState!==null&&n.memoizedState.cachePool!==null){var a=n.memoizedState.cachePool.pool;a!=null&&a.refCount++}break;case 24:Ql(n.memoizedState.cache)}if(a=n.child,a!==null)a.return=n,Re=a;else e:for(n=e;Re!==null;){a=Re;var l=a.sibling,o=a.return;if(oh(a),a===n){Re=null;break e}if(l!==null){l.return=o,Re=l;break e}Re=o}}}var Hg={getCacheForType:function(e){var t=ke(je),n=t.data.get(e);return n===void 0&&(n=e(),t.data.set(e,n)),n},cacheSignal:function(){return ke(je).controller.signal}},qg=typeof WeakMap=="function"?WeakMap:Map,re=0,me=null,F=null,$=0,ce=0,ut=null,Hn=!1,ll=!1,rc=!1,dn=0,Ee=0,qn=0,va=0,ko=0,dt=0,il=0,ui=null,tt=null,sc=!1,Vo=0,yh=0,Uo=1/0,Bo=null,In=null,_e=0,Dt=null,ba=null,Zt=0,cc=0,uc=null,vh=null,ol=null,rl=null,sl=null,di=0,Ho=null;function ft(){return(re&2)!==0&&$!==0?$&-$:q.T!==null?bc():_u()}function bh(){if(dt===0)if(($&536870912)===0||J){var e=Ri;Ri<<=1,(Ri&3932160)===0&&(Ri=262144),dt=e}else dt=536870912;return e=Ve.current,e!==null&&(e.flags|=32),dt}function cl(e,t){if(t!=null){var n=e.stateNode,a=n.ref;a===null&&(a=n.ref=em(en(e.memoizedProps,n))),rl===null&&(rl=[]),rl.push(t.bind(null,a))}}function nt(e,t,n){(e===me&&(ce===2||ce===9)||e.cancelPendingCommit!==null)&&(ul(e,0),Yn(e,$,dt,!1)),Cl(e,n),((re&2)===0||e!==me)&&(e===me&&((re&2)===0&&(va|=n),Ee===4&&Yn(e,$,dt,!1)),Kt(e))}function _h(e,t,n){if((re&6)!==0)throw Error(f(327));var a=!n&&(t&127)===0&&(t&e.expiredLanes)===0||Dl(e,t),l=a?Xg(e,t):fc(e,t,!0),o=a;do{if(l===0){ll&&!a&&Yn(e,t,0,!1);break}else{if(n=e.current.alternate,o&&!Ig(n)){l=fc(e,t,!1),o=!1;continue}if(l===2){if(o=t,e.errorRecoveryDisabledLanes&o)var r=0;else r=e.pendingLanes&-536870913,r=r!==0?r:r&536870912?536870912:0;if(r!==0){t=r;e:{var u=e;l=ui;var m=u.current.memoizedState.isDehydrated;if(m&&(ul(u,r).flags|=256),r=fc(u,r,!1),r!==2&&r!==6){if(rc&&!m){u.errorRecoveryDisabledLanes|=o,va|=o,l=4;break e}o=tt,tt=l,o!==null&&(tt===null?tt=o:tt.push.apply(tt,o))}l=r}if(o=!1,l!==2)continue}}if(l===1){ul(e,0),Yn(e,t,0,!0);break}e:{switch(a=e,o=l,o){case 0:case 1:throw Error(f(345));case 4:if((t&4194048)!==t&&(t&62914560)!==t)break;case 6:Yn(a,t,dt,!Hn);break e;case 2:tt=null;break;case 3:case 5:break;default:throw Error(f(329))}if((t&62914560)===t&&(l=Vo+300-at(),10<l)){if(Yn(a,t,dt,!Hn),Mi(a,0,!0)!==0)break e;Zt=t,a.timeoutHandle=Dc(Th.bind(null,a,n,tt,Bo,sc,t,dt,va,il,Hn,o,"Throttled",-0,0),l);break e}Th(a,n,tt,Bo,sc,t,dt,va,il,Hn,o,null,-0,0)}}break}while(!0);Kt(e)}function Th(e,t,n,a,l,o,r,u,m,b,w,A,g,T){e.timeoutHandle=-1;var L=t.subtreeFlags,U=(o&335544064)===o;if(A=null,(U||L&8192||(L&16785408)===16785408)&&(A={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:Ut},ct=null,mh(t,o,A),U&&(L=A,U=e.containerInfo,U=(U.nodeType===9?U:U.ownerDocument).__reactViewTransition,U!=null&&(L.count++,L.waitingForViewTransition=!0,L=vi.bind(L),U.finished.then(L,L))),L=(o&62914560)===o?Vo-at():(o&4194048)===o?yh-at():0,L=Qx(A,L),L!==null)){Zt=o,e.cancelPendingCommit=L(Nh.bind(null,e,t,o,n,a,l,r,u,m,b,w,A,null,g,T)),Yn(e,o,r,!b);return}Nh(e,t,o,n,a,l,r,u,m,b,w,A)}function Ig(e){for(var t=e;;){var n=t.tag;if((n===0||n===11||n===15)&&t.flags&16384&&(n=t.updateQueue,n!==null&&(n=n.stores,n!==null)))for(var a=0;a<n.length;a++){var l=n[a],o=l.getSnapshot;l=l.value;try{if(!rt(o(),l))return!1}catch{return!1}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function Yn(e,t,n,a){t=gu(e,t),t&=~ko,t&=~va,e.suspendedLanes|=t,e.pingedLanes&=~t,a&&(e.warmLanes|=t),a=e.expirationTimes;for(var l=t;0<l;){var o=31-it(l),r=1<<o;a[o]=-1,l&=~r}n!==0&&yu(e,n,t)}function qo(){return(re&6)===0?(fi(0),!1):!0}function dc(){if(F!==null){if(ce===0)var e=F.return;else e=F,ln=ra=null,vs(e),Ja=null,Pl=0,e=F;for(;e!==null;)Gf(e.alternate,e),e=e.return;F=null}}function ul(e,t){var n=e.timeoutHandle;return n!==-1&&(e.timeoutHandle=-1,fx(n)),n=e.cancelPendingCommit,n!==null&&(e.cancelPendingCommit=null,n()),Zt=0,dc(),me=e,F=n=nn(e.current,null),$=t,ce=0,ut=null,Hn=!1,ll=Dl(e,t),rc=!1,il=dt=ko=va=qn=Ee=0,tt=ui=null,sc=!1,dn=gu(e,t),Ki(),n}function Eh(e,t){Y=null,q.H=bo,t===Pa||t===io?(t=Od(),ce=3):t===os?(t=Od(),ce=4):ce=t===Ls?8:t!==null&&typeof t=="object"&&typeof t.then=="function"?6:1,ut=t,F===null&&(Ee=1,_o(e,yt(t,e.current)))}function wh(){var e=Ve.current;return e===null?!0:($&4194048)===$?Ie===null:($&62914560)===$||($&536870912)!==0?e===Ie:!1}function jh(){var e=q.H;return q.H=bo,e===null?bo:e}function Sh(){var e=q.A;return q.A=Hg,e}function Io(){Ee=4,Hn||($&4194048)!==$&&Ve.current!==null||(ll=!0),(qn&134217727)===0&&(va&134217727)===0||me===null||Yn(me,$,dt,!1)}function fc(e,t,n){var a=re;re|=2;var l=jh(),o=Sh();(me!==e||$!==t)&&(Bo=null,ul(e,t)),t=!1;var r=Ee;e:do try{if(ce!==0&&F!==null){var u=F,m=ut;switch(ce){case 8:dc(),r=6;break e;case 3:case 2:case 9:case 6:Ve.current===null&&(t=!0);var b=ce;if(ce=0,ut=null,dl(e,u,m,b),n&&ll){r=0;break e}break;default:b=ce,ce=0,ut=null,dl(e,u,m,b)}}Yg(),r=Ee;break}catch(w){Eh(e,w)}while(!0);return t&&e.shellSuspendCounter++,ln=ra=null,re=a,q.H=l,q.A=o,F===null&&(me=null,$=0,Ki()),r}function Yg(){for(;F!==null;)zh(F)}function Xg(e,t){var n=re;re|=2;var a=jh(),l=Sh();me!==e||$!==t?(Bo=null,Uo=at()+500,ul(e,t)):ll=Dl(e,t);e:do try{if(ce!==0&&F!==null){t=F;var o=ut;t:switch(ce){case 1:ce=0,ut=null,dl(e,t,o,1);break;case 2:case 9:if(zd(o)){ce=0,ut=null,Ah(t);break}t=function(){ce!==2&&ce!==9||me!==e||(ce=7),Kt(e)},o.then(t,t);break e;case 3:ce=7;break e;case 4:ce=5;break e;case 7:zd(o)?(ce=0,ut=null,Ah(t)):(ce=0,ut=null,dl(e,t,o,7));break;case 5:var r=null;switch(F.tag){case 26:r=F.memoizedState;case 5:case 27:var u=F;if(r?vm(r):u.stateNode.complete){ce=0,ut=null;var m=u.sibling;if(m!==null)F=m;else{var b=u.return;b!==null?(F=b,Yo(b)):F=null}break t}}ce=0,ut=null,dl(e,t,o,5);break;case 6:ce=0,ut=null,dl(e,t,o,6);break;case 8:dc(),Ee=6;break e;default:throw Error(f(462))}}Gg();break}catch(w){Eh(e,w)}while(!0);return ln=ra=null,q.H=a,q.A=l,re=n,F!==null?0:(me=null,$=0,Ki(),Ee)}function Gg(){for(;F!==null&&!s0();)zh(F)}function zh(e){var t=Yf(e.alternate,e,dn);e.memoizedProps=e.pendingProps,t===null?Yo(e):F=t}function Ah(e){var t=e,n=t.alternate;switch(t.tag){case 15:case 0:t=kf(n,t,t.pendingProps,t.type,void 0,$);break;case 11:t=kf(n,t,t.pendingProps,t.type.render,t.ref,$);break;case 5:vs(t);var a=t;a===De&&(J?(eo(a),a.tag===5&&a.stateNode!=null&&(ge=a.stateNode)):(eo(a),J=!0));default:Gf(n,t),t=F=gd(t,dn),t=Yf(n,t,dn)}e.memoizedProps=e.pendingProps,t===null?Yo(e):F=t}function dl(e,t,n,a){ln=ra=null,vs(t),Ja=null,Pl=0;var l=t.return;try{if(Cg(e,l,t,n,$)){Ee=1,_o(e,yt(n,e.current)),F=null;return}}catch(o){if(l!==null)throw F=l,o;Ee=1,_o(e,yt(n,e.current)),F=null;return}t.flags&32768?(J||a===1?e=!0:ll||($&536870912)!==0?e=!1:(Hn=e=!0,(a===2||a===9||a===3||a===6)&&(a=Ve.current,a!==null&&a.tag===13&&(a.flags|=16384))),Oh(t,e)):Yo(t)}function Yo(e){var t=e;do{if((t.flags&32768)!==0){Oh(t,Hn);return}e=t.return;var n=kg(t.alternate,t,dn);if(n!==null){F=n;return}if(t=t.sibling,t!==null){F=t;return}F=t=e}while(t!==null);Ee===0&&(Ee=5)}function Oh(e,t){do{var n=Vg(e.alternate,e);if(n!==null){n.flags&=32767,F=n;return}if(n=e.return,n!==null&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&(e=e.sibling,e!==null)){F=e;return}F=e=n}while(e!==null);Ee=6,F=null}function Nh(e,t,n,a,l,o,r,u,m,b,w,A){e.cancelPendingCommit=null;do Xo();while(_e!==0);if((re&6)!==0)throw Error(f(327));if(t!==null){if(t===e.current)throw Error(f(177));e===me&&(F=me=null,$=0),ba=t,Dt=e,Zt=n,uc=l,vh=a,Qg(e,t,n,r,u,m,A)}}function Qg(e,t,n,a,l,o,r){var u=t.lanes|t.childLanes;if(cc=u,u|=Zr,y0(e,n,u,a,l,o),rl=null,(n&335544064)===n?(sl=bg(e),a=10262):(sl=null,a=10256),(t.subtreeFlags&a)!==0||(t.flags&a)!==0?(e.callbackNode=null,e.callbackPriority=0,Wg(Di,function(){return gc(),null})):(e.callbackNode=null,e.callbackPriority=0),Oo=!1,a=(t.flags&13878)!==0,(t.subtreeFlags&13878)!==0||a){a=q.T,q.T=null,l=oe.p,oe.p=2,o=re,re|=4;try{Ug(e,t,n)}finally{re=o,oe.p=l,q.T=a}}_e=1,Oo?ol=yx(r,e.containerInfo,sl,hc,mc,Kg,pc,gc,Zg):(hc(),mc(),pc())}function Zg(e){if(_e!==0){var t=Dt.onRecoverableError;t(e,{componentStack:null})}}function Kg(){_e===3&&(_e=0,fh(ba,Dt),_e=4)}function hc(){if(_e===1){_e=0;var e=Dt,t=ba,n=Zt,a=(t.flags&13878)!==0;if((t.subtreeFlags&13878)!==0||a){a=q.T,q.T=null;var l=oe.p;oe.p=2;var o=re;re|=4;try{ri=Co=!1,uh(t,e,n),n=Ac;var r=od(e.containerInfo),u=n.focusedElem,m=n.selectionRange;if(r!==u&&u&&u.ownerDocument&&id(u.ownerDocument.documentElement,u)){if(m!==null&&Ir(u)){var b=m.start,w=m.end;if(w===void 0&&(w=b),"selectionStart"in u)u.selectionStart=b,u.selectionEnd=Math.min(w,u.value.length);else{var A=u.ownerDocument||document,g=A&&A.defaultView||window;if(g.getSelection){var T=g.getSelection(),L=u.textContent.length,U=Math.min(m.start,L),X=m.end===void 0?U:Math.min(m.end,L);!T.extend&&U>X&&(r=X,X=U,U=r);var v=ld(u,U),p=ld(u,X);if(v&&p&&(T.rangeCount!==1||T.anchorNode!==v.node||T.anchorOffset!==v.offset||T.focusNode!==p.node||T.focusOffset!==p.offset)){var _=A.createRange();_.setStart(v.node,v.offset),T.removeAllRanges(),U>X?(T.addRange(_),T.extend(p.node,p.offset)):(_.setEnd(p.node,p.offset),T.addRange(_))}}}}for(A=[],T=u;T=T.parentNode;)T.nodeType===1&&A.push({element:T,left:T.scrollLeft,top:T.scrollTop});for(typeof u.focus=="function"&&u.focus(),u=0;u<A.length;u++){var z=A[u];z.element.scrollLeft=z.left,z.element.scrollTop=z.top}}vl=!!zc,Ac=zc=null}finally{re=o,oe.p=l,q.T=a}}e.current=t,_e=2}}function mc(){if(_e===2){_e=0;var e=Dt,t=ba,n=(t.flags&8772)!==0;if((t.subtreeFlags&8772)!==0||n){n=q.T,q.T=null;var a=oe.p;oe.p=2;var l=re;re|=4;try{lh(e,t.alternate,t)}finally{re=l,oe.p=a,q.T=n}}_e=3}}function pc(){if(_e===4||_e===3){_e=0;var e=ol;ol=null,c0();var t=Dt,n=ba,a=Zt,l=vh,o=(a&335544064)===a?10262:10256;if((n.subtreeFlags&o)!==0||(n.flags&o)!==0?_e=5:(_e=0,ba=Dt=null,Dh(t,t.pendingLanes)),o=t.pendingLanes,o===0&&(In=null),wr(a),n=n.stateNode,lt&&typeof lt.onCommitFiberRoot=="function")try{lt.onCommitFiberRoot(Nl,n,void 0,(n.current.flags&128)===128)}catch{}if(l!==null){n=q.T,o=oe.p,oe.p=2,q.T=null;try{for(var r=t.onRecoverableError,u=0;u<l.length;u++){var m=l[u];r(m.value,{componentStack:m.stack})}}finally{q.T=n,oe.p=o}}if(l=rl,r=sl,sl=null,l!==null&&(rl=null,r===null&&(r=[]),e!==null))for(m=0;m<l.length;m++)n=(0,l[m])(r),n!==void 0&&e.finished.finally(n);(Zt&3)!==0&&Xo(),Kt(t),o=t.pendingLanes,(a&261930)!==0&&(o&42)!==0?t===Ho?di++:(di=0,Ho=t):(di=0,Ho=null),fi(0)}}function Dh(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,Ql(t)))}function Xo(){return ol!==null&&(ol.skipTransition(),ol=null),hc(),mc(),pc(),gc()}function gc(){if(_e!==5)return!1;var e=Dt,t=cc;cc=0;var n=wr(Zt),a=q.T,l=oe.p;try{oe.p=32>n?32:n,q.T=null,n=uc,uc=null;var o=Dt,r=Zt;if(_e=0,ba=Dt=null,Zt=0,(re&6)!==0)throw Error(f(331));var u=re;if(re|=4,gh(o.current),hh(o,o.current,r,n),re=u,fi(0,!1),lt&&typeof lt.onPostCommitFiberRoot=="function")try{lt.onPostCommitFiberRoot(Nl,o)}catch{}return!0}finally{oe.p=l,q.T=a,Dh(e,t)}}function Ch(e,t,n){t=yt(n,t),t=Rs(e.stateNode,t,2),e=Ln(e,t,2),e!==null&&(Cl(e,2),Kt(e))}function ue(e,t,n){if(e.tag===3)Ch(e,e,n);else for(;t!==null;){if(t.tag===3){Ch(t,e,n);break}else if(t.tag===1){var a=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof a.componentDidCatch=="function"&&(In===null||!In.has(a))){e=yt(n,e),n=Af(2),a=Ln(t,n,2),a!==null&&(Of(n,a,t,e),Cl(a,2),Kt(a));break}}t=t.return}}function xc(e,t,n){var a=e.pingCache;if(a===null){a=e.pingCache=new qg;var l=new Set;a.set(t,l)}else l=a.get(t),l===void 0&&(l=new Set,a.set(t,l));l.has(n)||(rc=!0,l.add(n),e=Pg.bind(null,e,t,n),t.then(e,e))}function Pg(e,t,n){var a=e.pingCache;a!==null&&a.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,me===e&&($&n)===n&&((Ee===4||Ee===3&&($&62914560)===$&&300>at()-Vo)&&(re&2)===0?ul(e,0):ko|=n,il===$&&(il=0)),Kt(e)}function Rh(e,t){t===0&&(t=xu()),e=la(e,t),e!==null&&(Cl(e,t),Kt(e))}function Jg(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),Rh(e,n)}function Fg(e,t){var n=0;switch(e.tag){case 31:case 13:var a=e.stateNode,l=e.memoizedState;l!==null&&(n=l.retryLane);break;case 19:a=e.stateNode;break;case 22:a=e.stateNode._retryCache;break;default:throw Error(f(314))}a!==null&&a.delete(t),Rh(e,n)}function Wg(e,t){return br(e,t)}var fl=null,hl=null,yc=!1,Go=!1,vc=!1,Xn=0;function Kt(e){e!==hl&&e.next===null&&(hl===null?fl=hl=e:hl=hl.next=e),Go=!0,yc||(yc=!0,ex())}function fi(e,t){if(!vc&&Go){vc=!0;do for(var n=!1,a=fl;a!==null;){if(e!==0){var l=a.pendingLanes;if(l===0)var o=0;else{var r=a.suspendedLanes,u=a.pingedLanes;o=(1<<31-it(42|e)+1)-1,o&=l&~(r&~u),o=o&201326741?o&201326741|1:o?o|2:0}o!==0&&(n=!0,Vh(a,o))}else o=$,o=Mi(a,a===me?o:0,a.cancelPendingCommit!==null||a.timeoutHandle!==-1),(o&3)===0||Dl(a,o)||(n=!0,Vh(a,o));a=a.next}while(n);vc=!1}}function $g(){Lh()}function Lh(){Go=yc=!1;var e=0;Xn!==0&&dx()&&(e=Xn);for(var t=at(),n=null,a=fl;a!==null;){var l=a.next,o=Mh(a,t);o===0?(a.next=null,n===null?fl=l:n.next=l,l===null&&(hl=n)):(n=a,(e!==0||(o&3)!==0)&&(Go=!0)),a=l}_e!==0&&_e!==5||fi(e),Xn!==0&&(Xn=0)}function Mh(e,t){for(var n=e.suspendedLanes,a=e.pingedLanes,l=e.expirationTimes,o=e.pendingLanes&-62914561;0<o;){var r=31-it(o),u=1<<r,m=l[r];m===-1?((u&n)===0||(u&a)!==0)&&(l[r]=x0(u,t)):m<=t&&(e.expiredLanes|=u),o&=~u}if(t=me,n=$,n=Mi(e,e===t?n:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),a=e.callbackNode,n===0||e===t&&(ce===2||ce===9)||e.cancelPendingCommit!==null)return a!==null&&a!==null&&_r(a),e.callbackNode=null,e.callbackPriority=0;if((n&3)===0||Dl(e,n)){if(t=n&-n,t===e.callbackPriority)return t;switch(a!==null&&_r(a),wr(n)){case 2:case 8:n=mu;break;case 32:n=Di;break;case 268435456:n=pu;break;default:n=Di}return a=kh.bind(null,e),n=br(n,a),e.callbackPriority=t,e.callbackNode=n,t}return a!==null&&a!==null&&_r(a),e.callbackPriority=2,e.callbackNode=null,2}function kh(e,t){if(_e!==0&&_e!==5)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(Xo()&&e.callbackNode!==n)return null;var a=$;return a=Mi(e,e===me?a:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),a===0?null:(_h(e,a,t),Mh(e,at()),e.callbackNode!=null&&e.callbackNode===n?kh.bind(null,e):null)}function Vh(e,t){if(Xo())return null;_h(e,t,!0)}function ex(){hx(function(){(re&6)!==0?br(hu,$g):Lh()})}function bc(){if(Xn===0){var e=ua;e===0&&(e=Ci,Ci<<=1,(Ci&261888)===0&&(Ci=256)),Xn=e}return Xn}function Uh(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:Hi(e)}function tx(e,t,n,a,l){if(t==="submit"&&n&&n.stateNode===l){var o=Uh((l[Fe]||null).action),r=a.submitter;r&&(t=(t=r[Fe]||null)?Uh(t.formAction):r.getAttribute("formAction"),t!==null&&(o=t,r=null));var u=new Xi("action","action",null,a,l);e.push({event:u,listeners:[{instance:null,listener:function(){if(a.defaultPrevented){if(Xn!==0){var m=new FormData(l,r);As(n,{pending:!0,data:m,method:l.method,action:o},null,m)}}else typeof o=="function"&&(u.preventDefault(),m=new FormData(l,r),As(n,{pending:!0,data:m,method:l.method,action:o},o,m))},currentTarget:l}]})}}for(var _c=0;_c<Qr.length;_c++){var Tc=Qr[_c],nx=Tc.toLowerCase(),ax=Tc[0].toUpperCase()+Tc.slice(1);zt(nx,"on"+ax)}zt(cd,"onAnimationEnd"),zt(ud,"onAnimationIteration"),zt(dd,"onAnimationStart"),zt("dblclick","onDoubleClick"),zt("focusin","onFocus"),zt("focusout","onBlur"),zt(fg,"onTransitionRun"),zt(hg,"onTransitionStart"),zt(mg,"onTransitionCancel"),zt(fd,"onTransitionEnd"),Ma("onMouseEnter",["mouseout","mouseover"]),Ma("onMouseLeave",["mouseout","mouseover"]),Ma("onPointerEnter",["pointerout","pointerover"]),Ma("onPointerLeave",["pointerout","pointerover"]),ta("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),ta("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),ta("onBeforeInput",["compositionend","keypress","textInput","paste"]),ta("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),ta("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),ta("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var hi="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),lx=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(hi));function Bh(e,t){t=(t&4)!==0;for(var n=0;n<e.length;n++){var a=e[n],l=a.event;a=a.listeners;e:{var o=void 0;if(t)for(var r=a.length-1;0<=r;r--){var u=a[r],m=u.instance,b=u.currentTarget;if(u=u.listener,m!==o&&l.isPropagationStopped())break e;o=u,l.currentTarget=b;try{o(l)}catch(w){Zi(w)}l.currentTarget=null,o=m}else for(r=0;r<a.length;r++){if(u=a[r],m=u.instance,b=u.currentTarget,u=u.listener,m!==o&&l.isPropagationStopped())break e;o=u,l.currentTarget=b;try{o(l)}catch(w){Zi(w)}l.currentTarget=null,o=m}}}}function W(e,t){var n=t[Eu];n===void 0&&(n=t[Eu]=new Set);var a=e+"__bubble";n.has(a)||(Hh(t,e,2,!1),n.add(a))}function Ec(e,t,n){var a=0;t&&(a|=4),Hh(n,e,a,t)}var Qo="_reactListening"+Math.random().toString(36).slice(2);function wc(e){if(!e[Qo]){e[Qo]=!0,Su.forEach(function(n){n!=="selectionchange"&&(lx.has(n)||Ec(n,!1,e),Ec(n,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[Qo]||(t[Qo]=!0,Ec("selectionchange",!1,t))}}function Hh(e,t,n,a){switch(Om(t)){case 2:var l=Jx;break;case 8:l=Fx;break;default:l=Xc}n=l.bind(null,t,n,e),l=void 0,!Cr||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(l=!0),a?l!==void 0?e.addEventListener(t,n,{capture:!0,passive:l}):e.addEventListener(t,n,!0):l!==void 0?e.addEventListener(t,n,{passive:l}):e.addEventListener(t,n,!1)}function jc(e,t,n,a,l){var o=a;if((t&1)===0&&(t&2)===0&&a!==null)e:for(;;){if(a===null)return;var r=a.tag;if(r===3||r===4){var u=a.stateNode.containerInfo;if(u===l)break;if(r===4)for(r=a.return;r!==null;){var m=r.tag;if((m===3||m===4)&&r.stateNode.containerInfo===l)return;r=r.return}for(;u!==null;){if(r=ea(u),r===null)return;if(m=r.tag,m===5||m===6||m===26||m===27){a=o=r;continue e}u=u.parentNode}}a=a.return}Bu(function(){var b=o,w=Nr(n),A=[];e:{var g=hd.get(e);if(g!==void 0){var T=Xi,L=e;switch(e){case"keypress":if(Ii(n)===0)break e;case"keydown":case"keyup":T=I0;break;case"focusin":L="focus",T=kr;break;case"focusout":L="blur",T=kr;break;case"beforeblur":case"afterblur":T=kr;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":T=Iu;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":T=N0;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":T=Z0;break;case cd:case ud:case dd:T=R0;break;case fd:T=P0;break;case"scroll":case"scrollend":T=A0;break;case"wheel":T=F0;break;case"copy":case"cut":case"paste":T=M0;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":T=Xu;break;case"submit":T=G0;break;case"toggle":case"beforetoggle":T=$0}var U=(t&4)!==0,X=!U&&(e==="scroll"||e==="scrollend"),v=U?g!==null?g+"Capture":null:g;U=[];for(var p=b,_;p!==null;){var z=p;if(_=z.stateNode,z=z.tag,z!==5&&z!==26&&z!==27||_===null||v===null||(z=Ml(p,v),z!=null&&U.push(mi(p,z,_))),X)break;p=p.return}0<U.length&&(g=new T(g,L,null,n,w),A.push({event:g,listeners:U}))}}if((t&7)===0){e:{if(T=e==="mouseover"||e==="pointerover",g=e==="mouseout"||e==="pointerout",T&&n!==Or&&(L=n.relatedTarget||n.fromElement)&&(ea(L)||L[Ca]))break e;(g||T)&&(L=w.window===w?w:(T=w.ownerDocument)?T.defaultView||T.parentWindow:window,g?(T=n.relatedTarget||n.toElement,g=b,T=T?ea(T):null,T!==null&&(X=E(T),U=T.tag,T!==X||U!==5&&U!==27&&U!==6)&&(T=null)):(g=null,T=b),g!==T&&(U=Iu,z="onMouseLeave",v="onMouseEnter",p="mouse",(e==="pointerout"||e==="pointerover")&&(U=Xu,z="onPointerLeave",v="onPointerEnter",p="pointer"),X=g==null?L:Ll(g),_=T==null?L:Ll(T),L=new U(z,p+"leave",g,n,w),L.target=X,L.relatedTarget=_,z=null,ea(w)===b&&(U=new U(v,p+"enter",T,n,w),U.target=_,U.relatedTarget=X,z=U),X=z,U=g&&T?pt(g,T,ix):null,g!==null&&qh(A,L,g,U,!1),T!==null&&X!==null&&qh(A,X,T,U,!0)))}e:{if(g=b?Ll(b):window,T=g.nodeName&&g.nodeName.toLowerCase(),T==="select"||T==="input"&&g.type==="file")var V=Wu;else if(Ju(g))if($u)V=cg;else{V=rg;var ee=og}else T=g.nodeName,!T||T.toLowerCase()!=="input"||g.type!=="checkbox"&&g.type!=="radio"?b&&Ar(b.elementType)&&(V=Wu):V=sg;if(V&&(V=V(e,b))){Fu(A,V,n,w);break e}ee&&ee(e,g,b)}switch(ee=b?Ll(b):window,e){case"focusin":(Ju(ee)||ee.contentEditable==="true")&&(qa=ee,Yr=b,Yl=null);break;case"focusout":Yl=Yr=qa=null;break;case"mousedown":Xr=!0;break;case"contextmenu":case"mouseup":case"dragend":Xr=!1,rd(A,n,w);break;case"selectionchange":if(dg)break;case"keydown":case"keyup":rd(A,n,w)}var B;if(Ur)e:{switch(e){case"compositionstart":var H="onCompositionStart";break e;case"compositionend":H="onCompositionEnd";break e;case"compositionupdate":H="onCompositionUpdate";break e}H=void 0}else Ha?Ku(e,n)&&(H="onCompositionEnd"):e==="keydown"&&n.keyCode===229&&(H="onCompositionStart");H&&(Gu&&n.locale!=="ko"&&(Ha||H!=="onCompositionStart"?H==="onCompositionEnd"&&Ha&&(B=Hu()):(jn=w,Rr="value"in jn?jn.value:jn.textContent,Ha=!0)),ee=Zo(b,H),0<ee.length&&(H=new Yu(H,e,null,n,w),A.push({event:H,listeners:ee}),B?H.data=B:(B=Pu(n),B!==null&&(H.data=B)))),(B=tg?ng(e,n):ag(e,n))&&(H=Zo(b,"onBeforeInput"),0<H.length&&(ee=new Yu("onBeforeInput","beforeinput",null,n,w),A.push({event:ee,listeners:H}),ee.data=B)),tx(A,e,b,n,w)}Bh(A,t)})}function mi(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Zo(e,t){for(var n=t+"Capture",a=[];e!==null;){var l=e,o=l.stateNode;if(l=l.tag,l!==5&&l!==26&&l!==27||o===null||(l=Ml(e,n),l!=null&&a.unshift(mi(e,l,o)),l=Ml(e,t),l!=null&&a.push(mi(e,l,o))),e.tag===3)return a;e=e.return}return[]}function ix(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function qh(e,t,n,a,l){for(var o=t._reactName,r=[];n!==null&&n!==a;){var u=n,m=u.alternate,b=u.stateNode;if(u=u.tag,m!==null&&m===a)break;u!==5&&u!==26&&u!==27||b===null||(m=b,l?(b=Ml(n,o),b!=null&&r.unshift(mi(n,b,m))):l||(b=Ml(n,o),b!=null&&r.push(mi(n,b,m)))),n=n.return}r.length!==0&&e.push({event:t,listeners:r})}var ox=/\r\n?/g,rx=/\u0000|\uFFFD/g;function Ih(e){return(typeof e=="string"?e:""+e).replace(ox,`
`).replace(rx,"")}function Yh(e,t){return t=Ih(t),Ih(e)===t}function de(e,t,n,a,l,o){switch(n){case"children":if(typeof a=="string")t==="body"||t==="textarea"&&a===""||Va(e,a);else if(typeof a=="number"||typeof a=="bigint")t!=="body"&&Va(e,""+a);else return;break;case"className":Bi(e,"class",a);break;case"tabIndex":Bi(e,"tabindex",a);break;case"dir":case"role":case"viewBox":case"width":case"height":Bi(e,n,a);break;case"style":Vu(e,a,o);return;case"data":if(t!=="object"){Bi(e,"data",a);break}case"src":case"href":if(a===""&&(t!=="a"||n!=="href")){e.removeAttribute(n);break}if(a==null||typeof a=="function"||typeof a=="symbol"||typeof a=="boolean"){e.removeAttribute(n);break}a=Hi(a),e.setAttribute(n,a);break;case"action":case"formAction":if(typeof a=="function"){e.setAttribute(n,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof o=="function"&&(n==="formAction"?(t!=="input"&&de(e,t,"name",l.name,l,null),de(e,t,"formEncType",l.formEncType,l,null),de(e,t,"formMethod",l.formMethod,l,null),de(e,t,"formTarget",l.formTarget,l,null)):(de(e,t,"encType",l.encType,l,null),de(e,t,"method",l.method,l,null),de(e,t,"target",l.target,l,null)));if(a==null||typeof a=="symbol"||typeof a=="boolean"){e.removeAttribute(n);break}a=Hi(a),e.setAttribute(n,a);break;case"onClick":a!=null&&(e.onclick=Ut);return;case"onScroll":a!=null&&W("scroll",e);return;case"onScrollEnd":a!=null&&W("scrollend",e);return;case"dangerouslySetInnerHTML":if(a!=null){if(typeof a!="object"||!("__html"in a))throw Error(f(61));if(n=a.__html,n!=null){if(l.children!=null)throw Error(f(60));o?.__html!==n&&(e.innerHTML=n)}}break;case"multiple":e.multiple=a&&typeof a!="function"&&typeof a!="symbol";break;case"muted":e.muted=a&&typeof a!="function"&&typeof a!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(a==null||typeof a=="function"||typeof a=="boolean"||typeof a=="symbol"){e.removeAttribute("xlink:href");break}n=Hi(a),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",n);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":a!=null&&typeof a!="function"&&typeof a!="symbol"?e.setAttribute(n,a):e.removeAttribute(n);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"credentialless":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":a&&typeof a!="function"&&typeof a!="symbol"?e.setAttribute(n,""):e.removeAttribute(n);break;case"capture":case"download":a===!0?e.setAttribute(n,""):a!==!1&&a!=null&&typeof a!="function"&&typeof a!="symbol"?e.setAttribute(n,a):e.removeAttribute(n);break;case"cols":case"rows":case"size":case"span":a!=null&&typeof a!="function"&&typeof a!="symbol"&&!isNaN(a)&&1<=a?e.setAttribute(n,a):e.removeAttribute(n);break;case"rowSpan":case"start":a==null||typeof a=="function"||typeof a=="symbol"||isNaN(a)?e.removeAttribute(n):e.setAttribute(n,a);break;case"popover":W("beforetoggle",e),W("toggle",e),Ui(e,"popover",a);break;case"xlinkActuate":Wt(e,"http://www.w3.org/1999/xlink","xlink:actuate",a);break;case"xlinkArcrole":Wt(e,"http://www.w3.org/1999/xlink","xlink:arcrole",a);break;case"xlinkRole":Wt(e,"http://www.w3.org/1999/xlink","xlink:role",a);break;case"xlinkShow":Wt(e,"http://www.w3.org/1999/xlink","xlink:show",a);break;case"xlinkTitle":Wt(e,"http://www.w3.org/1999/xlink","xlink:title",a);break;case"xlinkType":Wt(e,"http://www.w3.org/1999/xlink","xlink:type",a);break;case"xmlBase":Wt(e,"http://www.w3.org/XML/1998/namespace","xml:base",a);break;case"xmlLang":Wt(e,"http://www.w3.org/XML/1998/namespace","xml:lang",a);break;case"xmlSpace":Wt(e,"http://www.w3.org/XML/1998/namespace","xml:space",a);break;case"is":Ui(e,"is",a);break;case"innerText":case"textContent":return;default:if(!(2<n.length)||n[0]!=="o"&&n[0]!=="O"||n[1]!=="n"&&n[1]!=="N")n=S0.get(n)||n,Ui(e,n,a);else return}le=!0}function Sc(e,t,n,a,l,o){switch(n){case"style":Vu(e,a,o);return;case"dangerouslySetInnerHTML":if(a!=null){if(typeof a!="object"||!("__html"in a))throw Error(f(61));if(n=a.__html,n!=null){if(l.children!=null)throw Error(f(60));o?.__html!==n&&(e.innerHTML=n)}}break;case"children":if(typeof a=="string")Va(e,a);else if(typeof a=="number"||typeof a=="bigint")Va(e,""+a);else return;break;case"onScroll":a!=null&&W("scroll",e);return;case"onScrollEnd":a!=null&&W("scrollend",e);return;case"onClick":a!=null&&(e.onclick=Ut);return;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":return;case"innerText":case"textContent":return;default:if(!zu.hasOwnProperty(n))e:{if(n[0]==="o"&&n[1]==="n"&&(l=n.endsWith("Capture"),o=n.slice(2,l?n.length-7:void 0),t=e[Fe]||null,t=t!=null?t[n]:null,typeof t=="function"&&e.removeEventListener(o,t,l),typeof a=="function")){typeof t!="function"&&t!==null&&(n in e?e[n]=null:e.hasAttribute(n)&&e.removeAttribute(n)),e.addEventListener(o,a,l);break e}le=!0,n in e?e[n]=a:a===!0?e.setAttribute(n,""):Ui(e,n,a)}return}le=!0}function He(e,t,n){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":W("error",e),W("load",e);var a=!1,l=!1,o;for(o in n)if(n.hasOwnProperty(o)){var r=n[o];if(r!=null)switch(o){case"src":a=!0;break;case"srcSet":l=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(f(137,t));default:de(e,t,o,r,n,null)}}l&&de(e,t,"srcSet",n.srcSet,n,null),a&&de(e,t,"src",n.src,n,null);return;case"input":W("invalid",e);var u=o=r=l=null,m=null,b=null;for(a in n)if(n.hasOwnProperty(a)){var w=n[a];if(w!=null)switch(a){case"name":l=w;break;case"type":r=w;break;case"checked":m=w;break;case"defaultChecked":b=w;break;case"value":o=w;break;case"defaultValue":u=w;break;case"children":case"dangerouslySetInnerHTML":if(w!=null)throw Error(f(137,t));break;default:de(e,t,a,w,n,null)}}Ru(e,o,u,m,b,r,l,!1);return;case"select":W("invalid",e),a=r=o=null;for(l in n)if(n.hasOwnProperty(l)&&(u=n[l],u!=null))switch(l){case"value":o=u;break;case"defaultValue":r=u;break;case"multiple":a=u;default:de(e,t,l,u,n,null)}t=o,n=r,e.multiple=!!a,t!=null?ka(e,!!a,t,!1):n!=null&&ka(e,!!a,n,!0);return;case"textarea":W("invalid",e),o=l=a=null;for(r in n)if(n.hasOwnProperty(r)&&(u=n[r],u!=null))switch(r){case"value":a=u;break;case"defaultValue":l=u;break;case"children":o=u;break;case"dangerouslySetInnerHTML":if(u!=null)throw Error(f(91));break;default:de(e,t,r,u,n,null)}Mu(e,a,l,o);return;case"option":for(m in n)n.hasOwnProperty(m)&&(a=n[m],a!=null)&&(m==="selected"?e.selected=a&&typeof a!="function"&&typeof a!="symbol":de(e,t,m,a,n,null));return;case"dialog":W("beforetoggle",e),W("toggle",e),W("cancel",e),W("close",e);break;case"iframe":case"object":W("load",e);break;case"video":case"audio":for(a=0;a<hi.length;a++)W(hi[a],e);break;case"image":W("error",e),W("load",e);break;case"details":W("toggle",e);break;case"embed":case"source":case"link":W("error",e),W("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(b in n)if(n.hasOwnProperty(b)&&(a=n[b],a!=null))switch(b){case"children":case"dangerouslySetInnerHTML":throw Error(f(137,t));default:de(e,t,b,a,n,null)}return;default:if(Ar(t)){for(w in n)n.hasOwnProperty(w)&&(a=n[w],a!==void 0&&Sc(e,t,w,a,n,void 0));return}}for(u in n)n.hasOwnProperty(u)&&(a=n[u],a!=null&&de(e,t,u,a,n,null))}var sx={};function cx(e,t,n,a){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var l=null,o=null,r=null,u=null,m=null,b=null,w=null;for(T in n){var A=n[T];if(n.hasOwnProperty(T)&&A!=null)switch(T){case"checked":break;case"value":break;case"defaultValue":m=A;default:a.hasOwnProperty(T)||de(e,t,T,null,a,A)}}for(var g in a){var T=a[g];if(A=n[g],a.hasOwnProperty(g)&&(T!=null||A!=null))switch(g){case"type":T!==A&&(le=!0),o=T;break;case"name":T!==A&&(le=!0),l=T;break;case"checked":T!==A&&(le=!0),b=T;break;case"defaultChecked":T!==A&&(le=!0),w=T;break;case"value":T!==A&&(le=!0),r=T;break;case"defaultValue":T!==A&&(le=!0),u=T;break;case"children":case"dangerouslySetInnerHTML":if(T!=null)throw Error(f(137,t));break;default:T!==A&&de(e,t,g,T,a,A)}}Sr(e,r,u,m,b,w,o,l);return;case"select":T=r=u=g=null;for(o in n)if(m=n[o],n.hasOwnProperty(o)&&m!=null)switch(o){case"value":break;case"multiple":T=m;default:a.hasOwnProperty(o)||de(e,t,o,null,a,m)}for(l in a)if(o=a[l],m=n[l],a.hasOwnProperty(l)&&(o!=null||m!=null))switch(l){case"value":o!==m&&(le=!0),g=o;break;case"defaultValue":o!==m&&(le=!0),u=o;break;case"multiple":o!==m&&(le=!0),r=o;default:o!==m&&de(e,t,l,o,a,m)}t=u,n=r,a=T,g!=null?ka(e,!!n,g,!1):!!a!=!!n&&(t!=null?ka(e,!!n,t,!0):ka(e,!!n,n?[]:"",!1));return;case"textarea":T=g=null;for(u in n)if(l=n[u],n.hasOwnProperty(u)&&l!=null&&!a.hasOwnProperty(u))switch(u){case"value":break;case"children":break;default:de(e,t,u,null,a,l)}for(r in a)if(l=a[r],o=n[r],a.hasOwnProperty(r)&&(l!=null||o!=null))switch(r){case"value":l!==o&&(le=!0),g=l;break;case"defaultValue":l!==o&&(le=!0),T=l;break;case"children":break;case"dangerouslySetInnerHTML":if(l!=null)throw Error(f(91));break;default:l!==o&&de(e,t,r,l,a,o)}Lu(e,g,T);return;case"option":for(var L in n)g=n[L],n.hasOwnProperty(L)&&g!=null&&!a.hasOwnProperty(L)&&(L==="selected"?e.selected=!1:de(e,t,L,null,a,g));for(m in a)g=a[m],T=n[m],a.hasOwnProperty(m)&&g!==T&&(g!=null||T!=null)&&(m==="selected"?(g!==T&&(le=!0),e.selected=g&&typeof g!="function"&&typeof g!="symbol"):de(e,t,m,g,a,T));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var U in n)g=n[U],n.hasOwnProperty(U)&&g!=null&&!a.hasOwnProperty(U)&&de(e,t,U,null,a,g);for(b in a)if(g=a[b],T=n[b],a.hasOwnProperty(b)&&g!==T&&(g!=null||T!=null))switch(b){case"children":case"dangerouslySetInnerHTML":if(g!=null)throw Error(f(137,t));break;default:de(e,t,b,g,a,T)}return;default:if(Ar(t)){for(var X in n)g=n[X],n.hasOwnProperty(X)&&g!==void 0&&!a.hasOwnProperty(X)&&Sc(e,t,X,void 0,a,g);for(w in a)g=a[w],T=n[w],!a.hasOwnProperty(w)||g===T||g===void 0&&T===void 0||Sc(e,t,w,g,a,T);return}}for(var v in n)g=n[v],n.hasOwnProperty(v)&&g!=null&&!a.hasOwnProperty(v)&&de(e,t,v,null,a,g);for(A in a)g=a[A],T=n[A],!a.hasOwnProperty(A)||g===T||g==null&&T==null||de(e,t,A,g,a,T)}function Xh(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function ux(){if(typeof performance.getEntriesByType=="function"){for(var e=0,t=0,n=performance.getEntriesByType("resource"),a=0;a<n.length;a++){var l=n[a],o=l.transferSize,r=l.initiatorType,u=l.duration;if(o&&u&&Xh(r)){for(r=0,u=l.responseEnd,a+=1;a<n.length;a++){var m=n[a],b=m.startTime;if(b>u)break;var w=m.transferSize,A=m.initiatorType;w&&Xh(A)&&(m=m.responseEnd,r+=w*(m<u?1:(u-b)/(m-b)))}if(--a,t+=8*(o+r)/(l.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var zc=null,Ac=null;function pi(e){return e.nodeType===9?e:e.ownerDocument}function Gh(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function Qh(e,t){if(e===0)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&t==="foreignObject"?0:e}function Zh(e,t,n,a){return n=pi(n).createElement(e),n[Me]=a,n[Fe]=t,He(n,e,t),Ne(n),n}function Oc(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.children=="bigint"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var Nc=null;function dx(){var e=window.event;return e&&e.type==="popstate"?e===Nc?!1:(Nc=e,!0):(Nc=null,!1)}var Dc=typeof setTimeout=="function"?setTimeout:void 0,fx=typeof clearTimeout=="function"?clearTimeout:void 0,Kh=typeof Promise=="function"?Promise:void 0,Ph=typeof requestAnimationFrame=="function"?requestAnimationFrame:Dc,hx=typeof queueMicrotask=="function"?queueMicrotask:typeof Kh<"u"?function(e){return Kh.resolve(null).then(e).catch(mx)}:Dc;function mx(e){setTimeout(function(){throw e})}function Gn(e){return e==="head"}function Jh(e,t){var n=t,a=0;do{var l=n.nextSibling;if(e.removeChild(n),l&&l.nodeType===8)if(n=l.data,n==="/$"||n==="/&"){if(a===0){e.removeChild(l),bl(t);return}a--}else if(n==="$"||n==="$?"||n==="$~"||n==="$!"||n==="&")a++;else if(n==="html")Bc(e.ownerDocument.documentElement);else if(n==="head"){n=e.ownerDocument.head,Bc(n);for(var o=n.firstChild;o;){var r=o.nextSibling,u=o.nodeName;o[Rl]||u==="SCRIPT"||u==="STYLE"||u==="LINK"&&o.rel.toLowerCase()==="stylesheet"||n.removeChild(o),o=r}}else n==="body"&&Bc(e.ownerDocument.body);n=l}while(n);bl(t)}function Fh(e,t){var n=e;e=0;do{var a=n.nextSibling;if(n.nodeType===1?t?(n._stashedDisplay=n.style.display,n.style.display="none"):(n.style.display=n._stashedDisplay||"",n.getAttribute("style")===""&&n.removeAttribute("style")):n.nodeType===3&&(t?(n._stashedText=n.nodeValue,n.nodeValue=""):n.nodeValue=n._stashedText||""),a&&a.nodeType===8)if(n=a.data,n==="/$"){if(e===0)break;e--}else n!=="$"&&n!=="$?"&&n!=="$~"&&n!=="$!"||e++;n=a}while(n)}function Wh(e,t,n){if(t=CSS.escape(t)!==t?"r-"+btoa(t).replace(/=/g,""):t,e.style.viewTransitionName=t,n!=null&&(e.style.viewTransitionClass=n),n=getComputedStyle(e),n.display==="inline"){if(t=e.getClientRects(),t.length===1)var a=1;else for(var l=a=0;l<t.length;l++){var o=t[l];0<o.width&&0<o.height&&a++}a===1&&(e=e.style,e.display=t.length===1?"inline-block":"block",e.marginTop="-"+n.paddingTop,e.marginBottom="-"+n.paddingBottom)}}function $h(e,t){e=e.style,t=t.style;var n=t!=null?t.hasOwnProperty("viewTransitionName")?t.viewTransitionName:t.hasOwnProperty("view-transition-name")?t["view-transition-name"]:null:null;e.viewTransitionName=n==null||typeof n=="boolean"?"":(""+n).trim(),n=t!=null?t.hasOwnProperty("viewTransitionClass")?t.viewTransitionClass:t.hasOwnProperty("view-transition-class")?t["view-transition-class"]:null:null,e.viewTransitionClass=n==null||typeof n=="boolean"?"":(""+n).trim(),e.display==="inline-block"&&(t==null?e.display=e.margin="":(n=t.display,e.display=n==null||typeof n=="boolean"?"":n,n=t.margin,n!=null?e.margin=n:(n=t.hasOwnProperty("marginTop")?t.marginTop:t["margin-top"],e.marginTop=n==null||typeof n=="boolean"?"":n,t=t.hasOwnProperty("marginBottom")?t.marginBottom:t["margin-bottom"],e.marginBottom=t==null||typeof t=="boolean"?"":t)))}function px(e,t,n){return n=n.ownerDocument.defaultView,{rect:e,abs:t.position==="absolute"||t.position==="fixed",clip:t.clipPath!=="none"||t.overflow!=="visible"||t.filter!=="none"||t.mask!=="none"||t.mask!=="none"||t.borderRadius!=="0px",view:0<=e.bottom&&0<=e.right&&e.top<=n.innerHeight&&e.left<=n.innerWidth}}function Cc(e){var t=e.getBoundingClientRect(),n=getComputedStyle(e);return px(t,n,e)}function gx(e){return e.documentElement.clientHeight}function xx(e){this.addEventListener("load",e),this.addEventListener("error",e)}function yx(e,t,n,a,l,o,r,u,m){var b=t.nodeType===9?t:t.ownerDocument;try{var w=b.startViewTransition({update:function(){var g=b.defaultView,T=g.navigation&&g.navigation.transition,L=b.fonts.status;a();var U=[];if(L==="loaded"&&(gx(b),b.fonts.status==="loading"&&U.push(b.fonts.ready)),L=U.length,e!==null)for(var X=e.suspenseyImages,v=0,p=0;p<X.length;p++){var _=X[p];if(!_.complete){var z=_.getBoundingClientRect();if(0<z.bottom&&0<z.right&&z.top<g.innerHeight&&z.left<g.innerWidth){if(v+=bm(_),v>Jo){U.length=L;break}_=new Promise(xx.bind(_)),U.push(_)}}}if(0<U.length)return g=Promise.race([Promise.all(U),new Promise(function(V){return setTimeout(V,500)})]).then(l,l),(T?Promise.allSettled([T.finished,g]):g).then(o,o);if(l(),T)return T.finished.then(o,o);o()},types:n});b.__reactViewTransition=w;var A=[];return w.ready.then(function(){for(var g=b.documentElement.getAnimations({subtree:!0}),T=0;T<g.length;T++){var L=g[T],U=L.effect,X=U.pseudoElement;if(X!=null&&X.startsWith("::view-transition")){A.push(L),L=U.getKeyframes();for(var v=X=void 0,p=!0,_=0;_<L.length;_++){var z=L[_],V=z.width;if(X===void 0)X=V;else if(X!==V){p=!1;break}if(V=z.height,v===void 0)v=V;else if(v!==V){p=!1;break}delete z.width,delete z.height,z.transform==="none"&&delete z.transform}p&&X!==void 0&&v!==void 0&&(U.setKeyframes(L),p=getComputedStyle(U.target,U.pseudoElement),p.width!==X||p.height!==v)&&(p=L[0],p.width=X,p.height=v,p=L[L.length-1],p.width=X,p.height=v,U.setKeyframes(L))}}r()},function(g){b.__reactViewTransition===w&&(b.__reactViewTransition=null);try{typeof g=="object"&&g!==null&&g.name==="InvalidStateError"&&(g.message==="View transition was skipped because document visibility state is hidden."||g.message==="Skipping view transition because document visibility state has become hidden."||g.message==="Skipping view transition because viewport size changed."||g.message==="Transition was aborted because of invalid state")&&(g=null),g!==null&&m(g)}finally{a(),l(),r()}}),w.finished.finally(function(){for(var g=0;g<A.length;g++)A[g].cancel();b.__reactViewTransition===w&&(b.__reactViewTransition=null),u()}),w}catch{return a(),l(),r(),null}}function _a(e,t){this._scope=document.documentElement,this._selector="::view-transition-"+e+"("+t+")"}_a.prototype.animate=function(e,t){return t=typeof t=="number"?{duration:t}:te({},t),t.pseudoElement=this._selector,this._scope.animate(e,t)},_a.prototype.getAnimations=function(){for(var e=this._scope,t=this._selector,n=e.getAnimations({subtree:!0}),a=[],l=0;l<n.length;l++){var o=n[l].effect;o!==null&&o.target===e&&o.pseudoElement===t&&a.push(n[l])}return a},_a.prototype.getComputedStyle=function(){return getComputedStyle(this._scope,this._selector)};function em(e){return{name:e,group:new _a("group",e),imagePair:new _a("image-pair",e),old:new _a("old",e),new:new _a("new",e)}}function ht(e){this._fragmentFiber=e,this._observers=this._eventListeners=null}ht.prototype.addEventListener=function(e,t,n){var a=null,l=null;if(!(n!=null&&typeof n!="boolean"&&(a=n.signal||null,a!==null&&a.aborted))){this._eventListeners===null&&(this._eventListeners=[]);var o=this._eventListeners;if(nm(o,e,t,n)===-1){var r=this,u=t;n!=null&&typeof n!="boolean"&&n.once===!0&&(u=function(m){r.removeEventListener(e,t,n),typeof t=="function"?t.call(this,m):t.handleEvent(m)}),a!==null&&(l=r.removeEventListener.bind(r,e,t,n),a.addEventListener("abort",l,{once:!0}),l=a.removeEventListener.bind(a,"abort",l)),a=ml(n),o.push({type:e,listener:t,optionsOrUseCapture:n,attachedListener:u,cleanup:l}),O(this._fragmentFiber.child,!1,vx,e,u,a)}this._eventListeners=o}};function vx(e,t,n,a){return P(e).addEventListener(t,n,a),!1}ht.prototype.removeEventListener=function(e,t,n){var a=this._eventListeners;if(a!==null&&(t=nm(a,e,t,n),t!==-1)){var l=a[t];n=l.attachedListener;var o=l.cleanup;l=ml(l.optionsOrUseCapture),O(this._fragmentFiber.child,!1,bx,e,n,l),a.splice(t,1),o!==null&&o()}};function bx(e,t,n,a){return P(e).removeEventListener(t,n,a),!1}function ml(e){return e!=null&&typeof e!="boolean"&&(e.once===!0||e.signal instanceof AbortSignal)?{capture:e.capture,passive:e.passive}:e}function tm(e){return e==null?"c=0":typeof e=="boolean"?"c="+(e?"1":"0"):"c="+(e.capture?"1":"0")}function nm(e,t,n,a){if(e.length===0)return-1;a=tm(a);for(var l=0;l<e.length;l++){var o=e[l];if(o.type===t&&o.listener===n&&tm(o.optionsOrUseCapture)===a)return l}return-1}ht.prototype.dispatchEvent=function(e){var t=D(this._fragmentFiber);if(t===null)return!0;t=P(t);var n=this._eventListeners;if(n!==null&&0<n.length||!e.bubbles){var a=t.nodeType===9?t.createComment(""):document.createTextNode("");if(n)for(var l=0;l<n.length;l++){var o=n[l];a.addEventListener(o.type,o.attachedListener,ml(o.optionsOrUseCapture))}if(t.appendChild(a),e=a.dispatchEvent(e),n)for(l=0;l<n.length;l++)o=n[l],a.removeEventListener(o.type,o.attachedListener,ml(o.optionsOrUseCapture));return t.removeChild(a),e}return t.dispatchEvent(e)},ht.prototype.focus=function(e){O(this._fragmentFiber.child,!0,am,e,void 0,void 0)};function am(e,t){return e.tag===6?!1:(e=P(e),Cx(e,t))}ht.prototype.focusLast=function(e){var t=[];O(this._fragmentFiber.child,!0,Rc,t,void 0,void 0);for(var n=t.length-1;0<=n&&!am(t[n],e);n--);};function Rc(e,t){return t.push(e),!1}ht.prototype.blur=function(){var e=D(this._fragmentFiber);e!==null&&(e=P(e),e=pi(e).activeElement,e!==null&&O(this._fragmentFiber.child,!1,_x,e,void 0,void 0))};function _x(e,t){return e.tag===6?!1:(e=P(e),e===t||e.contains(t)?(t.blur(),!0):!1)}ht.prototype.observeUsing=function(e){this._observers===null&&(this._observers=new Set),this._observers.add(e),O(this._fragmentFiber.child,!1,Tx,e,void 0,void 0)};function Tx(e,t){return e.tag===6||(e=P(e),t.observe(e)),!1}ht.prototype.unobserveUsing=function(e){var t=this._observers;if(t!==null&&t.has(e)){t.delete(e),O(this._fragmentFiber.child,!1,Ex,e,void 0,void 0);for(var n=t=0;n<Ct.length;n++){var a=Ct[n];a.fragmentInstance===this&&a.observer===e?e.unobserve(a.instance):Ct[t++]=a}Ct.length=t}};function Ex(e,t){return e.tag===6||(e=P(e),t.unobserve(e)),!1}var Ct=[],Lc=!1;function wx(e,t,n){Ct.push({fragmentInstance:e,observer:t,instance:n}),Lc||(Lc=!0,Rx(function(){Lc=!1;var a=Ct;Ct=[];for(var l=0;l<a.length;l++){var o=a[l];o.observer.unobserve(o.instance)}}))}ht.prototype.getClientRects=function(){var e=[];return O(this._fragmentFiber.child,!1,jx,e,void 0,void 0),e};function jx(e,t){if(e.tag===6){e=e.stateNode;var n=e.ownerDocument.createRange();n.selectNodeContents(e),t.push.apply(t,n.getClientRects())}else e=P(e),t.push.apply(t,e.getClientRects());return!1}ht.prototype.getRootNode=function(e){var t=D(this._fragmentFiber);return t===null?this:P(t).getRootNode(e)},ht.prototype.compareDocumentPosition=function(e){var t=D(this._fragmentFiber);if(t===null)return Node.DOCUMENT_POSITION_DISCONNECTED;var n=[];O(this._fragmentFiber.child,!1,Rc,n,void 0,void 0);var a=P(t);if(n.length===0){if(n=a,ie(this._fragmentFiber)){e:{for(t=this._fragmentFiber.return;t!==null;){if(t.tag===4){t=t.stateNode.containerInfo;break e}if(t.tag===3||t.tag===5||t.tag===27)break;t=t.return}t=null}t!=null&&(n=t)}t=this._fragmentFiber;var l=a=n.compareDocumentPosition(e);return n===e?l=Node.DOCUMENT_POSITION_CONTAINS:a&Node.DOCUMENT_POSITION_CONTAINED_BY&&(n=K(t)[1],n===null?l=Node.DOCUMENT_POSITION_PRECEDING:(e=P(n).compareDocumentPosition(e),l=e===0||e&Node.DOCUMENT_POSITION_FOLLOWING?Node.DOCUMENT_POSITION_FOLLOWING:Node.DOCUMENT_POSITION_PRECEDING)),l|=Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC}t=P(n[0]),l=P(n[n.length-1]);var o=ie(this._fragmentFiber)?t.parentElement:a;if(o==null)return Node.DOCUMENT_POSITION_DISCONNECTED;a=o.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_CONTAINED_BY,o=o.compareDocumentPosition(l)&Node.DOCUMENT_POSITION_CONTAINED_BY;var r=t.compareDocumentPosition(e),u=l.compareDocumentPosition(e),m=r&Node.DOCUMENT_POSITION_CONTAINED_BY||u&Node.DOCUMENT_POSITION_CONTAINED_BY;return u=a&&o&&r&Node.DOCUMENT_POSITION_FOLLOWING&&u&Node.DOCUMENT_POSITION_PRECEDING,t=a&&t===e||o&&l===e||m||u?Node.DOCUMENT_POSITION_CONTAINED_BY:!a&&t===e||!o&&l===e?Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC:r,t&Node.DOCUMENT_POSITION_DISCONNECTED||t&Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC||Sx(t,this._fragmentFiber,n[0],n[n.length-1],e)?t:Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC};function Sx(e,t,n,a,l){var o=ea(l);if(e&Node.DOCUMENT_POSITION_CONTAINED_BY){if(n=!!o)e:{for(;o!==null;){if(o.tag===7&&(o===t||o.alternate===t)){n=!0;break e}o=o.return}n=!1}return n}if(e&Node.DOCUMENT_POSITION_CONTAINS){if(o===null)return o=l.ownerDocument,l===o||l===o.documentElement||l===o.body;e:{for(o=t,t=D(t);o!==null;){if(!(o.tag!==5&&o.tag!==3&&o.tag!==27||o!==t&&o.alternate!==t)){o=!0;break e}o=o.return}o=!1}return o}return e&Node.DOCUMENT_POSITION_PRECEDING?((t=!!o)&&!(t=o===n)&&(t=pt(n,o,vn),t===null?t=!1:(O(t,!0,xn,o,n),o=qe,qe=null,t=o!==null)),t):e&Node.DOCUMENT_POSITION_FOLLOWING?((t=!!o)&&!(t=o===a)&&(t=pt(a,o,vn),t===null?t=!1:(O(t,!0,yn,o,a),o=qe,jt=qe=null,t=o!==null)),t):!1}function lm(e,t){var n=e.ownerDocument.createRange();n.selectNodeContents(e),e=n.getBoundingClientRect(),window.scrollTo(window.scrollX+e.left,t?window.scrollY+e.top:window.scrollY+e.bottom-window.innerHeight)}ht.prototype.scrollIntoView=function(e){if(typeof e=="object")throw Error(f(566));var t=[];O(this._fragmentFiber.child,!1,Rc,t,void 0,void 0);var n=e!==!1;if(t.length===0){var a=K(this._fragmentFiber);if(a=n?a[1]||a[0]||D(this._fragmentFiber):a[0]||a[1],a===null)return;if(a.tag===6){e=P(a),lm(e,n);return}if(a=P(a),a.nodeType!==9){if(a.nodeType===11){n="host"in a?a.host:null,n!==null&&n.scrollIntoView(e);return}a.scrollIntoView(e)}}for(a=n?t.length-1:0;a!==(n?-1:t.length);){var l=t[a];l.tag===6?(l=P(l),lm(l,n)):P(l).scrollIntoView(e),a+=n?-1:1}};function zx(e,t){return e=P(e),im(e,t),!1}function im(e,t){e.reactFragments==null&&(e.reactFragments=new Set),e.reactFragments.add(t)}function om(e,t){var n=t._eventListeners;if(n!==null)for(var a=0;a<n.length;a++){var l=n[a];e.addEventListener(l.type,l.attachedListener,ml(l.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(o){for(var r=0,u=0;u<Ct.length;u++){var m=Ct[u];(m.fragmentInstance!==t||m.observer!==o||m.instance!==e)&&(Ct[r++]=m)}Ct.length=r,o.observe(e)}),im(e,t))}function Ax(e,t){var n=t._eventListeners;if(n!==null)for(var a=0;a<n.length;a++){var l=n[a];e.removeEventListener(l.type,l.attachedListener,ml(l.optionsOrUseCapture))}e.nodeType!==3&&(n=t._observers,n!==null&&n.forEach(function(o){typeof o.rootMargin=="string"?wx(t,o,e):o.unobserve(e)}),e.reactFragments!=null&&e.reactFragments.delete(t))}function Mc(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var n=t;switch(t=t.nextSibling,n.nodeName){case"HTML":case"HEAD":case"BODY":Mc(n),Vi(n);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(n.rel.toLowerCase()==="stylesheet")continue}e.removeChild(n)}}function Ox(e,t,n,a){for(;e.nodeType===1;){var l=n;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!a&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(a){if(!e[Rl])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(o=e.getAttribute("rel"),o==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(o!==l.rel||e.getAttribute("href")!==(l.href==null||l.href===""?null:l.href)||e.getAttribute("crossorigin")!==(l.crossOrigin==null?null:l.crossOrigin)||e.getAttribute("title")!==(l.title==null?null:l.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(o=e.getAttribute("src"),(o!==(l.src==null?null:l.src)||e.getAttribute("type")!==(l.type==null?null:l.type)||e.getAttribute("crossorigin")!==(l.crossOrigin==null?null:l.crossOrigin))&&o&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(t==="input"&&e.type==="hidden"){var o=l.name==null?null:""+l.name;if(l.type==="hidden"&&e.getAttribute("name")===o)return e}else return e;if(e=Et(e.nextSibling),e===null)break}return null}function Nx(e,t,n){if(t==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!n||(e=Et(e.nextSibling),e===null))return null;return e}function rm(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!t||(e=Et(e.nextSibling),e===null))return null;return e}function kc(e){return e.data==="$?"||e.data==="$~"}function Vc(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function Dx(e,t){var n=e.ownerDocument;if(e.data==="$~")e._reactRetry=t;else if(e.data!=="$?"||n.readyState!=="loading")t();else{var a=function(){t(),n.removeEventListener("DOMContentLoaded",a)};n.addEventListener("DOMContentLoaded",a),e._reactRetry=a}}function Et(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"||t==="F!"||t==="F")break;if(t==="/$"||t==="/&")return null}}return e}var Uc=null;function sm(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="/$"||n==="/&"){if(t===0)return Et(e.nextSibling);t--}else n!=="$"&&n!=="$!"&&n!=="$?"&&n!=="$~"&&n!=="&"||t++}e=e.nextSibling}return null}function cm(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="$"||n==="$!"||n==="$?"||n==="$~"||n==="&"){if(t===0)return e;t--}else n!=="/$"&&n!=="/&"||t++}e=e.previousSibling}return null}function Cx(e,t){function n(){a=!0}if(e.ownerDocument.activeElement===e)return!0;var a=!1;try{e.ownerDocument.addEventListener("focus",n,!0),(e.focus||HTMLElement.prototype.focus).call(e,t)}finally{e.ownerDocument.removeEventListener("focus",n,!0)}return a}function Rx(e){Ph(function(){Ph(function(t){return e(t)})})}function um(e,t,n){switch(t=pi(n),e){case"html":if(e=t.documentElement,!e)throw Error(f(452));return e;case"head":if(e=t.head,!e)throw Error(f(453));return e;case"body":if(e=t.body,!e)throw Error(f(454));return e;default:throw Error(f(451))}}function dm(e,t,n){for(var a in n){var l=n[a];n.hasOwnProperty(a)&&l!=null&&de(e,t,a,null,sx,l)}n.dangerouslySetInnerHTML!=null&&(e.textContent=""),e.onclick===Ut&&(e.onclick=null),Vi(e)}function Bc(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);Vi(e)}var wt=new Map,fm=new Set;function gi(e){if(typeof e.getRootNode=="function"){var t=e.getRootNode();if(t.nodeType===9||t.nodeType===11)return t}return e.nodeType===9?e:e.ownerDocument}var fn=oe.d;oe.d={f:Lx,r:Mx,D:kx,C:Vx,L:Ux,m:Bx,X:qx,S:Hx,M:Ix};function Lx(){var e=fn.f(),t=qo();return e||t}function Mx(e){var t=Ra(e);t!==null&&t.tag===5&&t.type==="form"?mf(t):fn.r(e)}var pl=typeof document>"u"?null:document;function hm(e,t,n){var a=pl;if(a&&typeof t=="string"&&t){var l=gt(t);l='link[rel="'+e+'"][href="'+l+'"]',typeof n=="string"&&(l+='[crossorigin="'+n+'"]'),fm.has(l)||(fm.add(l),e={rel:e,crossOrigin:n,href:t},a.querySelector(l)===null&&(t=a.createElement("link"),He(t,"link",e),Ne(t),a.head.appendChild(t)))}}function kx(e){fn.D(e),hm("dns-prefetch",e,null)}function Vx(e,t){fn.C(e,t),hm("preconnect",e,t)}function Ux(e,t,n){fn.L(e,t,n);var a=pl;if(a&&e&&t){var l='link[rel="preload"][as="'+gt(t)+'"]';t==="image"&&n&&n.imageSrcSet?(l+='[imagesrcset="'+gt(n.imageSrcSet)+'"]',typeof n.imageSizes=="string"&&(l+='[imagesizes="'+gt(n.imageSizes)+'"]')):l+='[href="'+gt(e)+'"]';var o=l;switch(t){case"style":o=gl(e);break;case"script":o=xl(e)}if(!(wt.has(o)||(e=te({rel:"preload",href:t==="image"&&n&&n.imageSrcSet?void 0:e,as:t},n),wt.set(o,e),a.querySelector(l)!==null||t==="style"&&a.querySelector(xi(o))||t==="script"&&a.querySelector(yi(o))))){var r=a.createElement("link");He(r,"link",e),t==="style"&&(r[ki]=!0,r.onload=r.onerror=function(){ju(r)}),Ne(r),a.head.appendChild(r)}}}function Bx(e,t){fn.m(e,t);var n=pl;if(n&&e){var a=t&&typeof t.as=="string"?t.as:"script",l='link[rel="modulepreload"][as="'+gt(a)+'"][href="'+gt(e)+'"]',o=l;switch(a){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":o=xl(e)}if(!wt.has(o)&&(e=te({rel:"modulepreload",href:e},t),wt.set(o,e),n.querySelector(l)===null)){switch(a){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(n.querySelector(yi(o)))return}a=n.createElement("link"),He(a,"link",e),Ne(a),n.head.appendChild(a)}}}function Hx(e,t,n){fn.S(e,t,n);var a=pl;if(a&&e){var l=La(a).hoistableStyles,o=gl(e);t=t||"default";var r=l.get(o);if(!r){var u={loading:0,preload:null};if(r=a.querySelector(xi(o)))u.loading=5;else{e=te({rel:"stylesheet",href:e,"data-precedence":t},n),(n=wt.get(o))&&Hc(e,n);var m=r=a.createElement("link");Ne(m),He(m,"link",e),m._p=new Promise(function(b,w){m.onload=b,m.onerror=w}),m.addEventListener("load",function(){u.loading|=1}),m.addEventListener("error",function(){u.loading|=2}),u.loading|=4,Ko(r,t,a)}r={type:"stylesheet",instance:r,count:1,state:u},l.set(o,r)}}}function qx(e,t){fn.X(e,t);var n=pl;if(n&&e){var a=La(n).hoistableScripts,l=xl(e),o=a.get(l);o||(o=n.querySelector(yi(l)),o||(e=te({src:e,async:!0},t),(t=wt.get(l))&&qc(e,t),o=n.createElement("script"),Ne(o),He(o,"link",e),n.head.appendChild(o)),o={type:"script",instance:o,count:1,state:null},a.set(l,o))}}function Ix(e,t){fn.M(e,t);var n=pl;if(n&&e){var a=La(n).hoistableScripts,l=xl(e),o=a.get(l);o||(o=n.querySelector(yi(l)),o||(e=te({src:e,async:!0,type:"module"},t),(t=wt.get(l))&&qc(e,t),o=n.createElement("script"),Ne(o),He(o,"link",e),n.head.appendChild(o)),o={type:"script",instance:o,count:1,state:null},a.set(l,o))}}function mm(e,t,n,a){var l=(l=Tn.current)?gi(l):null;if(!l)throw Error(f(446));switch(e){case"meta":case"title":return null;case"style":return typeof n.precedence=="string"&&typeof n.href=="string"?(n=gl(n.href),t=La(l).hoistableStyles,a=t.get(n),a||(a={type:"style",instance:null,count:0,state:null},t.set(n,a)),a):{type:"void",instance:null,count:0,state:null};case"link":if(n.rel==="stylesheet"&&typeof n.href=="string"&&typeof n.precedence=="string"){e=gl(n.href);var o=La(l).hoistableStyles,r=o.get(e);if(r||(l=l.ownerDocument||l,r={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},o.set(e,r),(o=l.querySelector(xi(e)))?o._p||(r.instance=o,r.state.loading=5):(o=wt.get(e),o||(o={rel:"preload",as:"style",href:n.href,crossOrigin:n.crossOrigin,integrity:n.integrity,media:n.media,hrefLang:n.hrefLang,referrerPolicy:n.referrerPolicy},wt.set(e,o)),Yx(l,e,o,r.state))),t&&a===null)throw Error(f(528,""));return r}if(t&&a!==null)throw Error(f(529,""));return null;case"script":return t=n.async,n=n.src,typeof n=="string"&&t&&typeof t!="function"&&typeof t!="symbol"?(n=xl(n),t=La(l).hoistableScripts,a=t.get(n),a||(a={type:"script",instance:null,count:0,state:null},t.set(n,a)),a):{type:"void",instance:null,count:0,state:null};default:throw Error(f(444,e))}}function gl(e){return'href="'+gt(e)+'"'}function xi(e){return'link[rel="stylesheet"]['+e+"]"}function pm(e){return te({},e,{"data-precedence":e.precedence,precedence:null})}function Yx(e,t,n,a){if(t=e.querySelector('link[rel="preload"][as="style"]['+t+"]")){if(t[ki]!==!0){a.loading=1;return}}else t=e.createElement("link"),t[ki]=!0,t.onload=t.onerror=ju.bind(null,t),He(t,"link",n),Ne(t),e.head.appendChild(t);a.preload=t,t.addEventListener("load",function(){return a.loading|=1}),t.addEventListener("error",function(){return a.loading|=2})}function xl(e){return'[src="'+gt(e)+'"]'}function yi(e){return"script[async]"+e}function gm(e,t,n){if(t.count++,t.instance===null)switch(t.type){case"style":var a=e.querySelector('style[data-href~="'+gt(n.href)+'"]');if(a)return t.instance=a,Ne(a),a;var l=te({},n,{"data-href":n.href,"data-precedence":n.precedence,href:null,precedence:null});return a=(e.ownerDocument||e).createElement("style"),Ne(a),He(a,"style",l),Ko(a,n.precedence,e),t.instance=a;case"stylesheet":l=gl(n.href);var o=e.querySelector(xi(l));if(o)return t.state.loading|=4,t.instance=o,Ne(o),o;a=pm(n),(l=wt.get(l))&&Hc(a,l),o=(e.ownerDocument||e).createElement("link"),Ne(o);var r=o;return r._p=new Promise(function(u,m){r.onload=u,r.onerror=m}),He(o,"link",a),t.state.loading|=4,Ko(o,n.precedence,e),t.instance=o;case"script":return o=xl(n.src),(l=e.querySelector(yi(o)))?(t.instance=l,Ne(l),l):(a=n,(l=wt.get(o))&&(a=te({},n),qc(a,l)),e=e.ownerDocument||e,l=e.createElement("script"),Ne(l),He(l,"link",a),e.head.appendChild(l),t.instance=l);case"void":return null;default:throw Error(f(443,t.type))}else t.type==="stylesheet"&&(t.state.loading&4)===0&&(a=t.instance,t.state.loading|=4,Ko(a,n.precedence,e));return t.instance}function Ko(e,t,n){for(var a=n.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),l=a.length?a[a.length-1]:null,o=l,r=0;r<a.length;r++){var u=a[r];if(u.dataset.precedence===t)o=u;else if(o!==l)break}o?o.parentNode.insertBefore(e,o.nextSibling):(t=n.nodeType===9?n.head:n,t.insertBefore(e,t.firstChild))}function Hc(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.title==null&&(e.title=t.title)}function qc(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.integrity==null&&(e.integrity=t.integrity)}var Po=null;function xm(e,t,n){if(Po===null){var a=new Map,l=Po=new Map;l.set(n,a)}else l=Po,a=l.get(n),a||(a=new Map,l.set(n,a));if(a.has(e))return a;for(a.set(e,null),n=n.getElementsByTagName(e),l=0;l<n.length;l++){var o=n[l];if(!(o[Rl]||o[Me]||e==="link"&&o.getAttribute("rel")==="stylesheet")&&o.namespaceURI!=="http://www.w3.org/2000/svg"){var r=o.getAttribute(t)||"";r=e+r;var u=a.get(r);u?u.push(o):a.set(r,[o])}}return a}function Ic(e,t,n){e=e.ownerDocument||e,e.head.insertBefore(n,t==="title"?e.querySelector("head > title"):null)}function Xx(e,t,n){if(n===1||t.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof t.precedence!="string"||typeof t.href!="string"||t.href==="")break;return!0;case"link":if(typeof t.rel!="string"||typeof t.href!="string"||t.href===""||t.onLoad||t.onError)break;return t.rel==="stylesheet"?(e=t.disabled,typeof t.precedence=="string"&&e==null):!0;case"script":if(t.async&&typeof t.async!="function"&&typeof t.async!="symbol"&&!t.onLoad&&!t.onError&&t.src&&typeof t.src=="string")return!0}return!1}function ym(e,t){return e==="img"&&t.src!=null&&t.src!==""&&t.onLoad==null&&t.loading!=="lazy"}function vm(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function bm(e){return(e.width||100)*(e.height||100)*(typeof devicePixelRatio=="number"?devicePixelRatio:1)*.25}function _m(e,t){typeof t.decode=="function"&&(e.imgCount++,t.complete||(e.imgBytes+=bm(t),e.suspenseyImages.push(t)),e=Zx.bind(e),t.decode().then(e,e))}function Gx(e,t,n,a){if(n.type==="stylesheet"&&(typeof a.media!="string"||matchMedia(a.media).matches!==!1)&&(n.state.loading&4)===0){if(n.instance===null){var l=gl(a.href),o=t.querySelector(xi(l));if(o){t=o._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(e.count++,e=vi.bind(e),t.then(e,e)),n.state.loading|=4,n.instance=o,Ne(o);return}o=t.ownerDocument||t,a=pm(a),(l=wt.get(l))&&Hc(a,l),o=o.createElement("link"),Ne(o);var r=o;r._p=new Promise(function(u,m){r.onload=u,r.onerror=m}),He(o,"link",a),n.instance=o}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(n,t),(t=n.state.preload)&&(n.state.loading&3)===0&&(e.count++,n=vi.bind(e),t.addEventListener("load",n),t.addEventListener("error",n))}}var Jo=0;function Qx(e,t){return e.stylesheets&&e.count===0&&Wo(e,e.stylesheets),0<e.count||0<e.imgCount?function(n){var a=setTimeout(function(){if(e.stylesheets&&Wo(e,e.stylesheets),e.unsuspend){var o=e.unsuspend;e.unsuspend=null,o()}},6e4+t);0<e.imgBytes&&Jo===0&&(Jo=62500*ux());var l=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&Wo(e,e.stylesheets),e.unsuspend)){var o=e.unsuspend;e.unsuspend=null,o()}},(e.imgBytes>Jo?50:800)+t);return e.unsuspend=n,function(){e.unsuspend=null,clearTimeout(a),clearTimeout(l)}}:null}function Tm(e){if(e.count===0&&(e.imgCount===0||!e.waitingForImages)){if(e.stylesheets)Wo(e,e.stylesheets);else if(e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}}}function vi(){this.count--,Tm(this)}function Zx(){this.imgCount--,Tm(this)}var Fo=null;function Wo(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,Fo=new Map,t.forEach(Kx,e),Fo=null,vi.call(e))}function Kx(e,t){if(!(t.state.loading&4)){var n=Fo.get(e);if(n)var a=n.get(null);else{n=new Map,Fo.set(e,n);for(var l=e.querySelectorAll("link[data-precedence],style[data-precedence]"),o=0;o<l.length;o++){var r=l[o];(r.nodeName==="LINK"||r.getAttribute("media")!=="not all")&&(n.set(r.dataset.precedence,r),a=r)}a&&n.set(null,a)}l=t.instance,r=l.getAttribute("data-precedence"),o=n.get(r)||a,o===a&&n.set(null,l),n.set(r,l),this.count++,a=vi.bind(this),l.addEventListener("load",a),l.addEventListener("error",a),o?o.parentNode.insertBefore(l,o.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(l,e.firstChild)),t.state.loading|=4}}var yl={$$typeof:Je,Provider:null,Consumer:null,_currentValue:Wn,_currentValue2:Wn,_threadCount:0};function Px(e,t,n,a,l,o,r,u,m){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Tr(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Tr(0),this.hiddenUpdates=Tr(null),this.identifierPrefix=a,this.onUncaughtError=l,this.onCaughtError=o,this.onRecoverableError=r,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=m,this.transitionTypes=null,this.incompleteTransitions=new Map}function Em(e,t,n,a,l,o,r,u,m,b,w,A){return e=new Px(e,t,n,r,m,b,w,A,u),t=1,o===!0&&(t|=24),o=We(3,null,null,t),e.current=o,o.stateNode=e,t=as(),t.refCount++,e.pooledCache=t,t.refCount++,o.memoizedState={element:a,isDehydrated:n,cache:t},rs(o),e}function wm(e){return e?(e=Xa,e):Xa}function jm(e,t,n,a,l,o){l=wm(l),a.context===null?a.context=l:a.pendingContext=l,a=Rn(t),a.payload={element:n},o=o===void 0?null:o,o!==null&&(a.callback=o),n=Ln(e,a,t),n!==null&&(nt(n,e,t),Jl(n,e,t))}function Sm(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function Yc(e,t){Sm(e,t),(e=e.alternate)&&Sm(e,t)}function zm(e){if(e.tag===13||e.tag===31){var t=la(e,67108864);t!==null&&nt(t,e,67108864),Yc(e,67108864)}}function Am(e){if(e.tag===13||e.tag===31){var t=ft();t=Er(t);var n=la(e,t);n!==null&&nt(n,e,t),Yc(e,t)}}var vl=!0;function Jx(e,t,n,a){var l=q.T;q.T=null;var o=oe.p;try{oe.p=2,Xc(e,t,n,a)}finally{oe.p=o,q.T=l}}function Fx(e,t,n,a){var l=q.T;q.T=null;var o=oe.p;try{oe.p=8,Xc(e,t,n,a)}finally{oe.p=o,q.T=l}}function Xc(e,t,n,a){if(vl){var l=Gc(a);if(l===null)jc(e,t,a,$o,n),Nm(e,a);else if($x(l,e,t,n,a))a.stopPropagation();else if(Nm(e,a),t&4&&-1<Wx.indexOf(e)){for(;l!==null;){var o=Ra(l);if(o!==null)switch(o.tag){case 3:if(o=o.stateNode,o.current.memoizedState.isDehydrated){var r=$n(o.pendingLanes);if(r!==0){var u=o;for(u.pendingLanes|=2,u.entangledLanes|=2;r;){var m=1<<31-it(r);u.entanglements[1]|=m,r&=~m}Kt(o),(re&6)===0&&(Uo=at()+500,fi(0))}}break;case 31:case 13:u=la(o,2),u!==null&&nt(u,o,2),qo(),Yc(o,2)}if(o=Gc(a),o===null&&jc(e,t,a,$o,n),o===l)break;l=o}l!==null&&a.stopPropagation()}else jc(e,t,a,null,n)}}function Gc(e){return e=Nr(e),Qc(e)}var $o=null;function Qc(e){if($o=null,e=ea(e),e!==null){var t=E(e);if(t===null)e=null;else{var n=t.tag;if(n===13){if(e=S(t),e!==null)return e;e=null}else if(n===31){if(e=C(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return $o=e,null}function Om(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"fullscreenerror":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"resize":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(u0()){case hu:return 2;case mu:return 8;case Di:case d0:return 32;case pu:return 268435456;default:return 32}default:return 32}}var Zc=!1,Qn=null,Zn=null,Kn=null,bi=new Map,_i=new Map,Pn=[],Wx="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function Nm(e,t){switch(e){case"focusin":case"focusout":Qn=null;break;case"dragenter":case"dragleave":Zn=null;break;case"mouseover":case"mouseout":Kn=null;break;case"pointerover":case"pointerout":bi.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":_i.delete(t.pointerId)}}function Ti(e,t,n,a,l,o){return e===null||e.nativeEvent!==o?(e={blockedOn:t,domEventName:n,eventSystemFlags:a,nativeEvent:o,targetContainers:[l]},t!==null&&(t=Ra(t),t!==null&&zm(t)),e):(e.eventSystemFlags|=a,t=e.targetContainers,l!==null&&t.indexOf(l)===-1&&t.push(l),e)}function $x(e,t,n,a,l){switch(t){case"focusin":return Qn=Ti(Qn,e,t,n,a,l),!0;case"dragenter":return Zn=Ti(Zn,e,t,n,a,l),!0;case"mouseover":return Kn=Ti(Kn,e,t,n,a,l),!0;case"pointerover":var o=l.pointerId;return bi.set(o,Ti(bi.get(o)||null,e,t,n,a,l)),!0;case"gotpointercapture":return o=l.pointerId,_i.set(o,Ti(_i.get(o)||null,e,t,n,a,l)),!0}return!1}function Dm(e){var t=ea(e.target);if(t!==null){var n=E(t);if(n!==null){if(t=n.tag,t===13){if(t=S(n),t!==null){e.blockedOn=t,Tu(e.priority,function(){Am(n)});return}}else if(t===31){if(t=C(n),t!==null){e.blockedOn=t,Tu(e.priority,function(){Am(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function er(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=Gc(e.nativeEvent);if(n===null){n=e.nativeEvent;var a=new n.constructor(n.type,n);Or=a,n.target.dispatchEvent(a),Or=null}else return t=Ra(n),t!==null&&zm(t),e.blockedOn=n,!1;t.shift()}return!0}function Cm(e,t,n){er(e)&&n.delete(t)}function ey(){Zc=!1,Qn!==null&&er(Qn)&&(Qn=null),Zn!==null&&er(Zn)&&(Zn=null),Kn!==null&&er(Kn)&&(Kn=null),bi.forEach(Cm),_i.forEach(Cm)}function tr(e,t){e.blockedOn===t&&(e.blockedOn=null,Zc||(Zc=!0,s.unstable_scheduleCallback(s.unstable_NormalPriority,ey)))}var nr=null;function Rm(e){nr!==e&&(nr=e,s.unstable_scheduleCallback(s.unstable_NormalPriority,function(){nr===e&&(nr=null);for(var t=0;t<e.length;t+=3){var n=e[t],a=e[t+1],l=e[t+2];if(typeof a!="function"){if(Qc(a||n)===null)continue;break}var o=Ra(n);o!==null&&(e.splice(t,3),t-=3,As(o,{pending:!0,data:l,method:n.method,action:a},a,l))}}))}function bl(e){function t(m){return tr(m,e)}Qn!==null&&tr(Qn,e),Zn!==null&&tr(Zn,e),Kn!==null&&tr(Kn,e),bi.forEach(t),_i.forEach(t);for(var n=0;n<Pn.length;n++){var a=Pn[n];a.blockedOn===e&&(a.blockedOn=null)}for(;0<Pn.length&&(n=Pn[0],n.blockedOn===null);)Dm(n),n.blockedOn===null&&Pn.shift();if(n=(e.ownerDocument||e).$$reactFormReplay,n!=null)for(a=0;a<n.length;a+=3){var l=n[a],o=n[a+1],r=l[Fe]||null;if(typeof o=="function")r||Rm(n);else if(r){var u=null;if(o&&o.hasAttribute("formAction")){if(l=o,r=o[Fe]||null)u=r.formAction;else if(Qc(l)!==null)continue}else u=r.action;typeof u=="function"?n[a+1]=u:(n.splice(a,3),a-=3),Rm(n)}}}function Lm(){function e(o){o.canIntercept&&o.info==="react-transition"&&o.intercept({handler:function(){return new Promise(function(r){return l=r})},focusReset:"manual",scroll:"manual"})}function t(){l!==null&&(l(),l=null),a||setTimeout(n,20)}function n(){if(!a&&!navigation.transition){var o=navigation.currentEntry;o&&o.url!=null&&navigation.navigate(o.url,{state:o.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var a=!1,l=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(n,100),function(){a=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),l!==null&&(l(),l=null)}}}function Kc(e){this._internalRoot=e}ar.prototype.render=Kc.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(f(409));var n=t.current,a=ft();jm(n,a,e,t,null,null)},ar.prototype.unmount=Kc.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;jm(e.current,2,null,e,null,null),qo(),t[Ca]=null}};function ar(e){this._internalRoot=e}ar.prototype.unstable_scheduleHydration=function(e){if(e){var t=_u();e={blockedOn:null,target:e,priority:t};for(var n=0;n<Pn.length&&t!==0&&t<Pn[n].priority;n++);Pn.splice(n,0,e),n===0&&Dm(e)}};var Mm=d.version;if(Mm!=="19.3.1")throw Error(f(527,Mm,"19.3.1"));oe.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(f(188)):(e=Object.keys(e).join(","),Error(f(268,e)));return e=N(t),e=e!==null?R(e):null,e=e===null?null:e.stateNode,e};var ty={bundleType:0,version:"19.3.1",rendererPackageName:"react-dom",currentDispatcherRef:q,reconcilerVersion:"19.3.1"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var lr=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!lr.isDisabled&&lr.supportsFiber)try{Nl=lr.inject(ty),lt=lr}catch{}}return Ei.createRoot=function(e,t){if(!y(e))throw Error(f(299));var n=!1,a="",l=wf,o=jf,r=Sf;return t!=null&&(t.unstable_strictMode===!0&&(n=!0),t.identifierPrefix!==void 0&&(a=t.identifierPrefix),t.onUncaughtError!==void 0&&(l=t.onUncaughtError),t.onCaughtError!==void 0&&(o=t.onCaughtError),t.onRecoverableError!==void 0&&(r=t.onRecoverableError)),t=Em(e,1,!1,null,null,n,a,null,l,o,r,Lm),e[Ca]=t.current,wc(e),new Kc(t)},Ei.hydrateRoot=function(e,t,n){if(!y(e))throw Error(f(299));var a=!1,l="",o=wf,r=jf,u=Sf,m=null;return n!=null&&(n.unstable_strictMode===!0&&(a=!0),n.identifierPrefix!==void 0&&(l=n.identifierPrefix),n.onUncaughtError!==void 0&&(o=n.onUncaughtError),n.onCaughtError!==void 0&&(r=n.onCaughtError),n.onRecoverableError!==void 0&&(u=n.onRecoverableError),n.formState!==void 0&&(m=n.formState)),t=Em(e,1,!0,t,n??null,a,l,m,o,r,u,Lm),t.context=wm(null),n=t.current,a=ft(),a=Er(a),l=Rn(a),l.callback=null,Ln(n,l,a),n=a,t.current.lanes=n,Cl(t,n),Kt(t),e[Ca]=t.current,wc(e),new ar(t)},Ei.version="19.3.1",Ei}var Bm;function hy(){if(Bm)return Pc.exports;Bm=1;function s(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(s)}catch(d){console.error(d)}}return s(),Pc.exports=fy(),Pc.exports}var my=hy();const py=ry(my),gy="modulepreload",xy=function(s){return"/"+s},Hm={},h=function(d,x,f){let y=Promise.resolve();if(x&&x.length>0){let M=function(N){return Promise.all(N.map(R=>Promise.resolve(R).then(O=>({status:"fulfilled",value:O}),O=>({status:"rejected",reason:O}))))};document.getElementsByTagName("link");const S=document.querySelector("meta[property=csp-nonce]"),C=S?.nonce||S?.getAttribute("nonce");y=M(x.map(N=>{if(N=xy(N),N in Hm)return;Hm[N]=!0;const R=N.endsWith(".css"),O=R?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${N}"]${O}`))return;const D=document.createElement("link");if(D.rel=R?"stylesheet":gy,R||(D.as="script"),D.crossOrigin="",D.href=N,C&&D.setAttribute("nonce",C),document.head.appendChild(D),R)return new Promise((ie,K)=>{D.addEventListener("load",ie),D.addEventListener("error",()=>K(new Error(`Unable to preload CSS for ${N}`)))})}))}function E(S){const C=new Event("vite:preloadError",{cancelable:!0});if(C.payload=S,window.dispatchEvent(C),!C.defaultPrevented)throw S}return y.then(S=>{for(const C of S||[])C.status==="rejected"&&E(C.reason);return d().catch(E)})},tp=window.location.origin,qm=tp;async function Q(s,{method:d="GET",body:x}={}){let f;try{f=await fetch(`${qm}${s}`,{method:d,credentials:"include",headers:x?{"Content-Type":"application/json"}:void 0,body:x?JSON.stringify(x):void 0})}catch{throw new Error(`Cannot reach the server at ${qm}. Is the backend running?`)}const y=await f.text();let E={};try{E=y?JSON.parse(y):{}}catch{E={message:y}}if(!f.ok){f.status===401&&!s.startsWith("/api/auth/")&&window.dispatchEvent(new Event("auth:expired"));const S=new Error(E.message||`Request failed (${f.status})`);throw S.status=f.status,S}return E}const wi=s=>({list:async()=>(await Q(s)).data||[],create:async d=>(await Q(s,{method:"POST",body:d})).data,update:async(d,x)=>(await Q(`${s}/${d}`,{method:"PUT",body:x})).data,remove:d=>Q(`${s}/${d}`,{method:"DELETE"})}),yy={news:wi("/api/news"),jobs:wi("/api/job-openings"),events:wi("/api/events"),whitepapers:wi("/api/whitepapers"),updates:wi("/api/latest-updates")},Wc=(s,d)=>{const x=s?.data||{},f=s?.accountType||x?.accountType||(x?.role==="candidate"?"candidate":null)||d;return{...x,accountType:f}},Si={register:s=>Q("/api/auth/register",{method:"POST",body:s}),registerCandidate:async s=>{const d=await Q("/api/auth/register-candidate",{method:"POST",body:s});return Wc(d,"candidate")},me:async()=>{const s=await Q("/api/auth/me");return Wc(s,null)},login:async s=>{const d=await Q("/api/auth/login",{method:"POST",body:s});return Wc(d,null)},logout:()=>Q("/api/auth/logout",{method:"POST"}),forgot:s=>Q("/api/auth/forgot-password",{method:"POST",body:{email:s}}),verifyOtp:(s,d)=>Q("/api/auth/verify-otp",{method:"POST",body:{email:s,otp:d}}),reset:s=>Q("/api/auth/reset-password",{method:"POST",body:s})},wl={profile:async()=>(await Q("/api/admin/profile")).data,list:async()=>(await Q("/api/admin")).data||[],update:async(s,d)=>(await Q(`/api/admin/${s}`,{method:"PUT",body:d})).data,changePassword:(s,d)=>Q(`/api/admin/${s}/password`,{method:"PUT",body:d}),toggleStatus:async s=>(await Q(`/api/admin/${s}/status`,{method:"PATCH"})).data,remove:s=>Q(`/api/admin/${s}`,{method:"DELETE"})},pn={published:async()=>(await Q("/api/blogs")).data||[],one:async s=>(await Q(`/api/blogs/${s}`)).data,mine:async()=>(await Q("/api/blogs/mine")).data||[],create:async s=>(await Q("/api/blogs",{method:"POST",body:s})).data,update:async(s,d)=>(await Q(`/api/blogs/mine/${s}`,{method:"PUT",body:d})).data,remove:s=>Q(`/api/blogs/mine/${s}`,{method:"DELETE"}),adminAll:async()=>(await Q("/api/blogs/admin/all")).data||[],adminCreate:async s=>(await Q("/api/blogs/admin",{method:"POST",body:s})).data,adminUpdate:async(s,d)=>(await Q(`/api/blogs/admin/${s}`,{method:"PUT",body:d})).data,adminRemove:s=>Q(`/api/blogs/admin/${s}`,{method:"DELETE"})},jl={create:async s=>(await Q("/api/interests",{method:"POST",body:s})).data,mine:async()=>(await Q("/api/interests/mine")).data||[],withdraw:s=>Q(`/api/interests/mine/${s}`,{method:"DELETE"}),adminAll:async()=>(await Q("/api/interests")).data||[],adminStatus:async(s,d)=>(await Q(`/api/interests/${s}/status`,{method:"PATCH",body:{status:d}})).data,adminRemove:s=>Q(`/api/interests/${s}`,{method:"DELETE"})},Jw={general:s=>Q("/api/general-enquiries",{method:"POST",body:s})},Fw={list:(s={})=>{const d=new URLSearchParams(Object.entries(s).filter(([,x])=>x!==""&&x!=null)).toString();return Q(`/api/queries${d?`?${d}`:""}`)},meta:async()=>(await Q("/api/queries/meta")).data,stats:async()=>(await Q("/api/queries/stats")).data,one:async(s,d)=>(await Q(`/api/queries/${s}/${d}`)).data,setStatus:async(s,d,x)=>(await Q(`/api/queries/${s}/${d}/status`,{method:"PATCH",body:{status:x}})).data,remove:(s,d)=>Q(`/api/queries/${s}/${d}`,{method:"DELETE"})},dr=["admin","profile"],Ww=(s=!0)=>Pt({queryKey:dr,queryFn:wl.profile,enabled:s,retry:!1,staleTime:300*1e3}),$w=()=>{const s=Xe();return Ge({mutationFn:Si.logout,onSettled:()=>s.clear()})},ej=()=>{const s=Xe();return Ge({mutationFn:({id:d,data:x})=>wl.update(d,x),onSuccess:()=>{s.invalidateQueries({queryKey:dr}),s.invalidateQueries({queryKey:["admins"]})}})},tj=()=>Ge({mutationFn:({id:s,data:d})=>wl.changePassword(s,d)}),nj=s=>Pt({queryKey:["admins"],queryFn:wl.list,enabled:s}),aj=()=>{const s=Xe();return Ge({mutationFn:wl.toggleStatus,onSuccess:()=>s.invalidateQueries({queryKey:["admins"]})})},lj=()=>{const s=Xe();return Ge({mutationFn:wl.remove,onSuccess:()=>s.invalidateQueries({queryKey:["admins"]})})},Tl=["me"],np=()=>Pt({queryKey:Tl,queryFn:async()=>{try{return await Si.me()}catch(s){if(s.status===401||s.status===403)return null;throw s}},retry:!1,staleTime:60*1e3}),ij=()=>{const s=Xe();return Ge({mutationFn:Si.login,onSuccess:d=>{s.setQueryData(Tl,d),d.accountType==="admin"&&s.setQueryData(dr,d),s.invalidateQueries({queryKey:Tl})}})},oj=()=>{const s=Xe();return Ge({mutationFn:Si.registerCandidate,onSuccess:d=>s.setQueryData(Tl,d)})},vy=()=>{const s=Xe();return Ge({mutationFn:Si.logout,onSettled:()=>{s.clear(),s.setQueryData(Tl,null)}})},rj=()=>Pt({queryKey:["blogs","published"],queryFn:pn.published}),sj=s=>Pt({queryKey:["blogs","one",s],queryFn:()=>pn.one(s),enabled:!!s}),cj=()=>Pt({queryKey:["jobs","public"],queryFn:yy.jobs.list}),uj=(s=!0)=>Pt({queryKey:["blogs","mine"],queryFn:pn.mine,enabled:s}),dj=(s=!0)=>Pt({queryKey:["interests","mine"],queryFn:jl.mine,enabled:s}),fj=()=>{const s=Xe();return Ge({mutationFn:({id:d,data:x})=>d?pn.update(d,x):pn.create(x),onSuccess:()=>s.invalidateQueries({queryKey:["blogs"]})})},hj=()=>{const s=Xe();return Ge({mutationFn:pn.remove,onSuccess:()=>s.invalidateQueries({queryKey:["blogs"]})})},mj=()=>{const s=Xe();return Ge({mutationFn:jl.create,onSuccess:()=>s.invalidateQueries({queryKey:["interests"]})})},pj=()=>{const s=Xe();return Ge({mutationFn:jl.withdraw,onSuccess:()=>s.invalidateQueries({queryKey:["interests"]})})},gj=()=>Pt({queryKey:["blogs","admin"],queryFn:pn.adminAll}),xj=()=>{const s=Xe();return Ge({mutationFn:({id:d,data:x})=>pn.adminUpdate(d,x),onSuccess:()=>s.invalidateQueries({queryKey:["blogs"]})})},yj=()=>{const s=Xe();return Ge({mutationFn:pn.adminRemove,onSuccess:()=>s.invalidateQueries({queryKey:["blogs"]})})},vj=()=>Pt({queryKey:["interests","admin"],queryFn:jl.adminAll}),bj=()=>{const s=Xe();return Ge({mutationFn:({id:d,status:x})=>jl.adminStatus(d,x),onSuccess:()=>s.invalidateQueries({queryKey:["interests"]})})},_j=()=>{const s=Xe();return Ge({mutationFn:jl.adminRemove,onSuccess:()=>s.invalidateQueries({queryKey:["interests"]})})};const by=s=>s?.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();function _y(s,d,x=[]){if(d==null)throw new Error("[lucide]: iconNode is required when icon name is used");return{name:by(s),size:24,node:d,...x.length>0?{aliases:x}:{}}}const Ty=s=>{let d="",x=!1;for(const f of s){if(f==="-"||f==="_"||f<=" "){x=d.length>0;continue}d.length===0?d+=f.toLowerCase():d+=x?f.toUpperCase():f,x=!1}return d};const Ey=s=>{const d=Ty(s);return d.charAt(0).toUpperCase()+d.slice(1)};const au=(...s)=>s.filter((d,x,f)=>!!d&&d.trim()!==""&&f.indexOf(d)===x).join(" ").trim();const Ta={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};function $c(s){return s!=null}function wy(s,d={}){const x=d.attributeNames??{},f=D=>x[D]??D,y=s.size??s.width??Ta.width,E=s.size??s.height??Ta.height,S=s.aliases?.filter(D=>typeof D=="string"&&D.trim()!=="").map(D=>`lucide-${D}`)??[],C=[...s.name?[`lucide-${s.name}`]:[],...S],M=d.className?.split(" ").filter(Boolean)??[],N=d.includeDefaultClasses===!1?au(...M):au("lucide",...C,...M),R=d.absoluteStrokeWidth?Number(d.strokeWidth??Ta["stroke-width"])*Number(s.size??s.width??Ta.width)/Number(d.size??d.width??Ta.width):d.strokeWidth??Ta["stroke-width"];return["svg",{...Object.entries(Ta).reduce((D,[ie,K])=>(D[f(ie)]=K,D),{}),..."color"in d&&d.color&&{[f("stroke")]:d.color},..."size"in d&&$c(d.size)&&{[f("width")]:d.size,[f("height")]:d.size},..."width"in d&&$c(d.width)&&{[f("width")]:d.width},..."height"in d&&$c(d.height)&&{[f("height")]:d.height},[f("stroke-width")]:R,...N&&{[f("class")]:N},[f("viewBox")]:`0 0 ${y} ${E}`,...d.hasA11yProp===!1?{[f("aria-hidden")]:"true"}:{},..."attributes"in d&&d.attributes},s.node.map(D=>{const[ie,K,ae]=D,P=d.nonScalingStroke?{[f("vector-effect")]:"non-scaling-stroke",...K}:K;return ae?[ie,P,ae]:[ie,P]})]}function jy(s,d={}){return wy(s,{...d,attributeNames:{...d.attributeNames,class:"className","stroke-width":"strokeWidth","stroke-linecap":"strokeLinecap","stroke-linejoin":"strokeLinejoin","vector-effect":"vectorEffect"}})}const Sy=s=>{for(const d in s)if(d.startsWith("aria-")||d==="role"||d==="title")return!0;return!1},zy=c.createContext({}),Ay=()=>c.useContext(zy),Oy=c.forwardRef(({color:s,size:d,width:x,height:f,strokeWidth:y,absoluteStrokeWidth:E,nonScalingStroke:S,className:C="",children:M,iconNode:N=[],icon:R={node:N,aliases:[],size:24},...O},D)=>{const{size:ie=24,strokeWidth:K=2,absoluteStrokeWidth:ae=!1,nonScalingStroke:P=!1,color:qe="currentColor",className:jt=""}=Ay()??{},xn=!!M||Sy(O),[yn,vn,pt=[]]=jy(R,{color:s??qe,width:x??d??ie,height:f??d??ie,strokeWidth:y??K,absoluteStrokeWidth:E??ae,nonScalingStroke:S??P,className:au(jt,C),hasA11yProp:xn,attributes:O});return c.createElement(yn,{ref:D,...vn},[...pt.map(([te,Sa])=>c.createElement(te,Sa)),...Array.isArray(M)?M:[M]])});function Z(s,d=[],x=[]){const f=typeof s=="string"?_y(s,d,x):s,y=c.forwardRef(({className:E,...S},C)=>c.createElement(Oy,{ref:C,icon:f,className:E,...S}));return f.name&&(y.displayName=Ey(f.name)),y}const ap={name:"arrow-left",size:24,node:[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]]};ap.node;const Ny=Z(ap);const lp={name:"arrow-right",size:24,node:[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]};lp.node;const mt=Z(lp);const ip={name:"briefcase",size:24,node:[["path",{d:"M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16",key:"jecpp"}],["rect",{width:"20",height:"14",x:"2",y:"6",rx:"2",key:"i6l2r4"}]]};ip.node;const Dy=Z(ip);const op={name:"building-complex",size:24,node:[["path",{d:"M10 12h4",key:"a56b0p"}],["path",{d:"M10 8h4",key:"1sr2af"}],["path",{d:"M14 21v-3a2 2 0 0 0-4 0v3",key:"1rgiei"}],["path",{d:"M6 10H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2",key:"secmi2"}],["path",{d:"M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16",key:"16ra0t"}]],aliases:["building-2"]};op.node;const rp=Z(op);const sp={name:"chevron-down",size:24,node:[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]};sp.node;const cp=Z(sp);const up={name:"chevron-right",size:24,node:[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]};up.node;const Cy=Z(up);const dp={name:"circle-check",size:24,node:[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m16 9-5.5 5.5L8 12",key:"xofnsj"}]],aliases:["check-circle-2"]};dp.node;const Ry=Z(dp);const fp={name:"circle-x",size:24,node:[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"m9 9 6 6",key:"z0biqf"}]],aliases:["x-circle"]};fp.node;const Ly=Z(fp);const hp={name:"compass",size:24,node:[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z",key:"9ktpf1"}]]};hp.node;const My=Z(hp);const mp={name:"credit-card",size:24,node:[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}],["path",{d:"M6 14h2",key:"mk7k0u"}]]};mp.node;const ky=Z(mp);const pp={name:"factory",size:24,node:[["path",{d:"M12 16h.01",key:"1drbdi"}],["path",{d:"M16 16h.01",key:"1f9h7w"}],["path",{d:"M3 19a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.5a.5.5 0 0 0-.769-.422l-4.462 2.844A.5.5 0 0 1 15 10.5v-2a.5.5 0 0 0-.769-.422L9.77 10.922A.5.5 0 0 1 9 10.5V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2z",key:"1iv0i2"}],["path",{d:"M8 16h.01",key:"18s6g9"}]]};pp.node;const Vy=Z(pp);const gp={name:"file-text",size:24,node:[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]]};gp.node;const Uy=Z(gp);const xp={name:"graduation-cap",size:24,node:[["path",{d:"M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",key:"j76jl0"}],["path",{d:"M22 10v6",key:"1lu8f3"}],["path",{d:"M6 12.5V16a6 3 0 0 0 12 0v-3.5",key:"1r8lef"}]]};xp.node;const By=Z(xp);const yp={name:"handshake",size:24,node:[["path",{d:"m11 17 2 2a1 1 0 1 0 3-3",key:"efffak"}],["path",{d:"m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4",key:"9pr0kb"}],["path",{d:"m21 3 1 11h-2",key:"1tisrp"}],["path",{d:"M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3",key:"1uvwmv"}],["path",{d:"M3 4h8",key:"1ep09j"}]]};yp.node;const Hy=Z(yp);const vp={name:"heart-pulse",size:24,node:[["path",{d:"M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",key:"mvr1a0"}],["path",{d:"M3.22 13H9.5l.5-1 2 4.5 2-7 1.5 3.5h5.27",key:"auskq0"}]]};vp.node;const qy=Z(vp);const bp={name:"heart",size:24,node:[["path",{d:"M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",key:"mvr1a0"}]]};bp.node;const Iy=Z(bp);const _p={name:"house",size:24,node:[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",key:"5wwlr5"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"r6nss1"}]],aliases:["home"]};_p.node;const Yy=Z(_p);const Tp={name:"landmark",size:24,node:[["path",{d:"M10 18v-7",key:"wt116b"}],["path",{d:"M11.119 2.205a2 2 0 0 1 1.762 0l7.84 3.846A.5.5 0 0 1 20.5 7h-17a.5.5 0 0 1-.22-.949z",key:"yxxwt6"}],["path",{d:"M14 18v-7",key:"vav6t3"}],["path",{d:"M18 18v-7",key:"aexdmj"}],["path",{d:"M3 22h18",key:"8prr45"}],["path",{d:"M6 18v-7",key:"1ivflk"}]]};Tp.node;const Xy=Z(Tp);const Ep={name:"layout-grid",size:24,node:[["rect",{width:"7",height:"7",x:"3",y:"3",rx:"1",key:"1g98yp"}],["rect",{width:"7",height:"7",x:"14",y:"3",rx:"1",key:"6d4xhi"}],["rect",{width:"7",height:"7",x:"14",y:"14",rx:"1",key:"nxv5o0"}],["rect",{width:"7",height:"7",x:"3",y:"14",rx:"1",key:"1bb6yr"}]]};Ep.node;const Gy=Z(Ep);const wp={name:"lightbulb",size:24,node:[["path",{d:"M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",key:"1gvzjb"}],["path",{d:"M9 18h6",key:"x1upvd"}],["path",{d:"M10 22h4",key:"ceow96"}]]};wp.node;const Qy=Z(wp);const jp={name:"loader-circle",size:24,node:[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],aliases:["loader-2"]};jp.node;const Zy=Z(jp);const Sp={name:"lock",size:24,node:[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 10 0v4",key:"fwvmzm"}]]};Sp.node;const Ky=Z(Sp);const zp={name:"log-out",size:24,node:[["path",{d:"m16 17 5-5-5-5",key:"1bji2h"}],["path",{d:"M21 12H9",key:"dn1m92"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}]]};zp.node;const Py=Z(zp);const Ap={name:"message-circle",size:24,node:[["path",{d:"M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",key:"1sd12s"}]]};Ap.node;const Jy=Z(Ap);const Op={name:"monitor",size:24,node:[["rect",{width:"20",height:"14",x:"2",y:"3",rx:"2",key:"48i651"}],["line",{x1:"8",x2:"16",y1:"21",y2:"21",key:"1svkeh"}],["line",{x1:"12",x2:"12",y1:"17",y2:"21",key:"vw1qmm"}]]};Op.node;const Fy=Z(Op);const Np={name:"newspaper",size:24,node:[["path",{d:"M15 18h-5",key:"95g1m2"}],["path",{d:"M18 14h-8",key:"sponae"}],["path",{d:"M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-4 0v-9a2 2 0 0 1 2-2h2",key:"39pd36"}],["rect",{width:"8",height:"4",x:"10",y:"6",rx:"1",key:"aywv1n"}]]};Np.node;const Dp=Z(Np);const Cp={name:"package",size:24,node:[["path",{d:"M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z",key:"1a0edw"}],["path",{d:"M12 22V12",key:"d0xqtd"}],["polyline",{points:"3.29 7 12 12 20.71 7",key:"ousv84"}],["path",{d:"m7.5 4.27 9 5.15",key:"1c824w"}]]};Cp.node;const Wy=Z(Cp);const Rp={name:"radio-tower",size:24,node:[["path",{d:"M4.9 16.1C1 12.2 1 5.8 4.9 1.9",key:"s0qx1y"}],["path",{d:"M7.8 4.7a6.14 6.14 0 0 0-.8 7.5",key:"1idnkw"}],["circle",{cx:"12",cy:"9",r:"2",key:"1092wv"}],["path",{d:"M16.2 4.8c2 2 2.26 5.11.8 7.47",key:"ojru2q"}],["path",{d:"M19.1 1.9a9.96 9.96 0 0 1 0 14.1",key:"rhi7fg"}],["path",{d:"M9.5 18h5",key:"mfy3pd"}],["path",{d:"m8 22 4-11 4 11",key:"25yftu"}]]};Rp.node;const $y=Z(Rp);const Lp={name:"refresh-cw",size:24,node:[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"v9h5vc"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"3uifl3"}],["path",{d:"M8 16H3v5",key:"1cv678"}]]};Lp.node;const e1=Z(Lp);const Mp={name:"search",size:24,node:[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]]};Mp.node;const t1=Z(Mp);const kp={name:"shield-check",size:24,node:[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]};kp.node;const n1=Z(kp);const Vp={name:"shopping-cart",size:24,node:[["path",{d:"m2.05 2.05 1.099-.028a1 1 0 0 1 1.008.815l2.69 14.347A1 1 0 0 0 7.83 18H18",key:"uebgi3"}],["path",{d:"M4.563 5h16.435a1 1 0 0 1 .981 1.204l-1.026 6.226A2 2 0 0 1 18.962 14H6.25",key:"1j7c9p"}],["circle",{cx:"18",cy:"20",r:"2",key:"t9985n"}],["circle",{cx:"8",cy:"20",r:"2",key:"ckkr5m"}]]};Vp.node;const a1=Z(Vp);const Up={name:"trending-up",size:24,node:[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]]};Up.node;const l1=Z(Up);const Bp={name:"triangle-exclamation-point",size:24,node:[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]],aliases:["alert-triangle","triangle-alert"]};Bp.node;const Hp=Z(Bp);const qp={name:"truck",size:24,node:[["path",{d:"M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2",key:"wrbu53"}],["path",{d:"M15 18H9",key:"1lyqi6"}],["path",{d:"M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14",key:"lysw3i"}],["circle",{cx:"17",cy:"18",r:"2",key:"332jqn"}],["circle",{cx:"7",cy:"18",r:"2",key:"19iecd"}]]};qp.node;const i1=Z(qp);const Ip={name:"user-plus",size:24,node:[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["line",{x1:"19",x2:"19",y1:"8",y2:"14",key:"1bvyxn"}],["line",{x1:"22",x2:"16",y1:"11",y2:"11",key:"1shjgl"}]]};Ip.node;const o1=Z(Ip);const Yp={name:"user-round",size:24,node:[["circle",{cx:"12",cy:"8",r:"5",key:"1hypcn"}],["path",{d:"M20 21a8 8 0 0 0-16 0",key:"rfgkzh"}]],aliases:["user-2"]};Yp.node;const r1=Z(Yp);const Xp={name:"users",size:24,node:[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]]};Xp.node;const cu=Z(Xp);const Gp={name:"wallet",size:24,node:[["path",{d:"M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1",key:"18etb6"}],["path",{d:"M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4",key:"xoc0q4"}]]};Gp.node;const s1=Z(Gp);const Qp={name:"x",size:24,node:[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]};Qp.node;const fr=Z(Qp);const Zp={name:"zap",size:24,node:[["path",{d:"M15.914 4a1.5 1.5 0 00-2.474-1.561l-9 9A1.5 1.5 0 005.5 14h4.002a.5.5 0 01.471.666L8.086 20a1.5 1.5 0 002.475 1.56l9-9A1.5 1.5 0 0018.5 10h-3.997a.5.5 0 01-.472-.667z",key:"1v7up4"}]]};Zp.node;const Kp=Z(Zp),c1="#780042",u1=2e3,d1=2100,Pp=c.createContext(()=>{}),Tj=()=>c.useContext(Pp);function f1({children:s}){const[d,x]=c.useState([]),f=c.useCallback((y,E="success")=>{const S=Date.now()+Math.random();x(C=>[...C,{id:S,message:y,type:E}]),setTimeout(()=>x(C=>C.filter(M=>M.id!==S)),4e3)},[]);return i.jsxs(Pp.Provider,{value:f,children:[s,i.jsx("div",{style:{zIndex:d1},className:"pointer-events-none fixed inset-x-4 bottom-4 flex flex-col items-stretch gap-2 sm:left-auto sm:right-5 sm:w-96",children:d.map(y=>i.jsxs("div",{role:"status",className:`pointer-events-auto flex items-start gap-3 rounded-xl border bg-white px-4 py-3 text-sm shadow-[0_12px_32px_-8px_rgba(0,0,0,0.25)] ${y.type==="error"?"border-red-200 text-red-700":"border-emerald-200 text-emerald-700"}`,children:[y.type==="error"?i.jsx(Ly,{size:18,className:"mt-0.5 shrink-0"}):i.jsx(Ry,{size:18,className:"mt-0.5 shrink-0"}),i.jsx("span",{className:"leading-snug",children:y.message})]},y.id))})]})}const Jp=({className:s=""})=>i.jsx(Zy,{className:`animate-spin ${s}`,size:18}),h1=()=>i.jsxs("div",{className:"flex items-center justify-center gap-2 py-24 text-sm text-stone-400",children:[i.jsx(Jp,{})," Loading…"]}),Ej=({error:s,onRetry:d})=>i.jsxs("div",{className:"flex items-center justify-between gap-3 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700",children:[i.jsxs("span",{className:"flex items-center gap-2",children:[i.jsx(Hp,{size:16,className:"shrink-0"}),s?.message||"Something went wrong"]}),d&&i.jsx("button",{onClick:d,className:"shrink-0 rounded-lg bg-white px-3 py-1 font-medium text-red-700 ring-1 ring-red-200 hover:bg-red-100",children:"Retry"})]}),Im={green:"bg-emerald-50 text-emerald-700 ring-emerald-200",amber:"bg-amber-50 text-amber-700 ring-amber-200",stone:"bg-stone-100 text-stone-600 ring-stone-200",blue:"bg-blue-50 text-blue-700 ring-blue-200",red:"bg-red-50 text-red-700 ring-red-200"},m1=({tone:s="stone",children:d})=>i.jsx("span",{className:`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium whitespace-nowrap ring-1 ring-inset ${Im[s]||Im.stone}`,children:d}),p1={published:"green",Published:"green",active:"green","Active / Open":"green",upcoming:"blue",draft:"stone",Draft:"stone","Draft / Unlisted":"stone",inactive:"red",past:"stone","Closing Soon":"amber"},wj=({value:s})=>s?i.jsx(m1,{tone:p1[s]||"stone",children:s}):i.jsx("span",{className:"text-stone-400",children:"—"}),Ym=({variant:s="primary",loading:d,className:x="",children:f,...y})=>{const E=s==="primary"?"text-white shadow-sm hover:brightness-110 active:brightness-95":s==="danger"?"bg-red-600 text-white shadow-sm hover:bg-red-700":"bg-white text-stone-700 ring-1 ring-inset ring-stone-300 hover:bg-stone-50";return i.jsxs("button",{...y,disabled:d||y.disabled,style:s==="primary"?{backgroundColor:c1}:void 0,className:`inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition focus:outline-none focus-visible:ring-2 focus-visible:ring-[#780042]/40 disabled:cursor-not-allowed disabled:opacity-60 ${E} ${x}`,children:[d&&i.jsx(Jp,{})," ",f]})};function g1({title:s,onClose:d,children:x,wide:f}){return c.useEffect(()=>{const y=document.body.style.overflow;document.body.style.overflow="hidden";const E=S=>S.key==="Escape"&&d?.();return window.addEventListener("keydown",E),()=>{document.body.style.overflow=y,window.removeEventListener("keydown",E)}},[d]),$m.createPortal(i.jsx("div",{style:{zIndex:u1},className:"fixed inset-0 flex items-end justify-center bg-stone-950/55 p-0 backdrop-blur-sm sm:items-center sm:p-6",onMouseDown:y=>y.target===y.currentTarget&&d?.(),children:i.jsxs("div",{role:"dialog","aria-modal":"true","aria-label":s,className:`flex max-h-[92dvh] w-full flex-col overflow-hidden rounded-t-2xl bg-white shadow-2xl sm:max-h-[88dvh] sm:rounded-2xl ${f?"sm:max-w-3xl":"sm:max-w-md"}`,children:[i.jsxs("div",{className:"flex shrink-0 items-center justify-between gap-4 border-b border-stone-200 bg-white px-5 py-4",children:[i.jsx("h2",{className:"truncate text-base font-semibold text-stone-900",children:s}),i.jsx("button",{onClick:d,"aria-label":"Close",className:"rounded-lg p-1.5 text-stone-500 transition hover:bg-stone-100 hover:text-stone-800",children:i.jsx(fr,{size:18})})]}),i.jsx("div",{className:"min-h-0 flex-1 overflow-y-auto overscroll-contain",children:x})]})}),document.body)}function jj({title:s,message:d,confirmLabel:x="Delete",loading:f,onConfirm:y,onCancel:E}){return i.jsx(g1,{title:s,onClose:E,children:i.jsxs("div",{className:"p-5",children:[i.jsxs("div",{className:"flex gap-3",children:[i.jsx("span",{className:"flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-50 text-red-600",children:i.jsx(Hp,{size:18})}),i.jsx("p",{className:"pt-1 text-sm leading-6 text-stone-600",children:d})]}),i.jsxs("div",{className:"mt-6 flex justify-end gap-2",children:[i.jsx(Ym,{variant:"ghost",onClick:E,children:"Cancel"}),i.jsx(Ym,{variant:"danger",loading:f,onClick:y,children:x})]})]})})}const x1=s=>s.accountType==="candidate"?"candidate":s.role==="superadmin"?"superadmin":"admin",y1=s=>s.accountType==="candidate"?"/candidate":"/admin-dashboard";function lu({allowedRoles:s,redirectTo:d="/signin"}){const x=gn(),f=Xe(),{data:y,isLoading:E,isError:S,refetch:C}=np();if(c.useEffect(()=>{const R=()=>{f.setQueryData(Tl,null),f.removeQueries({queryKey:dr})};return window.addEventListener("auth:expired",R),()=>window.removeEventListener("auth:expired",R)},[f]),E)return i.jsx(h1,{});if(S)return i.jsxs("div",{className:"min-h-screen flex flex-col items-center justify-center gap-3 text-center px-4",children:[i.jsx("p",{className:"text-stone-700",children:"Could not verify your session. Please check your connection."}),i.jsx("button",{type:"button",onClick:()=>C(),className:"rounded-lg bg-stone-900 px-4 py-2 text-sm text-white",children:"Try again"})]});if(!y)return i.jsx(ja,{to:d,replace:!0,state:{from:x}});const M=x1(y);return!s||s.includes(M)||M==="superadmin"&&s.includes("admin")?i.jsx(ep,{}):i.jsx(ja,{to:y1(y),replace:!0})}const Xm=c.lazy(()=>h(()=>import("./AdminLayout-Bm_4SjDw.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10]))),v1=c.lazy(()=>h(()=>import("./Overview-DzxM7lnW.js"),__vite__mapDeps([11,1,2,3,4,12,5,6,7,13]))),b1=c.lazy(()=>h(()=>import("./Account-CEcObHXa.js"),__vite__mapDeps([14,1,2,12]))),_1=c.lazy(()=>h(()=>import("./Admins-CaaqJPke.js"),__vite__mapDeps([15,1,2,12,16]))),T1=c.lazy(()=>h(()=>import("./Login-DCIVEgh2.js"),__vite__mapDeps([17,1,2,18,19]))),E1=c.lazy(()=>h(()=>import("./Signup-DsDANmpo.js"),__vite__mapDeps([20,1,2,18,19]))),w1=c.lazy(()=>h(()=>import("./ForgotPassword-CsuuI0OS.js"),__vite__mapDeps([21,1,2]))),j1=c.lazy(()=>h(()=>import("./CandidateBlogs-BbSnZ5Nn.js"),__vite__mapDeps([22,1,2,12,23,16]))),S1=c.lazy(()=>h(()=>import("./CandidateInterests-MBIVOJlD.js"),__vite__mapDeps([24,1,2,12,16]))),z1=c.lazy(()=>h(()=>import("./ContentPages-CTvWXHOp.js"),__vite__mapDeps([25,1,2,3,26,27,16,12])).then(s=>({default:s.EventsPage}))),A1=c.lazy(()=>h(()=>import("./ContentPages-CTvWXHOp.js"),__vite__mapDeps([25,1,2,3,26,27,16,12])).then(s=>({default:s.JobsPage}))),O1=c.lazy(()=>h(()=>import("./ContentPages-CTvWXHOp.js"),__vite__mapDeps([25,1,2,3,26,27,16,12])).then(s=>({default:s.NewsPage}))),N1=c.lazy(()=>h(()=>import("./ContentPages-CTvWXHOp.js"),__vite__mapDeps([25,1,2,3,26,27,16,12])).then(s=>({default:s.UpdatesPage}))),D1=c.lazy(()=>h(()=>import("./ContentPages-CTvWXHOp.js"),__vite__mapDeps([25,1,2,3,26,27,16,12])).then(s=>({default:s.WhitepapersPage}))),C1=c.lazy(()=>h(()=>import("./Queries-OYz9cZ2x.js"),__vite__mapDeps([28,1,2,12,4,29,19,16,30,31]))),R1=i.jsxs(i.Fragment,{children:[i.jsx(j,{path:"/admin-login",element:i.jsx(T1,{})}),i.jsx(j,{path:"/admin-signup",element:i.jsx(E1,{})}),i.jsx(j,{path:"/admin-forgot-password",element:i.jsx(w1,{})}),i.jsx(j,{path:"/admin-verify-otp",element:i.jsx(ja,{to:"/admin-forgot-password",replace:!0})}),i.jsx(j,{path:"/admin-reset-password",element:i.jsx(ja,{to:"/admin-forgot-password",replace:!0})}),i.jsx(j,{element:i.jsx(lu,{allowedRoles:["admin"]}),children:i.jsxs(j,{element:i.jsx(Xm,{}),children:[i.jsx(j,{path:"/admin-dashboard",element:i.jsx(v1,{})}),i.jsx(j,{path:"/news-insights",element:i.jsx(O1,{})}),i.jsx(j,{path:"/job-openings",element:i.jsx(A1,{})}),i.jsx(j,{path:"/events",element:i.jsx(z1,{})}),i.jsx(j,{path:"/whitepapers",element:i.jsx(D1,{})}),i.jsx(j,{path:"/latest-updates",element:i.jsx(N1,{})}),i.jsx(j,{path:"/candidate-blogs",element:i.jsx(j1,{})}),i.jsx(j,{path:"/candidate-interests",element:i.jsx(S1,{})}),i.jsx(j,{path:"/admin-queries",element:i.jsx(C1,{})}),i.jsx(j,{path:"/account",element:i.jsx(b1,{})})]})}),i.jsx(j,{element:i.jsx(lu,{allowedRoles:["superadmin"]}),children:i.jsx(j,{element:i.jsx(Xm,{}),children:i.jsx(j,{path:"/admin-accounts",element:i.jsx(_1,{})})})})]});function L1(){const s=gn(),d=El(),[x,f]=c.useState(!1),y=c.useRef(null);if(c.useEffect(()=>{const C=s.pathname.toLowerCase();if(C.startsWith("/admin")||C==="/signin"||C==="/signup"||C==="/login"||C==="/candidate"){f(!1);return}let M=!1;const N=async()=>{try{const D=await fetch(`${tp}/api/auth/me`,{credentials:"include"});return D.ok?(await D.json()).accountType==="candidate":!1}catch(O){return console.error("Auth check failed:",O),!1}},R=async O=>{const D=O.target.closest('input:not([type="button"]):not([type="submit"]), textarea, select, [contenteditable="true"]');if(!D||!document.contains(D)||!D.hasAttribute("data-on-auth-guard"))return;const ie=await N();M||ie||(O.preventDefault(),D.blur(),f(!0))};return document.addEventListener("focusin",R,!0),()=>{M=!0,document.removeEventListener("focusin",R,!0)}},[s.pathname]),c.useEffect(()=>{if(!x)return;const C=N=>{N.key==="Escape"&&f(!1)};document.addEventListener("keydown",C);const M=document.body.style.overflow;return document.body.style.overflow="hidden",y.current?.focus(),()=>{document.removeEventListener("keydown",C),document.body.style.overflow=M}},[x]),!x)return null;const E={pathname:s.pathname,search:s.search,hash:s.hash},S=C=>d(C,{state:{from:E}});return i.jsx("div",{className:"auth-prompt-overlay fixed inset-0 z-[99999] flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm",onMouseDown:C=>{C.target===C.currentTarget&&f(!1)},children:i.jsxs("div",{role:"dialog","aria-modal":"true","aria-labelledby":"auth-prompt-title","aria-describedby":"auth-prompt-desc",className:"auth-prompt-card relative w-full max-w-md rounded-2xl bg-white px-7 pb-7 pt-9 text-center shadow-2xl ring-1 ring-black/5",children:[i.jsx("button",{type:"button",onClick:()=>f(!1),"aria-label":"Close",className:"absolute right-3 top-3 rounded-full p-2 text-stone-400 transition hover:bg-stone-100 hover:text-stone-700",children:i.jsx(fr,{size:18})}),i.jsx("div",{className:"mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-[#780042]/10",children:i.jsx("div",{className:"flex h-11 w-11 items-center justify-center rounded-full bg-[#780042] text-white shadow-md shadow-[#780042]/30",children:i.jsx(Ky,{size:20,strokeWidth:2.2})})}),i.jsx("h2",{id:"auth-prompt-title",className:"text-2xl font-semibold tracking-tight text-[#1b1b2a]",children:"Sign in to continue"}),i.jsx("p",{id:"auth-prompt-desc",className:"mx-auto mt-2 max-w-xs text-[15px] leading-relaxed text-stone-500",children:"Please sign in or create a free account before submitting a query, so our team can get back to you."}),i.jsxs("div",{className:"mt-7 flex flex-col gap-3",children:[i.jsx("button",{ref:y,type:"button",onClick:()=>S("/signin"),className:"w-full rounded-xl bg-[#780042] px-5 py-3 text-[15px] font-semibold text-white shadow-sm transition hover:bg-[#5e0034] focus:outline-none focus-visible:ring-4 focus-visible:ring-[#780042]/30",children:"Sign In"}),i.jsx("button",{type:"button",onClick:()=>S("/signup"),className:"w-full rounded-xl border border-[#780042] bg-white px-5 py-3 text-[15px] font-semibold text-[#780042] transition hover:bg-[#780042]/5 focus:outline-none focus-visible:ring-4 focus-visible:ring-[#780042]/20",children:"Create Account"})]}),i.jsx("button",{type:"button",onClick:()=>f(!1),className:"mt-4 text-sm font-medium text-stone-400 transition hover:text-stone-700",children:"Maybe later"})]})})}const Gm="Get your 14 days free trial now!",M1="/torchx-talent-popup.webp",k1="https://torchxsuite.com/talent/",V1="https://wa.me/917078377916",U1="Chat Now",B1=0,Fp="torchx_talent_popup_last_closed",cr="support@torchxsuite.com",Wp="Support request - TorchX Talent",$p=`Hello TorchX Team,

`,e0=`mailto:${cr}?subject=${encodeURIComponent(Wp)}&body=${encodeURIComponent($p)}`,H1="+917454098820",q1="gmail",I1=`https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(cr)}&su=${encodeURIComponent(Wp)}&body=${encodeURIComponent($p)}`,Y1=30,X1=800,G1=["/signin","/signup","/talk-to-expert"],Q1=Y1*60*1e3;let iu=0;function Z1(){let s=iu;try{s=Math.max(s,Number(localStorage.getItem(Fp)||0))}catch{}return Math.max(0,s+Q1-Date.now())}function ji(){iu=Date.now();try{localStorage.setItem(Fp,String(iu))}catch{}}function t0(){return typeof navigator>"u"?!1:/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)}function K1(s){if(ji(),t0()||q1==="mailto")return;s.preventDefault();const d=I1;window.open(d,"_blank","noopener,noreferrer")||(window.location.href=e0)}function P1(){const{pathname:s}=gn(),[d,x]=c.useState(!1),f=c.useRef(null),y=c.useRef(!1),E=G1.includes(s.toLowerCase()),S=t0();c.useEffect(()=>{if(E||d)return;const M=Math.max(B1,Z1()),N=setTimeout(()=>{y.current=!0,x(!0)},M);return()=>clearTimeout(N)},[E,d]);const C=()=>{ji(),x(!1)};return c.useEffect(()=>{if(!d)return;const M=R=>{R.key==="Escape"&&C()};document.addEventListener("keydown",M);const N=document.body.style.overflow;return document.body.style.overflow="hidden",f.current?.focus(),()=>{document.removeEventListener("keydown",M),document.body.style.overflow=N}},[d]),!d||E?null:i.jsxs("div",{className:"promo-backdrop",onClick:C,role:"dialog","aria-modal":"true","aria-label":Gm,children:[i.jsxs("div",{className:"promo-box",style:{"--popup-max":`${X1}px`},onClick:M=>M.stopPropagation(),children:[i.jsxs("div",{className:"promo-header",children:[i.jsx("h2",{className:"promo-title",children:Gm}),i.jsx("button",{ref:f,type:"button",className:"promo-close",onClick:C,"aria-label":"Close pop-up",children:i.jsx(fr,{size:18,strokeWidth:2.4})})]}),i.jsx("div",{className:"promo-body",children:i.jsxs("div",{className:"promo-poster",children:[i.jsx("img",{loading:"lazy",decoding:"async",src:M1,alt:"TorchX Talent: HR management, free forever. Get started for free.",className:"promo-image"}),i.jsx("a",{href:k1,target:"_blank",rel:"noopener noreferrer",onClick:ji,className:"promo-link","aria-label":"Open TorchX Talent"}),i.jsx("a",{href:e0,onClick:K1,className:"promo-hotspot promo-hotspot-email","aria-label":`Email ${cr}`,title:cr}),S?i.jsx("a",{href:`tel:${H1}`,onClick:ji,className:"promo-hotspot promo-hotspot-phone","aria-label":"Call support"}):i.jsx("div",{className:"promo-hotspot promo-hotspot-phone is-static",onClick:M=>M.stopPropagation(),"aria-hidden":"true"})]})}),i.jsxs("div",{className:"promo-footer",children:[i.jsxs("a",{href:V1,target:"_blank",rel:"noopener noreferrer",onClick:ji,className:"promo-btn promo-btn-chat",children:[i.jsx("span",{"aria-hidden":"true",children:"💬"})," ",U1]}),i.jsx("button",{type:"button",className:"promo-btn promo-btn-close",onClick:C,children:"Close"})]})]}),i.jsx("style",{children:`
        .promo-backdrop {
          position: fixed;
          inset: 0;
          z-index: 100000;
          display: flex;
          padding: 24px 16px;
          background: rgba(15, 8, 20, 0.62);
          backdrop-filter: blur(3px);
          animation: promoFade 0.3s ease-out;

          /* Pop-up scrolls when it is taller than the screen */
          overflow-y: auto;
          overscroll-behavior: contain;
          -webkit-overflow-scrolling: touch;
        }

        .promo-box {
          position: relative;
          width: min(88vw, var(--popup-max, 800px));
          /* margin:auto centers when it fits, top-aligns when it overflows */
          margin: auto;
          background: #ffffff;
          border-radius: 18px;
          overflow: hidden;
          box-shadow: 0 30px 70px rgba(0, 0, 0, 0.45);
          animation: promoPop 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .promo-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 14px 18px;
          border-bottom: 1px solid #eeeeee;
        }

        .promo-title {
          margin: 0;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 18px;
          line-height: 1.3;
          font-weight: 700;
          color: #121826;
        }

        .promo-close {
          flex: 0 0 auto;
          width: 34px;
          height: 34px;
          border: none;
          border-radius: 50%;
          background: #f3f4f6;
          color: #730042;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: transform 0.2s ease, background 0.2s ease, color 0.2s ease;
        }

        .promo-close:hover {
          transform: scale(1.08);
          background: #730042;
          color: #fff;
        }

        .promo-close:focus-visible {
          outline: 3px solid #f6c6de;
          outline-offset: 2px;
        }

        .promo-body {
          padding: 14px 18px 0;
        }

        .promo-poster {
          position: relative;
          border-radius: 12px;
          overflow: hidden;
          line-height: 0;
        }

        .promo-image {
          display: block;
          width: 100%;
          height: auto;
          background: #fff;
        }

        /* poori image clickable (trial page) */
        .promo-link {
          position: absolute;
          inset: 0;
          z-index: 1;
        }

        /* email wala invisible clickable area, image link ke upar */
        .promo-hotspot {
          position: absolute;
          z-index: 2;
          cursor: pointer;
        }

        /* Position image ke % me hai. Zarurat ho to left/bottom/width/height badlo. */
        .promo-hotspot-email {
          left: 3%;
          bottom: 0.4%;
          width: 26.5%;
          height: 3%;
        }

        /* phone number ke upar. Position ke liye left/width adjust karo */
        .promo-hotspot-phone {
          left: 38%;
          bottom: 0.4%;
          width: 19.5%;
          height: 3%;
        }

        /* desktop par phone number unclickable (normal cursor, koi action nahi) */
        .promo-hotspot.is-static {
          cursor: default;
        }

        .promo-hotspot.is-debug {
          outline: 2px dashed red;
          background: rgba(255, 0, 0, 0.15);
        }

        .promo-footer {
          display: flex;
          justify-content: flex-end;
          flex-wrap: wrap;
          gap: 10px;
          padding: 14px 18px 18px;
        }

        .promo-btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          min-height: 42px;
          padding: 0 20px;
          border: none;
          border-radius: 10px;
          font-family: "Inter", sans-serif;
          font-size: 14px;
          font-weight: 600;
          text-decoration: none;
          cursor: pointer;
          transition: transform 0.2s ease, background 0.2s ease;
        }

        .promo-btn:hover {
          transform: translateY(-1px);
        }

        .promo-btn-chat {
          background: #198754;
          color: #ffffff;
        }

        .promo-btn-chat:hover {
          background: #157347;
        }

        .promo-btn-close {
          background: #6c757d;
          color: #ffffff;
        }

        .promo-btn-close:hover {
          background: #5c636a;
        }

        @media (max-width: 480px) {
          .promo-title { font-size: 16px; }
          .promo-footer { justify-content: stretch; }
          .promo-btn { flex: 1; }
        }

        @keyframes promoFade {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        @keyframes promoPop {
          from { opacity: 0; transform: translateY(16px) scale(0.96); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }

        @media (prefers-reduced-motion: reduce) {
          .promo-backdrop,
          .promo-box { animation: none; }
        }
      `})]})}var Qm={};const Ye={url:typeof process<"u"&&Qm&&Qm.VITE_SITE_URL||"https://www.techtorch.solutions",name:"TechTorch",ogImage:"/Slide1.webp",logo:"/TechTorchLogo.webp",locale:"en_IN",sameAs:[]},ou={title:"TechTorch | Enterprise Software, ERP, Cloud & IT Staffing Solutions",description:"TechTorch builds enterprise software, ERP, cloud and AI solutions and provides IT staffing and consulting for businesses across industries."},ur={"/":{title:ou.title,description:ou.description,priority:1},"/explore-solutions":{title:"Technology Solutions Built Around Your Business | TechTorch",description:"Explore TechTorch technology solutions: ERP, CRM, e-commerce, payments, web portals and more, designed around how your business works."},"/explore-erp":{title:"Connected ERP Solutions for Your Business | TechTorch",description:"Connect finance, operations, people and supply chain on one ERP platform so your teams work better together."},"/erp":{title:"ERP Solutions to Optimize Business Operations | TechTorch",description:"TechTorch ERP solutions streamline operations, improve visibility and help your business make faster, better decisions."},"/build-with-techtorch":{title:"Custom Software Built Around Your Business | TechTorch",description:"Work with TechTorch to design and build custom software that fits your processes, scales with growth and integrates with your systems."},"/explore-services":{title:"Technology Services That Move Your Business Forward | TechTorch",description:"From software engineering to cloud, AI and IT staffing, explore the technology services TechTorch offers to grow your business."},"/explore-torchXsuite":{title:"TorchX Suite: Everything Your Business Needs | TechTorch",description:"TorchX Suite brings business tools together so your whole organization works from one connected platform."},"/operation-management":{title:"Operations Management Solutions | TechTorch",description:"Improve efficiency and control across your operations with TechTorch operations management solutions."},"/operations-management":{title:"Optimise Your Operations with TechTorch Solutions",description:"Streamline workflows, reduce manual effort and gain real-time visibility with TechTorch operations management software."},"/supply-chain-management":{title:"Supply Chain Management Software | TechTorch",description:"Build a more connected and efficient supply chain with TechTorch supply chain management solutions."},"/aviation-management":{title:"Aviation Management Solutions | TechTorch",description:"Digital solutions for aviation operations, built to improve coordination, tracking and efficiency."},"/people-management":{title:"People Management & HR Software | TechTorch",description:"Empower your people and strengthen your business with TechTorch HR and people management solutions."},"/web-portals":{title:"Web Portal Development for Businesses | TechTorch",description:"Create connected digital experiences for customers, partners and employees with secure, scalable web portals from TechTorch."},"/payment-management":{title:"Payment Management Solutions | TechTorch",description:"Simplify payments and improve business efficiency with TechTorch payment management solutions for multiple industries."},"/healthcare-hospital-management":{title:"Hospital Management Software for Healthcare | TechTorch",description:"Transform healthcare operations with smart digital solutions for hospital management, patient records and workflows."},"/crm":{title:"CRM Solutions to Strengthen Customer Relationships | TechTorch",description:"Enhance customer experience and strengthen business relationships with TechTorch CRM solutions."},"/ecommerce-solutions":{title:"E-Commerce Platform Development | TechTorch",description:"Comprehensive e-commerce platforms for catalog, checkout, payments and fulfilment, built to grow with your online business."},"/project-management":{title:"Project Management Solutions | TechTorch",description:"Plan, track and deliver projects on time with TechTorch project management solutions."},"/software-development-support":{title:"Software Development & Support Services | TechTorch",description:"Software solutions designed to move your business forward, with development, maintenance and ongoing support from TechTorch."},"/cloud-infrastructure":{title:"Scalable Cloud Infrastructure Services | TechTorch",description:"Empower your business with scalable, secure and cost-efficient cloud infrastructure, migration and management."},"/software-engineering-outsourcing":{title:"Software Engineering Outsourcing Services | TechTorch",description:"Engineering digital solutions that drive business growth with dedicated software engineering teams from TechTorch."},"/it-consultancy":{title:"IT Consultancy & Digital Transformation Strategy | TechTorch",description:"Navigate digital transformation with the right IT strategy. TechTorch consultants help you plan, prioritize and execute technology change."},"/resource-staffing":{title:"IT Resource Staffing Services | TechTorch",description:"Empower your business with the right talent. TechTorch provides skilled IT professionals on flexible engagement models."},"/digital-solutions":{title:"Digital Solutions Designed Around Your Business | TechTorch",description:"Digital transformation solutions that connect your processes, data and teams, delivered by TechTorch."},"/digitalsolution":{canonical:"/digital-solutions",noindex:!0,title:"Digital Solutions | TechTorch",description:"Digital solutions designed around your business."},"/platform":{title:"TechTorch Platform: Technology Around Your Business",description:"The TechTorch platform brings together enterprise tools that adapt to your business instead of the other way around."},"/OurService":{title:"Our Services: Technology Built Around Your Business | TechTorch",description:"See the full range of TechTorch services, from strategy and engineering to cloud, AI and IT staffing."},"/ArtificialIntelligent":{title:"Artificial Intelligence as a Service (AIaaS) | TechTorch",description:"Use AI without the complexity. TechTorch integrates artificial intelligence into your existing business technology environment."},"/data-decisions":{title:"Data & Decisions: Analytics for Smarter Business | TechTorch",description:"Turn your data into decisions with TechTorch analytics, structured methodology and measurable operational impact."},"/ItAugmentation":{title:"IT Augmentation: Extend Your Technology Team | TechTorch",description:"Extend your technology team with flexible IT expertise. TechTorch supplies skilled engineers for contract, remote and project-based needs."},"/Contract-Staffing":{title:"Contract IT Staffing for Dynamic Project Demands | TechTorch",description:"Flexible technology resources for projects with changing demands. Scale engineering capacity up or down with contract staffing."},"/contract-to-hire":{title:"Contract-to-Hire IT Talent | TechTorch",description:"Find the right technology talent and build with confidence. Evaluate on the job, then convert to full-time hires."},"/Dedicated-Development-Teams":{title:"Dedicated Development Teams | TechTorch",description:"Strengthen your technology team with dedicated developers who work as an extension of your organization."},"/remote-engineers":{title:"Hire Remote Engineers | TechTorch",description:"Extend your engineering team with skilled remote engineers and scale your technology capabilities quickly."},"/project-based-hiring":{title:"Project-Based IT Hiring | TechTorch",description:"Deliver technology projects with the right engineering expertise, engaged only for the duration you need."},"/resource-replacement":{title:"IT Resource Replacement & Project Continuity | TechTorch",description:"Keep projects on track with quick, quality replacements for technology resources."},"/bench-hiring":{title:"Bench Hiring: Ready-to-Deploy IT Resources | TechTorch",description:"Build your technology team with pre-vetted bench resources that can start quickly."},"/vendor-partnership":{title:"Vendor Partnership Program | TechTorch",description:"Build stronger opportunities through technology partnership with TechTorch."},"/become-partner":{title:"Become a TechTorch Technology Partner",description:"Join the TechTorch partner network and grow together through shared technology opportunities."},"/msp-support":{title:"Managed Service Provider (MSP) Support | TechTorch",description:"TechTorch MSP support keeps your IT environment monitored, secure and running smoothly."},"/offshore-teams":{title:"Offshore Development Teams | TechTorch",description:"Build offshore development teams with clear governance, delivery lifecycle and transparent engagement models."},"/development-team":{title:"Build Your Development Team | TechTorch",description:"Set up a dedicated offshore development team tailored to your product and delivery goals."},"/industries/education":{title:"Technology for Education: EdTech Solutions | TechTorch",description:"Technology that helps education move forward: learning platforms, administration systems and digital campus solutions."},"/education-solutions":{title:"Technology Solutions for Modern Education | TechTorch",description:"Modern education technology solutions for institutions, from admissions to learning and administration."},"/industries/insurance":{title:"Insurance Software & Technology Solutions | TechTorch",description:"Technology solutions for modern insurance operations: policy, claims, customer experience and digital transformation."},"/industries/finance":{title:"Financial Services Technology Solutions | TechTorch",description:"Modern technology solutions for a more connected financial enterprise: architecture, fintech and key business systems."},"/industries/healthcare":{title:"Healthcare Technology Solutions | TechTorch",description:"Technology for more connected healthcare operations: records, workflows, security and operational insight."},"/industries/information-technology":{title:"Technology Solutions for IT Companies | TechTorch",description:"Technology solutions designed around your business: software, digital solutions, infrastructure and engineering."},"/industries/manufacturing":{title:"Manufacturing Software & ERP Solutions | TechTorch",description:"Technology solutions for modern manufacturing: ERP, shop-floor connectivity and software engineering."},"/industries/telecommunications":{title:"Telecommunications Technology Solutions | TechTorch",description:"Technology solutions for a more connected telecommunications business: key solutions, software engineering and services."},"/industries/energy":{title:"Energy Sector Technology Solutions | TechTorch",description:"Technology solutions for a more connected energy business: operations, software engineering and technology services."},"/industries/transportation":{title:"Transportation & Logistics Technology Solutions | TechTorch",description:"Technology solutions for a more connected transportation business: supply chain, software and enterprise systems."},"/industries/fmcg":{title:"FMCG Technology Solutions | TechTorch",description:"Technology solutions for modern FMCG businesses: distribution, sales, supply chain and business management."},"/industries/e-commerce":{title:"E-Commerce Industry Solutions | TechTorch",description:"E-commerce solutions for modern online businesses: enterprise platforms, front-end experience, custom builds and intelligence."},"/about-us":{title:"About TechTorch | Leadership & Company",description:"Meet the people behind TechTorch and learn about our purpose, values and leadership."},"/leadership":{canonical:"/about-us",noindex:!0,title:"Leadership | TechTorch",description:"The people behind TechTorch's purpose."},"/company-overview":{title:"Company Overview | TechTorch",description:"Technology. Innovation. Business transformation. Learn about TechTorch, what we do and how we work."},"/the-techtorch-way":{title:"The TechTorch Way: Technology with Purpose",description:"Technology with purpose. Solutions with impact. Discover the principles and approach behind every TechTorch engagement."},"/culture-inclusion":{title:"Culture & Inclusion at TechTorch",description:"People make the difference. See how TechTorch builds an inclusive, supportive and growth-focused workplace."},"/investors":{title:"Investors | TechTorch",description:"A vision for progress and a commitment to innovation. Information for TechTorch investors and stakeholders."},"/idea":{title:"Great Ideas Begin with a New Perspective | TechTorch",description:"Share your idea with TechTorch and see how fresh perspective turns it into a working solution."},"/partners-ecosystem":{title:"Partners & Ecosystem | TechTorch",description:"Partnerships that create business value. Explore TechTorch's technology and business partner ecosystem."},"/media":{title:"Media & Press | TechTorch",description:"Discover TechTorch through media coverage, announcements and company updates."},"/case-studies":{title:"Case Studies: Solving Business Challenges | TechTorch",description:"See how TechTorch has helped businesses solve real challenges through technology, with measurable results."},"/careers":{title:"Careers at TechTorch | Jobs & Openings",description:"Explore open roles at TechTorch and build your career with a technology team that values growth and ownership."},"/blogs":{title:"TechTorch Blogs: Technology, ERP, Cloud & AI Insights",description:"Read articles on enterprise technology, ERP, cloud, AI and digital transformation from the TechTorch team and community."},"/privacy-policy":{title:"Privacy Policy | TechTorch",description:"Read how TechTorch collects, uses and protects your personal information."},"/Our-Story":{title:"Our Story: Architecting Future Enterprise Technology | TechTorch",description:"TechTorch's philosophy, core foundation and strategic capabilities for enterprise technology at speed and scale."},"/KnowMore":{title:"Innovate at Speed, Scale with Confidence | TechTorch",description:"Enterprise acceleration, practical intelligence and proven impact: learn what makes TechTorch transformation-ready."},"/TechTorchView":{title:"The TechTorch View: Philosophy & Methodology",description:"TechTorch's point of view on technology: our philosophy, capabilities and deployment methodology."},"/field-note":{title:"Field Notes: Technology Insights from TechTorch",description:"Practical field notes on technology, connected operations and integrated capabilities from TechTorch teams."},"/integrated-capabilities":{title:"Integrated Capabilities | TechTorch",description:"ERP integration, operations management, data orchestration and legacy modernization from one team."},"/integrated-capabilities/erp-integration":{title:"ERP Integration Services | TechTorch",description:"Integrate ERP with the rest of your systems so data flows reliably across finance, operations and sales."},"/integrated-capabilities/operations-management":{title:"Operations Management Integration | TechTorch",description:"Bring operational data and workflows together for better control and faster execution."},"/integrated-capabilities/data-orchestration":{title:"Data Orchestration Services | TechTorch",description:"Orchestrate data across systems and pipelines so teams get trusted, timely information."},"/integrated-capabilities/legacy-modernization":{title:"Legacy System Modernization | TechTorch",description:"Modernize legacy applications safely, with minimal disruption and a clear migration roadmap."},"/think-ahead":{title:"Think Ahead: Technology Perspectives | TechTorch",description:"Perspectives on emerging technology, ecosystems and what's next for enterprise IT."},"/cyber-security":{title:"Cyber Security Services & Resilience | TechTorch",description:"Security capabilities, resilience pillars and measurable outcomes to protect your business from cyber threats."},"/secure-business":{title:"Secure Your Business: Security Advisory | TechTorch",description:"TechTorch's security initiative, advisory framework and protocol delivery to secure critical business systems."},"/Business-growth":{title:"Grow Your Business with Technology | TechTorch",description:"Architecture, methodology and ecosystem capabilities that help your business grow with technology."},"/schedule-advisory":{noindex:!0,title:"Schedule an Advisory Session | TechTorch",description:"Schedule a security advisory session with TechTorch."},"/engagement-protocol":{noindex:!0,title:"Engagement Protocol | TechTorch",description:"View your TechTorch engagement protocol."},"/accept-proceed":{noindex:!0,title:"Accept & Proceed | TechTorch",description:"Accept the engagement protocol and proceed."},"/export-protocol":{noindex:!0,title:"Export Protocol Package | TechTorch",description:"Export your engagement protocol package."},"/discuss-priorities":{noindex:!0,title:"Discuss Your IT Requirements | TechTorch",description:"Discuss your IT requirements and business priorities with TechTorch."},"/connect-msp":{noindex:!0,title:"Connect with TechTorch MSP",description:"Connect with the TechTorch MSP team."},"/development-requirements":{noindex:!0,title:"Discuss Your Development Requirements | TechTorch",description:"Share your development requirements with TechTorch."},"/schedule-discovery":{noindex:!0,title:"Schedule Education Discovery Session | TechTorch",description:"Schedule a discovery session with TechTorch."},"/insurance-get-in-touch":{noindex:!0,title:"Connect with Insurance Solutions Architects | TechTorch",description:"Get in touch with TechTorch insurance solutions architects."},"/finance-get-in-touch":{noindex:!0,title:"Connect with Financial Technology Architects | TechTorch",description:"Get in touch with TechTorch financial technology architects."},"/healthcare-get-in-touch":{noindex:!0,title:"Get in Touch with Healthcare Experts | TechTorch",description:"Get in touch with TechTorch healthcare experts."},"/it-get-in-touch":{noindex:!0,title:"Connect with TechTorch Technology Experts",description:"Get in touch with TechTorch technology experts."},"/manufacturing-get-in-touch":{noindex:!0,title:"Connect with Manufacturing Experts | TechTorch",description:"Get in touch with TechTorch manufacturing experts."},"/telecommunication-get-in-touch":{noindex:!0,title:"Telecommunications Technology Requirements | TechTorch",description:"Discuss your telecommunications technology requirements."},"/energy-get-in-touch":{noindex:!0,title:"Energy Technology Requirements | TechTorch",description:"Discuss your energy technology requirements."},"/transportation-get-in-touch":{noindex:!0,title:"Transportation Technology Requirements | TechTorch",description:"Discuss your transportation technology requirements."},"/fmcg-get-in-touch":{noindex:!0,title:"FMCG Technology Requirements | TechTorch",description:"Discuss your FMCG technology requirements."},"/ecommerce-get-in-touch":{noindex:!0,title:"E-Commerce Requirements | TechTorch",description:"Discuss your e-commerce requirements."},"/start-conversation":{noindex:!0,title:"Start a Conversation | TechTorch",description:"Turn your technology needs into solutions. Talk to TechTorch."},"/explore-questions":{noindex:!0,title:"Have a Question? | TechTorch",description:"Ask TechTorch a question."},"/conversation-toggle":{noindex:!0,title:"Let's Discuss What Your Business Needs | TechTorch",description:"Tell TechTorch what your business needs."},"/talk-to-expert":{noindex:!0,title:"Talk to Our Experts | TechTorch",description:"Talk to TechTorch experts about your requirements."},"/signin":{noindex:!0,title:"Sign In | TechTorch",description:"Sign in to your TechTorch account."},"/signup":{noindex:!0,title:"Create Account | TechTorch",description:"Create your TechTorch account."},"/candidate":{noindex:!0,title:"Candidate Dashboard | TechTorch",description:"Your TechTorch candidate dashboard."},"/404":{noindex:!0,title:"Page Not Found | TechTorch",description:"The page you are looking for does not exist."}},J1=["/admin","/dashboard","/login"],F1=(s,d)=>!!(d&&d.noindex)||J1.some(x=>s===x||s.startsWith(x+"-")||s.startsWith(x+"/"));function W1(s){const d=(s||"/").replace(/\/+$/,"")||"/";return ur[d]?{path:d,...ur[d]}:d.startsWith("/blogs/")?{path:d,title:"Blog | TechTorch",description:"Read this article on the TechTorch blog.",parent:"/blogs"}:{path:d,...ou,noindex:!0}}const ir=s=>/^https?:\/\//.test(s)?s:Ye.url.replace(/\/$/,"")+(s.startsWith("/")?s:"/"+s);function $1(s){const d=s.path||"/",x=F1(d,s),f=ir(s.canonical||d),y=ir(s.image||Ye.ogImage),E={title:s.title,description:s.description,canonical:f,robots:x?"noindex, follow":"index, follow, max-image-preview:large, max-snippet:-1",noindex:x,og:{"og:type":s.type||"website","og:site_name":Ye.name,"og:locale":Ye.locale,"og:title":s.title,"og:description":s.description,"og:url":f,"og:image":y,"og:image:alt":s.imageAlt||Ye.name},twitter:{"twitter:card":"summary_large_image","twitter:title":s.title,"twitter:description":s.description,"twitter:image":y},jsonLd:s.jsonLd||null};if(!E.jsonLd&&!x){const S={"@type":"Organization","@id":Ye.url+"/#organization",name:Ye.name,url:Ye.url+"/",logo:ir(Ye.logo),...Ye.sameAs.length?{sameAs:Ye.sameAs}:{}};if(d==="/")E.jsonLd={"@context":"https://schema.org","@graph":[S,{"@type":"WebSite","@id":Ye.url+"/#website",url:Ye.url+"/",name:Ye.name,publisher:{"@id":Ye.url+"/#organization"}}]};else{const C=[{"@type":"ListItem",position:1,name:"Home",item:Ye.url+"/"}];s.parent&&ur[s.parent]&&C.push({"@type":"ListItem",position:2,name:ur[s.parent].title.split(" | ")[0].split(":")[0],item:ir(s.parent)}),C.push({"@type":"ListItem",position:C.length+1,name:s.title.split(" | ")[0],item:f}),E.jsonLd={"@context":"https://schema.org","@type":"BreadcrumbList",itemListElement:C}}}return E}let ru=null,sr=null;function or(s,d,x){let f=document.head.querySelector(`meta[${s}="${d}"]`);if(!x){f&&f.remove();return}f||(f=document.createElement("meta"),f.setAttribute(s,d),document.head.appendChild(f)),f.setAttribute("content",x)}function ev(s){let d=document.head.querySelector('link[rel="canonical"]');d||(d=document.createElement("link"),d.setAttribute("rel","canonical"),document.head.appendChild(d)),d.setAttribute("href",s)}function tv(s){let d=document.head.querySelector('script[data-seo="jsonld"]');if(!s){d&&d.remove();return}d||(d=document.createElement("script"),d.type="application/ld+json",d.setAttribute("data-seo","jsonld"),document.head.appendChild(d)),d.textContent=JSON.stringify(s)}function su(){if(!ru||typeof document>"u")return;const s=$1({...ru,...sr||{}});document.title=s.title,or("name","description",s.description),or("name","robots",s.robots),ev(s.canonical),Object.entries(s.og).forEach(([d,x])=>or("property",d,x)),Object.entries(s.twitter).forEach(([d,x])=>or("name",d,x)),tv(s.jsonLd)}function nv(){const{pathname:s}=gn();return c.useEffect(()=>{ru=W1(s),su()},[s]),null}function Sj(s){const d=s?JSON.stringify(s):"";c.useEffect(()=>{if(s)return sr=s,su(),()=>{sr===s&&(sr=null,su())}},[d])}const av="/assets/TechTorchLogo-CzFyOsaS.webp",n0=c.createContext(null);function lv({children:s}){const[d,x]=c.useState(null),[f,y]=c.useState(0);return i.jsx(n0.Provider,{value:{activeMenu:d,setActiveMenu:x,navHeight:f,setNavHeight:y},children:s})}function iv(){const s=c.useContext(n0);if(!s)throw new Error("useNavMenu must be used inside <NavMenuProvider>");return s}const a0={"Company Overview":"/company-overview",Leadership:"/Leadership",Idea:"/Idea",Investors:"/investors","Partners Ecosystem":"/partners-ecosystem",News:"/blogs","Customer Centricity":"/KnowMore",ERP:"/erp","Operations Management":"/integrated-capabilities/operations-management","Supply Chain Management":"/supply-chain-management","Aviation Management":"/aviation-management","People Management":"/people-management","Web Portals":"/web-portals","Financial Management":"/industries/finance","Payment Management":"/payment-management","Healthcare & Hospital Management":"/healthcare-hospital-management",CRM:"/crm",Ecommerce:"/ecommerce-solutions","Project Management":"/project-management","IT Consultancy":"/it-consultancy","Artificial Intelligence (AaaS)":"/ArtificialIntelligent","Cloud Infrastructure Services (IaaS)":"/cloud-infrastructure","Cyber Security":"/cyber-security","Software Engineering Outsourcing":"/software-engineering-outsourcing","Software Development & Support":"/software-development-support","Resource and Staffing":"/resource-staffing","TorchX Suite":"/platform","TorchX Campus":"/platform",Finance:"/industries/finance",Education:"/industries/education",Healthcare:"/industries/healthcare",Manufacturing:"/industries/manufacturing","Information Technology":"/industries/information-technology",Insurance:"/industries/insurance",Energy:"/industries/energy",FMCG:"/industries/fmcg",Transportation:"/industries/transportation",Telecommunications:"/industries/telecommunications","Case Studies":"/case-studies",Media:"/media","Company Profile":"/Philosophy","Quick Brochure":"/KnowMore","The TechTorch Way":"/the-techtorch-way","Culture & Inclusion":"/culture-inclusion","Join Us":"/careers"},mn=s=>a0[s]||"/",ov=[{label:"About Us",children:["Company Overview","Leadership","Idea","Investors","Partners Ecosystem","News","Customer Centricity"]},{label:"Capabilities",children:["ERP","Operations Management","Supply Chain Management","Web Portals","CRM","Ecommerce","IT Consultancy","Artificial Intelligence (AaaS)","Cyber Security","Resource and Staffing","TorchX Suite"]},{label:"Product",children:["TorchX Talent","TorchX Finance","TorchX Suite","TorchX Engage","TorchX Inventory","TorchX Pay","TorchX Spark","TorchX Sync"]},{label:"Industries",children:["Finance","Education","Healthcare","Manufacturing","Information Technology","Insurance","Energy","FMCG","Transportation","Telecommunications"]},{label:"Insights",children:["Case Studies","Media","Company Profile","Quick Brochure"]},{label:"Careers",children:["The TechTorch Way","Culture & Inclusion","Join Us"]},{label:"Contact Us",to:"/start-conversation"}],l0="/assets/image1-DnpGB5Qq.webp",rv=[{title:"Company Overview",text:"Who we are and what we stand for.",Icon:rp},{title:"Leadership",text:"Meet the team guiding TechTorch.",Icon:cu},{title:"Idea",text:"The thinking behind our solutions.",Icon:Qy},{title:"Investors",text:"Information for our stakeholders.",Icon:l1},{title:"Partners Ecosystem",text:"The partners we grow and build with.",Icon:Hy},{title:"News",text:"Press, updates and announcements.",Icon:Dp},{title:"Customer Centricity",text:"How we put our customers first.",Icon:Iy}],sv=150;function cv(){const[s,d]=c.useState(!1),[x,f]=c.useState(0),y=c.useRef(null),E=c.useRef(null);c.useEffect(()=>{const O=()=>{if(!y.current)return;const D=y.current.closest("header, nav")||y.current;f(D.getBoundingClientRect().bottom)};return O(),window.addEventListener("resize",O),window.addEventListener("scroll",O,{passive:!0}),()=>{window.removeEventListener("resize",O),window.removeEventListener("scroll",O)}},[s]);const S=c.useCallback(()=>{E.current&&(clearTimeout(E.current),E.current=null)},[]),C=c.useCallback(()=>{S(),E.current=setTimeout(()=>{d(!1),E.current=null},sv)},[S]),M=c.useCallback(()=>{S(),d(!0)},[S]),N=()=>{S(),d(!1)},R=O=>O==="Leadership"?"/leadership":mn(O);return c.useEffect(()=>{if(!s)return;const O=D=>D.key==="Escape"&&d(!1);return document.addEventListener("keydown",O),()=>document.removeEventListener("keydown",O)},[s]),c.useEffect(()=>()=>S(),[S]),i.jsxs("div",{ref:y,className:"relative h-full",onMouseEnter:M,onMouseLeave:C,children:[i.jsx("span",{className:`relative inline-flex items-center h-full cursor-pointer text-[17px] \r
        text-gray-900 hover:text-[#8a1538] \r
        transition-colors duration-200 \r
        after:absolute after:left-0 after:bottom-0 \r
        after:h-[2px] after:w-0 \r
        after:bg-[#8a1538] \r
        after:transition-all after:duration-200 \r
        hover:after:w-full`,children:"About Us"}),s&&i.jsx("div",{style:{top:x},onMouseEnter:M,onMouseLeave:C,className:`fixed left-0 right-0 w-full max-h-[85vh] overflow-y-auto\r
          bg-white shadow-2xl z-[9999] border-t border-gray-100`,children:i.jsxs("div",{className:"grid gap-10 px-[6%] py-12 lg:grid-cols-[1fr_minmax(320px,32%)] lg:gap-14",children:[i.jsxs("div",{children:[i.jsx("p",{className:"m-0 mb-2 text-[11px] font-bold uppercase tracking-[0.14em] text-[#8a1538]",children:"About Us"}),i.jsx("h3",{className:"m-0 mb-2 font-plus-jakarta text-[26px] font-semibold leading-[1.2] text-gray-900",children:"Get to know TechTorch"}),i.jsx("p",{className:"m-0 mb-8 max-w-[520px] font-inter text-[14px] leading-[1.6] text-gray-500",children:"Our story, our leaders and the partners behind our work."}),i.jsx("div",{className:"grid gap-4 sm:grid-cols-2",children:rv.map(({title:O,text:D,Icon:ie})=>i.jsxs(ve,{to:R(O),onClick:N,className:`group flex items-start gap-4 rounded-xl border border-gray-100 \r
                    bg-white p-5 no-underline transition-all duration-200 \r
                    hover:border-[#8a1538]/30 hover:bg-[#fdf5f8] hover:shadow-md`,children:[i.jsx("span",{className:"flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-[#fdf0f6] text-[#8a1538]",children:i.jsx(ie,{size:20,strokeWidth:1.7})}),i.jsxs("span",{className:"min-w-0 flex-1",children:[i.jsxs("span",{className:"flex items-center justify-between gap-2 font-plus-jakarta text-[16px] font-semibold text-gray-900 group-hover:text-[#8a1538]",children:[O,i.jsx(mt,{size:16,className:"shrink-0 -translate-x-1 opacity-0 transition-all duration-200 group-hover:translate-x-0 group-hover:opacity-100"})]}),i.jsx("span",{className:"mt-1 block font-inter text-[13px] leading-[1.5] text-gray-500",children:D})]})]},O))})]}),i.jsx("div",{className:"flex flex-col",children:i.jsxs("div",{className:"relative min-h-[320px] flex-1 overflow-hidden rounded-2xl",children:[i.jsx("img",{src:l0,alt:"Business technology",className:"absolute inset-0 h-full w-full object-cover"}),i.jsx("div",{className:"absolute inset-0",style:{background:"linear-gradient(to top, rgba(0,0,0,0.78) 0%, rgba(0,0,0,0.25) 55%, rgba(0,0,0,0.05) 100%)"}}),i.jsxs("div",{className:"relative flex h-full min-h-[320px] flex-col justify-between p-6 text-white",children:[i.jsx("span",{className:"w-fit rounded-full bg-white/15 px-3 py-1 font-plus-jakarta text-[11px] font-semibold uppercase tracking-[0.1em] backdrop-blur",children:"Featured"}),i.jsxs("div",{children:[i.jsx("p",{className:"m-0 font-plus-jakarta text-[18px] font-semibold leading-[1.35]",children:"AI That Works for Your Business"}),i.jsxs(ve,{to:"/leadership",onClick:N,className:"mt-4 inline-flex items-center gap-2 font-inter text-[13px] font-bold uppercase tracking-wide text-white no-underline hover:text-gray-200",children:["Learn more ",i.jsx(mt,{size:15})]})]})]})]})})]})})]})}const uv="/assets/Navbarcap-iCz4oPrb.webp",Zm=[{heading:"Digital Solutions",items:["ERP","Operations Management","Supply Chain Management","Aviation Management","People Management","Web Portals","Financial Management","Payment Management","Healthcare & Hospital Management","CRM","Ecommerce","Project Management"]},{heading:"IT Augmentation Service",sections:[{subheading:"Our Services",items:["IT Consultancy","Artificial Intelligence (AaaS)","Cloud Infrastructure Services (IaaS)","Cyber Security","Software Engineering Outsourcing","Software Development & Support","Resource and Staffing"]},{subheading:"Platforms",items:["TorchX Suite","TorchX Campus"]}]}],dv=150;function fv(){const[s,d]=c.useState(!1),[x,f]=c.useState(0),y=c.useRef(null),E=c.useRef(null);c.useEffect(()=>{const N=()=>{if(!y.current)return;const R=y.current.closest("header, nav")||y.current;f(R.getBoundingClientRect().bottom)};return N(),window.addEventListener("resize",N),window.addEventListener("scroll",N),()=>{window.removeEventListener("resize",N),window.removeEventListener("scroll",N)}},[s]);const S=c.useCallback(()=>{E.current&&(clearTimeout(E.current),E.current=null)},[]),C=c.useCallback(()=>{S(),d(!0)},[S]),M=c.useCallback(()=>{S(),E.current=setTimeout(()=>{d(!1),E.current=null},dv)},[S]);return c.useEffect(()=>()=>S(),[S]),i.jsxs("div",{ref:y,className:"relative h-full",onMouseEnter:C,onMouseLeave:M,children:[i.jsx("span",{className:`\r
          relative inline-flex items-center h-full cursor-pointer\r
          text-[17px] text-gray-900 hover:text-[#8a1538]\r
          transition-colors duration-200\r
          after:absolute after:left-0 after:bottom-0 after:h-[2px]\r
          after:w-0 after:bg-[#8a1538]\r
          after:transition-all after:duration-200\r
          hover:after:w-full\r
        `,children:"Capabilities"}),s&&i.jsxs("div",{style:{top:x},onMouseEnter:C,onMouseLeave:M,className:`\r
            fixed left-0 right-0 w-full bg-white shadow-2xl\r
            z-[9999] overflow-y-auto max-h-[calc(100vh-70px)]\r
          `,children:[i.jsx("img",{src:uv,alt:"","aria-hidden":"true",className:`\r
              absolute top-0 left-0 w-full h-[650px]\r
              pointer-events-none select-none opacity-30 object-cover\r
            `}),i.jsxs("div",{className:`\r
              relative z-10\r
              px-4 sm:px-6 md:px-10 lg:px-[100px]\r
              pt-7 pb-10 md:pt-9 md:pb-14\r
            `,children:[i.jsx("div",{className:`\r
                grid grid-cols-1 md:grid-cols-2\r
                gap-6 md:gap-20 mb-6\r
              `,children:i.jsx("h2",{className:`\r
                  text-[22px] md:text-[25px] font-bold\r
                  text-gray-900 font-plus-jakarta text-left\r
                  m-0 leading-[1.2]\r
                `,children:"IT Capabilities"})}),i.jsxs("div",{className:`\r
                grid grid-cols-1 md:grid-cols-2\r
                gap-10 md:gap-20\r
              `,children:[i.jsxs("div",{className:`\r
                  grid grid-cols-1 sm:grid-cols-2\r
                  gap-8 items-start\r
                `,children:[i.jsxs("div",{className:"flex flex-col gap-3",children:[i.jsx("h3",{className:`\r
                      text-[20px] font-semibold text-gray-900\r
                      font-plus-jakarta mb-2 leading-[1.25]\r
                    `,children:"Digital Solutions"}),Zm[0].items.map(N=>i.jsx(ve,{to:mn(N),onClick:()=>d(!1),className:`\r
                        text-[15px] text-gray-800 font-inter\r
                        leading-[1.35] hover:text-[#8a1538]\r
                        transition-colors duration-200\r
                      `,children:N},N))]}),i.jsxs("div",{className:"flex flex-col gap-3 ml-0 md:ml-4",children:[i.jsx("h3",{className:`\r
                      text-[20px] font-semibold text-gray-900\r
                      font-plus-jakarta mb-2 leading-[1.25]\r
                    `,children:"IT Augmentation Service"}),Zm[1].sections.map((N,R)=>i.jsxs("div",{className:`flex flex-col gap-3 ${R>0?"mt-3":""}`,children:[i.jsx("h4",{className:`\r
                          text-[16px] md:text-[18px] font-semibold\r
                          text-gray-900 font-plus-jakarta\r
                          leading-[1.3]\r
                        `,children:N.subheading}),N.items.map(O=>i.jsx("a",{href:O==="TorchX Suite"||O==="TorchX Campus"?"https://torchxsuite.com/":mn(O),...O==="TorchX Suite"||O==="TorchX Campus"?{target:"_blank",rel:"noopener noreferrer"}:{},className:`\r
                            text-[15px] text-gray-800 font-inter\r
                            leading-[1.35] hover:text-[#8a1538]\r
                            transition-colors duration-200\r
                          `,children:O},O))]},N.subheading))]})]}),i.jsx("div",{className:`\r
                  flex flex-col items-end text-right min-h-[200px]\r
                `})]})]})]})]})}const hv=[{title:"Finance",text:"Secure, connected systems for financial services.",Icon:Xy},{title:"Education",text:"Software for institutions, students and staff.",Icon:By},{title:"Healthcare",text:"Technology for efficient hospital and care operations.",Icon:qy},{title:"Manufacturing",text:"Connected production, inventory and supply chain.",Icon:Vy},{title:"Information Technology",text:"Engineering and digital services for IT companies.",Icon:Fy},{title:"Insurance",text:"Streamlined policy, claims and customer processes.",Icon:n1},{title:"Energy",text:"Digital systems for energy and utility operations.",Icon:Kp},{title:"FMCG",text:"Distribution, inventory and sales for fast-moving goods.",Icon:a1},{title:"Transportation",text:"Logistics, fleet and supply chain visibility.",Icon:i1},{title:"Telecommunications",text:"Scalable software and support for telecom providers.",Icon:$y}],mv=150;function pv(){const[s,d]=c.useState(!1),[x,f]=c.useState(0),y=c.useRef(null),E=c.useRef(null);c.useEffect(()=>{const R=()=>{if(!y.current)return;const O=y.current.closest("header, nav")||y.current;f(O.getBoundingClientRect().bottom)};return R(),window.addEventListener("resize",R),window.addEventListener("scroll",R,{passive:!0}),()=>{window.removeEventListener("resize",R),window.removeEventListener("scroll",R)}},[s]);const S=c.useCallback(()=>{E.current&&(clearTimeout(E.current),E.current=null)},[]),C=c.useCallback(()=>{S(),E.current=setTimeout(()=>{d(!1),E.current=null},mv)},[S]),M=c.useCallback(()=>{S(),d(!0)},[S]),N=()=>{S(),d(!1)};return c.useEffect(()=>{if(!s)return;const R=O=>O.key==="Escape"&&d(!1);return document.addEventListener("keydown",R),()=>document.removeEventListener("keydown",R)},[s]),c.useEffect(()=>()=>S(),[S]),i.jsxs("div",{ref:y,className:"relative h-full",onMouseEnter:M,onMouseLeave:C,children:[i.jsx("span",{className:`relative inline-flex items-center h-full cursor-pointer text-[17px] \r
        text-gray-900 hover:text-[#8a1538] \r
        transition-colors duration-200 \r
        after:absolute after:left-0 after:bottom-0 \r
        after:h-[2px] after:w-0 \r
        after:bg-[#8a1538] \r
        after:transition-all after:duration-200 \r
        hover:after:w-full`,children:"Industries"}),s&&i.jsx("div",{style:{top:x},onMouseEnter:M,onMouseLeave:C,className:`fixed left-0 right-0 w-full max-h-[85vh] overflow-y-auto\r
          bg-white shadow-2xl z-[9999] border-t border-gray-100`,children:i.jsx("div",{className:"px-[6%] py-12",children:i.jsxs("div",{className:"max-w-[920px]",children:[i.jsx("p",{className:"m-0 mb-2 text-[11px] font-bold uppercase tracking-[0.14em] text-[#8a1538]",children:"Industries"}),i.jsx("h3",{className:"m-0 mb-2 font-plus-jakarta text-[26px] font-semibold leading-[1.2] text-gray-900",children:"Solutions for your sector"}),i.jsx("p",{className:"m-0 mb-8 max-w-[520px] font-inter text-[14px] leading-[1.6] text-gray-500",children:"Technology shaped around how your industry works."}),i.jsx("div",{className:"grid gap-4 sm:grid-cols-2",children:hv.map(({title:R,text:O,Icon:D})=>i.jsxs(ve,{to:mn(R),onClick:N,className:`group flex items-start gap-4 rounded-xl border border-gray-100 \r
                    bg-white p-5 no-underline transition-all duration-200 \r
                    hover:border-[#8a1538]/30 hover:bg-[#fdf5f8] hover:shadow-md`,children:[i.jsx("span",{className:"flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-[#fdf0f6] text-[#8a1538]",children:i.jsx(D,{size:20,strokeWidth:1.7})}),i.jsxs("span",{className:"min-w-0 flex-1",children:[i.jsxs("span",{className:"flex items-center justify-between gap-2 font-plus-jakarta text-[16px] font-semibold text-gray-900 group-hover:text-[#8a1538]",children:[R,i.jsx(mt,{size:16,className:"shrink-0 -translate-x-1 opacity-0 transition-all duration-200 group-hover:translate-x-0 group-hover:opacity-100"})]}),i.jsx("span",{className:"mt-1 block font-inter text-[13px] leading-[1.5] text-gray-500",children:O})]})]},R))})]})})})]})}const gv="data:image/webp;base64,UklGRlgMAABXRUJQVlA4WAoAAAAQAAAASgEACgEAQUxQSCgAAAABFyAQSFKffI2ICAc1AQgwyoikfyHniuj/BMgw77/77/67/+6/vAfHVlA4IAoMAABwSwCdASpLAQsBPm02mEkkIyKooTQI8RANiWVu3s0ffZqpBAGpcAdaVmXt7/Mj5wXpP/zXqAf3jqTvQA6W793vS71SqL2atDuZR6uOaT5CfrX2Belv6SH7SBqpRBFp3o0BICQGnb5oZP/8B/fmjCb+gJDnFRms1Z39wj/2R/zCAXZHledIzaG2rFSsz53nkbksnoTPGXPL75AqwyrOo9V8zo0lOP5Tx6POYT09aQFwrv6cZ+N3tgV0hmte0Boq0JT/Pn1ZVm0dCJ8zqkEXqU8lxpzXDznZ1ySpmTEW9YRQCW//lu3uhF39pyz6ujIwEJP+80NiEsoQPuIXY4OtIWbbnRD6stWxSj03zSyyB48SigqhMUfYQ4uKyITzqPud+iWFIYkoO4VOz8tBS2zGGps8+9nS5O+4Juzy54f/2xHY45vlCjHG+MxL8wYIGosTv5jUSdr+nFMHGIqA5IBJDd/KG8jdpDNkaOTCnbTg4HSapALvxmggPyp4KrN6QRFRxO+Wv8FYq1dfS07/41+zB3YxlVycMlLxRrDOIaSnBtRfcmbD6LJtXnwHyyt4n5tZWsmbFKBFt2C475fl6a2HjEhC/8/0Bhn1MsjBmwV5oUoiFithEckXwGozLrTSPUVYVbaEtJQfZ7EYNmbQga7l2ofIGtZVPgylmESd5y+Jqwan7WWI0B6gLE+gmets7uLvIT73ojqxSKdgdZJiTJT/kCoA6bkU94t4zioK7wJfRB5Rk2uTG/KHApgbl8vqdC8Evi6HBXEVd8LRj3JFh1lJadw7E6I/eAJ1y5eiWNFw0y9lLg1lDPAA/vflH//M0fYH1F6c/llh0tpn3ne68JISVEzEmep0YsHjYqbN66RyCjutdWsXdCy7MuPrWaPBNnhA7CVzhg8Q6L6Bgal6o4ytkmlMb2x+SRvqcpsOlE0IYYr1IKPjNJUu9YPdrbGy6ZqI6/vFIp928HV9bhAAouHLGUZeI0V3oBU6uBbwQgZnotwOJKqim8sEj009V9FqmGavvNyNfNXrImBSOdrMTrMCq9AuzORX+HFcnrgy4ngZOXt+rf9jxQAe2zooxrnbDVoLZ+8U/IZRHiwjeuc/gg2bJKfXP9N3YCxe26NsIppwQaA5KNGiJSk/OyVPtV60RCEU/dvJConAMa5QZLzbGaUKTrKZMqZHONzuogukKyRbRAUgMsHYknng8rIZies3Pe7pl3ACjsRyz8Ue+RXfOZY7UN59K7+KzubeRq59zl7mtSya2+Ld59SVwKD6LeqoiHQzhtXGN43RWsKT/pnDBvKOzy6on1cXmCuV7y041ERyp5ujRoMb053NJSDHyvolwSuOUYaCftnt6Xd0ZgYOPfVU2GSjdj9rg7cG6gVFOgR6DEayaELgOz/Ini/w2oXI8/l4/q/MJI+mqBEY52+2kue6Y3LKjTSXBDIyvmHG0rYJY06TaY5rtBFG+WPtAvakVYqj786TsZxtTQVjwiOAIceMatmEgT9BT74PXR64VJiYkz7JVg9nMmo7AiZfmQXyP8bgtxLFahAAp3EuVSleMdKEzIhD7RlH2x5wml6/7jtDwRP7F+0Jmbl0vhlxnDy5ZD9pKCCmvSe979adi/zxRD6zrqbbw5uhWaOk23sCvciNvZFywVmUdp8AaB8xKxLtopqkWOs58v0uMHlBG8JK/0YlOi9316bTPOZHkjHntOI7YG+SsYrsY5ZpppZqVnl+exkDteKTXURpSkzTCx2fzGPJfdUYptrB2E2b99YFMTjbLxEe07D/mLzJhBrfnZ3CdP6v5QnAA/wDD+dzTFTT1nqThKA5l0SJTiSdMWGvQh1cjayb8WJoLHVa24AjvQ1LYK5NFD2iYgmQ1RbgUFlOvcI8KBRV5ubzGls7sWJiRi3aEaaJzVJzx9945bqABAfiE/fn76KcysP7+Wvb+NdWZCXD2JPK5X0y61nATOZ6OigNCXDu0zO97Y6nYjd8ecCd9mWdef+tum66PwLVGaS2vAy0Xp5EgBb/F65vRqws+llqPzDgplfIAA0WJ+ZKKMnx2C0HzwlBKFlBlZjlmoqi7NJl1jQShDH9zoD+ayiIW1/GawYzs/IVJy8vrcajL8ocYw7sRtD4Fb6Woh9u0qP0hUbRMm69KCXou0XanqRbfc8aTTguqj4qHwKptTwu4TDAyu5fVqZUrYaS2v5vQ646hmPBWrbZ+0TNntQiUaz6EPC3H1ZWTXt6B7NgdRULqxzooAXDh9habgg1sG31lY3ltn3cbdvyrMvPBJKZU4dDYaDN0ixQWIZceGfr+Wsy11t45r3R2ELPwZ+dt0fvv3wks0er9QCi4oXMrgZzySjaCgI79PYkofOwjzYGPQM8fxiIRYiYOWq1mM96/iJUUFSsAPKRiE+WTDhxw5n48nM+PN58OlicHyH3OzZ8z/+T/0Kvrph9CwZyDGy+VE6V5CFacTcrR8yz0p8pWbbwtpvNXteqnR9+ZHMxPgjcEwcPyZTO/KQDLlaLh+njQwWQqVw4hlM9UIH/IGjKsIlLlah0SIhKvDr5eMtIvqfAmD6cJtWtSmzBhgBR2FPG3Er+DAgOvgBa0Cg4VBImT2JDpUK52lODLpBIfr7JoXyGpAbIiPz2Gg/KzUJoFk9p/4XFs4MKD9HpF2q007m5k4AVt3PnEOEECZrbQnAVVlQu4nNcHR2CuXo7Kw3yQFqEkhhAsZOAOOCSKAcRan9bXaNDPzTHVFZN7U/tcVJkrWTHF4a/pP0bPsGVHQmcXGd5HiRMouov01ckz+8F76hSQ/P0wQFxJaIFUipi/qVnwRWXctCPAC+qJwmLJHKj9NYQGNerU90UX9f9Z0RS8uLv3jp/j/B4l3NdsOLyG7BMg/QSJ+n0qcJgMUU3gvSjpeaDO5pL1IOl9W6LDCxcqtIKClofTeCJAAtHeJlFxSZeo5Mmz+3HwGvWBiuQlBIxJ2iKdznQNc6squQ9JGDnmsXQpRob+Ey/qoe9Xa/oD//gQuoyv73WlHnh1jxTNl1L+MB97wItG6iAAYHb9PjxTSuvadaYd2sDGHCPIzKes1ClyyJQH+rnSf7jKcc6VJ3BTMNM74kb6Tr3MJrErdHy4MU/oBkIflfxK/aU1zi+ykfAex6zu2U2C7Hu25tR9/E4DT5FgAWKk2qZtebH/H7D354u3s8RmnpQq0IvSKPkRcKXrq/G44Gyfg5Bs6dgsm9W8PDmjTGeb064UucggMEJ58pGpOB7f72M6xI2mCgS81QdrdPPUtPIBAdn8+wgp5BdX3mJD4NzJHjbZVDdPqtt22Bo8djiXKF25c4xX70/4YBM1HzUPcXkhKsL2tLnRyAxOTTYpwOwkk7aXsl7zRHNe9R4OGWQQjox07MytgZStkkPd6UC5EkVWAw2240f2qYVTpEYzik89lSVb8Tw0/XuiV4LJfB7tCqI7/w9tYsryGRtJmskmKiNF1VSmH444Y1Ka1GyIsWAcJO03bpDMoq8SLl0qro/mLI36NX/VV1FnvPWBF5A05OwhCh+sFO2imKMzD0ussvlhMFN5xjyDunh4Ofnpj4bIzwiZmRXqpLb0TP2l9J6OKrjpkS0GhZMbvC2x9QABB/PTdG7TCVLsl7uYcq6I2/NT4Z+QodeLVT/KENyd0dliZKSBipIsrtibKNiuOUiTHdeF62aMgATVzxQnUC9Da6tpIx6KKk4ppCSLOMXSQQFv4UoV7/DLIhHrY0I8OvCznA4P/Hb2t/MVfl/2Y7OpILBSW74rOoDMCcBoGZ/QPwGTWwSBvf8sw9XU5zX4Lp1sn41+lowsL/QgGPN6WyUZy5Uvqd2h8L1D2vNRetRbV2zQnmT64UeiiJqmTc7/5rTBhdw2wnK/K5cvvMYQhoitzjhEBPZxFbzt75riGwDmPXDc3SeM8HECozRJT3Alci1IoJaP2/9OzYceRuOZiT466Yo5ibVZcpkszN1GyaIMdlaxCBryK2kTkCAbLPdRxu9eoov5fl8cG9CNbvveCT4ii41vgUjuEYTxyxtQUx+ltDCApsYbUrAuu/jWcILBdk9DYlAiqRv8zCCKg4iVOidYeteygcX5k3oCWp17ddnxXQdEDSCBuTDrvMsoYwedq878eKEWUAA",xv="/assets/image3-CBEPi2OT.webp",yv=[{title:"Case Studies",text:"See how we solved real business challenges.",Icon:Dy},{title:"Media",text:"News, press and updates from TechTorch.",Icon:Dp},{title:"Company Profile",text:"Learn who we are and what we do.",Icon:rp},{title:"Quick Brochure",text:"A short overview of our services.",Icon:Uy}],vv=150;function bv(){const[s,d]=c.useState(!1),[x,f]=c.useState(0),y=c.useRef(null),E=c.useRef(null);c.useEffect(()=>{const N=()=>{if(!y.current)return;const R=y.current.closest("header, nav")||y.current;f(R.getBoundingClientRect().bottom)};return N(),window.addEventListener("resize",N),()=>window.removeEventListener("resize",N)},[s]);const S=c.useCallback(()=>{E.current&&(clearTimeout(E.current),E.current=null)},[]),C=c.useCallback(()=>{S(),d(!0)},[S]),M=c.useCallback(()=>{S(),E.current=setTimeout(()=>{d(!1),E.current=null},vv)},[S]);return c.useEffect(()=>{if(!s)return;const N=R=>R.key==="Escape"&&d(!1);return document.addEventListener("keydown",N),()=>document.removeEventListener("keydown",N)},[s]),c.useEffect(()=>()=>S(),[S]),i.jsxs("div",{ref:y,className:"relative h-full",onMouseEnter:C,onMouseLeave:M,children:[i.jsx("span",{className:`relative inline-flex items-center h-full cursor-pointer text-[17px] \r
        text-gray-900 hover:text-[#8a1538] \r
        transition-colors duration-200 \r
        after:absolute after:left-0 after:bottom-0 \r
        after:h-[2px] after:w-0 \r
        after:bg-[#8a1538] \r
        after:transition-all after:duration-200 \r
        hover:after:w-full`,children:"Insights"}),s&&i.jsx("div",{"data-nav-mega-menu":!0,style:{top:x},onMouseEnter:C,onMouseLeave:M,className:`fixed left-0 right-0 w-full max-h-[85vh] overflow-y-auto\r
          bg-white shadow-2xl z-[9999] border-t border-gray-100`,children:i.jsxs("div",{className:"grid gap-10 px-[6%] py-12 lg:grid-cols-[1fr_minmax(320px,32%)] lg:gap-14",children:[i.jsxs("div",{children:[i.jsx("p",{className:"m-0 mb-2 text-[11px] font-bold uppercase tracking-[0.14em] text-[#8a1538]",children:"Insights"}),i.jsx("h3",{className:"m-0 mb-2 font-plus-jakarta text-[26px] font-semibold leading-[1.2] text-gray-900",children:"Explore our work and ideas"}),i.jsx("p",{className:"m-0 mb-8 max-w-[520px] font-inter text-[14px] leading-[1.6] text-gray-500",children:"Stories, updates and resources from the TechTorch team."}),i.jsx("div",{className:"grid gap-4 sm:grid-cols-2",children:yv.map(({title:N,text:R,Icon:O})=>i.jsxs(ve,{to:mn(N),onClick:()=>d(!1),className:`group flex items-start gap-4 rounded-xl border border-gray-100 \r
                    bg-white p-5 no-underline transition-all duration-200 \r
                    hover:border-[#8a1538]/30 hover:bg-[#fdf5f8] hover:shadow-md`,children:[i.jsx("span",{className:"flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-[#fdf0f6] text-[#8a1538]",children:i.jsx(O,{size:20,strokeWidth:1.7})}),i.jsxs("span",{className:"min-w-0 flex-1",children:[i.jsxs("span",{className:"flex items-center justify-between gap-2 font-plus-jakarta text-[16px] font-semibold text-gray-900 group-hover:text-[#8a1538]",children:[N,i.jsx(mt,{size:16,className:"shrink-0 -translate-x-1 opacity-0 transition-all duration-200 group-hover:translate-x-0 group-hover:opacity-100"})]}),i.jsx("span",{className:"mt-1 block font-inter text-[13px] leading-[1.5] text-gray-500",children:R})]})]},N))})]}),i.jsxs("div",{className:"flex flex-col gap-5",children:[i.jsxs("div",{className:"relative min-h-[240px] flex-1 overflow-hidden rounded-2xl",children:[i.jsx("img",{src:xv,alt:"",className:"absolute inset-0 h-full w-full object-cover",style:{height:"100%",width:"100%",maxWidth:"none"}}),i.jsx("div",{className:"absolute inset-0",style:{background:"linear-gradient(to top, rgba(0,0,0,0.78) 0%, rgba(0,0,0,0.25) 55%, rgba(0,0,0,0.05) 100%)"}}),i.jsxs("div",{className:"relative flex h-full min-h-[240px] flex-col justify-between p-6 text-white",children:[i.jsx("span",{className:"w-fit rounded-full bg-white/15 px-3 py-1 font-plus-jakarta text-[11px] font-semibold uppercase tracking-[0.1em] backdrop-blur",children:"Latest Update"}),i.jsxs("div",{children:[i.jsx("p",{className:"m-0 font-plus-jakarta text-[18px] font-semibold leading-[1.35]",children:"TorchX Suite: Bringing Business Operations Together"}),i.jsxs(ve,{to:"/field-note",onClick:()=>d(!1),className:"mt-4 inline-flex items-center gap-2 font-inter text-[13px] font-bold uppercase tracking-wide text-white no-underline hover:text-gray-200",children:["Read more ",i.jsx(mt,{size:15})]})]})]})]}),i.jsxs("div",{className:"relative min-h-[170px] overflow-hidden rounded-2xl",children:[i.jsx("img",{src:gv,alt:"",className:"absolute inset-0 h-full w-full object-cover",style:{height:"100%",width:"100%",maxWidth:"none"}}),i.jsx("div",{className:"absolute inset-0",style:{background:"linear-gradient(to top, rgba(0,0,40,0.75) 0%, rgba(0,0,40,0.15) 60%, rgba(0,0,40,0) 100%)"}}),i.jsxs("div",{className:"relative flex h-full min-h-[170px] flex-col justify-between p-6 text-white",children:[i.jsx("span",{className:"w-fit rounded-full bg-white/15 px-3 py-1 font-plus-jakarta text-[11px] font-semibold uppercase tracking-[0.1em] backdrop-blur",children:"Upcoming Event"}),i.jsxs(ve,{to:"/think-ahead",onClick:()=>d(!1),className:"inline-flex items-center gap-2 font-inter text-[13px] font-bold uppercase tracking-wide text-white no-underline hover:text-gray-200",children:["View event ",i.jsx(mt,{size:15})]})]})]})]})]})})]})}const _v="data:image/webp;base64,UklGRgoPAABXRUJQVlA4WAoAAAAQAAAAuAEAqgEAQUxQSDEAAAABFyAQSFLZH3KNiAgHM23blGRJjmvfOaL/E9Cx4T/+4z/+4z/+4z/+4z/++yjw340NAFZQOCCyDgAAkHMAnQEquQGrAT5tNphJJDgtKKIzKIsADYlnbvhMZys6cqnv05qdUOx7X3/qbr7zCBAqF9VW6O+f/0/Ug4L4jdECOTynzu/MA/QzcAf//0//P/vnPyANVeo6PKr/t4Sz07pXaviuXtH6Ux5klf8mn/067wYxnms1AP07/frstftP///cA/Uf////8OLXU6jOmEj3ocaKHnlXZVt48adaRCFntIUZ1Cv+WL+s4FpU4RhVsSotRxxW/CZQJgYF+3kCQEgoiYhxcp8FF36FW2e5BbBBThz1+ywMkLacQk15G0dogFxey1XT5UE7eVkPdfhYf74qpu3931BxAK79HXlb7+fOkJOYs4HPZoBZeco6l00NKAZU/Esj3ZOsMzB3RY/B/9/Bp1R3sOZTZcwZW7cQwuaYXKruMOnWSkAQsnCyIq2ratq2rU9aq/V/0rMp6cXhlJVgLTYAIDlBMpxmeoUK/DD5kURXXZyyXG6yJAydqRvA1e6jJNWlSXpJlAZBI72j42VAEFL9bESPgwJ+60AYyHDVoBavh2pnyeWn9iX13r+cr0x2SbAngkryfNJVVHuUS5kFjK1fJyNR2bRCifdoW1eHiNLMrGwtQ9HNX2p9JaOtKvU74eJxyuix32FBtrI7Mv/sDe4Lv63XNb+83Un/63xGRFqo0zfqRYPkwMpOqg3pQqxZEv80CVBMPhbOoOyYbs9RkihDScpKBhxFNWpbdtI+L0YftaIcXB9QZAnxwxJzZQSaDLVqR2KzQY1fRwAF4phk3nxdRlL2XdfKhiWUZsIK1bPxdAADUt1ouM0oUdHNwsz/m+b9vFQkQqWuzZbz4pXawGvmCpcmBPTeS5e6IP0/dymD6+sN/L5UGUdVIz9zeERsEqeZrxejxn7IQIswY8DJ9QCbvTol2YPD7i/eX6+LEwyxwh1a8q6+xcmBk++HamegSZZPtUKJA1uOVW9LgNFaLjLoqLqSB4Iw6Yc/aJ8LilXK0QWv1NTDDAhn32CziHUva5TJ+T2GzBSXs/+0BWUIcatsOCWM58nXCzoIhHqHutQu/CUIILHwwr7ENAaaj+w8Q8VUnm2F2bNPP0dN18O1FK9xR0THwO1dPBHb4Qbl+Lfs+1zPM91UKis2BmQ9bwXPPouTTp/JY5z8R6/UZPQ6hFQ9ogcXK4eoYtQqO+KDBa+Hh8v1P20OwVEzNFephFx6UAlXnA6kXjg9Fh+WXGwwRFoTAoqXngj6VIB6NZwp/Q8wAP7zAY8t+2mTZTZf8kDKRTPm8G8ekYpCuYHa1eQtckBM1Ggyiw94d9Z8/OhqkU58xK9/rWv+2lRHEk21wt3k+eMdITSgsCSyaLKjiXov4WI8OibUNZ9iSfgVdw5uSDRMjnOxr30hJBaiStYFToV3DmTCu4c2/Yt6AKD3va7A+KpT/iDRMjr6O3iHJU9b+hKU4yBgcjud1Wp3IHc8W8MyHuqpFmzJHiI7/Cl5hC0M/UVwxWl/m5sz7ZI/sPWc9x3d60oez7od0mWhxxoNI518SNINI518SNbLqlKs+ZAai/iW0C8HHH8B2gXg44/q0T8x/3V03OJVL8PfIZySByM0A6nw+VlgbJdLx8K3JZHCWOp8O49ClH/+srYQ3/wazLxbv6EzHry/iGfxWJf3C168zoQnLipjzIChDDa5stO7+X7VQCImT11cNs+J53khpbhUxy5cBp0dHFmAp3YKE0BI3Ye8pUsxVCL5MhEP8NhCnGJ9aVlSCiIhS2Vckw3Sv9Gj0Jh5TVF++1DeesuhYVQZCM6vFJpOhay11F6OV/2VqFI6V7Ul8cdoLt27twFdxQ923zTkg44/tRGXZIiyMZoKRqpOkutWwJoQQn5+vmBSITZEMxO3ptcibPmfRbWDUfmo3EdpJBP+Y9D0pxFvWLLd26U6x7d8A3IzsVC5RKAYgd4cufTr/Ij/L05T7TJ+d9xFHALvxTyh4r8aznZcRII+IzDEJO6HXwRtESq57dWPNt5dQsbhNpPfCeopWlxp196Bu5C1RtlsXC8u2+M/4bLeUXFlz+GNXuXQPjLJlT2rQvmRoQh1bf5zK/7amWxSIe2TFA84rPaDw5T3/Pbvv0+Ag44779LneKHv8hRWEJwDImZzn7LvjT2VUKnlV6AOAP7akaRyVenpKxmNNNXcIi19wGTX4OX32Zkmvur1YdVFs2MzYHY8KDfTgjyRuEXkYV2JpK9ouBZhhYv45ZQksSB80J1iIDk1nUQD+FAFC4BvJUPXmCMbueqgkmbRRbtkNIdB0dpSnvgm3pCeoEgfsqDKEpRRRSKSQVGdoDKsGmRnIM0SljKbqkF/kqMvXXADakBuf8M4PlEnO3CxC9r5A7SBR7R06Rzr47tXLLH4SRf87zM85YdF335pW1djNshz5/3Nn/w+hB0TS5zuHQPrvQflxPspJimIa8sfAC+ZHkhFZa9IErFSZfB407paPbBHBUZ721/FcJnbKZ5/VvWVwmPOI1nZxwrDtHQ/6Ls/xQoAkp8dSD9Sl3TtOa+VdAC+wWlaTU6hAscpERLs8YuM6uMM7G+bYJeGXcNjX3FOlv38l4RnzQLwwuLLgyrDI+jGf5F5/QFtn+eCcyr0oBS7qVLtoyhjWOcc+8Yx+5+LkVpkKXsFwnNZP/PPJroG12U9MHeFQonqTvjGrPN0jcHh81X7d1UPiadfb5bVI24F8GNaumm/GxMvyLZBV9DvI6abiKE7Ftjf0/ZBJLObp2xbmyAloYxWZr+wnBP28hYkRcVFeD9AC0ktARv8pRdd22JG/nuE+27aWPbityeER/9K1n0OyLr4qHk0w5oAhkI7N2EjAc+PAJyRPNGW2KREyw+tlz03texbob1Fr+BVV3R2VWodQl36Ln9QlneUJExu0cvFjwaWcBzSkJpq58hK0rGvvvuiAA+d+MvBtHl7wJHfojaIpaqD8O6ZLrEUWaPgquSsq0pGHh+rv575foWgjSlvVn4W/LJXKtd9tZuHtWjLh1v5YzK0naQcSbDBQJLq/DV/HpNIb4vRqMSkQUQSWdHKarSzqvZYUjyHl6XHmpFKHfgvUyIh0enWXijY5JD6xz4t3baY3JOVsY/ZrJfvVRGMP7qM0gcSGSVOqVgW+FpcZW6wOLeNFaY5Fs/ulXPTCb4mz/xncheZTDh7a2fcOqrC+aGlnMLRklzk3RkTeu/Df6u3uOJtQDSoPmFW63BOcwq1hdPxD0Hjf4wJOf8D96oNmDq+BGfnQu746HFanvpqpdcv+SvVUSHEhWnAWGVJOxRCN3GuatI3erxvbSvVKCGdZB6WdKtgJoNuxGPqAAo7qqmv7kOv4XUP9Bg3a9vN4A9WdJH9lnHuzXbfMpp+djhUPLHEPssbKyq8bk9A00ZmgFr+YHyxghY0C9wd2yJuDSyRRSc5fdiKKBJ5rtoXcxg6mOVTeoQ5vffDfnbVe1yZC0LVjxKDukMNjogIMzP8WUfaBE6DFrUfoNZ/3TD9dfmeDZqRvE77R62Kb20jrVuAHnrQ7A/0VDlSBu40tQ32PjEjk05F6/l/H/qHUD/7WtT/8Zb+7yEY+2GfJBeVThgal5x+gIFH+wSzHCuWAoTtZlazygz/eXKJrSkn3e9ucoNKUsGVPT3T35Jcv1vKTt0dkRBr9Qs5a/FfnFCXgYrxWJudxQbORB1CkxrtH9lSGZ9dL1BixMz+Zr3UClzg+QuNKITJIsUF144Vt2vLdWxXLHZvqndsiYJWddqEtjRvJa8bQ4ePTspa/JM+0yR6MfeEkmVjQnytGJQUdlGx+KIs12olyvjuYfrYVZwUVCm4l1mnTjp63+wcZXGmrPa/dSRQ7sDDZ119Lqk66Ta9hdveCmrGaoG/Yn+hLm/do5h2D9Xl4i9SNs2+FXQzdE8SY5ygD96HLP41aOOyV8892L4rS7egx8C2hdsRrf8PG1vjSU+nJBkfUWUGxU8wNxHNtSOGUF2/RkcfSk0xKxQQh4QS+xmgI8cayb3uU7MRP7xuy4JHMqS85ro+ONLgSthDGY8iMWtOARMyrPT7LOpdloOwUhzpxwDgg+B8/g4QSUTCRV5Ag72XQGlZah6c4oTdVrdJ0KnyGv9HO6E12XyGwMyQiSBQhMsIQiqcygoVexfiZ7YKMBXI2UYj9ONyGT5EiDRrVORiEyko++Wc7WSZMoYtfK6qa4idcvDln/yr5Nk9gOP71r5TTOUm+QgDlrlckhFCsSBCuGtAS2pr6JBfIPNqmAMrdsHXsyPlg3omto5guqw2SSazoBTNkbL2vJ41M820LJYEaPH8Fz6d3HhDifEYISE8w1nFPhDWeHqZSH0VwYz9akHaXod3zXSkuxThHc8/u+eG2xArXWdSvfCQx9hhhjm4DinsYyiQxI/8VUHD+inPjpY1LmzC1yBhw63uLxxVaAAGPGzmJIyDrVxgABqUqtoJpdyyu2UuDzadXq1lwcpvtWZyzovLgkxyqWLbt2fRF6c30kc1gNZwXcxo28BWFjJfVHbjXQ0FTgIACVgcnq70wLC4Nhtmm4FbPaRRuztG90rFjbgvz9kRoEpCj20XTeYsFH8Pcp/EE1iFZbW0MAUDhSD4sjjCqOOXrPdZdmBInwXCEil/QxXSbOw9Vhs4dOqYCf/itDM5UWrscABjsLIVQcatbSgOyYAweSzqE3sjwWzWCAvTi7sTqr6cVMbwRVcWELYtjYuwY6YvABZUoXXSNCi/QCDwmPAIxYh9wNIVyy0ArQzNjxPSb8qQAnMC1AgK/DFhfQ76GALlaNs78/ZtbuEUpPlL4qXxPhcG9fdgdWc4w1YQg3eAliwdLDF9Ak41N8BUWKvaKv0fPXR1Z/YIif7wNinzOvL7wxXsOkgzENny9AYakxoRegACIORl6hWaM7C6+MDpRBQSmgUKnTBSwD0Bymr9SeiwD9wTdU2rscQkYPngm2I2HsLs66cjnT3Gwt8v7wtfkRhGPLZkAAf4Q/Als8k0MQa1TftW65RcnHJikW4RpswZrefC5eSFOWrmv8pIIKsLKFjCoDSuYAAA",Tv="/assets/image5-W61OZafA.webp",Ev=[{title:"The TechTorch Way",text:"How we think, work and deliver.",Icon:My},{title:"Culture & Inclusion",text:"The people and values behind TechTorch.",Icon:cu},{title:"Join Us",text:"Explore open roles and grow with us.",Icon:o1}],wv=150;function jv(){const[s,d]=c.useState(!1),[x,f]=c.useState(0),y=c.useRef(null),E=c.useRef(null);c.useEffect(()=>{const N=()=>{if(!y.current)return;const R=y.current.closest("header, nav")||y.current;f(R.getBoundingClientRect().bottom)};return N(),window.addEventListener("resize",N),()=>window.removeEventListener("resize",N)},[s]);const S=c.useCallback(()=>{E.current&&(clearTimeout(E.current),E.current=null)},[]),C=c.useCallback(()=>{S(),d(!0)},[S]),M=c.useCallback(()=>{S(),E.current=setTimeout(()=>{d(!1),E.current=null},wv)},[S]);return c.useEffect(()=>{if(!s)return;const N=R=>R.key==="Escape"&&d(!1);return document.addEventListener("keydown",N),()=>document.removeEventListener("keydown",N)},[s]),c.useEffect(()=>()=>S(),[S]),i.jsxs("div",{ref:y,className:"relative h-full",onMouseEnter:C,onMouseLeave:M,children:[i.jsx("span",{className:`relative inline-flex items-center h-full cursor-pointer text-[17px] \r
        text-gray-900 hover:text-[#8a1538] \r
        transition-colors duration-200 \r
        after:absolute after:left-0 after:bottom-0 \r
        after:h-[2px] after:w-0 \r
        after:bg-[#8a1538] \r
        after:transition-all after:duration-200 \r
        hover:after:w-full`,children:"Careers"}),s&&i.jsx("div",{"data-nav-mega-menu":!0,style:{top:x},onMouseEnter:C,onMouseLeave:M,className:`fixed left-0 right-0 w-full max-h-[85vh] overflow-y-auto\r
          bg-white shadow-2xl z-[9999] border-t border-gray-100`,children:i.jsxs("div",{className:"grid gap-10 px-[6%] py-12 lg:grid-cols-[1fr_minmax(320px,32%)] lg:gap-14",children:[i.jsxs("div",{children:[i.jsx("p",{className:"m-0 mb-2 text-[11px] font-bold uppercase tracking-[0.14em] text-[#8a1538]",children:"Careers"}),i.jsx("h3",{className:"m-0 mb-2 font-plus-jakarta text-[26px] font-semibold leading-[1.2] text-gray-900",children:"Build your career with us"}),i.jsx("p",{className:"m-0 mb-8 max-w-[520px] font-inter text-[14px] leading-[1.6] text-gray-500",children:"Our people, our culture and the opportunities at TechTorch."}),i.jsx("div",{className:"grid gap-4 sm:grid-cols-2",children:Ev.map(({title:N,text:R,Icon:O})=>i.jsxs(ve,{to:mn(N),onClick:()=>d(!1),className:`group flex items-start gap-4 rounded-xl border border-gray-100 \r
                    bg-white p-5 no-underline transition-all duration-200 \r
                    hover:border-[#8a1538]/30 hover:bg-[#fdf5f8] hover:shadow-md`,children:[i.jsx("span",{className:"flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-[#fdf0f6] text-[#8a1538]",children:i.jsx(O,{size:20,strokeWidth:1.7})}),i.jsxs("span",{className:"min-w-0 flex-1",children:[i.jsxs("span",{className:"flex items-center justify-between gap-2 font-plus-jakarta text-[16px] font-semibold text-gray-900 group-hover:text-[#8a1538]",children:[N,i.jsx(mt,{size:16,className:"shrink-0 -translate-x-1 opacity-0 transition-all duration-200 group-hover:translate-x-0 group-hover:opacity-100"})]}),i.jsx("span",{className:"mt-1 block font-inter text-[13px] leading-[1.5] text-gray-500",children:R})]})]},N))})]}),i.jsxs("div",{className:"flex flex-col gap-5",children:[i.jsxs("div",{className:"relative min-h-[240px] flex-1 overflow-hidden rounded-2xl",children:[i.jsx("img",{src:_v,alt:"",className:"absolute inset-0 h-full w-full object-cover",style:{height:"100%",width:"100%",maxWidth:"none"}}),i.jsx("div",{className:"absolute inset-0",style:{background:"linear-gradient(to top, rgba(0,0,0,0.78) 0%, rgba(0,0,0,0.25) 55%, rgba(0,0,0,0.05) 100%)"}}),i.jsxs("div",{className:"relative flex h-full min-h-[240px] flex-col justify-between p-6 text-white",children:[i.jsx("span",{className:"w-fit rounded-full bg-white/15 px-3 py-1 font-plus-jakarta text-[11px] font-semibold uppercase tracking-[0.1em] backdrop-blur",children:"Featured Story"}),i.jsxs("div",{children:[i.jsx("p",{className:"m-0 font-plus-jakarta text-[18px] font-semibold leading-[1.35]",children:"Life & Culture at TechTorch"}),i.jsxs(ve,{to:mn("Culture & Inclusion"),onClick:()=>d(!1),className:"mt-4 inline-flex items-center gap-2 font-inter text-[13px] font-bold uppercase tracking-wide text-white no-underline hover:text-gray-200",children:["Read more ",i.jsx(mt,{size:15})]})]})]})]}),i.jsxs("div",{className:"relative min-h-[170px] overflow-hidden rounded-2xl",children:[i.jsx("img",{src:Tv,alt:"",className:"absolute inset-0 h-full w-full object-cover",style:{height:"100%",width:"100%",maxWidth:"none"}}),i.jsx("div",{className:"absolute inset-0",style:{background:"linear-gradient(to top, rgba(20,0,40,0.75) 0%, rgba(20,0,40,0.15) 60%, rgba(20,0,40,0) 100%)"}}),i.jsxs("div",{className:"relative flex h-full min-h-[170px] flex-col justify-between p-6 text-white",children:[i.jsx("span",{className:"w-fit rounded-full bg-white/15 px-3 py-1 font-plus-jakarta text-[11px] font-semibold uppercase tracking-[0.1em] backdrop-blur",children:"Opportunities"}),i.jsxs(ve,{to:mn("Join Us"),onClick:()=>d(!1),className:"inline-flex items-center gap-2 font-inter text-[13px] font-bold uppercase tracking-wide text-white no-underline hover:text-gray-200",children:["View opportunities ",i.jsx(mt,{size:15})]})]})]})]})]})})]})}const Sv={"Artificial Intelligence (AaaS)":"ai machine learning ml automation","Cloud Infrastructure Services (IaaS)":"cloud aws azure hosting migration devops","Cyber Security":"security protection threat compliance","IT Consultancy":"consulting advisory strategy roadmap","Software Engineering Outsourcing":"engineering development outsourcing","Software Development & Support":"custom software app development maintenance support","Resource and Staffing":"staffing hiring talent resources augmentation","TorchX Suite":"platform hr talent product","TorchX Campus":"platform education campus",News:"blog blogs articles updates","Join Us":"careers jobs hiring work apply",ERP:"enterprise resource planning",CRM:"customer relationship management sales","Customer Centricity":"know more brochure"},zv=[{label:"Contact Us",path:"/start-conversation",keywords:"contact enquiry get in touch office address phone email location map noida bareilly"},{label:"Talk to an Expert",path:"/talk-to-expert",keywords:"expert consultation call speak book"},{label:"Ask a Question",path:"/explore-questions",keywords:"faq help questions support"},{label:"Our Services",path:"/OurService",keywords:"services portfolio offerings"},{label:"IT Augmentation",path:"/ItAugmentation",keywords:"staffing contract hiring bench remote offshore dedicated team"},{label:"Explore Solutions",path:"/explore-solutions",keywords:"solutions products"}],Av=["IT Consultancy","Artificial Intelligence (AaaS)","Cloud Infrastructure Services (IaaS)","Cyber Security","Contact Us","Join Us"],Ov=8,Km=(()=>{const s=new Set,d=[],x=(f,y,E="")=>{s.has(f)||(s.add(f),d.push({label:f,path:y,keywords:E,haystack:`${f} ${E}`.toLowerCase()}))};return Object.entries(a0).forEach(([f,y])=>x(f,y,Sv[f]||"")),zv.forEach(f=>x(f.label,f.path,f.keywords)),d})();function Nv(s){const d=s.trim().toLowerCase();if(!d)return Av.map(f=>Km.find(y=>y.label===f)).filter(Boolean);const x=d.split(/\s+/);return Km.map(f=>{if(!x.every(S=>f.haystack.includes(S)))return null;const y=f.label.toLowerCase();let E=0;return y===d&&(E+=10),y.startsWith(d)&&(E+=6),y.includes(d)&&(E+=4),x.forEach(S=>{y.split(/[\s&()/-]+/).some(C=>C.startsWith(S))?E+=2:y.includes(S)&&(E+=1)}),{page:f,score:E}}).filter(Boolean).sort((f,y)=>y.score-f.score||f.page.label.localeCompare(y.page.label)).slice(0,Ov).map(f=>f.page)}function Dv({onClose:s}){const d=El(),[x,f]=c.useState(""),[y,E]=c.useState(0),S=c.useRef(null),C=c.useRef(null),M=c.useMemo(()=>Nv(x),[x]);c.useEffect(()=>{S.current?.focus();const O=document.body.style.overflow;document.body.style.overflow="hidden";const D=ie=>{ie.key==="Escape"&&s()};return document.addEventListener("keydown",D),()=>{document.body.style.overflow=O,document.removeEventListener("keydown",D)}},[s]),c.useEffect(()=>E(0),[x]),c.useEffect(()=>{C.current?.children[y]?.scrollIntoView({block:"nearest"})},[y]);const N=O=>{s(),d(O.path)},R=O=>{O.key==="ArrowDown"?(O.preventDefault(),E(D=>Math.min(D+1,M.length-1))):O.key==="ArrowUp"?(O.preventDefault(),E(D=>Math.max(D-1,0))):O.key==="Enter"&&M[y]&&(O.preventDefault(),N(M[y]))};return $m.createPortal(i.jsxs("div",{className:"site-search-backdrop",onClick:s,role:"dialog","aria-modal":"true","aria-label":"Search TechTorch",children:[i.jsxs("div",{className:"site-search-box",onClick:O=>O.stopPropagation(),children:[i.jsxs("div",{className:"site-search-input-row",children:[i.jsx(t1,{size:20,strokeWidth:2.2,className:"site-search-icon"}),i.jsx("input",{ref:S,type:"text",value:x,onChange:O=>f(O.target.value),onKeyDown:R,placeholder:"Search services, industries, pages…","aria-label":"Search the website","data-no-auth-guard":!0,autoComplete:"off",spellCheck:"false"}),i.jsx("button",{type:"button",className:"site-search-close",onClick:s,"aria-label":"Close search",children:i.jsx(fr,{size:18,strokeWidth:2.4})})]}),i.jsx("p",{className:"site-search-label",children:x.trim()?"RESULTS":"POPULAR PAGES"}),M.length>0?i.jsx("ul",{className:"site-search-list",ref:C,role:"listbox",children:M.map((O,D)=>i.jsx("li",{role:"option","aria-selected":D===y,children:i.jsxs("button",{type:"button",className:`site-search-item ${D===y?"is-active":""}`,onClick:()=>N(O),onMouseEnter:()=>E(D),children:[i.jsxs("span",{className:"site-search-item-text",children:[i.jsx("strong",{children:O.label}),i.jsx("small",{children:O.path})]}),i.jsx(mt,{size:16,strokeWidth:2.2})]})},O.label))}):i.jsxs("div",{className:"site-search-empty",children:[i.jsxs("p",{children:["No pages found for “",x.trim(),"”."]}),i.jsxs("button",{type:"button",onClick:()=>N({path:"/start-conversation"}),children:["Talk to our team instead",i.jsx(mt,{size:14,strokeWidth:2.2})]})]}),i.jsxs("p",{className:"site-search-hint",children:[i.jsx("kbd",{children:"↑"})," ",i.jsx("kbd",{children:"↓"})," to move · ",i.jsx("kbd",{children:"Enter"})," to open ·"," ",i.jsx("kbd",{children:"Esc"})," to close"]})]}),i.jsx("style",{children:`
        .site-search-backdrop {
          position: fixed;
          inset: 0;
          z-index: 100001;
          display: flex;
          justify-content: center;
          align-items: flex-start;
          padding: 90px 16px 24px;
          background: rgba(15, 8, 20, 0.55);
          backdrop-filter: blur(3px);
          overflow-y: auto;
          animation: siteSearchFade 0.2s ease-out;
        }

        .site-search-box {
          width: 100%;
          max-width: 620px;
          background: #ffffff;
          border-radius: 18px;
          padding: 16px;
          box-shadow: 0 30px 70px rgba(0, 0, 0, 0.4);
          animation: siteSearchPop 0.25s cubic-bezier(0.16, 1, 0.3, 1);
          font-family: "Inter", sans-serif;
        }

        .site-search-input-row {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 0 6px 12px;
          border-bottom: 1px solid #eeeeee;
        }

        .site-search-icon {
          flex: 0 0 auto;
          color: #8a0048;
        }

        .site-search-input-row input {
          flex: 1;
          min-width: 0;
          height: 44px;
          border: none;
          outline: none;
          background: transparent;
          font-size: 16px;
          color: #121826;
          font-family: "Inter", sans-serif;
        }

        .site-search-input-row input::placeholder {
          color: #aab0ba;
        }

        .site-search-close {
          flex: 0 0 auto;
          width: 32px;
          height: 32px;
          display: flex;
          align-items: center;
          justify-content: center;
          border: none;
          border-radius: 50%;
          background: #f3f4f6;
          color: #555;
          cursor: pointer;
          transition: background 0.2s ease, color 0.2s ease;
        }

        .site-search-close:hover {
          background: #8a0048;
          color: #ffffff;
        }

        .site-search-label {
          margin: 14px 8px 6px;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.06em;
          color: #8b93a0;
        }

        .site-search-list {
          list-style: none;
          margin: 0;
          padding: 0;
          max-height: 52vh;
          overflow-y: auto;
        }

        .site-search-item {
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 11px 12px;
          border: none;
          border-radius: 12px;
          background: transparent;
          text-align: left;
          cursor: pointer;
          color: #8a0048;
        }

        .site-search-item.is-active {
          background: #fcecf4;
        }

        .site-search-item-text {
          display: flex;
          flex-direction: column;
          gap: 2px;
          min-width: 0;
        }

        .site-search-item-text strong {
          font-size: 14px;
          font-weight: 600;
          color: #121826;
        }

        .site-search-item-text small {
          font-size: 11px;
          color: #8b93a0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .site-search-empty {
          padding: 22px 12px 14px;
          text-align: center;
        }

        .site-search-empty p {
          margin: 0 0 12px;
          font-size: 14px;
          color: #5b6472;
        }

        .site-search-empty button {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          border: none;
          background: transparent;
          color: #8a0048;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
        }

        .site-search-hint {
          margin: 12px 8px 0;
          padding-top: 12px;
          border-top: 1px solid #eeeeee;
          font-size: 11px;
          color: #9aa1ad;
        }

        .site-search-hint kbd {
          padding: 1px 6px;
          border: 1px solid #e1e4e8;
          border-radius: 5px;
          background: #f7f8fa;
          font-family: inherit;
          font-size: 10px;
          color: #5b6472;
        }

        @media (max-width: 600px) {
          .site-search-backdrop { padding-top: 70px; }
          .site-search-hint { display: none; }
        }

        @keyframes siteSearchFade {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        @keyframes siteSearchPop {
          from { opacity: 0; transform: translateY(-10px) scale(0.98); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }

        @media (prefers-reduced-motion: reduce) {
          .site-search-backdrop,
          .site-search-box { animation: none; }
        }
      `})]}),document.body)}const wa="https://torchxsuite.com/",Cv=[{title:"TorchX Talent",text:"Hiring, onboarding and people management.",Icon:cu,url:"https://torchxsuite.com/talent/"},{title:"TorchX Finance",text:"Accounts, billing and financial control.",Icon:s1,url:wa},{title:"TorchX Suite",text:"Everything your business needs, in one platform.",Icon:Gy,url:wa},{title:"TorchX Engage",text:"Customer and stakeholder engagement.",Icon:Jy,url:wa},{title:"TorchX Inventory",text:"Stock, warehouses and supply tracking.",Icon:Wy,url:wa},{title:"TorchX Pay",text:"Payments and transactions made simple.",Icon:ky,url:wa},{title:"TorchX Spark",text:"Fast ideas and tools to get you moving.",Icon:Kp,url:"https://torchxsuite.com/spark/"},{title:"TorchX Sync",text:"Keep your systems and data connected.",Icon:e1,url:"https://torchxsuite.com/sync/"}],Rv=150,Pm=s=>{window.open(s,"_blank","noopener,noreferrer")};function Lv(){const[s,d]=c.useState(!1),[x,f]=c.useState(0),y=c.useRef(null),E=c.useRef(null);c.useEffect(()=>{const N=()=>{if(!y.current)return;const R=y.current.closest("header, nav")||y.current;f(R.getBoundingClientRect().bottom)};return N(),window.addEventListener("resize",N),()=>window.removeEventListener("resize",N)},[s]);const S=c.useCallback(()=>{E.current&&(clearTimeout(E.current),E.current=null)},[]),C=c.useCallback(()=>{S(),d(!0)},[S]),M=c.useCallback(()=>{S(),E.current=setTimeout(()=>{d(!1),E.current=null},Rv)},[S]);return c.useEffect(()=>{if(!s)return;const N=R=>R.key==="Escape"&&d(!1);return document.addEventListener("keydown",N),()=>document.removeEventListener("keydown",N)},[s]),c.useEffect(()=>()=>S(),[S]),i.jsxs("div",{ref:y,className:"relative h-full",onMouseEnter:C,onMouseLeave:M,children:[i.jsx("span",{className:`relative inline-flex items-center h-full cursor-pointer text-[17px] \r
        text-gray-900 hover:text-[#8a1538] \r
        transition-colors duration-200 \r
        after:absolute after:left-0 after:bottom-0 \r
        after:h-[2px] after:w-0 \r
        after:bg-[#8a1538] \r
        after:transition-all after:duration-200 \r
        hover:after:w-full`,children:"Product"}),s&&i.jsx("div",{"data-nav-mega-menu":!0,style:{top:x},onMouseEnter:C,onMouseLeave:M,className:`fixed left-0 right-0 w-full max-h-[85vh] overflow-y-auto\r
          bg-white shadow-2xl z-[9999] border-t border-gray-100`,children:i.jsxs("div",{className:"grid gap-10 px-[6%] py-12 lg:grid-cols-[1fr_minmax(320px,32%)] lg:gap-14",children:[i.jsxs("div",{children:[i.jsx("p",{className:"m-0 mb-2 text-[11px] font-bold uppercase tracking-[0.14em] text-[#8a1538]",children:"Product"}),i.jsx("h3",{className:"m-0 mb-2 font-plus-jakarta text-[26px] font-semibold leading-[1.2] text-gray-900",children:"Get to know TorchX"}),i.jsx("p",{className:"m-0 mb-8 max-w-[520px] font-inter text-[14px] leading-[1.6] text-gray-500",children:"Connected business products that work on their own or together."}),i.jsx("div",{className:"grid gap-4 sm:grid-cols-2",children:Cv.map(({title:N,text:R,Icon:O,url:D})=>i.jsxs("a",{href:D,target:"_blank",rel:"noopener noreferrer",onClick:ie=>{ie.preventDefault(),Pm(D),d(!1)},className:`group flex items-start gap-4 rounded-xl border border-gray-100 \r
                    bg-white p-5 no-underline transition-all duration-200 \r
                    hover:border-[#8a1538]/30 hover:bg-[#fdf5f8] hover:shadow-md`,children:[i.jsx("span",{className:"flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-[#fdf0f6] text-[#8a1538]",children:i.jsx(O,{size:20,strokeWidth:1.7})}),i.jsxs("span",{className:"min-w-0 flex-1",children:[i.jsxs("span",{className:"flex items-center justify-between gap-2 font-plus-jakarta text-[16px] font-semibold text-gray-900 group-hover:text-[#8a1538]",children:[N,i.jsx(mt,{size:16,className:"shrink-0 -translate-x-1 opacity-0 transition-all duration-200 group-hover:translate-x-0 group-hover:opacity-100"})]}),i.jsx("span",{className:"mt-1 block font-inter text-[13px] leading-[1.5] text-gray-500",children:R})]})]},N))})]}),i.jsx("div",{className:"flex flex-col",children:i.jsxs("div",{style:{background:"linear-gradient(135deg,#8a1538,#2a0612)"},className:"relative min-h-[320px] flex-1 overflow-hidden rounded-2xl",children:[i.jsx("img",{src:l0,alt:"",className:"absolute inset-0 h-full w-full object-cover",style:{height:"100%",width:"100%",maxWidth:"none"}}),i.jsx("div",{className:"absolute inset-0",style:{background:"linear-gradient(to top, rgba(42,6,18,0.85) 0%, rgba(138,21,56,0.35) 60%, rgba(138,21,56,0.1) 100%)"}}),i.jsxs("div",{className:"relative flex h-full min-h-[320px] flex-col justify-between p-6 text-white",children:[i.jsx("span",{className:"w-fit rounded-full bg-white/15 px-3 py-1 font-plus-jakarta text-[11px] font-semibold uppercase tracking-[0.1em] backdrop-blur",children:"Featured"}),i.jsxs("div",{children:[i.jsx("p",{className:"m-0 font-plus-jakarta text-[18px] font-semibold leading-[1.35]",children:"TorchX Suite: Bringing Business Operations Together"}),i.jsxs("a",{href:wa,target:"_blank",rel:"noopener noreferrer",onClick:N=>{N.preventDefault(),Pm(wa),d(!1)},className:"mt-4 inline-flex items-center gap-2 font-inter text-[13px] font-bold uppercase tracking-wide text-white no-underline hover:text-gray-200",children:["Learn more ",i.jsx(mt,{size:15})]})]})]})]})})]})})]})}const Mv=`
.tt-nav-links { font-size: 14px; line-height: 1.2; }
@media (min-width: 1280px) { .tt-nav-links { font-size: 15px; } }
@media (min-width: 1536px) { .tt-nav-links { font-size: 16px; } }

.tt-nav-links :is(a, button, span, p):not(
  [data-nav-mega-menu] *,
  [data-mega-menu] *,
  [role="menu"] *,
  [role="dialog"] *
) {
  font-size: inherit !important;
  font-weight: 500;
  white-space: nowrap;
}
`;function kv(){return i.jsxs("svg",{width:"20",height:"20",viewBox:"0 0 24 24",fill:"none",stroke:"#222",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[i.jsx("circle",{cx:"11",cy:"11",r:"7"}),i.jsx("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"})]})}function Vv({open:s}){return s?i.jsxs("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"#222",strokeWidth:"2",strokeLinecap:"round",children:[i.jsx("line",{x1:"18",y1:"6",x2:"6",y2:"18"}),i.jsx("line",{x1:"6",y1:"6",x2:"18",y2:"18"})]}):i.jsxs("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"#222",strokeWidth:"2",strokeLinecap:"round",children:[i.jsx("line",{x1:"3",y1:"6",x2:"21",y2:"6"}),i.jsx("line",{x1:"3",y1:"12",x2:"21",y2:"12"}),i.jsx("line",{x1:"3",y1:"18",x2:"21",y2:"18"})]})}function i0({onNavigate:s}){const d=El(),x=gn(),{data:f}=np(),y=vy(),[E,S]=c.useState(!1);if(c.useEffect(()=>{S(!1)},[x.key]),!f)return i.jsx(ve,{to:"/signin",onClick:s,className:"whitespace-nowrap rounded-full bg-[#780042] px-5 py-2 text-[14px] xl:text-[15px] font-medium text-white no-underline transition hover:opacity-90",children:"Sign in"});const C=f.accountType==="admin"?"/admin-dashboard":"/candidate",M=async()=>{S(!1);try{await y.mutateAsync()}catch{}s?.(),d("/",{replace:!0})};return i.jsxs("div",{className:"relative",children:[i.jsxs("button",{type:"button",onClick:()=>S(N=>!N),"aria-haspopup":"menu","aria-expanded":E,className:"flex items-center gap-2 rounded-full border border-gray-300 px-3 py-1.5 text-[14px] xl:text-[15px] text-gray-900 hover:bg-gray-50",children:[i.jsx(r1,{size:17}),i.jsx("span",{className:"max-w-[110px] truncate",children:f.name?.split(" ")[0]}),i.jsx(cp,{size:15})]}),E&&i.jsxs(i.Fragment,{children:[i.jsx("div",{className:"fixed inset-0 z-[1001]",onClick:()=>S(!1)}),i.jsxs("div",{role:"menu",className:"absolute right-0 top-full z-[1002] mt-2 w-52 overflow-hidden rounded-xl border border-gray-200 bg-white py-1 shadow-xl",children:[i.jsxs("div",{className:"border-b border-gray-100 px-4 py-2",children:[i.jsx("p",{className:"truncate text-sm font-medium text-gray-900",children:f.name}),i.jsx("p",{className:"truncate text-xs text-gray-500",children:f.accountType==="admin"?"Admin":"Candidate"})]}),i.jsx(ve,{role:"menuitem",to:C,onClick:()=>{S(!1),s?.()},className:"block px-4 py-2.5 text-sm text-gray-800 no-underline hover:bg-gray-50",children:f.accountType==="admin"?"Admin dashboard":"My dashboard"}),f.accountType==="candidate"&&i.jsx(ve,{role:"menuitem",to:"/careers",onClick:()=>{S(!1),s?.()},className:"block px-4 py-2.5 text-sm text-gray-800 no-underline hover:bg-gray-50",children:"Browse jobs"}),i.jsxs("button",{type:"button",role:"menuitem",onClick:M,className:"flex w-full items-center gap-2 px-4 py-2.5 text-left text-sm text-red-600 hover:bg-red-50",children:[i.jsx(Py,{size:15}),"Sign out"]})]})]})]})}function Uv({navHeight:s,close:d}){const[x,f]=c.useState(null);return i.jsx("div",{style:{top:s},className:"lg:hidden fixed left-0 right-0 w-full bg-white shadow-2xl z-[999] max-h-[80vh] overflow-y-auto border-t border-gray-100",children:i.jsxs("ul",{className:"flex flex-col divide-y divide-gray-100",children:[ov.map(y=>i.jsx("li",{children:y.to?i.jsx(ve,{to:y.to,onClick:d,className:"block px-6 py-4 text-[16px] text-gray-900 no-underline hover:bg-gray-50 hover:text-[#8a1538]",children:y.label}):i.jsxs(i.Fragment,{children:[i.jsxs("button",{type:"button","aria-expanded":x===y.label,onClick:()=>f(x===y.label?null:y.label),className:"flex w-full items-center justify-between px-6 py-4 text-left text-[16px] text-gray-900 hover:bg-gray-50",children:[y.label,i.jsx(cp,{size:18,className:`transition-transform ${x===y.label?"rotate-180":""}`})]}),x===y.label&&i.jsx("ul",{className:"bg-gray-50 pb-2",children:y.children.map(E=>i.jsx("li",{children:i.jsx(ve,{to:mn(E),onClick:()=>{f(null),d()},className:"block px-10 py-2.5 text-[15px] text-gray-700 no-underline hover:text-[#8a1538]",children:E})},E))})]})},y.label)),i.jsx("li",{className:"px-6 py-4",children:i.jsx(i0,{onNavigate:d})})]})})}function Bv(){const{setActiveMenu:s,navHeight:d,setNavHeight:x}=iv(),f=c.useRef(null),y=El(),E=gn(),[S,C]=c.useState(!1),[M,N]=c.useState(!1),[R,O]=c.useState(!1),D=()=>{s(null),C(!1)};return c.useLayoutEffect(()=>{D(),O(!0)},[E.key,s]),c.useLayoutEffect(()=>{const K=()=>{if(f.current){const P=f.current.getBoundingClientRect().height;x(P),document.documentElement.style.setProperty("--nav-h",`${P}px`)}};K(),window.addEventListener("resize",K);let ae;return typeof ResizeObserver<"u"&&f.current&&(ae=new ResizeObserver(K),ae.observe(f.current)),()=>{window.removeEventListener("resize",K),ae?.disconnect()}},[x]),c.useEffect(()=>{const K=ae=>{if(!(ae.target instanceof Element))return;const P=ae.target.closest("a[href]");if(!P)return;const qe=P.getAttribute("href");if(!qe)return;const jt=f.current?.contains(P),xn=!!P.closest("[data-nav-mega-menu], [data-mega-menu]");!jt&&!xn||P.target==="_blank"||P.hasAttribute("download")||ae.metaKey||ae.ctrlKey||ae.shiftKey||ae.altKey||ae.button!==0||(s(null),C(!1),O(!0),jt&&qe.startsWith("/")&&!qe.startsWith("//")&&!ae.defaultPrevented&&!P.hasAttribute("data-discover")&&(ae.preventDefault(),y(qe)))};return document.addEventListener("click",K,!0),()=>{document.removeEventListener("click",K,!0)}},[y,s]),c.useEffect(()=>{const K=ae=>{R&&f.current&&!f.current.contains(ae.target)&&O(!1)};return document.addEventListener("pointermove",K),()=>{document.removeEventListener("pointermove",K)}},[R]),c.useEffect(()=>{const K=ae=>{f.current&&!f.current.contains(ae.target)&&D()};return document.addEventListener("pointerdown",K),()=>{document.removeEventListener("pointerdown",K)}},[s]),c.useEffect(()=>{const K=ae=>{ae.key==="Escape"&&D()};return document.addEventListener("keydown",K),()=>{document.removeEventListener("keydown",K)}},[s]),c.useEffect(()=>{const K=()=>{s(null)};return window.addEventListener("scroll",K,{passive:!0}),()=>{window.removeEventListener("scroll",K)}},[s]),i.jsxs(i.Fragment,{children:[i.jsx("style",{children:Mv}),i.jsxs("nav",{ref:f,style:{fontFamily:"Plus Jakarta Sans, 'Times New Roman', serif"},className:"fixed top-0 left-0 w-full z-[1000] flex items-center gap-4 xl:gap-8 px-4 sm:px-6 lg:px-6 xl:px-10 py-2.5 lg:py-3 border-b border-gray-200 bg-white",children:[i.jsx(ve,{to:"/","aria-label":"TechTorch Solutions home",onClick:D,className:"flex shrink-0 items-center gap-2.5 lg:mr-2 xl:mr-4",children:i.jsx("img",{src:av,alt:"TechTorch Solutions",className:"h-11 sm:h-12 w-auto"})}),i.jsxs("ul",{onMouseLeave:()=>{s(null),O(!1)},className:"tt-nav-links hidden lg:flex flex-1 min-w-0 items-center justify-center gap-4 xl:gap-7 2xl:gap-9 list-none m-0 p-0",children:[i.jsx("li",{children:i.jsx(cv,{})}),i.jsx("li",{children:i.jsx(fv,{})}),i.jsx("li",{children:i.jsx(Lv,{})}),i.jsx("li",{children:i.jsx(pv,{})}),i.jsx("li",{children:i.jsx(bv,{})}),i.jsx("li",{children:i.jsx(jv,{})}),i.jsx("li",{children:i.jsx(ve,{to:"/start-conversation",onClick:D,className:"whitespace-nowrap text-gray-900 no-underline transition-colors duration-200 hover:text-[#8a1538]",children:"Contact Us"})})]}),i.jsxs("div",{className:"hidden lg:flex shrink-0 items-center gap-3 xl:gap-4",children:[i.jsx("button",{type:"button","aria-label":"Search",onClick:()=>{s(null),N(!0)},className:"flex items-center justify-center bg-transparent border-none cursor-pointer p-1",children:i.jsx(kv,{})}),i.jsx(i0,{onNavigate:D})]}),i.jsx("button",{type:"button","aria-label":S?"Close menu":"Open menu","aria-expanded":S,onClick:()=>{s(null),C(K=>!K)},className:"lg:hidden ml-auto flex items-center justify-center bg-transparent border-none cursor-pointer p-1",children:i.jsx(Vv,{open:S})}),S&&i.jsx(Uv,{navHeight:d,close:D}),M&&i.jsx(Dv,{onClose:()=>N(!1)})]}),i.jsx("div",{style:{height:d}})]})}function Hv(){const s=gn();return i.jsx(lv,{children:i.jsx(Bv,{})},s.key)}const qv=()=>{const s=El(),d=gn(),x=d.pathname.split("/").filter(Boolean).pop()||"Home",f=y=>decodeURIComponent(y).replace(/[-_]/g," ").replace(/\b\w/g,E=>E.toUpperCase());return d.pathname==="/"?null:i.jsx("div",{className:"sticky top-[var(--nav-h,72px)] z-40 w-full border-b border-gray-200 bg-white/95 backdrop-blur-md",children:i.jsxs("div",{className:"flex min-h-[52px] items-center justify-between gap-3 px-4 sm:px-6 md:px-10 lg:px-[100px]",children:[i.jsxs("button",{type:"button",onClick:()=>{window.history.state?.idx>0?s(-1):s("/")},className:"inline-flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-gray-700 transition-all duration-200 hover:bg-[#7A1F3D] hover:text-white","aria-label":"Go back",children:[i.jsx(Ny,{size:18}),i.jsx("span",{children:"Back"})]}),i.jsxs("div",{className:"flex min-w-0 items-center gap-2 overflow-hidden text-sm",children:[i.jsxs(ve,{to:"/",className:"flex shrink-0 items-center gap-1.5 text-gray-500 transition-colors hover:text-[#7A1F3D]",children:[i.jsx(Yy,{size:15}),i.jsx("span",{className:"hidden sm:inline",children:"Home"})]}),i.jsx(Cy,{size:15,className:"shrink-0 text-gray-400"}),i.jsx("span",{className:"truncate font-semibold text-[#7A1F3D]",children:f(x)})]})]})})},Iv="/logo.webp",Yv=[{label:"Industries",to:"/#industries"},{label:"Services",to:"/explore-services"},{label:"Products",to:"/platform"},{label:"Digital Solutions",to:"/digitalsolution"},{label:"Case Studies",to:"/case-studies"}],Xv=[{label:"About US",to:"/company-overview"},{label:"Careers",to:"/careers"},{label:"Company Profile - IT Services",to:"/Our-Story"},{label:"IT Staff Augmentation",to:"/ItAugmentation"}],Gv=["Terms of Use","Privacy","Refund Policy","Cancellation Policy","Cookie Policy"],Qv={Privacy:{title:"Privacy Policy",effective:"April 01, 2026",sections:[{blocks:[{p:"This Privacy Policy describes how Techtorch Solutions Private Limited (“Company”, “we”, “our”, or “us”) collects, uses, stores, and protects information when users access or use our SaaS platform suite including Talent, Engage, Pay, Inventory, and Finance (“Services”)."},{p:"By using our Services, you agree to the practices described in this Privacy Policy."}]},{title:"1. Information We Collect",blocks:[{p:"We may collect the following information:"},{sub:"a. Personal Information"},{list:["Name","Email address","Phone number","Billing information","Company details","Account credentials"]},{sub:"b. Usage Information"},{list:["IP address","Browser type","Device information","Login activity","Usage analytics","Cookies and tracking information"]},{sub:"c. Customer Data"},{p:"Any data uploaded, processed, or stored by customers while using our Services."}]},{title:"2. How We Use Information",blocks:[{p:"We use the collected information to:"},{list:["Provide and maintain Services","Process subscriptions and payments","Improve platform performance","Offer customer support","Prevent fraud and abuse","Send service-related notifications","Comply with legal obligations"]}]},{title:"3. Data Security",blocks:[{p:"We implement commercially reasonable administrative, technical, and organizational safeguards to protect user data from unauthorized access, disclosure, or misuse."},{p:"However, no internet-based service is completely secure, and we cannot guarantee absolute security."}]},{title:"4. Data Sharing",blocks:[{p:"We do not sell personal data."},{p:"We may share information with:"},{list:["Payment processors","Cloud hosting providers","Analytics providers","Legal authorities when required by law"]},{p:"All third-party partners are required to maintain confidentiality and data protection standards."}]},{title:"5. Data Retention",blocks:[{p:"We retain data only for as long as necessary to provide Services, comply with legal obligations, resolve disputes, and enforce agreements."}]},{title:"6. User Rights",blocks:[{p:"Users may request:"},{list:["Access to personal data","Correction of inaccurate data","Account deletion","Data export where applicable"]},{p:"Requests can be sent to:"},{list:["privacy@torchxsuite.com"]}]},{title:"7. International Data Transfers",blocks:[{p:"Your information may be processed and stored in locations outside your country, subject to applicable data protection laws."}]},{title:"8. Children’s Privacy",blocks:[{p:"Our Services are not intended for individuals under 18 years of age."}]},{title:"9. Changes to This Policy",blocks:[{p:"We reserve the right to modify this Privacy Policy at any time. Updated versions will be posted on this page with a revised effective date."}]},{title:"10. Contact Us",blocks:[{p:"For privacy-related concerns:"},{list:["Email: legal@torchxsuite.com"]}]}]},"Terms of Use":{title:"Terms of Service",effective:"April 01, 2026",sections:[{blocks:[{p:"These Terms of Service (“Terms”) govern the use of the SaaS products and services provided by Techtorch Solutions Private Limited including Talent, Engage, Pay, Inventory, and Finance."},{p:"By accessing or using the Services, you agree to these Terms."}]},{title:"1. Eligibility",blocks:[{p:"You must be legally capable of entering into binding agreements to use our Services."}]},{title:"2. Account Responsibilities",blocks:[{p:"Users are responsible for:"},{list:["Maintaining account confidentiality","All activities under their account","Providing accurate information"]},{p:"You agree not to:"},{list:["Use the Services unlawfully","Attempt unauthorized access","Reverse engineer or copy the platform","Upload malicious software"]}]},{title:"3. Subscription & Billing",blocks:[{list:["Services are offered on subscription plans.","Fees are billed monthly, quarterly, or annually.","Payments are non-refundable unless stated otherwise in our Refund Policy.","Failure to pay may result in suspension or termination."]}]},{title:"4. Intellectual Property",blocks:[{p:"All platform software, branding, designs, content, APIs, workflows, and technology remain the exclusive property of the Company."},{p:"Users receive a limited, non-transferable license to use the Services during an active subscription."}]},{title:"5. Customer Data",blocks:[{p:"Customers retain ownership of their uploaded data."},{p:"You grant us limited rights necessary to host, process, and operate the Services."}]},{title:"6. Service Availability",blocks:[{p:"We aim for high uptime but do not guarantee uninterrupted or error-free operation."},{p:"Scheduled maintenance and unforeseen outages may occur."}]},{title:"7. Limitation of Liability",blocks:[{p:"To the maximum extent permitted by law:"},{list:["We are not liable for indirect, incidental, or consequential damages.","Total liability shall not exceed the amount paid by the customer during the previous 3 months."]}]},{title:"8. Termination",blocks:[{p:"We may suspend or terminate accounts for:"},{list:["Violation of Terms","Fraudulent activity","Non-payment","Abuse of Services"]},{p:"Upon termination, access to Services may be revoked immediately."}]},{title:"9. Governing Law",blocks:[{p:"These Terms shall be governed by the laws of India."},{p:"Any disputes shall be subject to the jurisdiction of courts located in Bareilly, Uttar Pradesh, India."}]},{title:"10. Contact",blocks:[{list:["Email: legal@torchxsuite.com"]}]}]},"Refund Policy":{title:"Refund Policy",effective:"April 01, 2026",sections:[{blocks:[{p:"At Techtorch Solutions Private Limited, we strive to provide reliable SaaS solutions across our product suite including Talent, Engage, Pay, Inventory, and Finance."}]},{title:"1. Subscription Payments",blocks:[{p:"All subscription payments are generally non-refundable once billed."}]},{title:"2. Trial Periods",blocks:[{p:"Where trial access is provided, users are encouraged to evaluate the Services before purchasing a paid subscription."}]},{title:"3. Exceptional Refunds",blocks:[{p:"Refunds may be considered only under the following circumstances:"},{list:["Duplicate payment","Incorrect billing due to system error","Service unavailable for an extended verified duration caused solely by us"]},{p:"Approved refunds are processed within 7–15 business days."}]},{title:"4. Non-Refundable Situations",blocks:[{p:"Refunds will not be issued for:"},{list:["Partial usage","Change of mind","Failure to cancel before renewal","Account suspension due to policy violations","Third-party service interruptions"]}]},{title:"5. Chargebacks",blocks:[{p:"Initiating fraudulent chargebacks or payment disputes without contacting support may result in:"},{list:["Immediate account suspension","Permanent service restriction","Legal recovery actions where applicable"]}]},{title:"6. Contact",blocks:[{p:"For billing support:"},{list:["accounts@torchxsuite.com"]}]}]},"Cancellation Policy":{title:"Cancellation Policy",effective:"April 01, 2026",sections:[{blocks:[{p:"This Cancellation Policy applies to subscriptions purchased for the SaaS products provided by Techtorch Solutions Private Limited."}]},{title:"1. Subscription Cancellation",blocks:[{p:"Users may cancel their subscription at any time through:"},{list:["Account dashboard","Billing settings","Official support email"]},{p:"Cancellation requests become effective at the end of the current billing cycle unless otherwise specified."}]},{title:"2. No Partial Refunds",blocks:[{p:"Cancelling a subscription does not entitle users to refunds for unused subscription periods unless explicitly approved under the Refund Policy."}]},{title:"3. Data Retention After Cancellation",blocks:[{p:"After subscription termination:"},{list:["Account access may be restricted","Data may be retained temporarily for compliance and recovery purposes","Data may be permanently deleted after 30 days"]},{p:"Users are responsible for exporting the necessary data before cancellation."}]},{title:"4. Company-Initiated Cancellation",blocks:[{p:"We reserve the right to suspend or terminate accounts for:"},{list:["Fraudulent activity","Abuse of Services","Violation of policies","Non-payment"]}]},{title:"5. Contact",blocks:[{list:["accounts@torchxsuite.com"]}]}]},"Cookie Policy":{title:"Cookie Policy",effective:"April 01, 2026",sections:[{blocks:[{p:"This Cookie Policy explains how Techtorch Solutions Private Limited uses cookies and similar technologies on our websites and SaaS platforms."}]},{title:"1. What Are Cookies?",blocks:[{p:"Cookies are small text files stored on your device to improve website functionality and user experience."}]},{title:"2. Types of Cookies We Use",blocks:[{sub:"Essential Cookies"},{p:"Required for authentication, security, and core functionality."},{sub:"Analytics Cookies"},{p:"Help us understand platform usage and improve performance."},{sub:"Preference Cookies"},{p:"Remember user settings and preferences."},{sub:"Marketing Cookies"},{p:"Used for relevant communication and advertising where permitted."}]},{title:"3. Third-Party Cookies",blocks:[{p:"Some third-party services integrated into our platform may place cookies subject to their own privacy policies."}]},{title:"4. Managing Cookies",blocks:[{p:"Users can manage or disable cookies through browser settings."},{p:"Disabling cookies may affect platform functionality."}]},{title:"5. Updates",blocks:[{p:"We may update this Cookie Policy periodically."}]}]}};function Zv({policy:s,onClose:d}){return c.useEffect(()=>{const x=y=>{y.key==="Escape"&&d()},f=document.body.style.overflow;return document.addEventListener("keydown",x),document.body.style.overflow="hidden",()=>{document.removeEventListener("keydown",x),document.body.style.overflow=f}},[d]),i.jsx("div",{className:"fixed inset-0 z-[9999] flex items-start justify-center overflow-y-auto bg-black/40 px-4 pb-4 pt-24 backdrop-blur-md sm:pt-28",onClick:d,role:"presentation",children:i.jsxs("div",{role:"dialog","aria-modal":"true","aria-labelledby":"policy-modal-title",onClick:x=>x.stopPropagation(),className:"flex max-h-[calc(100vh-7rem)] w-full max-w-[900px] flex-col overflow-hidden rounded-[20px] border border-white/40 bg-white shadow-2xl sm:max-h-[calc(100vh-8rem)]",children:[i.jsxs("div",{className:"flex shrink-0 items-start justify-between gap-4 bg-[#7a0046] px-6 py-6 text-white sm:px-8",children:[i.jsxs("div",{children:[i.jsx("h2",{id:"policy-modal-title",className:"text-[22px] font-bold leading-tight",children:s.title}),i.jsxs("p",{className:"mt-1 text-[13px] text-white/75",children:["Effective ",s.effective]})]}),i.jsx("button",{type:"button",onClick:d,"aria-label":"Close policy",className:"flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-white/90 transition-colors hover:bg-white/15 hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-white",children:i.jsx("svg",{width:"20",height:"20",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round","aria-hidden":"true",children:i.jsx("path",{d:"M5 5l14 14M19 5L5 19"})})})]}),i.jsx("div",{className:"min-h-0 overflow-y-auto overscroll-contain px-6 py-6 sm:px-8",children:s.sections.map((x,f)=>i.jsxs("section",{className:"mb-7 last:mb-0",children:[x.title&&i.jsx("h3",{className:"mb-3 text-[16px] font-bold uppercase tracking-wide text-[#7a0046]",children:x.title}),x.blocks.map((y,E)=>y.p?i.jsx("p",{className:"mb-3 text-[15px] leading-relaxed text-[#5b4a53]",children:y.p},E):y.sub?i.jsx("h4",{className:"mb-2 mt-4 text-[15px] font-semibold text-[#3d2a34]",children:y.sub},E):i.jsx("ul",{className:"mb-3 flex flex-col gap-2",children:y.list.map(S=>i.jsxs("li",{className:"flex gap-3 text-[15px] leading-relaxed text-[#5b4a53]",children:[i.jsx("span",{"aria-hidden":"true",className:"mt-[9px] h-[5px] w-[5px] shrink-0 rounded-full bg-[#c07a9d]"}),i.jsx("span",{className:"min-w-0 break-words",children:S})]},S))},E))]},f))})]})})}const rr=({children:s,label:d,href:x})=>i.jsx("a",{href:x,"aria-label":d,target:"_blank",rel:"noopener noreferrer",className:"group flex h-12 w-12 items-center justify-center rounded-[10px] border border-[#e5c8d7] bg-white text-[#7a0046] transition-all duration-300 hover:-translate-y-1 hover:shadow-md",children:s});function Kv(){return i.jsx("svg",{width:"22",height:"22",viewBox:"0 0 24 24",fill:"currentColor",xmlns:"http://www.w3.org/2000/svg","aria-hidden":"true",children:i.jsx("path",{d:"M18.9 2.5H22l-6.8 7.75 8 11.25h-6.3L12 14.7l-5.95 6.8H2.95l7.2-8.25L2.5 2.5h6.45l4.45 6.25L18.9 2.5ZM17.8 19.5h1.75L7.95 4.4H6.05L17.8 19.5Z"})})}function Pv(){return i.jsx("div",{className:"flex h-[22px] w-[22px] items-center justify-center rounded-[3px] bg-[#730042] text-white",children:i.jsx("span",{className:"text-[14px] font-bold leading-none tracking-[-0.7px]",children:"in"})})}function Jv(){return i.jsxs("svg",{width:"23",height:"23",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg","aria-hidden":"true",children:[i.jsx("rect",{x:"3",y:"3",width:"18",height:"18",rx:"5",stroke:"currentColor",strokeWidth:"2"}),i.jsx("circle",{cx:"12",cy:"12",r:"4.2",stroke:"currentColor",strokeWidth:"2"}),i.jsx("circle",{cx:"17.5",cy:"6.5",r:"1.2",fill:"currentColor"})]})}function Fv(){return i.jsx("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"currentColor",xmlns:"http://www.w3.org/2000/svg","aria-hidden":"true",children:i.jsx("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M21.58 7.2a2.76 2.76 0 0 0-1.94-1.95C17.92 4.8 12 4.8 12 4.8s-5.92 0-7.64.45A2.76 2.76 0 0 0 2.42 7.2C2 8.92 2 12 2 12s0 3.08.42 4.8a2.76 2.76 0 0 0 1.94 1.95c1.72.45 7.64.45 7.64.45s5.92 0 7.64-.45a2.76 2.76 0 0 0 1.94-1.95C22 15.08 22 12 22 12s0-3.08-.42-4.8ZM10 15.3V8.7l5.5 3.3-5.5 3.3Z"})})}function Wv(){const[s,d]=c.useState(null);return i.jsxs("footer",{className:"w-full bg-[#730042] font-inter text-white",children:[i.jsxs("div",{className:"w-full px-4 pb-8 pt-12 sm:px-6 md:px-10 md:pt-16 lg:px-[100px]",children:[i.jsxs("div",{className:"grid grid-cols-1 gap-12 md:grid-cols-4",children:[i.jsxs("div",{children:[i.jsx("div",{className:"mb-6",children:i.jsx("img",{loading:"lazy",decoding:"async",src:Iv,alt:"TechTorch Solutions",className:"h-auto w-[180px] object-contain"})}),i.jsx("h3",{className:"mb-4 text-[16px] font-semibold leading-snug",children:"Technology. Expertise. Progress."}),i.jsx("p",{className:"mb-6 max-w-[260px] text-[14px] leading-relaxed text-white/70",children:"We bring technology, expertise and people together to solve real business challenges and create practical digital solutions."}),i.jsxs("div",{className:"flex items-center gap-4",children:[i.jsx(rr,{label:"X (Twitter)",href:"https://x.com/techtorch_sol",children:i.jsx(Kv,{})}),i.jsx(rr,{label:"LinkedIn",href:"https://www.linkedin.com/company/techtorch_sol/",children:i.jsx(Pv,{})}),i.jsx(rr,{label:"Instagram",href:"https://www.instagram.com/techtorch_sol/?hl=en",children:i.jsx(Jv,{})}),i.jsx(rr,{label:"YouTube",href:"https://www.youtube.com/@techtorch_sol",children:i.jsx(Fv,{})})]})]}),i.jsxs("div",{children:[i.jsx("h4",{className:"mb-5 text-[16px] font-semibold",children:"Explore"}),i.jsx("ul",{className:"flex flex-col gap-4",children:Yv.map(({label:x,to:f})=>i.jsx("li",{children:i.jsx(ve,{to:f,className:"text-[14px] text-white/80 transition-colors hover:text-white",children:x})},x))})]}),i.jsxs("div",{children:[i.jsx("h4",{className:"mb-5 text-[16px] font-semibold",children:"Company"}),i.jsx("ul",{className:"flex flex-col gap-4",children:Xv.map(({label:x,to:f})=>i.jsx("li",{children:i.jsx(ve,{to:f,className:"text-[14px] text-white/80 transition-colors hover:text-white",children:x})},x))})]}),i.jsxs("div",{children:[i.jsx("h4",{className:"mb-4 text-[16px] font-semibold",children:"Let's build what's next."}),i.jsx("p",{className:"mb-4 text-[14px] leading-relaxed text-white/70",children:"Have a project, technology requirement or business challenge? Let's talk."}),i.jsxs("div",{className:"flex flex-col gap-1 text-[14px] text-white/80",children:[i.jsx("a",{href:"https://www.techtorch.solutions",target:"_blank",rel:"noopener noreferrer",className:"transition-colors hover:text-white",children:"www.techtorch.solutions"}),i.jsx("a",{href:"tel:+917251090147",className:"transition-colors hover:text-white",children:"+91 7251090147"})]})]})]}),i.jsx("div",{className:"mt-14 border-t border-white/20 pt-6",children:i.jsx("p",{className:"max-w-4xl text-[13px] leading-relaxed text-white/70",children:"Disclaimer: The information provided on this website is for general informational purposes only. TechTorch Solutions reserves the right to modify services, offerings, and specifications without prior notice. Case studies and performance metrics represent past engagements and do not guarantee future results. All trademarks, logos, and service marks displayed are the property of TechTorch Solutions or their respective owners."})}),i.jsxs("div",{className:"mt-6 flex flex-col items-start justify-between gap-4 border-t border-white/20 pt-6 sm:flex-row sm:items-center",children:[i.jsx("p",{className:"text-[13px] text-white/70",children:"© 2024 — 2026 TechTorch Solutions Private Limited. All rights reserved."}),i.jsx("div",{className:"flex flex-wrap gap-x-6 gap-y-2",children:Gv.map(x=>i.jsx("button",{type:"button",onClick:()=>d(x),className:"text-left text-[13px] text-white/80 transition-colors hover:text-white",children:x},x))})]})]}),s&&i.jsx(Zv,{policy:Qv[s],onClose:()=>d(null)})]})}const Ea=[{image:"/Slide1.webp",headline:"Turning Business Challenges Into Digital Possibilities",body:"We bring technology, business processes and people together to create practical digital solutions that help businesses work smarter and grow with confidence.",ctaText:"EXPLORE OUR SOLUTIONS",ctaHref:"/explore-solutions",focus:"center"},{image:"/Slide2.webp",headline:"One Connected System for Your Business",body:"From custom applications to enterprise platforms, we create software that fits the way your business works today—and gives you room to grow tomorrow.",ctaText:"EXPLORE ERP",ctaHref:"/explore-erp",focus:"65% 40%"},{image:"/Slide3.webp",headline:"Software Built Around Your Business",body:"From custom applications to enterprise platforms, we create software that fits the way your business works today—and gives you room to grow tomorrow.",ctaText:"BUILD WITH TECHTORCH",ctaHref:"/build-with-techtorch",focus:"70% 50%"},{image:"/Slide4.webp",headline:"Technology That Keeps You Ready for What’s Next",body:"From AI and cloud to cybersecurity, we help businesses adopt modern technology with the reliability, security and flexibility they need to grow.",ctaText:"EXPLORE TECHNOLOGY SERVICES",ctaHref:"/explore-services",focus:"100% 45%"},{image:"/Slide6.webp",headline:"Everything Your Business Needs, Working Together",body:"TorchX Suite brings key business functions into one connected platform, helping teams manage people, customers, finance and operations with greater clarity.",ctaText:"EXPLORE TORCHX SUITE",ctaHref:"/explore-torchXsuite",focus:"100% 40%"}],$v=()=>{const[s,d]=c.useState(0),x=()=>{d(y=>(y+1)%Ea.length)},f=()=>{d(y=>(y-1+Ea.length)%Ea.length)};return c.useEffect(()=>{const y=setInterval(()=>{d(E=>(E+1)%Ea.length)},6e3);return()=>clearInterval(y)},[]),i.jsxs("section",{className:"techtorch-hero","aria-label":"TechTorch solutions","aria-roledescription":"carousel",children:[Ea.map((y,E)=>i.jsx("img",{src:y.image,alt:"","aria-hidden":"true",className:`techtorch-hero__image ${E===s?"is-active":""}`,style:{objectPosition:y.focus},decoding:"async"},y.image)),i.jsx("div",{className:"techtorch-hero__overlay","aria-hidden":"true"}),i.jsxs("div",{className:"techtorch-hero__layout",children:[i.jsx("div",{className:"techtorch-hero__content-area",children:i.jsx("div",{className:"techtorch-hero__stack",children:Ea.map((y,E)=>{const S=E===s,C=S?"h1":"div";return i.jsxs("div",{className:`techtorch-hero__content ${S?"is-active":""}`,"aria-hidden":S?void 0:"true",children:[i.jsx(C,{className:"techtorch-hero__h1",children:y.headline}),i.jsx("p",{children:y.body}),y.ctaHref.startsWith("/")?i.jsx(ve,{to:y.ctaHref,className:"techtorch-hero__cta",tabIndex:S?0:-1,children:y.ctaText}):i.jsx("a",{href:y.ctaHref,className:"techtorch-hero__cta",tabIndex:S?0:-1,children:y.ctaText})]},y.image)})})}),i.jsxs("div",{className:"techtorch-hero__controls",children:[i.jsx("div",{className:"techtorch-hero__dots",role:"group","aria-label":"Choose a slide",children:Ea.map((y,E)=>i.jsx("button",{type:"button",onClick:()=>d(E),"aria-label":`Go to slide ${E+1}`,"aria-current":E===s?"true":void 0,className:`techtorch-hero__dot ${E===s?"is-active":""}`,children:i.jsx("span",{})},y.image))}),i.jsxs("div",{className:"techtorch-hero__arrows",children:[i.jsx("button",{type:"button",onClick:f,"aria-label":"Previous slide",className:"techtorch-hero__arrow",children:i.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.5","aria-hidden":"true",children:i.jsx("polyline",{points:"15 18 9 12 15 6"})})}),i.jsx("button",{type:"button",onClick:x,"aria-label":"Next slide",className:"techtorch-hero__arrow",children:i.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.5","aria-hidden":"true",children:i.jsx("polyline",{points:"9 18 15 12 9 6"})})})]})]})]}),i.jsx("style",{children:`
        .techtorch-hero,
        .techtorch-hero * {
          box-sizing: border-box;
        }

        .techtorch-hero {
          position: relative;
          isolation: isolate;
          width: 100%;
          overflow: hidden;
          background: #0e1c2e;
          color: #ffffff;
        }

        .techtorch-hero .techtorch-hero__image {
          position: absolute;
          inset: 0;
          z-index: 0;
          display: block;
          width: 100%;
          height: 100%;
          object-fit: cover;
          opacity: 0;
          transition: opacity 700ms ease-in-out;
          pointer-events: none;
        }

        .techtorch-hero .techtorch-hero__image.is-active {
          opacity: 1;
        }

        .techtorch-hero .techtorch-hero__overlay {
          position: absolute;
          inset: 0;
          z-index: 1;
          pointer-events: none;
          background: linear-gradient(
            90deg,
            rgba(10, 18, 32, 0.72) 0%,
            rgba(10, 18, 32, 0.46) 38%,
            rgba(10, 18, 32, 0.08) 62%,
            rgba(10, 18, 32, 0) 78%
          );
        }

        .techtorch-hero .techtorch-hero__layout {
          position: relative;
          z-index: 2;
          display: grid;
          grid-template-rows: 1fr auto;
          width: 100%;
          max-width: 1600px;
          min-height: clamp(520px, 78vh, 620px);
          min-height: clamp(520px, 78svh, 620px);
          margin: 0 auto;
          padding: 0 100px;
        }

        .techtorch-hero .techtorch-hero__content-area {
          display: flex;
          align-items: center;
          min-width: 0;
          padding: 64px 0 32px;
        }

        .techtorch-hero .techtorch-hero__content {
          width: 100%;
          max-width: 500px;
          min-width: 0;
          animation: techtorchHeroFadeIn 500ms ease both;
        }

        .techtorch-hero .techtorch-hero__stack {
          display: grid;
          width: 100%;
          min-width: 0;
        }

        /* All slides share one cell, so the block is as tall as the
           longest slide and never changes height between slides */
        .techtorch-hero .techtorch-hero__stack > .techtorch-hero__content {
          grid-area: 1 / 1;
          display: flex;
          flex-direction: column;
          align-items: flex-start;
          visibility: hidden;
          opacity: 0;
          animation: none;
        }

        /* the button sits on the same line on every slide */
        .techtorch-hero .techtorch-hero__stack .techtorch-hero__cta {
          margin-top: auto;
        }

        .techtorch-hero .techtorch-hero__stack > .techtorch-hero__content.is-active {
          visibility: visible;
          opacity: 1;
          animation: techtorchHeroFadeIn 500ms ease both;
        }

        .techtorch-hero h1,
        .techtorch-hero .techtorch-hero__h1 {
          margin: 0 0 32px;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 38px;
          font-weight: 600;
          line-height: 1.12;
          overflow-wrap: break-word;
          color: #ffffff;
        }

        .techtorch-hero .techtorch-hero__content p {
          max-width: 520px;
          margin: 0 0 40px;
          font-family: "Inter", sans-serif;
          font-size: 15px;
          font-weight: 500;
          line-height: 1.65;
          color: rgba(255, 255, 255, 0.9);
        }

        .techtorch-hero .techtorch-hero__cta {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          max-width: 100%;
          min-height: 48px;
          padding: 14px 24px;
          border: 1.5px solid #ffffff;
          background: transparent;
          color: #ffffff;
          font-family: "Inter", sans-serif;
          font-size: 13px;
          font-weight: 700;
          line-height: 1.4;
          text-align: center;
          text-decoration: none;
          text-transform: uppercase;
          overflow-wrap: anywhere;
          transition:
            background-color 200ms ease,
            color 200ms ease;
        }

        .techtorch-hero .techtorch-hero__controls {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 8px;
          min-width: 0;
          padding-bottom: 24px;
        }

        .techtorch-hero .techtorch-hero__dots {
          display: flex;
          align-items: center;
          justify-content: center;
          flex-wrap: wrap;
        }

        .techtorch-hero .techtorch-hero__dot {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 30px;
          height: 44px;
          margin: 0;
          padding: 0;
          border: 0;
          background: transparent;
          cursor: pointer;
        }

        .techtorch-hero .techtorch-hero__dot span {
          display: block;
          width: 11px;
          height: 11px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.55);
          transition:
            transform 200ms ease,
            background-color 200ms ease;
        }

        .techtorch-hero .techtorch-hero__dot.is-active span {
          background: #ffffff;
          transform: scale(1.1);
        }

        .techtorch-hero .techtorch-hero__arrows {
          display: flex;
          align-items: center;
          flex-shrink: 0;
          gap: 12px;
        }

        .techtorch-hero .techtorch-hero__arrow {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 44px;
          height: 44px;
          margin: 0;
          padding: 0;
          border: 0;
          border-radius: 50%;
          background: #970052;
          color: #ffffff;
          cursor: pointer;
          transition: background-color 200ms ease;
        }

        .techtorch-hero .techtorch-hero__arrow svg {
          width: 20px;
          height: 20px;
        }

        .techtorch-hero .techtorch-hero__cta:focus-visible,
        .techtorch-hero button:focus-visible {
          outline: 2px solid #ffffff;
          outline-offset: 4px;
        }

        @media (hover: hover) {
          .techtorch-hero .techtorch-hero__cta:hover {
            background: #ffffff;
            color: #730042;
          }

          .techtorch-hero .techtorch-hero__arrow:hover {
            background: #730042;
          }
        }

        @keyframes techtorchHeroFadeIn {
          from {
            opacity: 0;
            transform: translateY(12px);
          }

          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        /* Tablet */
        @media (max-width: 1023px) {
          .techtorch-hero .techtorch-hero__layout {
            padding: 0 40px;
          }

          .techtorch-hero .techtorch-hero__content {
            max-width: 480px;
          }

          .techtorch-hero h1,
        .techtorch-hero .techtorch-hero__h1 {
            font-size: 36px;
            margin-bottom: 26px;
          }

          .techtorch-hero .techtorch-hero__content p {
            margin-bottom: 32px;
          }

          .techtorch-hero .techtorch-hero__overlay {
            background: linear-gradient(
              90deg,
              rgba(10, 18, 32, 0.84) 0%,
              rgba(10, 18, 32, 0.64) 48%,
              rgba(10, 18, 32, 0.2) 100%
            );
          }
        }

        /* Small tablet and mobile */
        @media (max-width: 767px) {
          .techtorch-hero .techtorch-hero__layout {
            min-height: 560px;
            padding: 0 24px;
          }

          .techtorch-hero .techtorch-hero__content-area {
            padding: 56px 0 32px;
          }

          .techtorch-hero .techtorch-hero__content {
            max-width: 520px;
          }

          .techtorch-hero h1,
        .techtorch-hero .techtorch-hero__h1 {
            font-size: clamp(28px, 4.6vw, 34px);
            line-height: 1.18;
            margin-bottom: 24px;
          }

          .techtorch-hero .techtorch-hero__content p {
            font-size: 14px;
            line-height: 1.7;
            margin-bottom: 30px;
          }

          .techtorch-hero .techtorch-hero__controls {
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 12px;
            padding-bottom: 24px;
          }

          .techtorch-hero .techtorch-hero__overlay {
            background: linear-gradient(
              90deg,
              rgba(10, 18, 32, 0.88) 0%,
              rgba(10, 18, 32, 0.7) 60%,
              rgba(10, 18, 32, 0.44) 100%
            );
          }
        }

        /* Mobile */
        @media (max-width: 480px) {
          .techtorch-hero .techtorch-hero__layout {
            min-height: 540px;
            padding: 0 16px;
          }

          .techtorch-hero .techtorch-hero__content-area {
            padding: 44px 0 30px;
          }

          .techtorch-hero h1,
        .techtorch-hero .techtorch-hero__h1 {
            font-size: 28px;
            line-height: 1.2;
            margin-bottom: 22px;
          }

          .techtorch-hero .techtorch-hero__content p {
            font-size: 13px;
            line-height: 1.7;
            margin-bottom: 28px;
          }

          .techtorch-hero .techtorch-hero__cta {
            padding: 13px 18px;
            font-size: 11px;
          }

          .techtorch-hero .techtorch-hero__controls {
            padding-bottom: 20px;
          }

          .techtorch-hero .techtorch-hero__dot {
            width: 28px;
          }

          .techtorch-hero .techtorch-hero__dot span {
            width: 9px;
            height: 9px;
          }

          .techtorch-hero .techtorch-hero__arrows {
            gap: 8px;
          }
        }

        /* Small mobile */
        @media (max-width: 359px) {
          .techtorch-hero h1,
        .techtorch-hero .techtorch-hero__h1 {
            font-size: 25px;
          }

          .techtorch-hero .techtorch-hero__dot {
            width: 25px;
          }
        }

        @media (prefers-reduced-motion: reduce) {
          .techtorch-hero .techtorch-hero__stack > .techtorch-hero__content.is-active {
            animation: none;
          }
          .techtorch-hero .techtorch-hero__content {
            animation: none;
          }

          .techtorch-hero .techtorch-hero__image,
          .techtorch-hero .techtorch-hero__cta,
          .techtorch-hero .techtorch-hero__arrow,
          .techtorch-hero .techtorch-hero__dot span {
            transition: none;
          }
        }
      `})]})};function eb(){return i.jsxs("section",{className:"w-full h-full grid grid-cols-1 lg:grid-cols-2 items-start relative",style:{backgroundImage:"url('/Section.webp')",backgroundSize:"cover",backgroundPosition:"center",backgroundRepeat:"no-repeat"},children:[i.jsx("div",{className:"relative bg-[#F6F2EA]/80 flex items-center overflow-hidden h-[400px] lg:h-[540px]",children:i.jsxs("div",{className:`\r
            relative\r
            z-10\r
            px-4\r
            sm:px-6\r
            md:px-10\r
            lg:px-[100px]\r
            max-w-xl\r
          `,children:[i.jsx("h2",{className:"text-2xl sm:text-3xl lg:text-[32px] font-plus-jakarta text-gray-900 leading-tight",children:"Build. Connect. Grow."}),i.jsx("h3",{className:"text-xl sm:text-2xl lg:text-[24px] font-plus-jakarta text-[#730042] mt-1",children:"With TechTorch Solutions"}),i.jsx("p",{className:"text-gray-600 text-[15px] sm:text-[15px] font-inter mt-10 max-w-md",children:"We bring technology, expertise and people together to solve real business challenges, create practical digital solutions and help businesses work smarter, adapt faster, and move forward with confidence."}),i.jsxs("div",{className:"flex items-center gap-4 mt-14",children:[i.jsx(ve,{to:"/KnowMore",className:"px-6 py-2.5 rounded-md bg-[#730042] text-white text-[13px] font-inter font-semibold tracking-wide no-underline hover:bg-[#970052] transition-colors duration-200",children:"KNOW MORE"}),i.jsx(ve,{to:"/Our-Story",className:"px-6 py-2.5 rounded-md border border-[#730042] text-[#730042] text-[13px] font-inter font-semibold tracking-wide no-underline hover:bg-[#730042] hover:text-white transition-colors duration-200",children:"OUR STORY"})]})]})}),i.jsx("div",{className:`\r
          w-full\r
          h-[280px]\r
          sm:h-[350px]\r
          md:h-[400px]\r
          lg:h-[540px]\r
          overflow-hidden\r
        `,children:i.jsx("img",{src:"/frame2.webp",alt:"TechTorch Solutions office building",className:`\r
            w-full\r
            h-full\r
            object-cover\r
            object-center\r
          `})})]})}function tb(){const[s,d]=c.useState(null),[x,f]=c.useState(!1),y=()=>{f(!0),setTimeout(()=>{d(null),f(!1)},600)};return s==="understand"?i.jsx("section",{className:"w-full bg-[#730042] min-h-[520px]",children:i.jsx("div",{className:"w-full px-4 sm:px-6 md:px-10 lg:px-20 py-8 sm:py-10 lg:py-12",children:i.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-10 items-center",children:[i.jsxs("div",{className:"text-white",children:[i.jsx("h2",{className:`\r
                  translate-y-[10px]\r
                  text-[32px]\r
                  sm:text-[34px]\r
                  lg:text-[36px]\r
                  font-plus-jakarta\r
                  font-bold\r
                  text-white\r
                `,children:"UNDERSTAND"}),i.jsx("p",{className:`\r
                  mt-4\r
                  sm:mt-10\r
                  lg:mt-12\r
                  text-[15px]\r
                  sm:text-[16px]\r
                  lg:text-[16px]\r
                  font-inter\r
                  leading-relaxed\r
                  max-w-[650px]\r
                `,children:"We take the time to understand your business, requirements, challenges, processes, users, and long-term goals. By gaining a clear understanding of how your business operates and where improvements are needed, we identify the right opportunities and define a focused direction. This ensures that every solution we build is aligned with your business objectives, user needs, and growth."}),i.jsxs("button",{onClick:y,className:`\r
                  mt-8\r
                  sm:mt-10\r
                  lg:mt-12\r
                  flex\r
                  items-center\r
                  gap-2\r
                  sm:gap-3\r
                  border\r
                  border-white\r
                  px-3\r
                  sm:px-4\r
                  py-1.5\r
                  sm:py-2\r
                  text-white\r
                  text-[14px]\r
                  sm:text-[16px]\r
                  font-inter\r
                  font-semibold\r
                  hover:bg-white/90\r
                  hover:text-[#730042]\r
                  hover:border-white\r
                  transition-all\r
                  duration-300\r
                `,children:[i.jsx("span",{className:"text-[24px] sm:text-[26px] leading-none",children:"←"}),i.jsx("span",{children:"Back"})]})]}),i.jsx("div",{className:"flex justify-center lg:justify-end",children:i.jsx("div",{className:`
                  relative
                  w-full
                  max-w-[420px]
                  border-[5px]
                  border-white
                  overflow-hidden
                  ${x?"animate-imageSlideBack":"animate-imageSlide"}
                `,children:i.jsx("img",{src:"/Sec3.2.webp",alt:"Understand",className:"w-full h-auto object-cover"})})})]})})}):s==="build"?i.jsx("section",{className:"w-full bg-[#730042] min-h-[520px]",children:i.jsx("div",{className:"w-full px-4 sm:px-6 md:px-10 lg:px-20 py-8 sm:py-10 lg:py-12",children:i.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-10 items-center",children:[i.jsxs("div",{className:"text-white",children:[i.jsx("h2",{className:`\r
                  translate-y-[10px]\r
                 text-[32px]\r
                  sm:text-[34px]\r
                  lg:text-[36px]\r
                  font-plus-jakarta\r
                  font-bold\r
                  text-white\r
                `,children:"BUILD"}),i.jsx("p",{className:`\r
                  mt-4\r
                  sm:mt-10\r
                  lg:mt-12\r
                  text-[15px]\r
                  sm:text-[16px]\r
                  lg:text-[16px]\r
                  font-inter\r
                  leading-relaxed\r
                  max-w-[650px]\r
                `,children:"Once we understand your business needs, we turn ideas and requirements into practical digital solutions. We design and develop technology around your specific goals, processes, and users—from software applications and digital platforms to AI, cloud, and enterprise solutions. Our focus is on building solutions that are reliable, scalable, secure, and easy to use, while creating a strong foundation for long-term business growth."}),i.jsxs("button",{onClick:y,className:`\r
                  mt-8\r
                  sm:mt-10\r
                  lg:mt-12\r
                  flex\r
                  items-center\r
                  gap-2\r
                  sm:gap-3\r
                  border\r
                  border-white\r
                  px-3\r
                  sm:px-4\r
                  py-1.5\r
                  sm:py-2\r
                  text-white\r
                  text-[14px]\r
                  sm:text-[16px]\r
                  font-inter\r
                  font-semibold\r
                  hover:bg-white/90\r
                  hover:text-[#730042]\r
                  hover:border-white\r
                  transition-all\r
                  duration-300\r
                `,children:[i.jsx("span",{className:"text-[24px] sm:text-[26px] leading-none",children:"←"}),i.jsx("span",{children:"Back"})]})]}),i.jsx("div",{className:"flex justify-center lg:justify-end",children:i.jsx("div",{className:`
                  relative
                  w-full
                  max-w-[420px]
                  border-[5px]
                  border-white
                  overflow-hidden
                  ${x?"animate-imageSlideBack":"animate-imageSlide"}
                `,children:i.jsx("img",{src:"/Sec3.3.webp",alt:"Build",className:"w-full h-auto object-cover"})})})]})})}):s==="grow"?i.jsx("section",{className:"w-full bg-[#730042] min-h-[520px]",children:i.jsx("div",{className:"w-full px-4 sm:px-6 md:px-10 lg:px-20 py-8 sm:py-10 lg:py-12",children:i.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-10 items-center",children:[i.jsxs("div",{className:"text-white",children:[i.jsx("h2",{className:`\r
                  translate-y-[1px]\r
                  text-[32px]\r
                  sm:text-[34px]\r
                  lg:text-[36px]\r
                  font-plus-jakarta\r
                  font-bold\r
                  text-white\r
                `,children:"GROW"}),i.jsx("p",{className:`\r
                  mt-4\r
                  sm:mt-10\r
                  lg:mt-12\r
                  text-[15px]\r
                  sm:text-[16px]\r
                  lg:text-[16px]\r
                  font-inter\r
                  leading-relaxed\r
                  max-w-[650px]\r
                `,children:"Our relationship continues beyond deployment. We provide ongoing support, maintenance, optimization, and continuous improvements to ensure your solutions remain effective as your business evolves. By adapting to changing requirements, emerging technologies, and new opportunities, we help you improve performance, stay competitive, and build a strong foundation for sustainable long-term growth."}),i.jsxs("button",{onClick:y,className:`\r
                  mt-8\r
                  sm:mt-10\r
                  lg:mt-12\r
                  flex\r
                  items-center\r
                  gap-2\r
                  sm:gap-3\r
                  border\r
                  border-white\r
                  px-3\r
                  sm:px-4\r
                  py-1.5\r
                  sm:py-2\r
                  text-white\r
                  text-[14px]\r
                  sm:text-[16px]\r
                  font-inter\r
                  font-semibold\r
                  hover:bg-white/90\r
                  hover:text-[#730042]\r
                  hover:border-white\r
                  transition-all\r
                  duration-300\r
                `,children:[i.jsx("span",{className:"text-[24px] sm:text-[26px] leading-none",children:"←"}),i.jsx("span",{children:"Back"})]})]}),i.jsx("div",{className:"flex justify-center lg:justify-end",children:i.jsx("div",{className:`
                  relative
                  w-full
                  max-w-[420px]
                  border-[5px]
                  border-white
                  overflow-hidden
                  ${x?"animate-imageSlideBack":"animate-imageSlide"}
                `,children:i.jsx("img",{src:"/Sec3.4.webp",alt:"Grow",className:"w-full h-auto object-cover"})})})]})})}):i.jsx("section",{className:"w-full bg-[#730042] min-h-[520px]",children:i.jsx("div",{className:"w-full px-4 sm:px-6 md:px-10 lg:px-[100px] py-8 sm:py-10 lg:py-12",children:i.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-10 items-center",children:[i.jsxs("div",{className:"text-white lg:-translate-y-8",children:[i.jsx("h2",{className:`\r
                mt-1\r
                text-[32px]\r
                sm:text-[34px]\r
                lg:text-[36px]\r
                font-bold\r
                font-plus-jakarta\r
              `,children:"HOW WE WORK"}),i.jsxs("h3",{className:`\r
                mt-6\r
                sm:mt-9\r
                text-[15px]\r
                sm:text-[14px]\r
                lg:text-[15px]\r
                font-inter\r
                text-white\r
                max-w-[650px]\r
                leading-relaxed\r
              `,children:["We understand your needs, build practical",i.jsx("br",{className:"hidden sm:block"})," solutions, and help your business grow",i.jsx("br",{className:"hidden sm:block"})," with technology."]}),i.jsxs("p",{className:`\r
                mt-8\r
                text-[13.5px]\r
                font-inter\r
                leading-relaxed\r
                max-w-[650px]\r
              `,children:["Our approach is simple:",i.jsx("br",{}),"first understand the business, then build the",i.jsx("br",{className:"hidden sm:block"}),"right solution, and continuously improve",i.jsx("br",{className:"hidden sm:block"}),"it as your needs evolve."]}),i.jsxs("div",{className:"mt-14 flex flex-wrap gap-5",children:[i.jsx("button",{onClick:()=>d("understand"),className:`\r
                  bg-white\r
                  text-[#730042]\r
                  px-4\r
                  py-2\r
                  text-[13px]\r
                  font-bold\r
                  font-inter\r
                  border\r
                  border-white\r
                  rounded-sm\r
                  transition-all\r
                  duration-300\r
                  hover:bg-[#730042]\r
                  hover:text-white\r
                  hover:border-white\r
                  hover:-translate-y-1\r
                  hover:shadow-[0_6px_15px_rgba(115,0,66,0.4)]\r
                `,children:"UNDERSTAND"}),i.jsx("button",{onClick:()=>d("build"),className:`\r
                  bg-white\r
                  text-[#730042]\r
                  px-4\r
                  py-2\r
                  text-[13px]\r
                  font-bold\r
                  font-inter\r
                  border\r
                  border-white\r
                  rounded-sm\r
                  transition-all\r
                  duration-300\r
                  hover:bg-[#730042]\r
                  hover:text-white\r
                  hover:border-white\r
                  hover:-translate-y-1\r
                  hover:shadow-[0_6px_15px_rgba(115,0,66,0.4)]\r
                `,children:"BUILD"}),i.jsx("button",{onClick:()=>d("grow"),className:`\r
                  bg-white\r
                  text-[#730042]\r
                  px-4\r
                  py-2\r
                  text-[13px]\r
                  font-bold\r
                  font-inter\r
                  border\r
                  border-white\r
                  rounded-sm\r
                  transition-all\r
                  duration-300\r
                  hover:bg-[#730042]\r
                  hover:text-white\r
                  hover:border-white\r
                  hover:-translate-y-1\r
                  hover:shadow-[0_6px_15px_rgba(115,0,66,0.4)]\r
                `,children:"GROW"})]})]}),i.jsx("div",{className:"flex justify-center lg:justify-end",children:i.jsx("div",{className:`\r
                relative\r
                w-full\r
                max-w-[440px]\r
                aspect-square\r
                border-[5px]\r
                border-white\r
                overflow-hidden\r
              `,children:i.jsx("img",{src:"/Sec3.1.webp",alt:"TechTorch Solutions",className:"w-full h-full object-cover object-center"})})})]})})})}const nb=[{tag:"TECHTORCH VIEW · ARTIFICIAL INTELLIGENCE",title:i.jsxs(i.Fragment,{children:["AI Is Moving Into",i.jsx("br",{}),"Everyday Business"]}),desc:"AI is becoming part of everyday business, changing how teams work, make decisions and create better experiences.",bg:"url('sec4.1.webp')",bgColor:"#2b2620",link:"/TechTorchView"},{tag:"FIELD NOTE · BUSINESS OPERATIONS",title:i.jsxs(i.Fragment,{children:["Better Connections Make",i.jsx("br",{}),"Better Work"]}),desc:"When teams, information and processes work together, everyday business becomes easier to manage.",bg:"url('sec4.2.webp')",bgColor:"#050810",link:"/field-note"},{tag:"THINK AHEAD · EMERGING TECHNOLOGY",title:i.jsxs(i.Fragment,{children:["What Comes Next Can Change",i.jsx("br",{}),"How We Work"]}),desc:"New technologies are opening up different ways to solve problems, create value and rethink what's possible.",bg:"url('sec4.3.webp')",bgColor:"#c9d3da",link:"/think-ahead"},{tag:"IN FOCUS · CYBERSECURITY",title:i.jsxs(i.Fragment,{children:["Security Shouldn't Be An",i.jsx("br",{}),"Afterthought"]}),desc:"As more work moves online, building security into everyday technology is becoming more important than ever.",bg:"url('sec4.4.webp')",bgColor:"#04070d",link:"/cyber-security"},{tag:"TECH PULSE · DATA & DECISIONS",title:i.jsxs(i.Fragment,{children:["More Data Doesn't Always Mean",i.jsx("br",{}),"Better Decisions"]}),desc:"Businesses have more data than ever. The real challenge is finding what matters and turning it into useful decisions.",bg:"url('sec4.5.webp')",bgColor:"#020306",link:"/data-decisions"},{tag:"BUSINESS GROWTH",title:i.jsxs(i.Fragment,{children:["Technology Should Grow With",i.jsx("br",{}),"Your Business"]}),desc:"As business needs change, technology should be flexible enough to adapt, scale and keep supporting what comes next.",bg:"url('sec4.6.webp')",bgColor:"#0a0a0a",link:"/Business-growth"}];function ab({tag:s,title:d,desc:x,bg:f,bgColor:y,imageUrl:E,link:S}){return i.jsxs("div",{className:"wn-card",style:{backgroundColor:y,backgroundImage:E?`url(${E})`:f,backgroundSize:"cover",backgroundPosition:"center"},children:[i.jsx("div",{className:"wn-overlay"}),i.jsx("div",{className:"wn-glass"}),i.jsx("div",{className:"wn-tag",children:s}),i.jsxs("div",{className:"wn-content",children:[i.jsx("h2",{className:"wn-title",children:d}),i.jsx("p",{className:"wn-desc",children:x}),i.jsxs("a",{className:"wn-read-more",href:S,children:["Read More ",i.jsx("span",{children:"→"})]})]})]})}function lb(){return i.jsxs("div",{className:"wn-wrap",children:[i.jsx("style",{children:`
  .wn-wrap {
    width: 100%;
    font-family: "Plus Jakarta Sans", sans-serif;
    color: #111;
    background: #fff;
    box-sizing: border-box;

    /* Vertical padding */
    padding-top: 60px;
    padding-bottom: 60px;

    /* Left/right padding same as Hero: 16 / 24 / 40 / 100 */
    padding-left: 16px;
    padding-right: 16px;
  }

  @media (min-width: 640px) {
    .wn-wrap {
      padding-left: 24px;
      padding-right: 24px;
    }
  }

  @media (min-width: 768px) {
    .wn-wrap {
      padding-left: 40px;
      padding-right: 40px;
    }
  }

  @media (min-width: 1024px) {
    .wn-wrap {
      padding-left: 100px;
      padding-right: 100px;
    }
  }

  /* ================= HEADER ================= */

  .wn-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    flex-wrap: wrap;
    gap: 20px;
    margin-bottom: 36px;
  }

  .wn-header h1 {
    font-family: "Plus Jakarta Sans", sans-serif;
    font-size: 36px;
    font-weight: 800;
    letter-spacing: -0.5px;
    margin: 0;
  }

  .wn-header p {
    font-family: "Plus Jakarta Sans", sans-serif;
    font-size: 16px;
    line-height: 1.5;
    color: #4a4a4a;
    max-width: 520px;
    margin: 0;
  }

  /* ================= GRID ================= */

  .wn-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 24px;
  }

  /* ================= CARD ================= */

  .wn-card {
    position: relative;
    width: 100%;
    height: 340px;
    border-radius: 6px;
    overflow: hidden;
    cursor: pointer;
    isolation: isolate;
    box-sizing: border-box;
  }

  /* ================= OVERLAY ================= */

  .wn-overlay {
    position: absolute;
    inset: 0;
    background: linear-gradient(
      to top,
      rgba(0,0,0,0.85) 0%,
      rgba(0,0,0,0.35) 45%,
      rgba(0,0,0,0) 70%
    );

    backdrop-filter: blur(0px) saturate(100%);
    -webkit-backdrop-filter: blur(0px) saturate(100%);

    transition:
      background 0.4s ease,
      backdrop-filter 0.4s ease;
    
    z-index: 1;
  }

  .wn-card:hover .wn-overlay {
    background: linear-gradient(
      to top,
      rgba(10,10,10,0.5) 0%,
      rgba(10,10,10,0.3) 55%,
      rgba(10,10,10,0.12) 100%
    );

    backdrop-filter: blur(4px) saturate(120%);
    -webkit-backdrop-filter: blur(4px) saturate(120%);
  }

  /* ================= GLASS ================= */

  .wn-glass {
    position: absolute;
    inset: 0;
    z-index: 1;
    pointer-events: none;
    opacity: 0;

    backdrop-filter: blur(0px);
    -webkit-backdrop-filter: blur(0px);

    background: rgba(255,255,255,0);

    transition:
      opacity 0.4s ease,
      backdrop-filter 0.4s ease,
      background 0.4s ease;
  }

  .wn-card:hover .wn-glass {
    opacity: 1;

    backdrop-filter: blur(3px) saturate(120%);
    -webkit-backdrop-filter: blur(3px) saturate(120%);

    background: rgba(255,255,255,0.04);
  }

  /* ================= TAG ================= */

  .wn-tag {
    position: absolute;
    top: 20px;
    left: 20px;
    right: 20px;

    width: fit-content;
    max-width: calc(100% - 40px);

    z-index: 3;

    background: rgba(0,0,0,0.55);
    color: #fff;

    font-family: "Plus Jakarta Sans", sans-serif;
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.6px;

    padding: 6px 12px;
    border-radius: 3px;

    box-sizing: border-box;
  }

  /* ================= CONTENT ================= */

  .wn-content {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;

    z-index: 3;

    padding: 24px;
    box-sizing: border-box;
  }

  /* ================= TITLE ================= */

  .wn-title {
    color: #fff;

    font-family: "Plus Jakarta Sans", sans-serif;

    font-size: 22px;
    font-weight: 800;
    line-height: 1.2;

    margin: 0 0 12px 0;

    transition: transform 0.4s ease;
  }

  .wn-card:hover .wn-title {
    transform: translateY(-50px);
  }

  /* ================= DESCRIPTION ================= */

  .wn-desc {
    color: #e7e7e7;

    font-family: "Inter", sans-serif;

    font-size: 15px;
    line-height: 1.5;

    max-width: 420px;
    max-height: 0;

    opacity: 0;
    overflow: hidden;

    margin: 0;

    transition:
      max-height 0.35s ease,
      opacity 0.3s ease,
      margin 0.35s ease,
      transform 0.4s ease;
  }

  .wn-card:hover .wn-desc {
    max-height: 120px;
    opacity: 1;
    margin: 0 0 14px 0;
    transform: translateY(-40px);
  }

  /* ================= READ MORE ================= */

  .wn-read-more {
    display: inline-flex;
    align-items: center;
    gap: 6px;

    color: #fff;

    font-family: "Inter", sans-serif;
    font-size: 15px;
    font-weight: 600;

    text-decoration: none;

    opacity: 0;

    transform: translateY(8px);

    transition:
      opacity 0.3s ease 0.1s,
      transform 0.3s ease 0.1s;
  }

  .wn-card:hover .wn-read-more {
    opacity: 1;
    transform: translateY(0);
  }

  .wn-read-more span {
    transition: transform 0.25s ease;
  }

  .wn-card:hover .wn-read-more span {
    transform: translateX(4px);
  }


  /* ==================================================
     TABLET
     ================================================== */

  @media (max-width: 1100px) {

    .wn-wrap {
      padding-top: 50px;
      padding-bottom: 50px;
    }

    .wn-header h1 {
      font-size: 40px;
    }

    .wn-header p {
      font-size: 17px;
      max-width: 450px;
    }

    .wn-grid {
      gap: 20px;
    }

    .wn-card {
      height: 320px;
    }

    .wn-title {
      font-size: 21px;
    }

    .wn-desc {
      font-size: 15px;
    }

    .wn-content {
      padding: 22px;
    }
  }


  /* ==================================================
     TABLET / SMALL LAPTOP
     ================================================== */

  @media (max-width: 900px) {

    .wn-wrap {
      padding-top: 45px;
      padding-bottom: 45px;
    }

    .wn-header {
      flex-direction: column;
      gap: 12px;
      margin-bottom: 28px;
    }

    .wn-header h1 {
      font-size: 36px;
    }

    .wn-header p {
      max-width: 100%;
      font-size: 16px;
    }

    .wn-grid {
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 18px;
    }

    .wn-card {
      height: 300px;
    }

    .wn-title {
      font-size: 19px;
    }

    .wn-desc {
      font-size: 14px;
    }

    .wn-content {
      padding: 20px;
    }

    .wn-tag {
      top: 16px;
      left: 16px;
      font-size: 10.5px;
      padding: 5px 9px;
    }
  }


  /* ==================================================
     MOBILE
     ================================================== */

  @media (max-width: 600px) {

    .wn-wrap {
      padding-top: 40px;
      padding-bottom: 40px;
    }

    .wn-header {
      margin-bottom: 24px;
    }

    .wn-header h1 {
      font-size: 30px;
      line-height: 1.2;
    }

    .wn-header p {
      font-size: 15px;
      line-height: 1.5;
    }

    .wn-grid {
      grid-template-columns: 1fr;
      gap: 18px;
    }

    .wn-card {
      width: 100%;
      height: 300px;
      border-radius: 6px;
    }

    .wn-tag {
      top: 16px;
      left: 16px;
      right: 16px;

      max-width: calc(100% - 32px);

      font-size: 10px;
      letter-spacing: 0.4px;

      padding: 5px 8px;

      white-space: normal;
    }

    .wn-content {
      padding: 18px;
    }

    .wn-title {
      font-size: 20px;
      line-height: 1.25;
    }

    .wn-desc {
      font-size: 14px;
      line-height: 1.45;
      max-width: 100%;
    }

    .wn-card:hover .wn-title {
      transform: translateY(-40px);
    }

    .wn-card:hover .wn-desc {
      transform: translateY(-30px);
      max-height: 140px;
    }

    .wn-read-more {
      font-size: 14px;
    }
  }


  /* ==================================================
     SMALL MOBILE
     ================================================== */

  @media (max-width: 400px) {

    .wn-wrap {
      padding-top: 32px;
      padding-bottom: 32px;
    }

    .wn-header h1 {
      font-size: 27px;
    }

    .wn-header p {
      font-size: 14px;
    }

    .wn-card {
      height: 290px;
    }

    .wn-content {
      padding: 16px;
    }

    .wn-title {
      font-size: 19px;
    }

    .wn-desc {
      font-size: 13.5px;
    }

    .wn-tag {
      font-size: 9px;
    }
  }
`}),i.jsxs("div",{className:"wn-header",children:[i.jsx("h1",{children:"What's Next"}),i.jsx("p",{children:"Ideas, trends and technology shaping how businesses adapt, evolve and move forward."})]}),i.jsx("div",{className:"wn-grid",children:nb.map(s=>i.jsx(ab,{...s},s.tag))})]})}const _l=[{title:"Platforms",img:"/card1.webp",href:"/platform"},{title:"Digital Solutions",img:"/card2.webp",href:"/digitalsolution"},{title:"Our Services",img:"/card3.webp",href:"/OurService"},{title:"IT Augmentation Service",img:"/card5.webp",href:"/ItAugmentation"},{title:"Artificial Intelligent",img:"/card6.webp",href:"/ArtificialIntelligent"}];function ib({title:s,img:d,href:x,position:f}){return i.jsxs("div",{className:`cap-card cap-card-${f}`,"aria-hidden":Math.abs(f)>1,children:[i.jsx("div",{className:"cap-card-art",children:i.jsx("img",{loading:"lazy",decoding:"async",src:d,alt:s,className:"cap-card-img",draggable:!1})}),i.jsxs(ve,{to:x,className:"cap-card-label",children:[i.jsx("span",{className:"cap-card-title",children:s}),i.jsx("span",{className:"cap-card-arrow",children:"→"})]})]})}function ob(){const[s,d]=c.useState(1),x=()=>{d(E=>(E+1)%_l.length)},f=()=>{d(E=>(E-1+_l.length)%_l.length)};c.useEffect(()=>{const E=setInterval(()=>{d(S=>(S+1)%_l.length)},3e3);return()=>clearInterval(E)},[]);const y=E=>{const S=_l.length;let C=E-s;return C>S/2&&(C-=S),C<-S/2&&(C+=S),C};return i.jsxs("section",{className:"cap-section",children:[i.jsx("style",{children:`

        /* =====================================================
           SECTION
        ===================================================== */

        .cap-section {
          width: 100%;
          box-sizing: border-box;

          background: #730042;

          background-image:
            linear-gradient(
              rgba(255, 255, 255, 0.05) 1px,
              transparent 1px
            ),
            linear-gradient(
              90deg,
              rgba(255, 255, 255, 0.05) 1px,
              transparent 1px
            );

          background-size: 18px 18px;

          padding-top: 56px;
          padding-bottom: 64px;

          overflow: hidden;

          font-family:
            "Plus Jakarta Sans",
            sans-serif;
        }


        /* =====================================================
           HEADER
        ===================================================== */

        
.cap-header {
  width: 100%;
  max-width: 1600px;
  margin: 0 auto 25px;
  padding: 0 100px;
  box-sizing: border-box;

  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 30px;
  flex-wrap: wrap;
}

/* Tablet */
@media (max-width: 1023px) {
  .cap-header {
    padding: 0 40px;
  }
}

/* Mobile */
@media (max-width: 767px) {
  .cap-header {
    padding: 0 24px;
  }
}

/* Small mobile */
@media (max-width: 480px) {
  .cap-header {
    padding: 0 16px;
  }
}



        /* =====================================================
           TITLE
        ===================================================== */

        .cap-title {
          color: #ffffff;

          font-size: 38px;

          font-weight: 600;

          margin: 0;

          letter-spacing: -0.02em;

          transform: translateY(-10px);
        }


        /* =====================================================
           DESCRIPTION
        ===================================================== */

        .cap-desc {
          color: rgba(255, 255, 255, 0.92);

          font-size: 18px;

          line-height: 1.5;

          max-width: 620px;

          margin: 0;

          transform: translateY(-10px);
        }


        /* =====================================================
           SLIDER
        ===================================================== */

        .cap-slider {
          width: 100%;

          overflow: hidden;

          padding: 35px 0 45px;

          box-sizing: border-box;
        }


        /* =====================================================
           TRACK
        ===================================================== */

        .cap-slider-track {
          width: 100%;

          height: 430px;

          position: relative;

          display: block;

          overflow: visible;

          box-sizing: border-box;
        }


        /* =====================================================
           CARD
        ===================================================== */

        .cap-card {
          width: 300px;

          position: absolute;

          left: 50%;
          top: 50%;

          background: #ffffff;

          border: 4px solid #ffffff;

          border-radius: 16px;

          overflow: hidden;

          box-sizing: border-box;

          box-shadow:
            0 14px 34px rgba(0, 0, 0, 0.30);

          transition:
            transform 0.85s cubic-bezier(0.22, 1, 0.36, 1),
            opacity 0.7s ease,
            box-shadow 0.7s ease,
            filter 0.7s ease;

          will-change: transform, opacity;

          pointer-events: auto;

          z-index: 1;
        }


        /* =====================================================
           CENTER
        ===================================================== */

        .cap-card-0 {
          transform:
            translate3d(-50%, -50%, 0)
            scale(1.10);

          opacity: 1;

          z-index: 5;

          box-shadow:
            0 30px 65px rgba(0, 0, 0, 0.45);

          filter: none;
        }


        /* =====================================================
           LEFT
        ===================================================== */

        .cap-card--1 {
          transform:
            translate3d(
              calc(-50% - 345px),
              calc(-50% + 8px),
              0
            )
            scale(0.90);

          opacity: 0.72;

          z-index: 2;

          box-shadow:
            0 14px 34px rgba(0, 0, 0, 0.30);
        }


        /* =====================================================
           RIGHT
        ===================================================== */

        .cap-card-1 {
          transform:
            translate3d(
              calc(-50% + 345px),
              calc(-50% + 8px),
              0
            )
            scale(0.90);

          opacity: 0.72;

          z-index: 2;

          box-shadow:
            0 14px 34px rgba(0, 0, 0, 0.30);
        }


        /* =====================================================
           HIDDEN CARDS
        ===================================================== */

        .cap-card--2,
        .cap-card-2,
        .cap-card--3,
        .cap-card-3,
        .cap-card--4,
        .cap-card-4 {
          transform:
            translate3d(-50%, -50%, 0)
            scale(0.80);

          opacity: 0;

          pointer-events: none;

          z-index: 0;
        }


        /* =====================================================
           IMAGE
        ===================================================== */

        .cap-card-art {
          width: 100%;

          aspect-ratio: 1 / 1;

          overflow: hidden;
        }


        .cap-card-img {
          width: 100%;
          height: 100%;

          object-fit: cover;

          display: block;

          user-select: none;
          -webkit-user-drag: none;
        }


        /* =====================================================
           LABEL
        ===================================================== */

        .cap-card-label {
          padding: 14px 18px 16px;

          display: flex;

          align-items: center;

          justify-content: flex-start;

          color: #16161a;

          font-size: 16px;

          font-weight: 600;

          white-space: nowrap;

          text-decoration: none;

          transition:
            color 0.3s ease;
        }


        .cap-card-title {
          white-space: nowrap;
        }


        .cap-card-label:hover {
          color: #730042;
        }


        /* =====================================================
           CARD ARROW
        ===================================================== */

        .cap-card-arrow {
          margin-left: 8px;

          color: #730042;

          font-size: 20px;

          font-weight: 600;

          opacity: 0;

          transform:
            translate3d(-8px, 0, 0);

          transition:
            opacity 0.25s ease,
            transform 0.25s ease;
        }


        .cap-card-label:hover .cap-card-arrow {
          opacity: 1;

          transform:
            translate3d(0, 0, 0);
        }


        /* =====================================================
           CONTROLS
        ===================================================== */

        .cap-controls {
          display: flex;

          justify-content: center;
          align-items: center;

          gap: 14px;

          margin-top: 4px;
        }


        /* =====================================================
           CONTROL BUTTON
        ===================================================== */

        .cap-control-btn {
          position: relative;

          width: 50px;
          height: 50px;

          padding: 0;
          margin: 0;

          border: 1px solid rgba(255, 255, 255, 0.42);

          border-radius: 14px;

          background:
            linear-gradient(
              145deg,
              rgba(255, 255, 255, 0.20),
              rgba(255, 255, 255, 0.07)
            );

          backdrop-filter: blur(14px);
          -webkit-backdrop-filter: blur(14px);

          color: #ffffff;

          display: flex;

          align-items: center;
          justify-content: center;

          font-family:
            "Plus Jakarta Sans",
            sans-serif;

          font-size: 24px;

          font-weight: 400;

          line-height: 1;

          cursor: pointer;

          overflow: hidden;

          box-shadow:
            0 8px 25px rgba(0, 0, 0, 0.16),
            inset 0 1px 0 rgba(255, 255, 255, 0.20);

          transition:
            background 0.35s ease,
            border-color 0.35s ease,
            color 0.35s ease,
            transform 0.35s cubic-bezier(0.22, 1, 0.36, 1),
            box-shadow 0.35s ease;

          -webkit-tap-highlight-color: transparent;
        }


        /* =====================================================
           ARROW
        ===================================================== */

        .cap-control-arrow {
          position: relative;

          z-index: 3;

          display: flex;

          align-items: center;
          justify-content: center;

          width: 100%;
          height: 100%;

          color: inherit;

          line-height: 1;

          transform: translateX(0);

          transition:
            color 0.3s ease,
            transform 0.35s cubic-bezier(0.22, 1, 0.36, 1);
        }


        /* =====================================================
           SHINE
        ===================================================== */

        .cap-control-btn::before {
          content: "";

          position: absolute;

          top: 0;
          left: -130%;

          width: 80%;
          height: 100%;

          background:
            linear-gradient(
              90deg,
              transparent,
              rgba(255, 255, 255, 0.30),
              transparent
            );

          transform: skewX(-20deg);

          transition:
            left 0.65s ease;

          pointer-events: none;

          z-index: 1;
        }


        /* =====================================================
           INNER HIGHLIGHT
        ===================================================== */

        .cap-control-btn::after {
          content: "";

          position: absolute;

          inset: 1px;

          border-radius: 13px;

          background:
            linear-gradient(
              145deg,
              rgba(255, 255, 255, 0.10),
              transparent 55%
            );

          pointer-events: none;

          z-index: 1;
        }


        /* =====================================================
           HOVER
        ===================================================== */

        .cap-control-btn:hover {
          background: #ffffff;

          border-color: #ffffff;

          color: #730042;

          box-shadow:
            0 14px 32px rgba(0, 0, 0, 0.24),
            0 0 24px rgba(255, 255, 255, 0.14);

          transform:
            translateY(-4px)
            scale(1.04);
        }


        /* =====================================================
           HOVER SHINE
        ===================================================== */

        .cap-control-btn:hover::before {
          left: 130%;
        }


        /* =====================================================
           LEFT ARROW HOVER
        ===================================================== */

        .cap-control-btn:first-child:hover {
          transform:
            translate(-4px, -4px)
            scale(1.04);
        }

        .cap-control-btn:first-child:hover .cap-control-arrow {
          transform: translateX(-3px);
        }


        /* =====================================================
           RIGHT ARROW HOVER
        ===================================================== */

        .cap-control-btn:last-child:hover {
          transform:
            translate(4px, -4px)
            scale(1.04);
        }

        .cap-control-btn:last-child:hover .cap-control-arrow {
          transform: translateX(3px);
        }


        /* =====================================================
           ACTIVE
        ===================================================== */

        .cap-control-btn:active {
          transform:
            scale(0.92);

          box-shadow:
            0 5px 14px rgba(0, 0, 0, 0.18);
        }


        .cap-control-btn:first-child:active,
        .cap-control-btn:last-child:active {
          transform: scale(0.92);
        }


        /* =====================================================
           FOCUS
        ===================================================== */

        .cap-control-btn:focus-visible {
          outline: none;

          border-color: #ffffff;

          box-shadow:
            0 0 0 3px rgba(255, 255, 255, 0.24),
            0 10px 28px rgba(0, 0, 0, 0.22);
        }


        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 767px) {

          .cap-controls {
            gap: 11px;

            margin-top: 2px;
          }

          .cap-control-btn {
            width: 46px;
            height: 46px;

            border-radius: 13px;

            font-size: 22px;
          }
        }


        /* =====================================================
           SMALL MOBILE
        ===================================================== */

        @media (max-width: 480px) {

          .cap-controls {
            gap: 9px;
          }

          .cap-control-btn {
            width: 43px;
            height: 43px;

            border-radius: 11px;

            font-size: 20px;
          }
        }


        /* =====================================================
           REDUCED MOTION
        ===================================================== */

        @media (prefers-reduced-motion: reduce) {

          .cap-control-btn,
          .cap-control-btn::before,
          .cap-control-arrow {
            transition: none;
          }
        }

      `}),i.jsxs("div",{className:"cap-header",children:[i.jsx("h2",{className:"cap-title",children:"Capabilities"}),i.jsx("p",{className:"cap-desc",children:"We bring together technology, expertise and practical solutions to solve complex business challenges. From digital platforms to AI, we help businesses work smarter, adapt and grow."})]}),i.jsx("div",{className:"cap-slider",children:i.jsx("div",{className:"cap-slider-track",children:_l.map((E,S)=>{const C=y(S);return i.jsx(ib,{...E,position:C},E.title)})})}),i.jsxs("div",{className:"cap-controls",children:[i.jsx("button",{type:"button",className:"cap-control-btn",onClick:f,"aria-label":"Previous card",children:i.jsx("span",{className:"cap-control-arrow",children:"←"})}),i.jsx("button",{type:"button",className:"cap-control-btn",onClick:x,"aria-label":"Next card",children:i.jsx("span",{className:"cap-control-arrow",children:"→"})})]})]})}const Lt={cream:"#F9F8F2",ink:"#191013",brand:"#730042"};function rb({children:s}){return i.jsxs("div",{className:"flex items-center gap-2.5",style:{marginBottom:"28px",fontSize:"15px",fontWeight:700,textTransform:"uppercase",letterSpacing:"0.14em",color:Lt.ink},children:[i.jsx("span",{style:{display:"block",width:"24px",height:"2px",backgroundColor:Lt.brand}}),s]})}function sb(){return i.jsx("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",className:"shrink-0","aria-hidden":"true",children:i.jsx("path",{d:"M3 8H13M13 8L8.5 3.5M13 8L8.5 12.5",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round"})})}function cb({children:s}){return i.jsxs("a",{href:"https://torchxsuite.com",target:"_blank",rel:"noopener noreferrer",className:"tx-cta inline-flex items-center justify-center gap-2.5 self-start rounded-lg whitespace-nowrap w-full sm:w-auto",style:{marginTop:"10px",border:`1.5px solid ${Lt.brand}`,color:Lt.brand,padding:"6px 14px",fontSize:"16px",fontWeight:700,textDecoration:"none"},children:[s,i.jsx(sb,{})]})}function ub(){return i.jsxs("div",{className:"flex w-full max-w-2xl flex-col justify-center tx-copy",style:{paddingTop:"65px",paddingBottom:"65px"},children:[i.jsx(rb,{children:"The Next Chapter"}),i.jsxs("h1",{className:"tx-heading",style:{marginBottom:"24px",fontSize:"26px",lineHeight:1.18,fontFamily:"Plus Jakarta Sans",fontWeight:600,color:Lt.ink,letterSpacing:"-0.01em"},children:["We had an"," ",i.jsx("span",{style:{color:Lt.brand},children:"idea."})," Then we"," ",i.jsx("span",{style:{color:Lt.brand},children:"built it."})]}),i.jsx("p",{className:"tx-suite",style:{marginBottom:"20px",fontSize:"25px",fontFamily:"Plus Jakarta Sans",fontWeight:600,lineHeight:1.25,color:Lt.brand},children:"TorchX Suite"}),i.jsx("p",{className:"tx-intro",style:{marginBottom:"40px",fontSize:"20px",fontFamily:"Plus Jakarta Sans",maxWidth:"28rem",lineHeight:1.5,fontWeight:500,color:"#1e1e1e"},children:"One connected platform for the way your business works."}),i.jsx("p",{className:"tx-description",style:{marginBottom:"16px",marginTop:"-10px",fontFamily:"Inter",fontSize:"15px",maxWidth:"28rem",lineHeight:1.65,fontWeight:400,color:"#1e1e1e"},children:"TorchX Suite brings HR, finance, payroll, inventory, and customer operations together in one place — helping teams work with less complexity, better visibility, and more confidence."}),i.jsx(cb,{children:"Explore TorchX Suite"})]})}function db(){return i.jsx("div",{className:"tx-image-panel relative w-full h-full flex items-center justify-end overflow-hidden",children:i.jsx("img",{loading:"lazy",decoding:"async",src:"/sec7.webp",alt:"TorchX Suite",className:"tx-image block"})})}function fb(){return i.jsxs("div",{className:"w-full font-sans",style:{backgroundColor:"#fff",isolation:"isolate"},children:[i.jsx("style",{children:`
        .tx-cta {
          transition: all 0.25s ease;
          cursor: pointer;
        }

        .tx-cta:hover {
          background-color: ${Lt.brand};
          color: ${Lt.cream} !important;
          transform: translateY(-1px);
        }

        .tx-cta svg {
          transition: transform 0.25s ease;
        }

        .tx-cta:hover svg {
          transform: translateX(3px);
        }

        .tx-section {
          width: 100%;
          display: grid;
          grid-template-columns: 45% 55%;
          align-items: stretch;
          background: ${Lt.cream};
          overflow: hidden;
          padding-left: 16px;
          padding-right: 16px;
          box-sizing: border-box;
        }

        .tx-copy-wrapper {
          width: 100%;
          min-width: 0;
          display: flex;
          align-items: center;
        }

        .tx-image-wrapper {
          width: 100%;
          min-width: 0;
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: flex-end;
          overflow: hidden;
        }

        .tx-image-panel {
          width: 100%;
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: flex-end;
          overflow: hidden;
        }

        .tx-image {
          display: block;
          width: 120%;
          height: 100%;
          object-fit: contain;
          object-position: center right;
          max-width: none;
        }

        @media (min-width: 640px) {
          .tx-section {
            padding-left: 24px;
            padding-right: 24px;
          }
        }

        @media (min-width: 768px) {
          .tx-section {
            padding-left: 40px;
            padding-right: 40px;
          }
        }

        @media (max-width: 767px) {
          .tx-section {
            display: flex;
            flex-direction: column;
            height: auto;
          }

          .tx-copy-wrapper {
            order: 1;
            width: 100%;
            height: auto;
          }

          .tx-image-wrapper {
            order: 2;
            width: 100%;
            height: auto;
            min-height: 0;
          }

          .tx-copy {
            width: 100%;
            max-width: none;
            padding: 40px 0 35px !important;
          }

          .tx-heading {
            font-size: 26px !important;
            line-height: 1.25 !important;
            margin-bottom: 18px !important;
          }

          .tx-suite {
            font-size: 25px !important;
            margin-bottom: 14px !important;
          }

          .tx-intro {
            font-size: 18px !important;
            line-height: 1.5 !important;
            margin-bottom: 22px !important;
            max-width: 100% !important;
          }

          .tx-description {
            font-size: 16px !important;
            line-height: 1.6 !important;
            margin-bottom: 18px !important;
            max-width: 100% !important;
          }

          .tx-cta {
            width: 100%;
            font-size: 15px !important;
            padding: 11px 18px !important;
          }

          .tx-image-panel {
            width: 100%;
            height: auto;
            min-height: 0;
          }

          .tx-image {
            display: block;
            width: 100%;
            height: auto;
            max-width: 100%;
            object-fit: contain;
            object-position: center center;
          }
        }

        @media (min-width: 768px) and (max-width: 1023px) {
          .tx-section {
            height: 450px;
            grid-template-columns: 46% 54%;
            align-items: stretch;
          }

          .tx-copy-wrapper,
          .tx-image-wrapper {
            height: 450px;
          }

          .tx-image-panel {
            width: 100%;
            height: 450px;
          }

          .tx-copy {
            padding-left: 0 !important;
            padding-right: 30px !important;
            padding-top: 45px !important;
            padding-bottom: 45px !important;
          }

          .tx-heading {
            font-size: 28px !important;
          }

          .tx-suite {
            font-size: 27px !important;
          }

          .tx-intro {
            font-size: 20px !important;
          }

          .tx-description {
            font-size: 16px !important;
          }

          .tx-image {
            width: 120%;
            height: 100%;
            max-width: none;
            object-fit: contain;
            object-position: center right;
          }
        }

        @media (min-width: 1024px) {
          .tx-section {
            padding-left: 100px;
            padding-right: 100px;
          }
        }

        @media (min-width: 1024px) and (max-width: 1279px) {
          .tx-section {
            height: 460px;
            grid-template-columns: 44% 56%;
            align-items: stretch;
          }

          .tx-copy-wrapper,
          .tx-image-wrapper {
            height: 460px;
          }

          .tx-image-panel {
            width: 100%;
            height: 460px;
          }

          .tx-copy {
            padding-left: 0 !important;
            padding-right: 35px !important;
            padding-top: 50px !important;
            padding-bottom: 50px !important;
          }

          .tx-heading {
            font-size: 30px !important;
          }

          .tx-suite {
            font-size: 28px !important;
          }

          .tx-intro {
            font-size: 21px !important;
          }

          .tx-description {
            font-size: 15px !important;
          }

          .tx-image {
            width: 125%;
            height: 100%;
            max-width: none;
            object-fit: contain;
            object-position: center right;
          }
        }

        @media (min-width: 1280px) {
          .tx-section {
            height: 510px;
            grid-template-columns: 43% 57%;
            align-items: stretch;
          }

          .tx-copy-wrapper,
          .tx-image-wrapper {
            height: 510px;
          }

          .tx-image-panel {
            width: 100%;
            height: 510px;
          }

          .tx-copy {
            padding-left: 0 !important;
            padding-right: 45px !important;
            padding-top: 60px !important;
            padding-bottom: 60px !important;
          }

          .tx-image {
            width: 125%;
            height: 100%;
            max-width: none;
            object-fit: contain;
            object-position: center right;
          }
        }

        @media (min-width: 1600px) {
          .tx-section {
            height: 490px;
            grid-template-columns: 42% 58%;
          }

          .tx-copy {
            padding-left: 0 !important;
            padding-right: 55px !important;
          }

          .tx-image {
            width: 130%;
            height: 100%;
            max-width: none;
            object-fit: contain;
            object-position: center right;
          }
        }
      `}),i.jsxs("section",{className:"tx-section",children:[i.jsx("div",{className:"tx-copy-wrapper",children:i.jsx(ub,{})}),i.jsx("div",{className:"tx-image-wrapper",children:i.jsx(db,{})})]})]})}const Rt={cream:"#F5F1E8",maroon:"#7A1350",ink:"#1A1A1A",grey:"#5B5B5B",border:"#ECE7DC"},eu=[{id:"education",title:"Education",description:"Connected solutions for better learning experiences.",image:"/Education 2 [Vectorized].svg",path:"/industries/education"},{id:"insurance",title:"Insurance",description:"Digital solutions for smarter, more resilient insurance.",image:"/Insurance 2 [Vectorized].svg",path:"/industries/insurance"},{id:"finance",title:"Finance",description:"Secure technology built for modern financial services.",image:"/Finance.svg",path:"/industries/finance"},{id:"healthcare",title:"Healthcare",description:"Technology that enables smarter, connected care.",image:"/Healthcare 2 [Vectorized].svg",path:"/industries/healthcare"},{id:"manufacturing",title:"Manufacturing",description:"Smarter technology for connected operations.",image:"/Manufacturing 2 [Vectorized].svg",path:"/industries/manufacturing"},{id:"fmcg",title:"FMCG",description:"Connected solutions for smarter movement and operations.",image:"/FMCG 2 [Vectorized].svg",path:"/industries/fmcg"},{id:"it",title:"Information Technology",description:"Digital capabilities built to accelerate innovation.",image:"/Information-Technology 2 [Vectorized].svg",path:"/industries/information-technology"},{id:"energy",title:"Energy",description:"Technology for efficient, evolving energy ecosystems.",image:"/Energy 3 [Vectorized] (1).svg",path:"/industries/energy"},{id:"telecommunications",title:"Telecommunications",description:"Scalable solution for connected experiences.",image:"/Telecommunications 2 [Vectorized].svg",path:"/industries/telecommunications"},{id:"transportation",title:"Transportation",description:"Connected solutions for smarter movement and operations.",image:"/Transportation 2 [Vectorized].svg",path:"/industries/transportation"},{id:"E-Commerce",title:"E-Commerce",description:"Scalable experiences for a connected marketplace.",image:"/TechTorch_E-Commerce_Icon 1.svg",path:"/industries/e-commerce"}];function hb({src:s,alt:d,hovered:x}){return i.jsx("div",{className:"industry-image-wrapper",children:i.jsx("img",{loading:"lazy",decoding:"async",src:s,alt:d,className:`industry-image ${x?"industry-image-hovered":""}`})})}function mb({item:s}){const[d,x]=hn.useState(!1);return i.jsxs(ve,{to:s.path,className:`industry-card ${d?"industry-card-hovered":""}`,onMouseEnter:()=>x(!0),onMouseLeave:()=>x(!1),children:[i.jsx("div",{className:"industry-icon-box",children:i.jsx(hb,{src:s.image,alt:s.title,hovered:d})}),i.jsx("h3",{className:"industry-title",children:s.title}),i.jsx("p",{className:"industry-description",children:s.description}),i.jsxs("span",{className:"industry-link",children:["Explore Industry",i.jsxs("svg",{viewBox:"0 0 24 24",width:"16",height:"16",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",className:`industry-arrow ${d?"industry-arrow-hovered":""}`,children:[i.jsx("line",{x1:"5",y1:"12",x2:"19",y2:"12"}),i.jsx("polyline",{points:"12 5 19 12 12 19"})]})]})]})}function pb(){const[s,d]=hn.useState(!1),x=hn.useRef(null),[f,y]=hn.useState(0),E=hn.useRef(304),S=hn.useRef(null);hn.useEffect(()=>{const R=()=>{if(!x.current)return;const O=x.current.querySelector(".industry-card");if(!O)return;const D=window.getComputedStyle(O),ie=parseFloat(D.marginRight)||0;E.current=O.offsetWidth+ie};return R(),window.addEventListener("resize",R),()=>{window.removeEventListener("resize",R)}},[]);const C=()=>{x.current&&(d(!0),y(R=>R-E.current),x.current.style.transition="transform 0.55s ease",x.current.style.transform=`translateX(${f-E.current}px)`)},M=()=>{x.current&&(d(!0),y(R=>R+E.current),x.current.style.transition="transform 0.55s ease",x.current.style.transform=`translateX(${f+E.current}px)`)};hn.useEffect(()=>{if(s)return;const R=x.current;if(!R)return;let O=f;const D=.45,ie=()=>{s||(O-=D,y(O),R.style.transform=`translateX(${O}px)`),S.current=requestAnimationFrame(ie)};return S.current=requestAnimationFrame(ie),()=>{S.current&&cancelAnimationFrame(S.current)}},[s]),hn.useEffect(()=>{const R=x.current;if(!R)return;const O=eu.length*E.current;if(Math.abs(f)>=O){const D=f+O;y(D),R.style.transition="none",R.style.transform=`translateX(${D}px)`}if(f>0){const D=f-O;y(D),R.style.transition="none",R.style.transform=`translateX(${D}px)`}},[f]);const N=[...eu,...eu];return i.jsxs("section",{id:"industries",className:"industries-section",style:{scrollMarginTop:"90px"},children:[i.jsx("style",{children:`

        /* =====================================================
           SECTION
        ===================================================== */

        .industries-section {
          position: relative;

          width: 100%;

          /*
             HOW WE WORK SAME HORIZONTAL SPACING
             Mobile = 16px
             Small = 24px
             Tablet = 40px
             Desktop = 100px
          */

          padding:
            64px
            16px
            72px;

          background: ${Rt.cream};

          background-image:
            repeating-linear-gradient(
              90deg,
              rgba(122,19,80,0.06) 0px,
              rgba(122,19,80,0.06) 1px,
              transparent 1px,
              transparent 145px
            );

          font-family:
            Plus Jakarta Sans,
            "Segoe UI",
            Roboto,
            Helvetica,
            Arial,
            sans-serif;

          color: ${Rt.ink};

          overflow: hidden;

          box-sizing: border-box;
        }


        /* =====================================================
           SMALL
           640px+
        ===================================================== */

        @media (min-width: 640px) {
          .industries-section {
            padding-left: 24px;
            padding-right: 24px;
          }
        }


        /* =====================================================
           TABLET
           768px+
        ===================================================== */

        @media (min-width: 768px) {
          .industries-section {
            padding-left: 40px;
            padding-right: 40px;
          }
        }


        /* =====================================================
           DESKTOP
           1024px+
        ===================================================== */

        @media (min-width: 1024px) {
          .industries-section {
            padding-left: 100px;
            padding-right: 100px;
          }
        }


        /* =====================================================
           HEADER WRAPPER
        ===================================================== */

        .industries-header-wrapper {
          width: 100%;

          display: flex;

          align-items: flex-end;

          justify-content: space-between;

          gap: 30px;

          margin-bottom: 48px;
        }


        /* =====================================================
           HEADER
        ===================================================== */

        .industries-header {
          width: 100%;

          max-width: 640px;

          margin: 0;
        }


        .industries-heading {
          margin: 0 0 16px;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 38px;

          line-height: 1.15;

          font-weight: 700;

          letter-spacing: -0.5px;
        }


        .industries-heading span {
          color: ${Rt.maroon};
        }


        .industries-subtitle {
          margin: 0;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 15px;

          line-height: 1.5;

          color: ${Rt.grey};
        }


        /* =====================================================
           CONTROLS
        ===================================================== */

        .industries-controls {
          display: flex;

          align-items: center;

          gap: 10px;

          flex-shrink: 0;

          margin-bottom: 5px;
        }


        .industry-control-btn {
          width: 46px;

          height: 46px;

          border: 1px solid ${Rt.maroon};

          border-radius: 50%;

          background: transparent;

          color: ${Rt.maroon};

          display: flex;

          align-items: center;

          justify-content: center;

          cursor: pointer;

          transition:
            background 0.25s ease,
            color 0.25s ease,
            transform 0.25s ease;
        }


        .industry-control-btn:hover {
          background: ${Rt.maroon};

          color: #ffffff;

          transform: translateY(-2px);
        }


        .industry-control-btn:active {
          transform: translateY(0);
        }


        /* =====================================================
           CAROUSEL VIEWPORT
        ===================================================== */

        .industries-viewport {
          width: 100%;

          overflow: hidden;

          padding-top: 14px;

          padding-bottom: 8px;

          margin-top: -14px;

          mask-image:
            linear-gradient(
              90deg,
              transparent,
              black 3%,
              black 97%,
              transparent
            );

          -webkit-mask-image:
            linear-gradient(
              90deg,
              transparent,
              black 3%,
              black 97%,
              transparent
            );
        }


        /* =====================================================
           TRACK
        ===================================================== */

        .industries-track {
          display: flex;

          width: max-content;

          will-change: transform;
        }


        /* =====================================================
           CARD
        ===================================================== */

        .industry-card {
          width: 280px;

          min-width: 280px;

          height: 360px;

          margin-right: 24px;

          padding:
            30px
            28px
            26px;

          background: #ffffff;

          border:
            1px solid ${Rt.border};

          border-radius: 16px;

          display: flex;

          flex-direction: column;

          flex-shrink: 0;

          box-shadow:
            0 1px 2px rgba(0,0,0,0.03);

          text-decoration: none;

          color: inherit;

          cursor: pointer;

          transition:
            box-shadow 0.3s ease,
            transform 0.3s ease;

          box-sizing: border-box;
        }


        .industry-card-hovered {
          transform:
            translateY(-4px);

          box-shadow:
            0 12px 28px
            rgba(122,19,80,0.14);
        }


        /* =====================================================
           IMAGE
        ===================================================== */

        .industry-icon-box {
          width: 100px;

          height: 100px;

          margin-bottom: 22px;

          flex-shrink: 0;

          overflow: visible;

          position: relative;

          z-index: 2;
        }


        .industry-image-wrapper {
          width: 100%;

          height: 100%;

          overflow: visible;

          border-radius: 12px;

          display: flex;

          align-items: center;

          justify-content: center;

          position: relative;
        }


        .industry-image {
          width: 100%;

          height: 100%;

          object-fit: contain;

          transform-origin: center center;

          transition:
            transform 0.4s ease,
            filter 0.3s ease;

          transform:
            translate(0, 0)
            scale(1);
        }


        .industry-image-hovered {
          animation:
            softFloat
            1.5s
            ease-in-out
            infinite;
        }


        @keyframes softFloat {

          0% {
            transform:
              translateY(0)
              scale(1);
          }

          50% {
            transform:
              translateY(-7px)
              scale(1.04);
          }

          100% {
            transform:
              translateY(0)
              scale(1);
          }

        }


        /* =====================================================
           TITLE
        ===================================================== */

        .industry-title {
          margin:
            0
            0
            9px;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 18px;

          line-height: 1.3;

          font-weight: 700;

          color: ${Rt.ink};
        }


        /* =====================================================
           DESCRIPTION
        ===================================================== */

        .industry-description {
          margin:
            0
            0
            20px;
          font-family: "Inter", sans-serif;
          font-size: 15px;

          line-height: 1.5;

          color: ${Rt.grey};

          flex-grow: 1;
        }


        /* =====================================================
           LINK
        ===================================================== */

        .industry-link {
          display: inline-flex;

          align-items: center;

          gap: 8px;

          width: fit-content;

          color: ${Rt.maroon};
          font-family: "Inter", sans-serif;

          font-size: 14px;

          font-weight: 600;

          text-decoration: none;
        }


        .industry-arrow {
          transition:
            transform 0.2s ease;
        }


        .industry-arrow-hovered {
          transform:
            translateX(4px);
        }


        /* =====================================================
           TABLET
        ===================================================== */

        @media (max-width: 1023px) {

          .industries-section {
            padding-top: 56px;
            padding-bottom: 64px;
          }


          .industries-header-wrapper {
            margin-bottom: 40px;
          }


          .industries-heading {
            font-size: 36px;
          }


          .industries-subtitle {
            font-size: 18px;
          }


          .industry-control-btn {
            width: 42px;

            height: 42px;
          }


          .industry-card {
            width: 260px;

            min-width: 260px;

            height: 345px;

            margin-right: 20px;

            padding:
              26px
              24px
              24px;
          }


          .industry-icon-box {
            width: 88px;

            height: 88px;

            margin-bottom: 18px;
          }


          .industry-title {
            font-size: 19px;
          }


          .industry-description {
            font-size: 14px;
          }

        }


        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 767px) {

          .industries-section {
            padding-top: 48px;
            padding-bottom: 56px;
          }


          .industries-header-wrapper {
            align-items: flex-end;

            gap: 15px;

            margin-bottom: 32px;
          }


          .industries-header {
            max-width: 100%;
          }


          .industries-heading {
            font-size: 32px;

            line-height: 1.2;

            letter-spacing: -0.4px;

            margin-bottom: 12px;
          }


          .industries-subtitle {
            font-size: 16px;

            line-height: 1.55;
          }


          .industries-controls {
            gap: 7px;

            margin-bottom: 0;
          }


          .industry-control-btn {
            width: 38px;

            height: 38px;
          }


          .industry-control-btn svg {
            width: 17px;

            height: 17px;
          }


          .industries-viewport {
            margin-left: 0;

            width: 100%;

            padding-top: 12px;

            margin-top: -12px;
          }


          .industry-card {
            width: 250px;

            min-width: 250px;

            height: 335px;

            margin-right: 16px;

            padding:
              25px
              22px
              23px;

            border-radius: 14px;
          }


          .industry-icon-box {
            width: 82px;

            height: 82px;

            margin-bottom: 18px;
          }


          .industry-title {
            font-size: 18px;

            margin-bottom: 9px;
          }


          .industry-description {
            font-size: 14px;

            line-height: 1.5;

            margin-bottom: 18px;
          }


          .industry-link {
            font-size: 14px;
          }

        }


        /* =====================================================
           SMALL MOBILE
        ===================================================== */

        @media (max-width: 479px) {

          .industries-section {
            padding-top: 40px;
            padding-bottom: 48px;
          }


          .industries-header-wrapper {
            align-items: flex-end;

            gap: 10px;

            margin-bottom: 28px;
          }


          .industries-heading {
            font-size: 28px;
          }


          .industries-subtitle {
            font-size: 15px;
          }


          .industry-control-btn {
            width: 35px;

            height: 35px;
          }


          .industry-control-btn svg {
            width: 15px;

            height: 15px;
          }


          .industry-card {
            width: 235px;

            min-width: 235px;

            height: 320px;

            margin-right: 14px;

            padding:
              23px
              20px
              21px;
          }


          .industry-icon-box {
            width: 76px;

            height: 76px;

            margin-bottom: 17px;
          }


          .industry-title {
            font-size: 17px;
          }


          .industry-description {
            font-size: 13.5px;
          }


          .industry-link {
            font-size: 13.5px;
          }

        }


        /* =====================================================
           TOUCH DEVICES
        ===================================================== */

        @media (hover: none) {

          .industry-card-hovered {
            transform: none;

            box-shadow:
              0 1px 2px rgba(0,0,0,0.03);
          }


          .industry-image-hovered {
            animation: none;

            transform:
              scale(1)
              translateY(0);

            filter: none;
          }


          .industry-arrow-hovered {
            transform: none;
          }

        }


        /* =====================================================
           REDUCED MOTION
        ===================================================== */

        @media (prefers-reduced-motion: reduce) {

          .industries-track {
            animation: none;
          }


          .industry-card,
          .industry-image,
          .industry-arrow {
            transition: none;
          }

        }

      `}),i.jsxs("div",{className:"industries-header-wrapper",children:[i.jsxs("div",{className:"industries-header",children:[i.jsxs("h1",{className:"industries-heading",children:["Technology Across ",i.jsx("span",{children:"Industries"})]}),i.jsxs("p",{className:"industries-subtitle",children:["Technology solutions shaped around the unique needs of",i.jsx("br",{className:"desktop-break"}),"industry we serve."]})]}),i.jsxs("div",{className:"industries-controls",children:[i.jsx("button",{type:"button",className:"industry-control-btn",onClick:M,"aria-label":"Previous",children:i.jsxs("svg",{viewBox:"0 0 24 24",width:"20",height:"20",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[i.jsx("line",{x1:"19",y1:"12",x2:"5",y2:"12"}),i.jsx("polyline",{points:"12 19 5 12 12 5"})]})}),i.jsx("button",{type:"button",className:"industry-control-btn",onClick:C,"aria-label":"Next",children:i.jsxs("svg",{viewBox:"0 0 24 24",width:"20",height:"20",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[i.jsx("line",{x1:"5",y1:"12",x2:"19",y2:"12"}),i.jsx("polyline",{points:"12 5 19 12 12 19"})]})})]})]}),i.jsx("div",{className:"industries-viewport",onMouseEnter:()=>d(!0),onMouseLeave:()=>d(!1),children:i.jsx("div",{ref:x,className:"industries-track",children:N.map((R,O)=>i.jsx(mb,{item:R},`${R.id}-${O}`))})})]})}const tu={maroon:"#7A1350",white:"#FFFFFF"};function gb({backgroundImage:s="/sec9.webp"}){const d=El();return i.jsxs("section",{className:"cta-section",children:[i.jsx("style",{children:`
        /* =========================
           MAIN SECTION
        ========================== */

        .cta-section {
          position: relative;
          width: 100%;
          min-height: 560px;

          overflow: hidden;

          display: flex;
          align-items: center;

          font-family: "Plus Jakarta Sans", sans-serif;

          /* HOW WE WORK SAME HORIZONTAL SPACING */
          padding-left: 16px;
          padding-right: 16px;

          box-sizing: border-box;
        }


        /* =========================
           BACKGROUND IMAGE
        ========================== */

        .cta-bg {
          position: absolute;
          inset: 0;

          background-image: url("${s}");
          background-size: cover;
          background-position: center;
          background-repeat: no-repeat;
        }


        /* =========================
           OVERLAY
        ========================== */

        .cta-overlay {
          position: absolute;
          inset: 0;

          background:
            linear-gradient(
              90deg,
              rgba(0,0,0,0.72) 0%,
              rgba(0,0,0,0.45) 45%,
              rgba(0,0,0,0.15) 75%,
              rgba(0,0,0,0) 100%
            );
        }


        /* =========================
           CONTENT
        ========================== */

        .cta-content {
          position: relative;
          z-index: 2;

          width: 100%;
          max-width: 640px;

          padding: 0;
        }


        /* =========================
           HEADING
        ========================== */

        .cta-title {
          margin: 0 0 24px;
          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 38px;
          line-height: 1.2;
          font-weight: 700;

          color: ${tu.white};

          letter-spacing: -0.5px;
        }


        /* =========================
           DESCRIPTION
        ========================== */

        .cta-description {
          max-width: 480px;

          margin: 0 0 40px;
          font-family: "Inter", sans-serif;
          font-size: 16px;
          line-height: 1.6;

          color: rgba(255,255,255,0.9);
        }


        /* =========================
           BUTTON
        ========================== */

        .cta-button {
          display: inline-flex;
          align-items: center;
          justify-content: center;

          gap: 10px;

          background: ${tu.white};
          color: ${tu.maroon};

          font-weight: 700;
          font-size: 14px;

          padding: 14px 24px;

          border-radius: 10px;

          text-decoration: none;

          width: fit-content;

          margin-top: 30px;

          transition:
            transform 0.15s ease,
            box-shadow 0.15s ease;
        }

        .cta-button:hover {
         background: #730042;
         color: #ffffff;
          transform: translateY(-2px);

          box-shadow:
            0 8px 20px rgba(0,0,0,0.25);
        }

        .cta-button svg {
          flex-shrink: 0;

          transition:
            transform 0.2s ease;
        }

        .cta-button:hover svg {
          transform: translateX(3px);
        }


        /* =========================
           SMALL DEVICES
           640px+
        ========================== */

        @media (min-width: 640px) {

          .cta-section {
            padding-left: 24px;
            padding-right: 24px;
          }
        }


        /* =========================
           TABLET
           768px+
        ========================== */

        @media (min-width: 768px) {

          .cta-section {
            padding-left: 40px;
            padding-right: 40px;
          }
        }


        /* =========================
           DESKTOP
           1024px+
        ========================== */

        @media (min-width: 1024px) {

          .cta-section {
            padding-left: 100px;
            padding-right: 100px;
          }
        }


        /* =========================
           TABLET
           Below 1023px
        ========================== */

        @media (max-width: 1023px) {

          .cta-section {
            min-height: 500px;
          }

          .cta-content {
            max-width: 580px;
          }

          .cta-title {
            font-size: 40px;
            line-height: 1.18;
          }

          .cta-description {
            font-size: 16px;
            max-width: 440px;
          }

          .cta-button {
            font-size: 15px;
            padding: 15px 24px;
          }
        }


        /* =========================
           MOBILE
           Below 767px
        ========================== */

        @media (max-width: 767px) {

          .cta-section {
            min-height: 520px;

            border-radius: 8px;

            align-items: flex-end;
          }

          .cta-bg {
            background-position: center;
          }

          .cta-overlay {
            background:
              linear-gradient(
                180deg,
                rgba(0,0,0,0.15) 0%,
                rgba(0,0,0,0.35) 35%,
                rgba(0,0,0,0.72) 70%,
                rgba(0,0,0,0.85) 100%
              );
          }

          .cta-content {
            max-width: 100%;

            padding:
              40px
              0
              42px;
          }

          .cta-title {
            font-size: 32px;
            line-height: 1.2;

            letter-spacing: -0.3px;

            margin-bottom: 18px;
          }

          .cta-description {
            max-width: 100%;

            font-size: 15px;
            line-height: 1.55;

            margin-bottom: 24px;
          }

          .cta-button {
            width: fit-content;

            font-size: 14px;

            padding:
              14px
              20px;

            margin-top: 18px;

            border-radius: 8px;
          }

          .cta-button svg {
            width: 17px;
            height: 17px;
          }
        }


        /* =========================
           SMALL MOBILE
           Below 480px
        ========================== */

        @media (max-width: 479px) {

          .cta-section {
            min-height: 500px;
          }

          .cta-content {
            padding:
              32px
              0
              30px;
          }

          .cta-title {
            font-size: 28px;
            line-height: 1.2;

            margin-bottom: 16px;
          }

          .cta-description {
            font-size: 14px;
            line-height: 1.55;

            margin-bottom: 20px;
          }

          .cta-description br {
            display: none;
          }

          .cta-button {
            width: 100%;

            padding:
              14px
              18px;

            font-size: 14px;
          }
        }


        /* =========================
           VERY SMALL DEVICES
           Below 360px
        ========================== */

        @media (max-width: 359px) {

          .cta-section {
            min-height: 470px;
          }

          .cta-content {
            padding:
              28px
              0
              26px;
          }

          .cta-title {
            font-size: 25px;
          }

          .cta-description {
            font-size: 13.5px;
          }

          .cta-button {
            font-size: 13px;
          }
        }


        /* =========================
           REDUCED MOTION
        ========================== */

        @media (prefers-reduced-motion: reduce) {

          .cta-button,
          .cta-button svg {
            transition: none;
          }
        }
      `}),i.jsx("div",{className:"cta-bg"}),i.jsx("div",{className:"cta-overlay"}),i.jsxs("div",{className:"cta-content",children:[i.jsx("h2",{className:"cta-title",children:"Let’s build something great together."}),i.jsxs("p",{className:"cta-description",children:["Have an idea, a challenge, or a vision?",i.jsx("br",{}),"Let’s talk about how technology can help bring it to life."]}),i.jsxs("a",{href:"#contact",className:"cta-button",onClick:x=>{x.preventDefault(),d("/start-conversation")},children:["Start a conversation",i.jsxs("svg",{viewBox:"0 0 24 24",width:"18",height:"18",fill:"none",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round",children:[i.jsx("line",{x1:"5",y1:"12",x2:"19",y2:"12"}),i.jsx("polyline",{points:"12 5 19 12 12 19"})]})]})]})]})}const Jm=c.lazy(()=>h(()=>import("./AccessPage-C_NCWN7m.js"),__vite__mapDeps([18,1,2,19]))),xb=c.lazy(()=>h(()=>import("./CandidateDashboard-9Atca06f.js"),__vite__mapDeps([32,1,2,12,8,26,27,16]))),yb=c.lazy(()=>h(()=>import("./Careers-F9cTpkWY.js"),__vite__mapDeps([33,1,2,12,34]))),vb=c.lazy(()=>h(()=>import("./Blogs-CI4LwJxq.js"),__vite__mapDeps([35,1,2,12,36,37]))),bb=c.lazy(()=>h(()=>import("./BlogDetail-D-PQxSL3.js"),__vite__mapDeps([38,1,2,12,37]))),_b=c.lazy(()=>h(()=>import("./PrivacyPolicy-Bu6oIHTe.js"),__vite__mapDeps([39,1,2]))),Tb=c.lazy(()=>h(()=>import("./TalkToExpert-Hmnv84n_.js"),__vite__mapDeps([40,1,2]))),Eb=c.lazy(()=>h(()=>import("./TechTorchWay-0a9AkzkY.js"),__vite__mapDeps([41,1,2,42,43,44,45]))),wb=c.lazy(()=>h(()=>import("./CaseStudies-DYDiG--N.js"),__vite__mapDeps([46,1,2,47,43]))),jb=c.lazy(()=>h(()=>import("./OpManagement-DH3eflM6.js"),__vite__mapDeps([48,1,2]))),Sb=c.lazy(()=>h(()=>import("./CultureInclusion-CZvodXKe.js"),__vite__mapDeps([49,1,2,8,50,51]))),zb=c.lazy(()=>h(()=>import("./PeopleManagement-CxTz2WGN.js"),__vite__mapDeps([52,1,2,53,54,37,5,55,8]))),Ab=c.lazy(()=>h(()=>import("./WebPortal-C54UIYFQ.js"),__vite__mapDeps([56,1,2,53,43,57,26,55,8,45,58]))),Ob=c.lazy(()=>h(()=>import("./PaymentManagement-CEoLh8b6.js"),__vite__mapDeps([59,1,2,23,60,61,62,55,19,63,64,65]))),Nb=c.lazy(()=>h(()=>import("./HealthcareHospitalManagementPage-BaMeJ-kI.js"),__vite__mapDeps([66,1,2,23,53,44,67,68,57,69]))),Db=c.lazy(()=>h(()=>import("./CrmSolutionsPage-B8X4q0gQ.js"),__vite__mapDeps([70,1,2,71,53,72,57,73,55,74,64,7]))),Cb=c.lazy(()=>h(()=>import("./EcommerceSolutionsPage-BzSjj2bU.js"),__vite__mapDeps([75,1,2,64,62,76,77,57]))),Rb=c.lazy(()=>h(()=>import("./ProjectManagementSolutionsPage-Cl_Dsxey.js"),__vite__mapDeps([78,1,2,5,57,53,23,7,55,19,74]))),Lb=c.lazy(()=>h(()=>import("./AviationManagement-cNmtU5dl.js"),__vite__mapDeps([79,1,2,74,62,19,80,5,58,64]))),Mb=c.lazy(()=>h(()=>import("./SupplyChainManagement-B-MGFQAs.js"),__vite__mapDeps([81,1,2,19,55,82,83,10,84,58,68]))),kb=c.lazy(()=>h(()=>import("./SoftwareDevelopmentSupportPage-Bd_w8Ex7.js"),__vite__mapDeps([85,1,2,43,55,86,65,51,64,57]))),Vb=c.lazy(()=>h(()=>import("./ResourceStaffingPage-DsO9KNEG.js"),__vite__mapDeps([87,1,2,43,53,5,55,37,69]))),Ub=c.lazy(()=>h(()=>import("./CloudInfrastructurePage-BSy4zSb0.js"),__vite__mapDeps([88,1,2,65,55,89]))),Bb=c.lazy(()=>h(()=>import("./SoftwareEngineeringOutsourcingPage-BaPmr_t7.js"),__vite__mapDeps([90,1,2,43,91,86,92,93,94,72,44,65,77,47,95,64]))),Hb=c.lazy(()=>h(()=>import("./ITConsultancyPage-BAjBehdA.js"),__vite__mapDeps([96,1,2,97,84,55,10]))),qb=c.lazy(()=>h(()=>import("./NotFound-B89QEctI.js"),__vite__mapDeps([98,1,2]))),Ib=c.lazy(()=>h(()=>import("./ExploreSolutions-Ji9bVEp8.js"),__vite__mapDeps([99,1,2,100,29,31]))),Yb=c.lazy(()=>h(()=>import("./ERP-DH7RZsIH.js"),__vite__mapDeps([101,1,2,102,103,100,29,31,104,105]))),Xb=c.lazy(()=>h(()=>import("./ErpSolutions-CfhBnVTF.js"),__vite__mapDeps([106,1,2,44,105,80,23,54,69,73,45,19,64,53,55,58]))),Gb=c.lazy(()=>h(()=>import("./BuildTechTorch-kdOkkfDZ.js"),__vite__mapDeps([107,1,2,100,29,31,74,10,108,97,86,44,63,30]))),Qb=c.lazy(()=>h(()=>import("./TechnologyServices-BfZZBhO6.js"),__vite__mapDeps([109,1,2,100,29,31,30,42,110,65,111,104]))),Zb=c.lazy(()=>h(()=>import("./TorchXSuite-6oaDaTsB.js"),__vite__mapDeps([112,1,2,100,29,31]))),Kb=c.lazy(()=>h(()=>import("./PhilosophySection-729VSvxr.js"),__vite__mapDeps([113,1,2]))),Pb=c.lazy(()=>h(()=>import("./EnterpriseReadiness-BMvandCZ.js"),__vite__mapDeps([114,1,2,100,29,31]))),Jb=c.lazy(()=>h(()=>import("./ScaleAtSpeed-douBbsY2.js"),__vite__mapDeps([115,1,2,116]))),Fb=c.lazy(()=>h(()=>import("./CoreFoundation-toHT84hX.js"),__vite__mapDeps([117,1,2,116]))),Wb=c.lazy(()=>h(()=>import("./StrategicCapabilities-USbDkn5N.js"),__vite__mapDeps([118,1,2]))),$b=c.lazy(()=>h(()=>import("./TransformationForm-Ny8Er47G.js"),__vite__mapDeps([119,1,2,120,31]))),e2=c.lazy(()=>h(()=>import("./EnterpriseAcceleration-dxCX6wL7.js"),__vite__mapDeps([121,1,2]))),t2=c.lazy(()=>h(()=>import("./PracticalIntelligence-Iy5fasDC.js"),__vite__mapDeps([122,1,2]))),n2=c.lazy(()=>h(()=>import("./ProvenImpact-B4K_Tw-E.js"),__vite__mapDeps([123,1,2]))),a2=c.lazy(()=>h(()=>import("./TransformationReady-QZHBMkGo.js"),__vite__mapDeps([124,1,2]))),l2=c.lazy(()=>h(()=>import("./TechTorchView-BIREg2io.js"),__vite__mapDeps([125,1,2]))),i2=c.lazy(()=>h(()=>import("./Philosophy-cEY45yOS.js"),__vite__mapDeps([126,1,2]))),o2=c.lazy(()=>h(()=>import("./Capabilities-C6L8bt8o.js"),__vite__mapDeps([127,1,2]))),r2=c.lazy(()=>h(()=>import("./DeploymentMethodology-Bx4w11Hg.js"),__vite__mapDeps([128,1,2,102,103]))),s2=c.lazy(()=>h(()=>import("./Banner-GZippcXm.js"),__vite__mapDeps([129,1,2]))),c2=c.lazy(()=>h(()=>import("./TechnologySection-Bp3CZ70z.js"),__vite__mapDeps([130,1,2]))),u2=c.lazy(()=>h(()=>import("./ConnectSection-BI3g4Zkm.js"),__vite__mapDeps([131,1,2]))),d2=c.lazy(()=>h(()=>import("./OperationalAdvantage-DxnJOHSX.js"),__vite__mapDeps([132,1,2]))),f2=c.lazy(()=>h(()=>import("./IntegratedCapabilities-DqLDFREp.js"),__vite__mapDeps([133,1,2]))),h2=c.lazy(()=>h(()=>import("./IntegratedCapLayout-B3bsjVJG.js"),__vite__mapDeps([134,1,2]))),m2=c.lazy(()=>h(()=>import("./ERPIntegration-BSvJ3Zly.js"),__vite__mapDeps([135,1,2]))),p2=c.lazy(()=>h(()=>import("./OpManagement-DH3eflM6.js"),__vite__mapDeps([48,1,2]))),g2=c.lazy(()=>h(()=>import("./DataOrchestration-Ck8jX8zV.js"),__vite__mapDeps([136,1,2]))),x2=c.lazy(()=>h(()=>import("./Legacy-Chf-9jVY.js"),__vite__mapDeps([137,1,2]))),y2=c.lazy(()=>h(()=>import("./ReadSection-CRGMOmia.js"),__vite__mapDeps([138,1,2]))),v2=c.lazy(()=>h(()=>import("./Technologyarticlesection-D-0Owz7R.js"),__vite__mapDeps([139,1,2]))),b2=c.lazy(()=>h(()=>import("./Ecosystem-DUlq6UEU.js"),__vite__mapDeps([140,1,2]))),_2=c.lazy(()=>h(()=>import("./Perspectivesection-DzfliHCa.js"),__vite__mapDeps([141,1,2,57,63,37]))),T2=c.lazy(()=>h(()=>import("./WhatNextSection-Cd_tlYH6.js"),__vite__mapDeps([142,1,2]))),E2=c.lazy(()=>h(()=>import("./CyberSecurityHeroSection-Bs4xKdWH.js"),__vite__mapDeps([143,1,2]))),w2=c.lazy(()=>h(()=>import("./SecurityCapabilities-x_dbd0vd.js"),__vite__mapDeps([144,1,2]))),j2=c.lazy(()=>h(()=>import("./Resiliencepillarssection-QAsk3dyN.js"),__vite__mapDeps([145,1,2,102,103]))),S2=c.lazy(()=>h(()=>import("./SecurityOutcomes-CX3Wynm-.js"),__vite__mapDeps([146,1,2]))),z2=c.lazy(()=>h(()=>import("./Securityperspectivesection-C8t0LHx_.js"),__vite__mapDeps([147,1,2]))),A2=c.lazy(()=>h(()=>import("./AboutSecurity-DrdM_Css.js"),__vite__mapDeps([148,1,2]))),O2=c.lazy(()=>h(()=>import("./SecurityChallenge-DoU_o9UL.js"),__vite__mapDeps([149,1,2]))),N2=c.lazy(()=>h(()=>import("./EditorialReflection-CyUFAS1X.js"),__vite__mapDeps([150,1,2]))),D2=c.lazy(()=>h(()=>import("./OurApproach-BMBNf0RJ.js"),__vite__mapDeps([151,1,2]))),C2=c.lazy(()=>h(()=>import("./WhyTechtorch-Co1F265-.js"),__vite__mapDeps([152,1,2]))),R2=c.lazy(()=>h(()=>import("./SecurityInitiative-DZMpSvKl.js"),__vite__mapDeps([153,1,2]))),L2=c.lazy(()=>h(()=>import("./ProtocolDelivery-CoJKjZFz.js"),__vite__mapDeps([154,1,2]))),M2=c.lazy(()=>h(()=>import("./SelectionEngine-CKCewz_G.js"),__vite__mapDeps([155,1,2]))),k2=c.lazy(()=>h(()=>import("./AdvisoryFramework-DAIK2lO8.js"),__vite__mapDeps([156,1,2,120]))),V2=c.lazy(()=>h(()=>import("./ViewEngagementProtocol-DOq-45Vq.js"),__vite__mapDeps([157,1,2]))),U2=c.lazy(()=>h(()=>import("./AcceptProceed-CiFounzl.js"),__vite__mapDeps([158,1,2]))),B2=c.lazy(()=>h(()=>import("./ExportProtocolPackage-DxH6DO73.js"),__vite__mapDeps([159,1,2,42,160,116,13,161,65,162,31,163,83,164,29]))),H2=c.lazy(()=>h(()=>import("./AdvisoryDesk-Cvxv9qYH.js"),__vite__mapDeps([165,1,2]))),q2=c.lazy(()=>h(()=>import("./DispatchConsole-O8dcpNaP.js"),__vite__mapDeps([166,1,2]))),I2=c.lazy(()=>h(()=>import("./TimeboxProtocol-pyxTmAqd.js"),__vite__mapDeps([167,1,2]))),Y2=c.lazy(()=>h(()=>import("./GrowwTechnology-BYUDtIGd.js"),__vite__mapDeps([168,1,2]))),X2=c.lazy(()=>h(()=>import("./PurspectiveSection-svgiLC0A.js"),__vite__mapDeps([169,1,2]))),G2=c.lazy(()=>h(()=>import("./ArchitectureSection-Dul5OHwZ.js"),__vite__mapDeps([170,1,2,171,58,63,172,84]))),Q2=c.lazy(()=>h(()=>import("./MethodologySection-B9SMvmzQ.js"),__vite__mapDeps([173,1,2,108]))),Z2=c.lazy(()=>h(()=>import("./EcosystemCapabilities-B3u-Ohad.js"),__vite__mapDeps([174,1,2,55,80,175,176,177,178,30]))),K2=c.lazy(()=>h(()=>import("./TechnologyCapabilties-DnaanLId.js"),__vite__mapDeps([179,1,2,110,65,108,97]))),P2=c.lazy(()=>h(()=>import("./CoreEngineering-DcF3349A.js"),__vite__mapDeps([180,1,2,108,86,58,76]))),J2=c.lazy(()=>h(()=>import("./MarketExpertise-BwANhUby.js"),__vite__mapDeps([181,1,2,62,72,95,30]))),F2=c.lazy(()=>h(()=>import("./InstitutionalCommitment-DoelrMKY.js"),__vite__mapDeps([182,1,2,58]))),W2=c.lazy(()=>h(()=>import("./ParadigmSection-QQ9RqVnw.js"),__vite__mapDeps([183,1,2]))),$2=c.lazy(()=>h(()=>import("./DataDecisions-CuTEm-sR.js"),__vite__mapDeps([184,1,2,100,29,31]))),e_=c.lazy(()=>h(()=>import("./PerspectiveAnalysis-D6zQ_Xzb.js"),__vite__mapDeps([185,1,2]))),t_=c.lazy(()=>h(()=>import("./StrategicInquiry-UZhH5kpi.js"),__vite__mapDeps([186,1,2]))),n_=c.lazy(()=>h(()=>import("./StructuredMethodology-DjJZy2hk.js"),__vite__mapDeps([187,1,2]))),a_=c.lazy(()=>h(()=>import("./OperationalImpact-B53NXc7G.js"),__vite__mapDeps([188,1,2]))),l_=c.lazy(()=>h(()=>import("./Automation-Cp-9PiAy.js"),__vite__mapDeps([189,1,2]))),i_=c.lazy(()=>h(()=>import("./CrossFunctional-DY52o5Y4.js"),__vite__mapDeps([190,1,2]))),o_=c.lazy(()=>h(()=>import("./Discipline-5xfr6PWW.js"),__vite__mapDeps([191,1,2]))),r_=c.lazy(()=>h(()=>import("./ExecutiveStrategy-BLpyiM87.js"),__vite__mapDeps([192,1,2,100,29,31]))),s_=c.lazy(()=>h(()=>import("./Enterprisesolution-_ShPUlbB.js"),__vite__mapDeps([193,1,2,57]))),c_=c.lazy(()=>h(()=>import("./SystemicAgility-DHx6JoeW.js"),__vite__mapDeps([194,1,2,195,175,196]))),u_=c.lazy(()=>h(()=>import("./ArchitectureLifecycle-DVmyyWUf.js"),__vite__mapDeps([197,1,2,42,198,72]))),d_=c.lazy(()=>h(()=>import("./ValidatedSystem-BoeDu8sY.js"),__vite__mapDeps([199,1,2,120,82,200,65,37]))),f_=c.lazy(()=>h(()=>import("./Businessplatformshero-BaULfw5K.js"),__vite__mapDeps([201,1,2]))),h_=c.lazy(()=>h(()=>import("./OurAproach-BHszDxe9.js"),__vite__mapDeps([202,1,2]))),m_=c.lazy(()=>h(()=>import("./OurPlatforms-pLPrdryJ.js"),__vite__mapDeps([203,1,2]))),p_=c.lazy(()=>h(()=>import("./TechTorchPlatform-B48L0jHj.js"),__vite__mapDeps([204,1,2,58,205]))),g_=c.lazy(()=>h(()=>import("./DirectEnterprise-b3Od8kXq.js"),__vite__mapDeps([206,1,2]))),x_=c.lazy(()=>h(()=>import("./DigitalSolutionHero-CUGrQVhv.js"),__vite__mapDeps([207,1,2]))),y_=c.lazy(()=>h(()=>import("./DigitalTransformation-DPIXUbRF.js"),__vite__mapDeps([208,1,2,209]))),v_=c.lazy(()=>h(()=>import("./OurDigitalSolution-DmssqTnn.js"),__vite__mapDeps([210,1,2,55,211,175,105,74,30]))),b_=c.lazy(()=>h(()=>import("./DiffrentIndustries-C9iUUtTP.js"),__vite__mapDeps([212,1,2,211]))),__=c.lazy(()=>h(()=>import("./ConnectedBusiness-B_CGgoVp.js"),__vite__mapDeps([213,1,2,55,73,108]))),T_=c.lazy(()=>h(()=>import("./TechTorchTechnology-DBe4_Eef.js"),__vite__mapDeps([214,1,2,205,58,37]))),E_=c.lazy(()=>h(()=>import("./RequirementReality-BD_Gax97.js"),__vite__mapDeps([215,1,2,108,94,37]))),w_=c.lazy(()=>h(()=>import("./OurServiceHero-B14sQU_z.js"),__vite__mapDeps([216,1,2]))),j_=c.lazy(()=>h(()=>import("./StrategicPerspective-m7jl0SgS.js"),__vite__mapDeps([217,1,2]))),S_=c.lazy(()=>h(()=>import("./PortfolioArchitecture-COUM5Crg.js"),__vite__mapDeps([218,1,2,77,65,108,73]))),z_=c.lazy(()=>h(()=>import("./DeliveryBlueprint-CKRf7hrb.js"),__vite__mapDeps([219,1,2]))),A_=c.lazy(()=>h(()=>import("./TechnologyRoadmap-BIR-yN8X.js"),__vite__mapDeps([220,1,2]))),O_=c.lazy(()=>h(()=>import("./AiService-BRBgRlDQ.js"),__vite__mapDeps([221,1,2,200,76]))),N_=c.lazy(()=>h(()=>import("./AiStrategic-oQ4td8yz.js"),__vite__mapDeps([222,1,2,34,223]))),D_=c.lazy(()=>h(()=>import("./AiAdvantage-OQtV4anz.js"),__vite__mapDeps([224,1,2,50]))),C_=c.lazy(()=>h(()=>import("./AiEcosystem-CAMbVoeq.js"),__vite__mapDeps([225,1,2,65,160,86]))),R_=c.lazy(()=>h(()=>import("./AiEcosystemIntegration-DKqTYmRD.js"),__vite__mapDeps([226,1,2,55,223,100]))),L_=c.lazy(()=>h(()=>import("./ItWorkforceVelocity-DzaR74qY.js"),__vite__mapDeps([227,1,2]))),M_=c.lazy(()=>h(()=>import("./ItStrategicperspective-BPmKR4Ph.js"),__vite__mapDeps([228,1,2,229]))),k_=c.lazy(()=>h(()=>import("./ItFlexibleEngagement-CKIcaOYk.js"),__vite__mapDeps([230,1,2]))),V_=c.lazy(()=>h(()=>import("./ItOperational-DXkYZBuJ.js"),__vite__mapDeps([231,1,2]))),U_=c.lazy(()=>h(()=>import("./contracthero-C0atVo6r.js"),__vite__mapDeps([232,1,2,200,233,67]))),B_=c.lazy(()=>h(()=>import("./CapabilityAnalysis-BGkb6NRs.js"),__vite__mapDeps([234,1,2,229,80]))),H_=c.lazy(()=>h(()=>import("./Pipeline-Xr1Rtqkt.js"),__vite__mapDeps([235,1,2]))),q_=c.lazy(()=>h(()=>import("./ContractToHireHero-3tdPDq9g.js"),__vite__mapDeps([236,1,2,237]))),I_=c.lazy(()=>h(()=>import("./CthFramework-C1xWjZMg.js"),__vite__mapDeps([238,1,2,8]))),Y_=c.lazy(()=>h(()=>import("./BuildConfidence-DfZK3aQI.js"),__vite__mapDeps([239,1,2]))),X_=c.lazy(()=>h(()=>import("./DdHero-CvAOYFu6.js"),__vite__mapDeps([240,1,2,108,241]))),G_=c.lazy(()=>h(()=>import("./DdOverview-EO4LjQSk.js"),__vite__mapDeps([242,1,2,8]))),Q_=c.lazy(()=>h(()=>import("./DdStrenghten-DbtmS--1.js"),__vite__mapDeps([243,1,2,47]))),Z_=c.lazy(()=>h(()=>import("./ReHero-44IoL9BJ.js"),__vite__mapDeps([244,1,2,23,108,241]))),K_=c.lazy(()=>h(()=>import("./CapabilityOverview-Cyr-vxkk.js"),__vite__mapDeps([245,1,2,8]))),P_=c.lazy(()=>h(()=>import("./ReStrengthen-CcrlKf5X.js"),__vite__mapDeps([246,1,2,47]))),J_=c.lazy(()=>h(()=>import("./PbhHero-DPyTEPZL.js"),__vite__mapDeps([247,1,2,196,211]))),F_=c.lazy(()=>h(()=>import("./PbhExecutive-4jkp5cWa.js"),__vite__mapDeps([248,1,2,23,74,108,47]))),W_=c.lazy(()=>h(()=>import("./PbhSpecialized-D8RfBHB5.js"),__vite__mapDeps([249,1,2,108,86,84,195,250,42]))),$_=c.lazy(()=>h(()=>import("./PbhProjectForward-BUF1BWfL.js"),__vite__mapDeps([251,1,2,42,47,93,23,108,237,196]))),eT=c.lazy(()=>h(()=>import("./RrMain-D8l2qq0x.js"),__vite__mapDeps([252,1,2,10,211,108,86,84,195]))),tT=c.lazy(()=>h(()=>import("./BhMain-BHR6RV_N.js"),__vite__mapDeps([253,1,2,10,211,108,86,84,195,97,42,47,233]))),nT=c.lazy(()=>h(()=>import("./VpMain-BpO9kYJi.js"),__vite__mapDeps([254,1,2,108,65,76,10,77,23,47,233]))),aT=c.lazy(()=>h(()=>import("./BecomePartner-C9AUclEN.js"),__vite__mapDeps([255,1,2,76,23,72,256,108,104,200,257]))),lT=c.lazy(()=>h(()=>import("./MSP1-CW3sFpU7.js"),__vite__mapDeps([258,1,2,89,108,200,65,57,77,55,64]))),iT=c.lazy(()=>h(()=>import("./MSP2-B3bJbBPw.js"),__vite__mapDeps([259,1,2,23,89,47,65]))),oT=c.lazy(()=>h(()=>import("./MSP3-sTV3UIRQ.js"),__vite__mapDeps([260,1,2,23,200,64]))),rT=c.lazy(()=>h(()=>import("./DiscussPriorities-BtwNZimH.js"),__vite__mapDeps([261,1,2,53,31,29,162,163,55,172,200]))),sT=c.lazy(()=>h(()=>import("./ConnectMSP-CqQyDbhc.js"),__vite__mapDeps([262,1,2,120,160,200,116,53,29,89,176,263,264,162,163]))),cT=c.lazy(()=>h(()=>import("./OffshoreStrategy-CqDHhm-5.js"),__vite__mapDeps([265,1,2]))),uT=c.lazy(()=>h(()=>import("./EngagementArchitecture-X4t4zEZh.js"),__vite__mapDeps([266,1,2,23]))),dT=c.lazy(()=>h(()=>import("./LifecycleGovernance-bxbdgahR.js"),__vite__mapDeps([267,1,2]))),fT=c.lazy(()=>h(()=>import("./DevelopmentTeam-BPjIgWdT.js"),__vite__mapDeps([268,1,2,120,23]))),hT=c.lazy(()=>h(()=>import("./DevelopmentRequirements-KxMS7vsM.js"),__vite__mapDeps([269,1,2,120]))),mT=c.lazy(()=>h(()=>import("./EducationHero-BUxAqzyb.js"),__vite__mapDeps([270,1,2]))),pT=c.lazy(()=>h(()=>import("./EducationWork-P6iy6Nru.js"),__vite__mapDeps([271,1,2,53,74,172,84]))),gT=c.lazy(()=>h(()=>import("./EducationTechnology-4dr9Ryfz.js"),__vite__mapDeps([272,1,2,42,161,23]))),xT=c.lazy(()=>h(()=>import("./EducationGrowth-DEdE_KQU.js"),__vite__mapDeps([273,1,2,65,63]))),yT=c.lazy(()=>h(()=>import("./EducationMethodology-DGdzuKPq.js"),__vite__mapDeps([274,1,2,64,97]))),vT=c.lazy(()=>h(()=>import("./EducationSolutions-B9kQdiu8.js"),__vite__mapDeps([275,1,2,60,58,162,8,73,200,163,84,71,223,276]))),bT=c.lazy(()=>h(()=>import("./ScheduleDiscovery-HBBk3b6l.js"),__vite__mapDeps([277,1,2,120]))),_T=c.lazy(()=>h(()=>import("./InsuranceHero-00GvdGR8.js"),__vite__mapDeps([278,1,2]))),TT=c.lazy(()=>h(()=>import("./InsuranceSolution-aDwx2viN.js"),__vite__mapDeps([279,1,2,108,65]))),ET=c.lazy(()=>h(()=>import("./ConnectedOperations-DoNwCD2L.js"),__vite__mapDeps([280,1,2,53,160,223,281,92,84]))),wT=c.lazy(()=>h(()=>import("./InsuranceDigitalTransformation-cYHN4yeU.js"),__vite__mapDeps([282,1,2,65]))),jT=c.lazy(()=>h(()=>import("./InsuranceCustomer-C31mzUHP.js"),__vite__mapDeps([283,1,2,86,58,171,74,108,23,91]))),ST=c.lazy(()=>h(()=>import("./InsuranceWhyTt-B6Ee-P2q.js"),__vite__mapDeps([284,1,2,285]))),zT=c.lazy(()=>h(()=>import("./GetInTouch-BTrrhJ29.js"),__vite__mapDeps([286,1,2,120,162]))),AT=c.lazy(()=>h(()=>import("./FinanceHero-BY4RqV1t.js"),__vite__mapDeps([287,1,2]))),OT=c.lazy(()=>h(()=>import("./FinanceArchitecture-DyDpANCZ.js"),__vite__mapDeps([288,1,2,91,108,65]))),NT=c.lazy(()=>h(()=>import("./FinanceTechnology-9Xv2cjFy.js"),__vite__mapDeps([289,1,2]))),DT=c.lazy(()=>h(()=>import("./FinanceKeyBusiness-DQtTOh6r.js"),__vite__mapDeps([290,1,2,291,205,58,292,63]))),CT=c.lazy(()=>h(()=>import("./FinanceFintech-DSXT0QLy.js"),__vite__mapDeps([293,1,2,120,116,23,160,64,250,31,53,257,29,162]))),RT=c.lazy(()=>h(()=>import("./FinanceNextStep-D2G7gn55.js"),__vite__mapDeps([294,1,2,53,58,281,291,295]))),LT=c.lazy(()=>h(()=>import("./FinanceGetInTouch-cpOPN6I_.js"),__vite__mapDeps([296,1,2,116,23,160,64,250,31,53,257,29,162]))),MT=c.lazy(()=>h(()=>import("./HealthcareHero-I9z5vj6s.js"),__vite__mapDeps([297,1,2,57]))),kT=c.lazy(()=>h(()=>import("./HealthcareExplore-B-xzxO-F.js"),__vite__mapDeps([298,1,2,53,74,68,86,291]))),VT=c.lazy(()=>h(()=>import("./HealthcareTechnology-D9LHGU5b.js"),__vite__mapDeps([299,1,2]))),UT=c.lazy(()=>h(()=>import("./HealthcareOperation-B9Oclbpv.js"),__vite__mapDeps([300,1,2,291,205,58,292,63]))),BT=c.lazy(()=>h(()=>import("./ExperianceSecurity-DVx2lhIe.js"),__vite__mapDeps([301,1,2,53,263,86,160,196,61]))),HT=c.lazy(()=>h(()=>import("./InsightOperations-C4ZKO0Xn.js"),__vite__mapDeps([302,1,2,50,205,76,73,53,68,178]))),qT=c.lazy(()=>h(()=>import("./HealthcareApproach-CCa5XZmu.js"),__vite__mapDeps([303,1,2,42,63,205,291,295]))),IT=c.lazy(()=>h(()=>import("./TransformationDesk-BsCQBP3F.js"),__vite__mapDeps([304,1,2]))),YT=c.lazy(()=>h(()=>import("./HealthcareGetInTouch-3sZRH5mP.js"),__vite__mapDeps([305,1,2,120,53,31,29,163,162,276]))),XT=c.lazy(()=>h(()=>import("./ItHero-B3TJ8_aX.js"),__vite__mapDeps([306,1,2,63]))),GT=c.lazy(()=>h(()=>import("./ItBusiness-AHCX_wJf.js"),__vite__mapDeps([307,1,2,116,209,63,200]))),QT=c.lazy(()=>h(()=>import("./ItService-6UnxRByN.js"),__vite__mapDeps([308,1,2,309,108,63,160]))),ZT=c.lazy(()=>h(()=>import("./ItSoftware-By1Qfoqr.js"),__vite__mapDeps([310,1,2]))),KT=c.lazy(()=>h(()=>import("./ItDigitalSolution-KcVPjs4s.js"),__vite__mapDeps([311,1,2,55,175,9]))),PT=c.lazy(()=>h(()=>import("./ItInfrastructure-LaLr3RvW.js"),__vite__mapDeps([312,1,2,285,65,63]))),JT=c.lazy(()=>h(()=>import("./ItApproach-uTBHFjH7.js"),__vite__mapDeps([313,1,2,36,64]))),FT=c.lazy(()=>h(()=>import("./ItTechTorch-BeNRypD4.js"),__vite__mapDeps([314,1,2,23]))),WT=c.lazy(()=>h(()=>import("./ItFoundation-VaJlaycJ.js"),__vite__mapDeps([315,1,2,160]))),$T=c.lazy(()=>h(()=>import("./ITGetInTouch-CFwib9rv.js"),__vite__mapDeps([316,1,2,120,72,257,211,264]))),eE=c.lazy(()=>h(()=>import("./ManufacturingHero-DndhiNDl.js"),__vite__mapDeps([317,1,2,72]))),tE=c.lazy(()=>h(()=>import("./ManufacturingTechnology-CdDEjb_M.js"),__vite__mapDeps([318,1,2]))),nE=c.lazy(()=>h(()=>import("./ManufacturingSolution-BOnCiKUY.js"),__vite__mapDeps([319,1,2,19,63,160]))),aE=c.lazy(()=>h(()=>import("./ManufacturingErp-C2_5rhbs.js"),__vite__mapDeps([320,1,2,73,205]))),lE=c.lazy(()=>h(()=>import("./SoftwareEngineering-DVVXyuR7.js"),__vite__mapDeps([321,1,2,108,63,64]))),iE=c.lazy(()=>h(()=>import("./ManufacturingApproach-4LFaNKT1.js"),__vite__mapDeps([322,1,2]))),oE=c.lazy(()=>h(()=>import("./ManufacturingTechTorch-SwHkMLiA.js"),__vite__mapDeps([323,1,2,42,58,205]))),rE=c.lazy(()=>h(()=>import("./ManufacturingGetInTouch-DBalkq1R.js"),__vite__mapDeps([324,1,2,120,31,34,257,198,108,264]))),sE=c.lazy(()=>h(()=>import("./TcHero-BqAXMsYu.js"),__vite__mapDeps([325,1,2,237]))),cE=c.lazy(()=>h(()=>import("./TcTechnology-BPBV-iK1.js"),__vite__mapDeps([326,1,2,30]))),uE=c.lazy(()=>h(()=>import("./TcKeySolution-DJDhIGKO.js"),__vite__mapDeps([327,1,2,256,205,61]))),dE=c.lazy(()=>h(()=>import("./TcSoftwareEngineer-6Zn1O2EC.js"),__vite__mapDeps([328,1,2,329,108,86,63,64]))),fE=c.lazy(()=>h(()=>import("./TcService-DXLvKHRc.js"),__vite__mapDeps([330,1,2,34,65,160]))),hE=c.lazy(()=>h(()=>import("./TcApproach-BPzTxY-j.js"),__vite__mapDeps([331,1,2,97]))),mE=c.lazy(()=>h(()=>import("./TcGetInTouch-CDX65QL0.js"),__vite__mapDeps([332,1,2,120,26,162,200]))),pE=c.lazy(()=>h(()=>import("./EnergyHero-Cd00gdlZ.js"),__vite__mapDeps([333,1,2,55]))),gE=c.lazy(()=>h(()=>import("./EnergyTechnology-BT3BIXfA.js"),__vite__mapDeps([334,1,2,19,211]))),xE=c.lazy(()=>h(()=>import("./EnergyKeySolution-Dq78ve__.js"),__vite__mapDeps([335,1,2,63,55,198]))),yE=c.lazy(()=>h(()=>import("./EnergySoftwareEngineering-Cc01S05P.js"),__vite__mapDeps([336,1,2,108,86,63,55,77]))),vE=c.lazy(()=>h(()=>import("./EnergyTechnologyService-DKBm5z1q.js"),__vite__mapDeps([337,1,2,64,65,329]))),bE=c.lazy(()=>h(()=>import("./EnergyApproach-BBgCqMDI.js"),__vite__mapDeps([338,1,2]))),_E=c.lazy(()=>h(()=>import("./EnergyGetInTouch-CI0-Y5mS.js"),__vite__mapDeps([339,1,2,120,195,65,108,76,31,29,162,200]))),TE=c.lazy(()=>h(()=>import("./TransHero-BiudayuU.js"),__vite__mapDeps([340,1,2,237]))),EE=c.lazy(()=>h(()=>import("./TransportationConnected-qdduw68T.js"),__vite__mapDeps([341,1,2,211]))),wE=c.lazy(()=>h(()=>import("./TransportationSolution-CDB0knmv.js"),__vite__mapDeps([342,1,2,55,53,198,108]))),jE=c.lazy(()=>h(()=>import("./TransportationSupplyChain-D1E6_uka.js"),__vite__mapDeps([343,1,2]))),SE=c.lazy(()=>h(()=>import("./TransportationSoftware-Da77jKZM.js"),__vite__mapDeps([344,1,2]))),zE=c.lazy(()=>h(()=>import("./TransportationApproach-DPkqBUGP.js"),__vite__mapDeps([345,1,2,64]))),AE=c.lazy(()=>h(()=>import("./TransportationEnterprise-Db_x84tC.js"),__vite__mapDeps([346,1,2]))),OE=c.lazy(()=>h(()=>import("./TransportationGetInTouch-CoL_yGmb.js"),__vite__mapDeps([347,1,2,120,257,195,104,177,108,23,31,29,200,76]))),NE=c.lazy(()=>h(()=>import("./FmcgHero-D4W1LQ6L.js"),__vite__mapDeps([348,1,2]))),DE=c.lazy(()=>h(()=>import("./FmcgSolution-CxbrSMDN.js"),__vite__mapDeps([349,1,2,73,205,91]))),CE=c.lazy(()=>h(()=>import("./FmcgOurSolution-C-LlNRET.js"),__vite__mapDeps([350,1,2,63,47,309]))),RE=c.lazy(()=>h(()=>import("./FmcgManagement-BSXenbyL.js"),__vite__mapDeps([351,1,2]))),LE=c.lazy(()=>h(()=>import("./FmcgBusiness-XBuKNOKI.js"),__vite__mapDeps([352,1,2,63,61]))),ME=c.lazy(()=>h(()=>import("./FmcgSoftwareEngineering-uCO0DI1z.js"),__vite__mapDeps([353,1,2]))),kE=c.lazy(()=>h(()=>import("./FmcgTechnologyService-CI_uWyUG.js"),__vite__mapDeps([354,1,2,74,110,65,176,108]))),VE=c.lazy(()=>h(()=>import("./FmcgApproach-7C5qpnja.js"),__vite__mapDeps([355,1,2]))),UE=c.lazy(()=>h(()=>import("./FmcgGetInTouch-E5xwbU2H.js"),__vite__mapDeps([356,1,2,120]))),BE=c.lazy(()=>h(()=>import("./EcommerceHero-CEAsEiay.js"),__vite__mapDeps([357,1,2,62]))),HE=c.lazy(()=>h(()=>import("./EcommerceEnterprise-BJmkKlKc.js"),__vite__mapDeps([358,1,2,63]))),qE=c.lazy(()=>h(()=>import("./EcommerceCapabilities-cZ1R3xA8.js"),__vite__mapDeps([359,1,2,61]))),IE=c.lazy(()=>h(()=>import("./EcommerceFrontend-73NHsxqr.js"),__vite__mapDeps([360,1,2,62,111,86]))),YE=c.lazy(()=>h(()=>import("./EcommerceSynergy-oBZ0OUch.js"),__vite__mapDeps([361,1,2,74]))),XE=c.lazy(()=>h(()=>import("./EcommerceCustom-DNcDxSeU.js"),__vite__mapDeps([362,1,2,108,86,63,55,64]))),GE=c.lazy(()=>h(()=>import("./EcommerceIntelligence-CzuQ_JaV.js"),__vite__mapDeps([363,1,2,57]))),QE=c.lazy(()=>h(()=>import("./EcommerceApproach-CVjN6hgr.js"),__vite__mapDeps([364,1,2,9]))),ZE=c.lazy(()=>h(()=>import("./EcommerceNextPhase-BO78NzTM.js"),__vite__mapDeps([365,1,2]))),KE=c.lazy(()=>h(()=>import("./ECommerceGetInTouch-CZn7ZbQW.js"),__vite__mapDeps([366,1,2,120]))),PE=c.lazy(()=>h(()=>import("./StartConversation-KsxspF6e.js"),__vite__mapDeps([367,1,2,8,34]))),JE=c.lazy(()=>h(()=>import("./ExploreQuestions-Cn4y_2Kq.js"),__vite__mapDeps([368,1,2,163,164,31,29,34]))),FE=c.lazy(()=>h(()=>import("./ConversationToggle-DySpSvdY.js"),__vite__mapDeps([369,1,2,53,257,60,31,29,34,163]))),WE=c.lazy(()=>h(()=>import("./Leadership-_svp66Vy.js"),__vite__mapDeps([370,1,2]))),$E=c.lazy(()=>h(()=>import("./CompanyOverview-sBa5I6aA.js"),__vite__mapDeps([371,1,2,26]))),ew=c.lazy(()=>h(()=>import("./Idea-DliZ_Y7T.js"),__vite__mapDeps([372,1,2,42,97]))),tw=c.lazy(()=>h(()=>import("./PartnersEcosystem-Ddyzj0FK.js"),__vite__mapDeps([373,1,2,65,92,55,58,42,241]))),nw=c.lazy(()=>h(()=>import("./Investors-BQm5W54x.js"),__vite__mapDeps([374,1,2,100,108,241,291,97]))),aw=c.lazy(()=>h(()=>import("./Media-D61xxtBk.js"),__vite__mapDeps([375,1,2]))),lw=c.lazy(()=>h(()=>import("./OperationsManagementPage-B6zYdHwB.js"),__vite__mapDeps([376,1,2,80,44,26,62,55,5,57,92,58,64])));"scrollRestoration"in window.history&&(window.history.scrollRestoration="manual");const iw=(()=>{try{return performance.getEntriesByType("navigation")[0]?.type==="reload"}catch{return!1}})();function ow(){return i.jsxs("div",{role:"status","aria-label":"Loading",style:{minHeight:"60vh",display:"flex",alignItems:"center",justifyContent:"center"},children:[i.jsx("div",{style:{width:40,height:40,borderRadius:"50%",border:"4px solid #e5e7eb",borderTopColor:"#f97316",animation:"tt-spin 0.8s linear infinite"}}),i.jsx("style",{children:"@keyframes tt-spin{to{transform:rotate(360deg)}}"})]})}let nu=null;function rw(){const{pathname:s,hash:d,key:x}=gn();return nu===null&&(nu=x),c.useEffect(()=>{if(iw&&x===nu){d&&window.history.replaceState(window.history.state,"",s+window.location.search),window.scrollTo({top:0,left:0,behavior:"instant"});return}if(d){const f=d.replace("#","");let y=0;const E=setInterval(()=>{const S=document.getElementById(f);y+=1,S?(S.scrollIntoView({behavior:"smooth",block:"start"}),clearInterval(E)):y>20&&clearInterval(E)},100);return()=>clearInterval(E)}window.scrollTo({top:0,left:0,behavior:"instant"})},[s,d,x]),null}function Fm(){return i.jsxs("div",{className:"min-h-screen flex flex-col",children:[i.jsx(L1,{}),i.jsx(P1,{}),i.jsx(Hv,{}),i.jsx(qv,{}),i.jsx("main",{className:"flex-1 w-full",children:i.jsx(ep,{})}),i.jsx(Wv,{})]})}function sw(){return i.jsxs(i.Fragment,{children:[i.jsx($v,{}),i.jsx(eb,{}),i.jsx(tb,{}),i.jsx(lb,{}),i.jsx(ob,{}),i.jsx(fb,{}),i.jsx(pb,{}),i.jsx(gb,{})]})}function cw(){return i.jsxs(i.Fragment,{children:[i.jsx(Pb,{}),i.jsx(Fb,{}),i.jsx(Jb,{}),i.jsx(Wb,{}),i.jsx(Kb,{}),i.jsx($b,{})]})}function uw(){return i.jsxs(i.Fragment,{children:[i.jsx(e2,{}),i.jsx(a2,{}),i.jsx(n2,{}),i.jsx(t2,{})]})}function dw(){return i.jsxs(i.Fragment,{children:[i.jsx(l2,{}),i.jsx(i2,{}),i.jsx(o2,{}),i.jsx(r2,{})]})}function fw(){return i.jsxs(i.Fragment,{children:[i.jsx(s2,{}),i.jsx(c2,{}),i.jsx(u2,{}),i.jsx(d2,{}),i.jsx(f2,{})]})}function hw(){return i.jsxs(i.Fragment,{children:[i.jsx(y2,{}),i.jsx(v2,{}),i.jsx(_2,{}),i.jsx(b2,{})]})}function mw(){return i.jsxs(i.Fragment,{children:[i.jsx(E2,{}),i.jsx(z2,{}),i.jsx(O2,{}),i.jsx(D2,{}),i.jsx(w2,{}),i.jsx(j2,{}),i.jsx(C2,{}),i.jsx(S2,{}),i.jsx(N2,{}),i.jsx(A2,{}),i.jsx(T2,{})]})}function pw(){return i.jsxs(i.Fragment,{children:[i.jsx(R2,{}),i.jsx(L2,{}),i.jsx(M2,{}),i.jsx(k2,{})]})}function gw(){return i.jsxs(i.Fragment,{children:[i.jsx(H2,{}),i.jsx(q2,{}),i.jsx(I2,{})]})}function xw(){return i.jsxs(i.Fragment,{children:[i.jsx(Y2,{}),i.jsx(X2,{}),i.jsx(G2,{}),i.jsx(Q2,{}),i.jsx(Z2,{}),i.jsx(K2,{}),i.jsx(P2,{}),i.jsx(J2,{}),i.jsx(F2,{}),i.jsx(W2,{})]})}function yw(){return i.jsxs(i.Fragment,{children:[i.jsx($2,{}),i.jsx(e_,{}),i.jsx(t_,{}),i.jsx(n_,{}),i.jsx(a_,{}),i.jsx(l_,{}),i.jsx(i_,{}),i.jsx(o_,{}),i.jsx(r_,{})]})}function vw(){return i.jsxs(i.Fragment,{children:[i.jsx(s_,{}),i.jsx(c_,{}),i.jsx(u_,{}),i.jsx(d_,{})]})}function bw(){return i.jsxs(i.Fragment,{children:[i.jsx(f_,{}),i.jsx(h_,{}),i.jsx(m_,{}),i.jsx(p_,{}),i.jsx(g_,{})]})}function _w(){return i.jsxs(i.Fragment,{children:[i.jsx(x_,{}),i.jsx(y_,{}),i.jsx(v_,{}),i.jsx(b_,{}),i.jsx(__,{}),i.jsx(T_,{}),i.jsx(E_,{})]})}function Tw(){return i.jsxs(i.Fragment,{children:[i.jsx(w_,{}),i.jsx(j_,{}),i.jsx(S_,{}),i.jsx(z_,{}),i.jsx(A_,{})]})}function Ew(){return i.jsxs(i.Fragment,{children:[i.jsx(O_,{}),i.jsx(N_,{}),i.jsx(D_,{}),i.jsx(C_,{}),i.jsx(R_,{})]})}function ww(){return i.jsxs(i.Fragment,{children:[i.jsx(L_,{}),i.jsx(M_,{}),i.jsx(k_,{}),i.jsx(V_,{})]})}function jw(){return i.jsxs(i.Fragment,{children:[i.jsx(U_,{}),i.jsx(B_,{}),i.jsx(H_,{})]})}function Sw(){return i.jsxs(i.Fragment,{children:[i.jsx(q_,{}),i.jsx(I_,{}),i.jsx(Y_,{})]})}function zw(){return i.jsxs(i.Fragment,{children:[i.jsx(X_,{}),i.jsx(G_,{}),i.jsx(Q_,{})]})}function Aw(){return i.jsxs(i.Fragment,{children:[i.jsx(Z_,{}),i.jsx(K_,{}),i.jsx(P_,{})]})}function Ow(){return i.jsxs(i.Fragment,{children:[i.jsx(J_,{}),i.jsx(F_,{}),i.jsx(W_,{}),i.jsx($_,{})]})}function Nw(){return i.jsx(i.Fragment,{children:i.jsx(eT,{})})}function Dw(){return i.jsx(i.Fragment,{children:i.jsx(tT,{})})}function Cw(){return i.jsx(i.Fragment,{children:i.jsx(nT,{})})}function Rw(){return i.jsxs(i.Fragment,{children:[i.jsx(lT,{}),i.jsx(iT,{}),i.jsx(oT,{})]})}function Lw(){return i.jsxs(i.Fragment,{children:[i.jsx(cT,{}),i.jsx(uT,{}),i.jsx(dT,{})]})}function Mw(){return i.jsxs(i.Fragment,{children:[i.jsx(mT,{}),i.jsx(pT,{}),i.jsx(gT,{}),i.jsx(xT,{}),i.jsx(yT,{})]})}function kw(){return i.jsxs(i.Fragment,{children:[i.jsx(_T,{}),i.jsx(TT,{}),i.jsx(ET,{}),i.jsx(wT,{}),i.jsx(jT,{}),i.jsx(ST,{})]})}function Vw(){return i.jsxs(i.Fragment,{children:[i.jsx(AT,{}),i.jsx(OT,{}),i.jsx(NT,{}),i.jsx(DT,{}),i.jsx(CT,{}),i.jsx(RT,{})]})}function Uw(){return i.jsxs(i.Fragment,{children:[i.jsx(MT,{}),i.jsx(kT,{}),i.jsx(VT,{}),i.jsx(UT,{}),i.jsx(BT,{}),i.jsx(HT,{}),i.jsx(qT,{}),i.jsx(IT,{})]})}function Bw(){return i.jsxs(i.Fragment,{children:[i.jsx(XT,{}),i.jsx(GT,{}),i.jsx(QT,{}),i.jsx(ZT,{}),i.jsx(KT,{}),i.jsx(PT,{}),i.jsx(JT,{}),i.jsx(FT,{}),i.jsx(WT,{})]})}function Hw(){return i.jsxs(i.Fragment,{children:[i.jsx(eE,{}),i.jsx(tE,{}),i.jsx(nE,{}),i.jsx(aE,{}),i.jsx(lE,{}),i.jsx(iE,{}),i.jsx(oE,{})]})}function qw(){return i.jsxs(i.Fragment,{children:[i.jsx(sE,{}),i.jsx(cE,{}),i.jsx(uE,{}),i.jsx(dE,{}),i.jsx(fE,{}),i.jsx(hE,{})]})}function Iw(){return i.jsxs(i.Fragment,{children:[i.jsx(pE,{}),i.jsx(gE,{}),i.jsx(xE,{}),i.jsx(yE,{}),i.jsx(vE,{}),i.jsx(bE,{})]})}function Yw(){return i.jsxs(i.Fragment,{children:[i.jsx(TE,{}),i.jsx(EE,{}),i.jsx(wE,{}),i.jsx(jE,{}),i.jsx(SE,{}),i.jsx(zE,{}),i.jsx(AE,{})]})}function Xw(){return i.jsxs(i.Fragment,{children:[i.jsx(NE,{}),i.jsx(DE,{}),i.jsx(CE,{}),i.jsx(RE,{}),i.jsx(LE,{}),i.jsx(ME,{}),i.jsx(kE,{}),i.jsx(VE,{})]})}function Gw(){return i.jsxs(i.Fragment,{children:[i.jsx(BE,{}),i.jsx(HE,{}),i.jsx(qE,{}),i.jsx(IE,{}),i.jsx(YE,{}),i.jsx(XE,{}),i.jsx(GE,{}),i.jsx(QE,{}),i.jsx(ZE,{})]})}function Wm(){return i.jsx(i.Fragment,{children:i.jsx(WE,{})})}function Qw(){return i.jsxs(i.Fragment,{children:[i.jsx(rw,{}),i.jsx(nv,{}),i.jsx(c.Suspense,{fallback:i.jsx(ow,{}),children:i.jsxs(sy,{children:[i.jsxs(j,{element:i.jsx(Fm,{}),children:[i.jsx(j,{path:"/",element:i.jsx(sw,{})}),i.jsx(j,{path:"/explore-solutions",element:i.jsx(Ib,{})}),i.jsx(j,{path:"/explore-erp",element:i.jsx(Yb,{})}),i.jsx(j,{path:"/erp",element:i.jsx(Xb,{})}),i.jsx(j,{path:"/build-with-techtorch",element:i.jsx(Gb,{})}),i.jsx(j,{path:"/explore-services",element:i.jsx(Qb,{})}),i.jsx(j,{path:"/explore-torchXsuite",element:i.jsx(Zb,{})}),i.jsx(j,{path:"/media",element:i.jsx(aw,{})}),i.jsx(j,{path:"/the-techtorch-way",element:i.jsx(Eb,{})}),i.jsx(j,{path:"/case-studies",element:i.jsx(wb,{})}),i.jsx(j,{path:"/operation-management",element:i.jsx(jb,{})}),i.jsx(j,{path:"/culture-inclusion",element:i.jsx(Sb,{})}),i.jsx(j,{path:"/company-overview",element:i.jsx($E,{})}),i.jsx(j,{path:"/operations-management",element:i.jsx(lw,{})}),i.jsx(j,{path:"/supply-chain-management",element:i.jsx(Mb,{})}),i.jsx(j,{path:"/people-management",element:i.jsx(zb,{})}),i.jsx(j,{path:"/web-portals",element:i.jsx(Ab,{})}),i.jsx(j,{path:"/payment-management",element:i.jsx(Ob,{})}),i.jsx(j,{path:"/healthcare-hospital-management",element:i.jsx(Nb,{})}),i.jsx(j,{path:"/crm",element:i.jsx(Db,{})}),i.jsx(j,{path:"/ecommerce-solutions",element:i.jsx(Cb,{})}),i.jsx(j,{path:"/project-management",element:i.jsx(Rb,{})}),i.jsx(j,{path:"/investors",element:i.jsx(nw,{})}),i.jsx(j,{path:"/aviation-management",element:i.jsx(Lb,{})}),i.jsx(j,{path:"/software-development-support",element:i.jsx(kb,{})}),i.jsx(j,{path:"/resource-staffing",element:i.jsx(Vb,{})}),i.jsx(j,{path:"/cloud-infrastructure",element:i.jsx(Ub,{})}),i.jsx(j,{path:"/software-engineering-outsourcing",element:i.jsx(Bb,{})}),i.jsx(j,{path:"/it-consultancy",element:i.jsx(Hb,{})}),i.jsx(j,{path:"/Our-Story",element:i.jsx(cw,{})}),i.jsx(j,{path:"/KnowMore",element:i.jsx(uw,{})}),i.jsx(j,{path:"/TechTorchView",element:i.jsx(dw,{})}),i.jsx(j,{path:"/field-note",element:i.jsx(fw,{})}),i.jsxs(j,{path:"/integrated-capabilities",element:i.jsx(h2,{}),children:[i.jsx(j,{path:"erp-integration",element:i.jsx(m2,{})}),i.jsx(j,{path:"operations-management",element:i.jsx(p2,{})}),i.jsx(j,{path:"data-orchestration",element:i.jsx(g2,{})}),i.jsx(j,{path:"legacy-modernization",element:i.jsx(x2,{})})]}),i.jsx(j,{path:"/think-ahead",element:i.jsx(hw,{})}),i.jsx(j,{path:"/cyber-security",element:i.jsx(mw,{})}),i.jsx(j,{path:"/secure-business",element:i.jsx(pw,{})}),i.jsx(j,{path:"/schedule-advisory",element:i.jsx(gw,{})}),i.jsx(j,{path:"/engagement-protocol",element:i.jsx(V2,{})}),i.jsx(j,{path:"/accept-proceed",element:i.jsx(U2,{})}),i.jsx(j,{path:"/export-protocol",element:i.jsx(B2,{})}),i.jsx(j,{path:"/Business-growth",element:i.jsx(xw,{})}),i.jsx(j,{path:"/data-decisions",element:i.jsx(yw,{})}),i.jsx(j,{path:"/digital-solutions",element:i.jsx(vw,{})}),i.jsx(j,{path:"/platform",element:i.jsx(bw,{})}),i.jsx(j,{path:"/digitalsolution",element:i.jsx(_w,{})}),i.jsx(j,{path:"/OurService",element:i.jsx(Tw,{})}),i.jsx(j,{path:"/ArtificialIntelligent",element:i.jsx(Ew,{})}),i.jsx(j,{path:"/ItAugmentation",element:i.jsx(ww,{})}),i.jsx(j,{path:"/Contract-Staffing",element:i.jsx(jw,{})}),i.jsx(j,{path:"/contract-to-hire",element:i.jsx(Sw,{})}),i.jsx(j,{path:"/Dedicated-Development-Teams",element:i.jsx(zw,{})}),i.jsx(j,{path:"/remote-engineers",element:i.jsx(Aw,{})}),i.jsx(j,{path:"/project-based-hiring",element:i.jsx(Ow,{})}),i.jsx(j,{path:"/resource-replacement",element:i.jsx(Nw,{})}),i.jsx(j,{path:"/bench-hiring",element:i.jsx(Dw,{})}),i.jsx(j,{path:"/vendor-partnership",element:i.jsx(Cw,{})}),i.jsx(j,{path:"/become-partner",element:i.jsx(aT,{})}),i.jsx(j,{path:"/msp-support",element:i.jsx(Rw,{})}),i.jsx(j,{path:"/discuss-priorities",element:i.jsx(rT,{})}),i.jsx(j,{path:"/connect-msp",element:i.jsx(sT,{})}),i.jsx(j,{path:"/offshore-teams",element:i.jsx(Lw,{})}),i.jsx(j,{path:"/development-team",element:i.jsx(fT,{})}),i.jsx(j,{path:"/development-requirements",element:i.jsx(hT,{})}),i.jsx(j,{path:"/industries/education",element:i.jsx(Mw,{})}),i.jsx(j,{path:"/industries/insurance",element:i.jsx(kw,{})}),i.jsx(j,{path:"/industries/finance",element:i.jsx(Vw,{})}),i.jsx(j,{path:"/industries/healthcare",element:i.jsx(Uw,{})}),i.jsx(j,{path:"/education-solutions",element:i.jsx(vT,{})}),i.jsx(j,{path:"/schedule-discovery",element:i.jsx(bT,{})}),i.jsx(j,{path:"/industries/information-technology",element:i.jsx(Bw,{})}),i.jsx(j,{path:"/industries/manufacturing",element:i.jsx(Hw,{})}),i.jsx(j,{path:"/insurance-get-in-touch",element:i.jsx(zT,{})}),i.jsx(j,{path:"/finance-get-in-touch",element:i.jsx(LT,{})}),i.jsx(j,{path:"/healthcare-get-in-touch",element:i.jsx(YT,{})}),i.jsx(j,{path:"/it-get-in-touch",element:i.jsx($T,{})}),i.jsx(j,{path:"/manufacturing-get-in-touch",element:i.jsx(rE,{})}),i.jsx(j,{path:"/industries/telecommunications",element:i.jsx(qw,{})}),i.jsx(j,{path:"/industries/energy",element:i.jsx(Iw,{})}),i.jsx(j,{path:"/telecommunication-get-in-touch",element:i.jsx(mE,{})}),i.jsx(j,{path:"/energy-get-in-touch",element:i.jsx(_E,{})}),i.jsx(j,{path:"/industries/transportation",element:i.jsx(Yw,{})}),i.jsx(j,{path:"/transportation-get-in-touch",element:i.jsx(OE,{})}),i.jsx(j,{path:"/industries/fmcg",element:i.jsx(Xw,{})}),i.jsx(j,{path:"/fmcg-get-in-touch",element:i.jsx(UE,{})}),i.jsx(j,{path:"/industries/e-commerce",element:i.jsx(Gw,{})}),i.jsx(j,{path:"/ecommerce-get-in-touch",element:i.jsx(KE,{})}),i.jsx(j,{path:"/start-conversation",element:i.jsx(PE,{})}),i.jsx(j,{path:"/explore-questions",element:i.jsx(JE,{})}),i.jsx(j,{path:"/conversation-toggle",element:i.jsx(FE,{})}),i.jsx(j,{path:"/talk-to-expert",element:i.jsx(Tb,{})}),i.jsx(j,{path:"/about-us",element:i.jsx(Wm,{})}),i.jsx(j,{path:"/leadership",element:i.jsx(Wm,{})}),i.jsx(j,{path:"/idea",element:i.jsx(ew,{})}),i.jsx(j,{path:"/partners-ecosystem",element:i.jsx(tw,{})}),i.jsx(j,{path:"/signin",element:i.jsx(Jm,{initialTab:"signin"})}),i.jsx(j,{path:"/signup",element:i.jsx(Jm,{initialTab:"signup"})}),i.jsx(j,{element:i.jsx(lu,{allowedRoles:["candidate"]}),children:i.jsx(j,{path:"/candidate",element:i.jsx(xb,{})})}),i.jsx(j,{path:"/careers",element:i.jsx(yb,{})}),i.jsx(j,{path:"/blogs",element:i.jsx(vb,{})}),i.jsx(j,{path:"/blogs/:id",element:i.jsx(bb,{})}),i.jsx(j,{path:"/privacy-policy",element:i.jsx(_b,{})})]}),R1,i.jsx(j,{path:"/admin",element:i.jsx(ja,{to:"/admin-dashboard",replace:!0})}),i.jsx(j,{path:"/dashboard",element:i.jsx(ja,{to:"/admin-dashboard",replace:!0})}),i.jsx(j,{path:"/login",element:i.jsx(ja,{to:"/signin",replace:!0})}),i.jsx(j,{element:i.jsx(Fm,{}),children:i.jsx(j,{path:"*",element:i.jsx(qb,{})})})]})})]})}const Zw=new ay({defaultOptions:{queries:{refetchOnWindowFocus:!1,retry:1}}});py.createRoot(document.getElementById("root")).render(i.jsx(cy,{children:i.jsx(ly,{client:Zw,children:i.jsx(f1,{children:i.jsx(Qw,{})})})}));export{oj as $,mt as A,Ym as B,jj as C,Xy as D,Ej as E,qy as F,By as G,Iy as H,Cy as I,Ky as J,Jy as K,Py as L,g1 as M,i1 as N,Wy as O,h1 as P,Uy as Q,e1 as R,Ye as S,l1 as T,r1 as U,Vy as V,s1 as W,t1 as X,Hy as Y,Kp as Z,ij as _,vy as a,c1 as a0,Si as a1,Ry as a2,cp as a3,Q as a4,o1 as a5,My as a6,fr as a7,Jw as a8,Ww as a9,$w as aa,yy as ab,Fw as ac,wj as ad,ej as ae,tj as af,nj as ag,aj as ah,lj as ai,gj as aj,xj as ak,yj as al,vj as am,bj as an,_j as ao,Jp as ap,Dy as b,Tj as c,uj as d,hj as e,m1 as f,dj as g,pj as h,fj as i,cj as j,mj as k,rj as l,sj as m,Sj as n,Ny as o,tp as p,Qy as q,n1 as r,cu as s,Z as t,np as u,rp as v,Fy as w,a1 as x,Gy as y,ky as z};
