import{j as e}from"./vendor-query-PraSc8EQ.js";import{r as u}from"./vendor-router-L4ZCoGSs.js";import{t as a,a2 as t,J as o,v as b,Q as y}from"./index-BThRNyH6.js";import{T as j}from"./target-CywCxRzC.js";import{S as r}from"./shield-B_34gOBp.js";import{B as w}from"./badge-check-Ce5jPJWp.js";import{D as s}from"./download-tto1bib7.js";import{F as v}from"./file-check-corner-B2WXpt3k.js";import{C as k}from"./cloud-DZemR4H4.js";import{L as N}from"./lock-keyhole-qgr5czx6.js";import{M as c}from"./mail-3Flp59qD.js";import{C as z}from"./clock-3-D3KlVi6Z.js";import{P as A}from"./presentation-APq4Nxoy.js";import{C as E}from"./circle-question-mark-qtdJEbSs.js";import{P as I}from"./phone-B3rJcDGo.js";const l={name:"gavel",size:24,node:[["path",{d:"m14 13-8.381 8.38a1 1 0 0 1-3.001-3l8.384-8.381",key:"pgg06f"}],["path",{d:"m16 16 6-6",key:"vzrcl6"}],["path",{d:"m21.5 10.5-8-8",key:"a17d9x"}],["path",{d:"m8 8 6-6",key:"18bi4p"}],["path",{d:"m8.5 7.5 8 8",key:"1oyaui"}]]};l.node;const S=a(l);const p={name:"key-round",size:24,node:[["path",{d:"M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",key:"1s6t7t"}],["circle",{cx:"16.5",cy:"7.5",r:".5",fill:"currentColor",key:"w0ekpg"}]]};p.node;const T=a(p);const d={name:"send",size:24,node:[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]]};d.node;const D=a(d);function K(){const[x,n]=u.useState(!1),h=[{number:"01",icon:S,title:"Bilateral Mutual Non-Disclosure Agreement (MNDA)",description:"Cryptographically counter-signed via TechTorch KMS Enclave. Universal jurisdiction binding covenants.",tags:["PDF / A-1b","2.4 MB","Signed & Locked"]},{number:"02",icon:j,title:"Diagnostic Telemetry & Non-Intrusive Scanning Scope Matrix",description:"Explicit CIDR network boundaries, VPC telemetry hook definitions, passive inspection guarantees.",tags:["XLSX / PDF","1.8 MB","Production-Safe"]},{number:"03",icon:r,title:"Institutional SLA & Incident Escalation Matrix",description:"Zero-Impact operational uptime warranty, 15-minute Tier-1 warm SLA, legal liability indemnification.",tags:["PDF","1.2 MB","Underwritten"]},{number:"04",icon:w,title:"Lead Architect Clearance & Accreditation Dossier",description:"Dr. Evelyn Vance & Marcus Chen credentials, ISO/IEC 27001 Lead Auditor certifications, background clearance.",tags:["PDF / Portfolios","3.6 MB","Gov-Grade Clearance"]},{number:"05",icon:T,title:"Digital Signature & Verification Key Ring",description:"TechTorch OpenPGP 4096-bit public master key, per-document SHA-256 manifests, and timestamped root certs.",tags:["ASC / TXT","48 KB","4096-bit RSA"]}];return e.jsxs("div",{className:"protocol-page",children:[x&&e.jsx("div",{className:"download-alert-overlay",children:e.jsxs("div",{className:"download-alert",children:[e.jsx("div",{className:"download-alert-icon",children:e.jsx(t,{size:18,strokeWidth:2})}),e.jsxs("div",{className:"download-alert-content",children:[e.jsx("strong",{children:"DOWNLOAD INITIATED"}),e.jsx("span",{children:"Your signed archive download has been initiated."})]}),e.jsx("button",{className:"download-alert-ok",onClick:()=>n(!1),children:"OK"})]})}),e.jsx("style",{children:`
        * {
          box-sizing: border-box;
        }

        body {
          margin: 0;
          background: #f7f8f9;
          color: #20242b;
          font-family: "Inter", Arial, sans-serif;
        }

        .protocol-page {
          width: 100%;
          min-height: 100vh;
          padding: 50px 28px 35px;
          background: #f7f8f9;
        }

        .protocol-container {
          max-width: 1180px;
          margin: 0 auto;
        }

        /* ================= DOWNLOAD ALERT ================= */

        .download-alert-overlay {
          position: fixed;
          inset: 0;
          z-index: 9999;
          display: flex;
          align-items: flex-start;
          justify-content: center;
          padding-top: 25px;
          background: rgba(20, 24, 28, 0.18);
        }

        .download-alert {
          width: min(420px, calc(100% - 30px));
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 15px 16px;
          border: 1px solid #dfe1e4;
          border-radius: 7px;
          background: #ffffff;
          color: #30343a;
          box-shadow: 0 10px 30px rgba(20, 25, 30, 0.15);
          animation: downloadAlertIn 0.25s ease-out;
        }

        .download-alert-icon {
          width: 32px;
          height: 32px;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          background: #e8f1e9;
          color: #4d8054;
        }

        .download-alert-content {
          flex: 1;
          min-width: 0;
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .download-alert-content strong {
          color: #30343a;
          font-size: 12px;
          font-weight: 800;
          letter-spacing: 0.35px;
        }

        .download-alert-content span {
          color: #777c83;
          font-size: 10px;
          line-height: 1.4;
        }

        .download-alert-ok {
          flex-shrink: 0;
          min-width: 48px;
          height: 30px;
          padding: 0 12px;
          border: 1px solid #d7d9dc;
          border-radius: 5px;
          background: #f1f2f3;
          color: #30343a;
          font-size: 10px;
          font-weight: 700;
          cursor: pointer;
          transition: 0.2s ease;
        }

        .download-alert-ok:hover {
          background: #e4e5e7;
        }

        @keyframes downloadAlertIn {
          from {
            opacity: 0;
            transform: translateY(-12px);
          }

          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        /* ================= TOP ================= */

        .protocol-top {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 20px;
        }

        .breadcrumbs {
          display: flex;
          align-items: center;
          flex-wrap: wrap;
          gap: 8px;
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 0.65px;
          text-transform: uppercase;
          color: #666b73;
        }

        .breadcrumbs span {
          white-space: nowrap;
        }

        .breadcrumbs .separator {
          color: #c5c7ca;
        }

        .breadcrumbs .current {
          color: #650033;
        }

        .verification {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .verify-badge {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          padding: 6px 10px;
          border-radius: 20px;
          font-size: 9px;
          font-weight: 800;
          letter-spacing: 0.45px;
          white-space: nowrap;
        }

        .verify-green {
          background: #005b20;
          color: #fff;
        }

        .verify-grey {
          background: #e4e5e7;
          color: #650033;
        }

        /* ================= HEADING ================= */

        .protocol-heading {
          margin-top: 27px;
        }

        .protocol-heading h1 {
          margin: 0;
          color: #202327;
          font-family: "Plus Jakarta Sans", "Inter", Arial, sans-serif;
          font-size: 32px;
          line-height: 1.12;
          letter-spacing: -1.6px;
          font-weight: 550;
        }

        .protocol-heading p {
          max-width: 800px;
          margin: 11px 0 0;
          color: #555b64;
          font-size: 14px;
          line-height: 1.55;
        }

        /* ================= GRID ================= */

        .protocol-grid {
          margin-top: 27px;
          display: grid;
          grid-template-columns: minmax(0, 1.55fr) minmax(300px, 1fr);
          gap: 22px;
          align-items: start;
        }

        .left-column,
        .right-column {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        /* ================= CARD ================= */

        .protocol-card {
          background: #ffffff;
          border: 1px solid #e7e8ea;
          border-radius: 8px;
          box-shadow: 0 2px 7px rgba(20, 25, 30, 0.025);
        }

        .manifest-card {
          padding: 25px 21px;
        }

        /* ================= MANIFEST ================= */

        .manifest-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
          gap: 15px;
          padding-bottom: 14px;
          border-bottom: 1px solid #eeeeef;
        }

        .eyebrow {
          display: block;
          margin: 0 0 5px;
          color: #701040;
          font-size: 11px;
          font-weight: 850;
          letter-spacing: 0.8px;
          text-transform: uppercase;
        }

        .manifest-title {
          margin: 0;
          color: #22262c;
          font-family: "Plus Jakarta Sans", "Inter", Arial, sans-serif;
          font-size: 18px;
          line-height: 1.1;
          letter-spacing: -0.8px;
          font-weight: 600;
        }

        .artifact-count {
          padding: 6px 9px;
          border-radius: 4px;
          background: #eceeef;
          color: #22262c;
          font-weight: 600;
          font-family: monospace;
          font-size: 10px;
          white-space: nowrap;
        }

        .artifact-list {
          display: flex;
          flex-direction: column;
          gap: 9px;
          margin-top: 17px;
        }

        .artifact {
          display: grid;
          grid-template-columns: 36px minmax(0, 1fr) 20px;
          gap: 10px;
          align-items: start;
          padding: 12px 10px;
          border-radius: 6px;
          background: #f7f8f9;
        }

        .artifact-icon {
          width: 31px;
          height: 31px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 6px;
          background: #e9e0e5;
          color: #650033;
        }

        .artifact-title {
          margin: 0;
          color: #33383f;
          font-size: 13px;
          line-height: 1.35;
          font-weight: 800;
        }

        .artifact-number {
          margin-right: 6px;
          color: #650033;
          font-size: 11px;
          letter-spacing: 0.8px;
        }

        .artifact-description {
          margin: 4px 0 7px;
          color: #626871;
          font-size: 12px;
          line-height: 1.45;
        }

        .artifact-tags {
          display: flex;
          flex-wrap: wrap;
          align-items: center;
          gap: 7px;
        }

        .artifact-tag {
          padding: 3px 5px;
          border-radius: 3px;
          background: #dedfe1;
          color: #44484e;
          font-size: 8.5px;
          font-weight: 800;
        }

        .artifact-tag:last-child {
          padding-left: 0;
          background: transparent;
          color: #4a8054;
        }

        .artifact-download {
          display: flex;
          justify-content: center;
          color: #565b62;
        }

        /* ================= MANIFEST FOOTER ================= */

        .manifest-footer {
          margin-top: 17px;
          padding: 11px 12px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 15px;
          border-radius: 6px;
          background: #f0f1f2;
        }

        .manifest-note {
          display: flex;
          align-items: center;
          gap: 7px;
          color: #666b73;
          font-size: 11px;
          line-height: 1.4;
        }

        .manifest-note-icon {
          color: #650033;
          flex-shrink: 0;
        }

        .manifest-json {
          color: #650033;
          font-size: 11px;
          font-weight: 800;
          text-align: right;
        }

        /* ================= CRYPTO ================= */

        .crypto-card {
          padding: 25px 21px;
        }

        .crypto-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 15px;
          padding-bottom: 13px;
          border-bottom: 1px solid #eeeeef;
        }

        .crypto-title {
          display: flex;
          align-items: center;
          gap: 9px;
        }

        .crypto-icon {
          color: #72003e;
          flex-shrink: 0;
        }

        .crypto-title h2 {
          margin: 0;
          color: #22262c;
          font-family: "Plus Jakarta Sans", "Inter", Arial, sans-serif;
          font-size: 18px;
          font-weight: 600;
        }

        .immutable {
          padding: 5px 8px;
          border-radius: 3px;
          background: #dce8dc;
          color: #4d9a55;
          font-family: monospace;
          font-size: 9px;
          font-weight: 800;
          white-space: nowrap;
        }

        .crypto-description {
          margin: 14px 0 16px;
          color: #565d66;
          font-size: 13px;
          line-height: 1.55;
        }

        .hash-box {
          padding: 11px 12px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 12px;
          border-radius: 6px;
          background: #e7e8ea;
        }

        .hash-content {
          min-width: 0;
        }

        .hash-label {
          display: block;
          margin-bottom: 5px;
          color: #777c83;
          font-family: monospace;
          font-size: 10px;
          letter-spacing: 1px;
        }

        .hash-value {
          display: block;
          color: #292d32;
          font-family: monospace;
          font-size: 11px;
          font-weight: 700;
          word-break: break-all;
        }

        .copy-hash {
          border: 0;
          padding: 7px 9px;
          border-radius: 4px;
          background: #f0f1f2;
          color: #30343a;
          font-size: 9px;
          font-weight: 800;
          cursor: pointer;
          white-space: nowrap;
        }

        .compliance-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 9px;
          margin-top: 18px;
        }

        .compliance-item {
          min-height: 65px;
          padding: 8px;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          text-align: center;
          border-radius: 6px;
          background: #f7f8f9;
        }

        .compliance-item .icon {
          margin-bottom: 5px;
          color: #650033;
        }

        .compliance-item strong {
          color: #30343a;
          font-size: 9.5px;
          letter-spacing: 1px;
        }

        .compliance-item span {
          margin-top: 4px;
          color: #777c82;
          font-size: 10px;
        }

        /* ================= RIGHT CARDS ================= */

        .right-card {
          padding: 20px;
        }

        .delivery-card {
          position: relative;
          overflow: hidden;
          padding: 25px 21px;
        }

        .delivery-card::after {
          content: "";
          position: absolute;
          width: 110px;
          height: 110px;
          right: -38px;
          top: -45px;
          border-radius: 50%;
          background: #f3edf0;
        }

        .delivery-content {
          position: relative;
          z-index: 1;
        }

        .delivery-label {
          display: flex;
          align-items: center;
          gap: 7px;
          margin-bottom: 7px;
          color: #650033;
          font-size: 10px;
          font-weight: 850;
          letter-spacing: 0.8px;
        }

        .delivery-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #650033;
        }

        .right-card h2 {
          margin: 0;
          color: #22262c;
          font-family: "Plus Jakarta Sans", "Inter", Arial, sans-serif;
          font-size: 18px;
          line-height: 1.15;
          font-weight: 600;
        }

        .right-description {
          margin: 9px 0 15px;
          color: #60545a;
          font-size: 12px;
          line-height: 1.5;
        }

        /* ================= ZIP FILE ================= */

        .zip-file {
          padding: 10px;
          display: flex;
          align-items: center;
          gap: 7px;
          border-radius: 6px;
          background: #f5f6f7;
        }

        .zip-icon {
          width: 31px;
          height: 31px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          border-radius: 4px;
          background: #ffdce9;
          color: #650033;
          font-size: 10px;
          font-weight: 900;
        }

        .zip-info {
          flex: 1;
          min-width: 0;
        }

        .zip-info strong {
          display: block;
          margin-bottom: 4px;
          color: #30343a;
          font-size: 11px;
          line-height: 1.1;
        }

        .zip-info span {
          display: block;
          margin-top: 0;
          color: #777c83;
          font-size: 10px;
          line-height: 1.1;
        }

        .zip-lock {
          display: flex;
          flex-shrink: 0;
          color: #075d20;
        }

        /* ================= DOWNLOAD ================= */

        .download-button {
          width: 100%;
          height: 40px;
          margin-top: 15px;
          border: 1px solid #650033;
          border-radius: 6px;
          background: #650033;
          color: white;
          font-size: 11.5px;
          font-weight: 800;
          letter-spacing: 0.25px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 7px;
          transition: 0.2s ease;
        }

        .download-button:hover {
          background: #4e0028;
        }

        .encryption-note {
          margin: 13px 0 0;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 5px;
          color: #777c83;
          font-size: 10px;
        }

        /* ================= DISPATCH ================= */

        .dispatch-label {
          margin-bottom: 6px;
          color: #701040;
          font-size: 10px;
          font-weight: 850;
          letter-spacing: 0.8px;
          text-transform: uppercase;
        }

        .dispatch-description {
          margin: 8px 0 15px;
          color: #5f565b;
          font-size: 12px;
          line-height: 1.55;
        }

        .email-label {
          margin-bottom: 6px;
          color: #30343a;
          font-size: 11px;
          font-weight: 850;
          letter-spacing: 0.9px;
        }

        .email-input-wrapper {
          position: relative;
          width: 100%;
        }

        .email-input {
          width: 100%;
          height: 34px;
          padding: 0 34px 0 10px;
          border: 0;
          outline: none;
          border-radius: 6px;
          background: #f2f3f4;
          color: #866e78;
          font-family: monospace;
          font-size: 10px;
        }

        .email-input-wrapper svg {
          position: absolute;
          right: 10px;
          top: 50%;
          transform: translateY(-50%);
          color: #555b62;
          pointer-events: none;
        }

        .expiry {
          margin: 11px 0 14px;
          display: flex;
          align-items: center;
          gap: 5px;
          color: #777b81;
          font-size: 10px;
        }

        .dispatch-button {
          width: 100%;
          height: 35px;
          border: 0;
          border-radius: 5px;
          background: #e9eaec;
          color: #650033;
          font-size: 11px;
          font-weight: 850;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 5px;
        }

        /* ================= PRESENTATION ================= */

        .presentation-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 12px;
        }

        .presentation-title {
          margin: 0 0 7px !important;
        }

        .presentation-description {
          margin: 0;
          color: #60555b;
          font-size: 12px;
          line-height: 1.5;
        }

        .aspect {
          padding: 5px 7px;
          border-radius: 3px;
          background: #eee7eb;
          color: #650033;
          font-size: 8px;
          font-weight: 850;
          white-space: nowrap;
        }

        .presentation-buttons {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 9px;
          margin-top: 15px;
        }

        .presentation-button {
          height: 34px;
          border: 0;
          border-radius: 5px;
          background: #f6f7f8;
          color: #30343a;
          font-size: 9px;
          font-weight: 850;
          letter-spacing: 0.7px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
        }

        /* ================= ATTESTATION ================= */

        .attestation {
          max-width: 1180px;
          margin: 37px auto 0;
          padding: 20px 21px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 20px;
          background: #ffffff;
          border: 1px solid #e7e8ea;
          border-radius: 8px;
          box-shadow: 0 2px 7px rgba(20, 25, 30, 0.025);
        }

        .attestation-person {
          display: flex;
          align-items: center;
          gap: 13px;
          min-width: 0;
        }

        .person-image {
          width: 52px;
          height: 52px;
          flex-shrink: 0;
          object-fit: cover;
          border-radius: 50%;
          background: #d9dde2;
        }

        .person-info h3 {
          margin: 0 0 3px;
          color: #292d32;
          font-size: 12px;
          font-weight: 800;
        }

        .person-designation {
          margin-bottom: 6px;
          color: #777c83;
          font-size: 11px;
        }

        .quote {
          max-width: 750px;
          margin: 0;
          color: #62585d;
          font-size: 10px;
          line-height: 1.45;
        }

        .attestation-stamp {
          min-width: 130px;
          padding: 8px 11px;
          text-align: center;
          border-radius: 5px;
          background: #faf7f8;
        }

        .stamp-title {
          display: block;
          margin-bottom: 0;
          color: #650033;
          font-size: 9px;
          font-weight: 850;
          letter-spacing: 0.7px;
          line-height: 1;
        }

        .stamp-code {
          display: block;
          margin-top: 0;
          color: #777b81;
          font-family: monospace;
          font-size: 10px;
          line-height: 1;
        }

        /* ================= FOOTER ================= */

        .protocol-footer {
          width: calc(100% + 56px);
          margin-left: -28px;
          margin-top: 37px;
          min-height: 104px;
          padding: 18px 28px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #5e0030;
          color: white;
        }

        .footer-inner {
          width: 100%;
          max-width: 1180px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 25px;
        }

        .footer-content {
          display: flex;
          align-items: center;
          gap: 13px;
        }

        .footer-icon {
          width: 38px;
          height: 38px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          border-radius: 6px;
          background: rgba(255, 255, 255, 0.12);
        }

        .footer-content h3 {
          margin: 0 0 4px;
          font-size: 16px;
          line-height: 1.15;
        }

        .footer-content p {
          margin: 0;
          color: #e7ceda;
          font-size: 11px;
        }

        .footer-actions {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .footer-contact {
          height: 37px;
          padding: 0 13px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          border-radius: 5px;
          font-size: 10.5px;
          font-weight: 800;
          white-space: nowrap;
        }

        .footer-phone {
          background: #771044;
          color: white;
        }

        .footer-email {
          background: white;
          color: #5d1637;
        }

        /* ================= RESPONSIVE ================= */

        @media (max-width: 1050px) {
          .protocol-grid {
            grid-template-columns: 1.45fr 1fr;
          }

          .protocol-heading h1 {
            font-size: 33px;
          }
        }

        @media (max-width: 800px) {
          .protocol-top {
            flex-direction: column;
            align-items: flex-start;
          }

          .verification {
            width: 100%;
            justify-content: flex-start;
            flex-wrap: wrap;
          }

          .protocol-grid {
            grid-template-columns: 1fr;
          }

          .right-column {
            display: grid;
            grid-template-columns: 1fr 1fr;
          }

          .delivery-card {
            grid-column: 1 / -1;
          }

          .footer-inner {
            flex-direction: column;
            align-items: flex-start;
          }

          .footer-actions {
            width: 100%;
          }

          .footer-contact {
            flex: 1;
          }
        }

        @media (max-width: 600px) {
          .protocol-page {
            padding: 25px 12px;
          }

          .download-alert-overlay {
            padding-top: 15px;
            padding-left: 12px;
            padding-right: 12px;
          }

          .download-alert {
            width: 100%;
            padding: 13px;
            gap: 10px;
          }

          .download-alert-content strong {
            font-size: 11px;
          }

          .download-alert-content span {
            font-size: 9.5px;
          }

          .download-alert-ok {
            min-width: 44px;
            height: 29px;
            font-size: 9.5px;
          }

          .protocol-heading {
            margin-top: 22px;
          }

          .protocol-heading h1 {
            font-size: 28px;
            letter-spacing: -1px;
          }

          .protocol-heading p {
            font-size: 12px;
          }

          .protocol-grid {
            margin-top: 20px;
          }

          .manifest-card,
          .crypto-card,
          .right-card {
            padding: 20px 15px;
          }

          .manifest-header {
            flex-direction: column;
            align-items: flex-start;
          }

          .manifest-title {
            font-size: 22px;
          }

          .artifact {
            grid-template-columns: 32px minmax(0, 1fr) 16px;
            gap: 8px;
          }

          .artifact-title {
            font-size: 11.5px;
          }

          .artifact-description {
            font-size: 9.5px;
          }

          .compliance-grid {
            grid-template-columns: 1fr;
          }

          .hash-box {
            flex-direction: column;
            align-items: flex-start;
          }

          .copy-hash {
            align-self: flex-end;
          }

          .right-column {
            display: flex;
          }

          .presentation-buttons {
            grid-template-columns: 1fr;
          }

          .attestation {
            margin-top: 28px;
            padding: 18px 15px;
            flex-direction: column;
            align-items: flex-start;
          }

          .attestation-stamp {
            align-self: stretch;
          }

          .protocol-footer {
            width: calc(100% + 24px);
            margin-left: -12px;
            margin-top: 28px;
            padding: 18px 15px;
          }

          .footer-actions {
            flex-direction: column;
          }

          .footer-contact {
            width: 100%;
          }
        }
      `}),e.jsxs("div",{className:"protocol-container",children:[e.jsxs("div",{className:"protocol-top",children:[e.jsxs("div",{className:"breadcrumbs",children:[e.jsx("span",{children:"Protocol Management"}),e.jsx("span",{className:"separator",children:"/"}),e.jsx("span",{children:"Engagement Protocols"}),e.jsx("span",{className:"separator",children:"/"}),e.jsx("span",{className:"current",children:"Package TT-SEC-2026-V4.2"})]}),e.jsxs("div",{className:"verification",children:[e.jsxs("span",{className:"verify-badge verify-green",children:[e.jsx(o,{size:10,strokeWidth:2}),"CRYPTOGRAPHICALLY VERIFIED BUNDLE"]}),e.jsxs("span",{className:"verify-badge verify-grey",children:[e.jsx(t,{size:10,strokeWidth:2}),"SHA-256 Validated"]})]})]}),e.jsxs("div",{className:"protocol-heading",children:[e.jsx("h1",{children:"Export Institutional Protocol Package"}),e.jsx("p",{children:"Download or securely dispatch the authoritative governance archive. This dossier contains executed Bilateral MNDAs, diagnostic telemetry scope definitions, SLA covenants, and independent third-party auditor clearance credentials."})]}),e.jsxs("div",{className:"protocol-grid",children:[e.jsxs("div",{className:"left-column",children:[e.jsxs("section",{className:"protocol-card manifest-card",children:[e.jsxs("div",{className:"manifest-header",children:[e.jsxs("div",{children:[e.jsx("span",{className:"eyebrow",children:"Document Manifest"}),e.jsx("h2",{className:"manifest-title",children:"Package File Inventory"})]}),e.jsx("div",{className:"artifact-count",children:"5 Artifacts · 9.04 MB"})]}),e.jsx("div",{className:"artifact-list",children:h.map(i=>{const m=i.icon;return e.jsxs("div",{className:"artifact",children:[e.jsx("div",{className:"artifact-icon",children:e.jsx(m,{size:17,strokeWidth:1.8})}),e.jsxs("div",{children:[e.jsxs("p",{className:"artifact-title",children:[e.jsx("span",{className:"artifact-number",children:i.number}),i.title]}),e.jsx("p",{className:"artifact-description",children:i.description}),e.jsx("div",{className:"artifact-tags",children:i.tags.map((f,g)=>e.jsx("span",{className:"artifact-tag",children:f},g))})]}),e.jsx("div",{className:"artifact-download",children:e.jsx(s,{size:15,strokeWidth:1.8})})]},i.number)})}),e.jsxs("div",{className:"manifest-footer",children:[e.jsxs("div",{className:"manifest-note",children:[e.jsx(t,{className:"manifest-note-icon",size:13,strokeWidth:1.8}),e.jsx("span",{children:"All 5 artifacts compile to standard ISO/IEC 27001 evidentiary preservation specs."})]}),e.jsx("div",{className:"manifest-json",children:"Export manifest as JSON"})]})]}),e.jsxs("section",{className:"protocol-card crypto-card",children:[e.jsxs("div",{className:"crypto-header",children:[e.jsxs("div",{className:"crypto-title",children:[e.jsx(v,{className:"crypto-icon",size:18,strokeWidth:1.8}),e.jsx("h2",{children:"Cryptographic Integrity & Custody"})]}),e.jsx("span",{className:"immutable",children:"IMMUTABLE HASH"})]}),e.jsx("p",{className:"crypto-description",children:"The generated package archive matches the exact cryptographic hash generated by the TechTorch Trust Engine. Verify this checksum in your local terminal prior to opening any unencrypted archive files."}),e.jsxs("div",{className:"hash-box",children:[e.jsxs("div",{className:"hash-content",children:[e.jsx("span",{className:"hash-label",children:"SHA-256 MASTER FINGERPRINT"}),e.jsx("span",{className:"hash-value",children:"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"})]}),e.jsx("button",{className:"copy-hash",children:"COPY HASH"})]}),e.jsxs("div",{className:"compliance-grid",children:[e.jsxs("div",{className:"compliance-item",children:[e.jsx(b,{className:"icon",size:17,strokeWidth:1.8}),e.jsx("strong",{children:"ISO/IEC 27001"}),e.jsx("span",{children:"Clause A.18 Certified"})]}),e.jsxs("div",{className:"compliance-item",children:[e.jsx(r,{className:"icon",size:17,strokeWidth:1.8}),e.jsx("strong",{children:"SOC 2 Type II"}),e.jsx("span",{children:"Trust Criteria Evaluated"})]}),e.jsxs("div",{className:"compliance-item",children:[e.jsx(k,{className:"icon",size:17,strokeWidth:1.8}),e.jsx("strong",{children:"CSA STAR"}),e.jsx("span",{children:"Level 2 Attestation"})]})]})]})]}),e.jsxs("div",{className:"right-column",children:[e.jsx("section",{className:"protocol-card delivery-card",children:e.jsxs("div",{className:"delivery-content",children:[e.jsxs("div",{className:"delivery-label",children:[e.jsx("span",{className:"delivery-dot"}),"PRIMARY DELIVERY"]}),e.jsx("h2",{children:"Direct Instant Download"}),e.jsx("p",{className:"right-description",children:"Immediate retrieval of the complete digitally-signed archive package formatted for legal and enterprise architecture review."}),e.jsxs("div",{className:"zip-file",children:[e.jsx("div",{className:"zip-icon",children:"ZIP"}),e.jsxs("div",{className:"zip-info",children:[e.jsx("strong",{children:"TechTorch_Sec_Protocol_v4.2.zip"}),e.jsx("span",{children:"Full Package · 9.04 MB · Signed"})]}),e.jsx("span",{className:"zip-lock",children:e.jsx(N,{size:18,strokeWidth:1.8})})]}),e.jsxs("button",{className:"download-button",onClick:()=>{n(!0)},children:["DOWNLOAD SIGNED ARCHIVE (.ZIP)",e.jsx(s,{size:14,strokeWidth:1.8})]}),e.jsxs("p",{className:"encryption-note",children:[e.jsx(o,{size:10,strokeWidth:1.8}),"AES-256 Enclave Encryption standard applied"]})]})}),e.jsxs("section",{className:"protocol-card right-card",children:[e.jsx("div",{className:"dispatch-label",children:"Secure Enclave Relay"}),e.jsx("h2",{children:"Encrypted Dispatch"}),e.jsx("p",{className:"dispatch-description",children:"Deliver an ephemeral, single-use download portal access key directly to your corporate inbox or designated outside legal counsel."}),e.jsx("div",{className:"email-label",children:"Authorized Corporate Email"}),e.jsxs("div",{className:"email-input-wrapper",children:[e.jsx("input",{type:"email",className:"email-input",defaultValue:"ciso@enterprise-corp.com"}),e.jsx(c,{size:14,strokeWidth:1.7})]}),e.jsxs("div",{className:"expiry",children:[e.jsx(z,{size:11,strokeWidth:1.8}),"Expires strictly 48 hours from generation."]}),e.jsxs("button",{className:"dispatch-button",children:[e.jsx(D,{size:12,strokeWidth:1.8}),"Dispatch Ephemeral Link"]})]}),e.jsxs("section",{className:"protocol-card right-card",children:[e.jsxs("div",{className:"presentation-header",children:[e.jsxs("div",{children:[e.jsx("div",{className:"eyebrow",children:"Executive Presentation"}),e.jsx("h2",{className:"presentation-title",children:"Boardroom Briefing Deck"}),e.jsx("p",{className:"presentation-description",children:"Curated visual deck designed specifically for Audit Committee, Chief Legal Officer, and Board Governance reviews."})]}),e.jsx("span",{className:"aspect",children:"16:9 Widescreen"})]}),e.jsxs("div",{className:"presentation-buttons",children:[e.jsxs("button",{className:"presentation-button",children:[e.jsx(A,{size:12,strokeWidth:1.8}),"Deck (PPTX)"]}),e.jsxs("button",{className:"presentation-button",children:[e.jsx(y,{size:12,strokeWidth:1.8}),"Briefing (PDF)"]})]})]})]})]}),e.jsxs("section",{className:"attestation",children:[e.jsxs("div",{className:"attestation-person",children:[e.jsx("img",{loading:"lazy",decoding:"async",src:"/EvelynVance.webp",alt:"Dr. Evelyn Vance",className:"person-image"}),e.jsxs("div",{className:"person-info",children:[e.jsx("h3",{children:"Dr. Evelyn Vance, CISSP"}),e.jsx("div",{className:"person-designation",children:"Principal Advisory Architect & Engagement Director · TechTorch Solutions"}),e.jsx("p",{className:"quote",children:'"Every artifact packaged within TT-SEC-2026-V4.2 has undergone rigorous multi-signature review. Scope constraints are cryptographically bound to protect production workloads without compromise."'})]})]}),e.jsxs("div",{className:"attestation-stamp",children:[e.jsx("span",{className:"stamp-title",children:"STAMP OF ATTESTATION"}),e.jsx("span",{className:"stamp-code",children:"VAL-2026-ENCLAVE-91"})]})]})]}),e.jsx("footer",{className:"protocol-footer",children:e.jsxs("div",{className:"footer-inner",children:[e.jsxs("div",{className:"footer-content",children:[e.jsx("div",{className:"footer-icon",children:e.jsx(E,{size:17,strokeWidth:1.8})}),e.jsxs("div",{children:[e.jsx("h3",{children:"Questions Regarding Scope or Governance Terms?"}),e.jsx("p",{children:"Direct real-time consultation with the assigned engagement lead and governance council."})]})]}),e.jsxs("div",{className:"footer-actions",children:[e.jsxs("a",{href:"tel:+919999366708",className:"footer-contact footer-phone",children:[e.jsx(I,{size:12,strokeWidth:1.8}),"+91 99933 66708"]}),e.jsxs("a",{href:"mailto:advisory@techtorch.solutions",className:"footer-contact footer-email",children:[e.jsx(c,{size:12,strokeWidth:1.8}),"advisory@techtorch.solutions"]})]})]})})]})}export{K as default};
