import{j as e}from"./vendor-query-PraSc8EQ.js";import{d as E,L as x}from"./vendor-router-L4ZCoGSs.js";import{t as p,A as m,r as l,G as h,s as c,Y as k,T as u,z as A,v as S,R as C}from"./index-BThRNyH6.js";import{C as F}from"./calendar-days-u_cmp8dG.js";import{L as z}from"./link-2-WSmG37JH.js";import{L as g}from"./lock-keyhole-qgr5czx6.js";import{B as $}from"./book-open-BO7FIfpV.js";import{D as f}from"./database-Dq2-QkKw.js";import{N as b}from"./network-Bh2G015s.js";import{C as I}from"./clock-3-D3KlVi6Z.js";import{C as D}from"./chart-column-4WxSCpbG.js";import{F as T}from"./funnel-BHTGezsu.js";import{R as M}from"./radio-DpU8JJLz.js";import{S as O}from"./scale-OZoywk_6.js";const j={name:"laptop",size:24,node:[["path",{d:"M18 5a2 2 0 0 1 2 2v8.526a2 2 0 0 0 .212.897l1.068 2.127a1 1 0 0 1-.9 1.45H3.62a1 1 0 0 1-.9-1.45l1.068-2.127A2 2 0 0 0 4 15.526V7a2 2 0 0 1 2-2z",key:"1pdavp"}],["path",{d:"M20.054 15.987H3.946",key:"14rxg9"}]]};j.node;const R=p(j);const v={name:"user-round-check",size:24,node:[["path",{d:"M2 21a8 8 0 0 1 13.292-6",key:"bjp14o"}],["circle",{cx:"10",cy:"8",r:"5",key:"o932ke"}],["path",{d:"m16 19 2 2 4-4",key:"1b14m6"}]],aliases:["user-check-2"]};v.node;const w=p(v),L="/EducationSolutions.webp",n="font-['Plus_Jakarta_Sans']",i="font-['Inter']";function o({icon:t,children:a,light:r=!1}){return e.jsxs("div",{className:`inline-flex w-fit items-center gap-2 rounded-full border px-3.5 py-2 text-[10px] font-semibold uppercase tracking-[0.16em] ${i} ${r?"border-white/25 bg-white/10 text-white":"border-[#E4D2DC] bg-[#F8F0F4] text-[#741044]"}`,children:[t&&e.jsx(t,{size:12,strokeWidth:2.2}),e.jsx("span",{children:a})]})}function P({children:t}){return e.jsxs("button",{className:`group inline-flex w-full items-center justify-center gap-3 rounded-xl bg-[#85004A] px-6 py-3.5 sm:w-auto ${i} text-[12px] font-semibold uppercase tracking-[0.08em] text-white shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:bg-[#70003F]`,children:[t,e.jsx(m,{size:17,className:"transition-transform duration-200 group-hover:translate-x-1"})]})}function N({children:t,dark:a=!1}){return e.jsx("div",{className:`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${a?"border border-white/15 bg-white/10 text-white":"bg-[#F2E7ED] text-[#85004A]"}`,children:t})}function _(){const t=E();return e.jsx("section",{className:"education-section education-hero",children:e.jsx("div",{className:"education-container",children:e.jsx("div",{className:"hero-card",children:e.jsxs("div",{className:"hero-grid",children:[e.jsxs("div",{className:"hero-content",children:[e.jsxs("div",{className:`inline-flex w-fit items-center gap-1.5 rounded-full border border-[#E4D2DC] bg-[#F8F0F4] px-3 py-1.5 ${i} text-[9px] font-semibold uppercase tracking-[0.14em] text-[#741044]`,children:[e.jsx("span",{className:"h-[7px] w-[7px] rounded-full bg-[#730042]"}),e.jsx("span",{children:"TechTorch Solutions · Education Platform"})]}),e.jsxs("h1",{className:`
                  mt-6
                  max-w-[650px]
                  ${n}
                  text-[30px]
                  font-semibold
                  leading-[1.05]
                  tracking-[-0.05em]
                  text-[#111113]
                  sm:mt-7
                  sm:text-[34px]
                  md:text-[38px]
                  lg:text-[42px]
                  xl:text-[44px]
                `,children:[e.jsx("span",{className:"block",children:"Technology Solutions for"}),e.jsx("span",{className:"mt-1 block",children:"Modern Education"})]}),e.jsx("p",{className:`
                  mt-6
                  max-w-[650px]
                  ${i}
                  text-[14px]
                  leading-6
                  text-[#6C6065]
                  sm:mt-7
                  sm:text-[15px]
                  md:text-[16px]
                `,children:"Connected digital solutions for academic, administrative and institutional operations."}),e.jsxs("div",{className:"mt-7 flex w-full flex-col gap-3 sm:flex-row sm:flex-wrap",children:[e.jsxs(x,{to:"/talk-to-expert",className:`
    group
    inline-flex
    w-full
    items-center
    justify-center
    gap-2.5
    rounded-xl
    bg-[#730042]
    px-5 py-2.5
    sm:w-auto
    ${i}
    text-[11px]
    font-semibold
    uppercase
    tracking-[0.06em]
    text-white
    shadow-sm
    transition-all
    duration-200
    hover:-translate-y-0.5
    hover:bg-[#620038]
  `,children:["Talk to Our Experts",e.jsx(m,{size:16,className:"transition-transform duration-200 group-hover:translate-x-1"})]}),e.jsxs("button",{onClick:()=>t("/schedule-discovery"),className:`
                    inline-flex
                    w-full
                    items-center
                    justify-center
                    gap-2.5
                    rounded-xl
                    border
                    border-[#E2E6EA]
                    bg-[#F8F9FA]
                    px-5 py-2.5
                    sm:w-auto
                    ${i}
                    text-[11px]
                    font-semibold
                    uppercase
                    tracking-[0.06em]
                    text-[#302A2D]
                    transition-all
                    duration-200
                    hover:-translate-y-0.5
                    hover:bg-white
                    hover:shadow-sm
                  `,children:[e.jsx(F,{size:16,className:"text-[#730042]"}),"Schedule Discovery"]})]}),e.jsx("div",{className:"mt-8 border-t border-[#ECE8E9] pt-5",children:e.jsxs("div",{className:"flex flex-col gap-3",children:[e.jsx(s,{icon:e.jsx(l,{size:16}),text:"Institutional Standards Compliant"}),e.jsx(s,{icon:e.jsx(z,{size:16}),text:"Interoperable Open Architecture"}),e.jsx(s,{icon:e.jsx(g,{size:16}),text:"Privacy-First Security Governance"})]})})]}),e.jsx("div",{className:"hero-image-column",children:e.jsx("div",{className:"relative h-full w-full max-w-[420px]",children:e.jsxs("div",{className:"hero-image-wrapper",children:[e.jsx("img",{loading:"lazy",decoding:"async",src:L,alt:"Modern university education environment",className:"hero-image"}),e.jsxs("div",{className:`
                      absolute
                      left-3 top-3
                      flex
                      items-center
                      gap-1.5
                      rounded-full
                      bg-white
                      px-3 py-1.5
                      ${i}
                      text-[9px]
                      font-bold
                      uppercase
                      tracking-[0.07em]
                      text-[#292326]
                      shadow-md
                      sm:left-4 sm:top-4
                    `,children:[e.jsx("span",{className:"h-[7px] w-[7px] rounded-full bg-[#1DBA82]"}),"Smart Campus Hub"]}),e.jsx("div",{className:"absolute bottom-3 left-3 right-3 rounded-[13px] border border-white/70 bg-white/95 p-2.5 shadow-lg backdrop-blur-sm",children:e.jsxs("div",{className:"flex items-center gap-2.5",children:[e.jsx("div",{className:"flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#730042] text-white",children:e.jsx(h,{size:18})}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("h3",{className:`${n} text-[12px] font-semibold leading-4 text-[#191719]`,children:"Next-Gen Campus Deployment"}),e.jsx("p",{className:`mt-0.5 ${i} text-[10px] leading-3.5 text-[#756B70]`,children:"Connecting educators, administrators & students"})]}),e.jsxs("div",{className:`hidden items-center gap-1 rounded-full border border-[#A7E7D0] bg-[#F1FFF9] px-2 py-1 ${i} text-[9px] font-semibold text-[#23936E] sm:flex`,children:[e.jsx(l,{size:11}),"Active"]})]})})]})})})]})})})})}function s({icon:t,text:a}){return e.jsxs("div",{className:`flex items-start gap-2.5 ${i} text-[10px] font-semibold uppercase tracking-[0.15em] text-[#655B60]`,children:[e.jsx("span",{className:"mt-0.5 shrink-0 text-[#730042]",children:t}),e.jsx("span",{children:a})]})}function B(){return e.jsx("section",{className:"education-section",children:e.jsx("div",{className:"education-container",children:e.jsxs("div",{className:"editorial-card",children:[e.jsx(o,{icon:$,children:"Editorial Perspective · Modern Institutional Architecture"}),e.jsxs("h2",{className:`
              mt-6
              max-w-[900px]
              ${n}
              text-[28px]
              font-medium
              leading-[1.08]
              tracking-[-0.04em]
              text-[#171719]
              sm:text-[30px]
              md:text-[34px]
              lg:text-[38px]
            `,children:["Connecting People, Processes, and Learning",e.jsx("br",{className:"hidden sm:block"}),"Systems into One Unified Institutional Ecosystem"]}),e.jsx("p",{className:`
              mt-5
              max-w-[1020px]
              ${i}
              text-[14px]
              leading-6
              text-[#6D6266]
              sm:text-[15px]
            `,children:"Educational institutions today face a structural challenge: academic departments, admissions pipelines, student records, and campus operations frequently run on disconnected legacy platforms. When software operates in silos, faculty spend valuable hours on redundant paperwork, students face friction during registration, and leadership lacks real-time institutional visibility."}),e.jsx("div",{className:"mt-7 overflow-hidden rounded-xl border border-[#ECE8E8] bg-[#F5F5F5]",children:e.jsxs("div",{className:"border-l-[3px] border-[#85004A] px-5 py-5 sm:px-8 sm:py-6",children:[e.jsx("p",{className:`${i} max-w-[950px] text-[14px] font-medium italic leading-6 text-[#40383C]`,children:"“At TechTorch Solutions, our belief is simple: Technology shouldn't add layers of complexity. It should connect people, streamline essential workflows, and give institutions the digital agility to grow sustainably.”"}),e.jsxs("div",{className:"mt-5 flex items-center gap-3",children:[e.jsx("div",{className:`flex h-7 w-7 items-center justify-center rounded-md bg-[#85004A] ${i} text-[9px] font-bold text-white`,children:"TT"}),e.jsx("span",{className:`${i} text-[9px] font-semibold uppercase tracking-[0.15em] text-[#756A70]`,children:"TechTorch Architectural Principles · Campus Transformation"})]})]})}),e.jsxs("div",{className:"mt-8 grid gap-4 md:grid-cols-3",children:[e.jsx(d,{icon:e.jsx(f,{size:18}),title:"Beyond Disconnected Software",description:"Moving from isolated vendor tools to an interoperable data architecture that preserves institutional governance."}),e.jsx(d,{icon:e.jsx(c,{size:18}),title:"Empowering Educators & Students",description:"Reducing repetitive administrative overhead so faculties can focus on teaching and students enjoy seamless digital access."}),e.jsx(d,{icon:e.jsx(H,{}),title:"Scalable & Future-Ready Foundation",description:"Architecting cloud-native, modular systems that evolve alongside institutional accreditation, multi-campus expansions, and hybrid learning models."})]})]})})})}function H(){return e.jsx(u,{size:18})}function d({icon:t,title:a,description:r}){return e.jsxs("div",{className:"rounded-xl border border-[#E7E4E4] bg-[#F9F9F8] p-5",children:[e.jsx(N,{children:t}),e.jsx("h3",{className:`mt-5 ${n} text-[15px] font-semibold leading-5 text-[#252125]`,children:a}),e.jsx("p",{className:`mt-2 ${i} text-[13px] leading-5 text-[#766B70]`,children:r})]})}const G=[{icon:e.jsx(h,{size:18}),title:"Student & Academic Management",description:"Profiles, transcripts, degree audits, student progress"},{icon:e.jsx(w,{size:18}),title:"Admissions & Enrollment",description:"Online applications, documentation, tracking & enrollment workflows"},{icon:e.jsx(R,{size:18}),title:"Digital Learning",description:"Virtual classrooms, coursework, learning material distribution & assessment"},{icon:e.jsx(c,{size:18}),title:"Faculty Management",description:"Workload planning, schedule coordination, department administration"},{icon:e.jsx(A,{size:18}),title:"Finance & Administration",description:"Tuition billing, fee management, payroll support & institutional reporting"},{icon:e.jsx(D,{size:18}),title:"Reporting & Insights",description:"Centralized dashboards, operational analytics & multi-campus visibility"}];function U(){return e.jsx("section",{className:"education-section",children:e.jsx("div",{className:"education-container",children:e.jsxs("div",{className:"white-section-card",children:[e.jsx(o,{children:"Practical Digital Capabilities"}),e.jsx("h2",{className:`
              mt-5
              ${n}
              text-[28px]
              font-semibold
              tracking-[-0.04em]
              text-[#171719]
              sm:text-[30px]
              md:text-[34px]
            `,children:"Core Education Solutions"}),e.jsx("p",{className:`mt-3 max-w-[760px] ${i} text-[14px] leading-6 text-[#71666B] sm:text-[15px]`,children:"Practical digital capabilities designed to support every layer of institutional operations."}),e.jsx("div",{className:"mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",children:G.map(t=>e.jsx(W,{...t},t.title))})]})})})}function W({icon:t,title:a,description:r}){return e.jsxs("div",{className:`\r
        group\r
        relative\r
        min-h-[175px]\r
        overflow-hidden\r
        rounded-xl\r
        border\r
        border-[#E5E2E3]\r
        bg-[#FAFAFA]\r
        p-5\r
        shadow-[0_7px_18px_rgba(30,0,20,0.06)]\r
        transition-all\r
        duration-300\r
        ease-in-out\r
        hover:-translate-y-2\r
        hover:border-[#730042]\r
        hover:bg-[#eee9ec]\r
        hover:shadow-[0_16px_32px_rgba(30,0,20,0.16)]\r
      `,children:[e.jsx("div",{className:`\r
          pointer-events-none\r
          absolute\r
          -right-[45px]\r
          -top-[45px]\r
          z-0\r
          h-[130px]\r
          w-[130px]\r
          rounded-full\r
          bg-[#730042]/[0.04]\r
          blur-[28px]\r
          transition-opacity\r
          duration-300\r
        `}),e.jsxs("div",{className:"relative z-10",children:[e.jsx("div",{className:`\r
            flex\r
            h-10\r
            w-10\r
            items-center\r
            justify-center\r
            rounded-lg\r
            bg-[#730042]/10\r
            text-[#730042]\r
            transition-all\r
            duration-300\r
          `,children:t}),e.jsx("h3",{className:`
            mt-5
            max-w-[230px]
            ${n}
            text-[14px]
            font-semibold
            leading-5
            text-[#292327]
            transition-colors
            duration-300
            group-hover:text-[#730042]
          `,children:a}),e.jsx("p",{className:`
            mt-2
            ${i}
            text-[13px]
            leading-5
            text-[#756A70]
            transition-colors
            duration-300
            group-hover:text-[#475569]
          `,children:r})]})]})}const Y=[{icon:e.jsx(f,{size:18}),number:"01",title:"Student Information & Records",description:"Centralize student profiles, academic records and essential institutional information."},{icon:e.jsx(T,{size:18}),number:"02",title:"Admissions & Enrollment",description:"Manage applications, documents and enrollment through an organized workflow."},{icon:e.jsx(w,{size:18}),number:"03",title:"Faculty & Workload Management",description:"Support faculty scheduling, workload planning and academic coordination."},{icon:e.jsx(S,{size:18}),number:"04",title:"Digital Campus Operations",description:"Connect attendance, campus activities and everyday operational processes."},{icon:e.jsx(M,{size:18}),number:"05",title:"Digital Learning",description:"Support courses, learning content, assignments and assessments."},{icon:e.jsx(u,{size:18}),number:"06",title:"Analytics & Multi-Campus",description:"Improve visibility across academic, operational and institutional activities."}];function q(){return e.jsx("section",{className:"education-section",children:e.jsx("div",{className:"education-container",children:e.jsxs("div",{className:"cream-section-card",children:[e.jsx(o,{children:"Modular Institutional Taxonomy"}),e.jsx("h2",{className:`
              mt-5
              ${n}
              text-[28px]
              font-semibold
              tracking-[-0.04em]
              text-[#171719]
              sm:text-[30px]
              md:text-[34px]
            `,children:"Six Specialized Education Pillars"}),e.jsx("p",{className:`mt-3 max-w-[780px] ${i} text-[14px] leading-6 text-[#71666B] sm:text-[15px]`,children:"Each capability can be integrated independently into legacy environments or combined to create a unified campus operating standard."}),e.jsx("div",{className:"mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",children:Y.map(t=>e.jsx(V,{...t},t.number))})]})})})}function V({icon:t,number:a,title:r,description:y}){return e.jsxs("div",{className:"relative min-h-[175px] overflow-hidden rounded-xl border border-[#E4E0E0] bg-[#FAFAFA] p-5",children:[e.jsx("span",{className:`pointer-events-none absolute right-3 top-0 ${i} text-[52px] font-light leading-none text-[#F0EEEE]`,children:a}),e.jsxs("div",{className:"relative",children:[e.jsxs("div",{className:"flex items-start justify-between gap-4",children:[e.jsx(N,{children:t}),e.jsxs("span",{className:`rounded-md border border-[#E6D8DF] bg-[#F7EFF3] px-2 py-1 ${i} text-[9px] font-semibold uppercase tracking-[0.1em] text-[#7A174B]`,children:["Pillar ",a]})]}),e.jsx("h3",{className:`mt-5 ${n} text-[14px] font-semibold leading-5 text-[#292327]`,children:r}),e.jsx("p",{className:`mt-2 ${i} text-[13px] leading-5 text-[#756A70]`,children:y})]})]})}const J=[{icon:e.jsx(C,{size:18}),title:"System Integration",description:"Connect legacy SIS, LMS, identity management and institutional tools"},{icon:e.jsx(b,{size:18}),title:"Connected Data",description:"Unify disparate departmental data for clean institutional reporting"},{icon:e.jsx(g,{size:18}),title:"Secure Access",description:"Role-based access control, privacy-first data handling and confidentiality"},{icon:e.jsx(O,{size:18}),title:"Flexible Architecture",description:"Modular APIs and scalable cloud foundations that evolve with your campus"}];function K(){return e.jsx("section",{className:"education-section",children:e.jsx("div",{className:"education-container",children:e.jsxs("div",{className:"integration-card",children:[e.jsx(o,{icon:b,light:!0,children:"Seamless System Interoperability"}),e.jsx("h2",{className:`
              mt-6
              ${n}
              text-[28px]
              font-medium
              leading-tight
              tracking-[-0.045em]
              sm:text-[34px]
              md:text-[40px]
              lg:text-[42px]
            `,children:"Connect With Your Existing Systems"}),e.jsx("p",{className:`mt-3 max-w-[820px] ${i} text-[14px] leading-6 text-white/75 sm:text-[15px]`,children:"Modernize your education environment without disrupting the systems and processes your institution already depends on."}),e.jsx("div",{className:"mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",children:J.map(t=>e.jsxs("div",{className:`\r
                  group\r
                  relative\r
                  overflow-hidden\r
                  rounded-xl\r
                  border\r
                  border-white/15\r
                  bg-white/[0.07]\r
                  p-5\r
                  shadow-[0_7px_18px_rgba(30,0,20,0.10)]\r
                  transition-all\r
                  duration-300\r
                  ease-in-out\r
                  hover:-translate-y-2\r
                  hover:border-white/40\r
                  hover:bg-white\r
                  hover:shadow-[0_16px_32px_rgba(30,0,20,0.24)]\r
                `,children:[e.jsx("div",{className:`\r
                    pointer-events-none\r
                    absolute\r
                    -right-[45px]\r
                    -top-[45px]\r
                    h-[130px]\r
                    w-[130px]\r
                    rounded-full\r
                    bg-white/10\r
                    blur-[28px]\r
                  `}),e.jsxs("div",{className:"relative z-10",children:[e.jsx("div",{className:`\r
                      flex\r
                      h-10\r
                      w-10\r
                      items-center\r
                      justify-center\r
                      rounded-lg\r
                      bg-white/10\r
                      text-white\r
                      transition-all\r
                      duration-300\r
                      group-hover:bg-[#730042]/10\r
                      group-hover:text-[#730042]\r
                    `,children:t.icon}),e.jsx("h3",{className:`
                      mt-5
                      ${n}
                      text-[15px]
                      font-semibold
                      text-white
                      transition-colors
                      duration-300
                      group-hover:text-[#730042]
                    `,children:t.title}),e.jsx("p",{className:`
                      mt-2
                      ${i}
                      text-[12px]
                      leading-5
                      text-white/65
                      transition-colors
                      duration-300
                      group-hover:text-[#475569]
                    `,children:t.description})]})]},t.title))})]})})})}const X=[{number:"1",phase:"Phase 01",title:"Understand & Plan",description:"Review requirements, processes and existing systems."},{number:"2",phase:"Phase 02",title:"Build & Validate",description:"Configure the solution, integrate systems and validate key workflows."},{number:"3",phase:"Phase 03",title:"Launch & Support",description:"Introduce the solution and provide ongoing support as teams adopt it."}];function Z(){return e.jsx("section",{className:"education-section",children:e.jsx("div",{className:"education-container",children:e.jsxs("div",{className:"white-section-card implementation-card",children:[e.jsx(o,{children:"Structured Methodology"}),e.jsx("h2",{className:`
              mt-5
              ${n}
              text-[28px]
              font-semibold
              tracking-[-0.04em]
              text-[#171719]
              sm:text-[30px]
              md:text-[34px]
            `,children:"A Structured Approach to Implementation"}),e.jsx("p",{className:`mx-auto mt-3 max-w-[720px] ${i} text-[14px] leading-6 text-[#71666B] sm:text-[15px]`,children:"A practical three-phase approach designed to help institutions move from planning to adoption with greater clarity."}),e.jsx("div",{className:"mt-9 grid gap-5 text-left md:grid-cols-3",children:X.map(t=>e.jsxs("div",{className:`\r
                  relative\r
                  min-h-[205px]\r
                  overflow-hidden\r
                  rounded-xl\r
                  border\r
                  border-[#E4E2E3]\r
                  bg-[#FAFAFA]\r
                  p-5\r
                  sm:p-6\r
                `,children:[e.jsxs("div",{className:"relative flex flex-wrap items-center gap-3",children:[e.jsx("div",{className:`flex h-9 w-9 items-center justify-center rounded-xl bg-[#730042] ${i} text-sm font-bold text-white`,children:t.number}),e.jsx("span",{className:`rounded-md border border-[#E6D8DF] bg-[#F7EFF3] px-2.5 py-1.5 ${i} text-[9px] font-semibold uppercase tracking-[0.1em] text-[#730042]`,children:t.phase})]}),e.jsx("h3",{className:`mt-6 ${n} text-[15px] font-semibold text-[#292327]`,children:t.title}),e.jsx("p",{className:`mt-2.5 max-w-[280px] ${i} text-[13px] leading-5 text-[#756A70]`,children:t.description})]},t.number))})]})})})}function Q(){return e.jsx("section",{className:"education-section",children:e.jsx("div",{className:"education-container",children:e.jsx("div",{className:"cta-card",children:e.jsxs("div",{className:"grid items-center gap-8 lg:grid-cols-[1fr_auto] lg:gap-10",children:[e.jsxs("div",{children:[e.jsx(o,{icon:k,children:"Institutional Collaboration"}),e.jsxs("h2",{className:`
                  mt-6
                  max-w-[720px]
                  ${n}
                  text-[28px]
                  font-semibold
                  leading-[1.05]
                  tracking-[-0.045em]
                  text-[#171719]
                  sm:text-[30px]
                  md:text-[34px]
                  lg:text-[38px]
                `,children:["Ready to Build a More Connected",e.jsx("br",{className:"hidden sm:block"}),"Education Environment?"]}),e.jsx("p",{className:`mt-5 max-w-[700px] ${i} text-[14px] leading-6 text-[#70656A] sm:text-[15px]`,children:"Let's discuss your institution's technology requirements and explore a practical approach for your next stage of digital growth."}),e.jsx("div",{className:"mt-7 border-t border-[#ECE9E9] pt-5",children:e.jsxs("div",{className:"flex flex-wrap gap-x-8 gap-y-4",children:[e.jsx(s,{icon:e.jsx(c,{size:16}),text:"Direct Architect Consultation"}),e.jsx(s,{icon:e.jsx(l,{size:16}),text:"Bilateral NDA Protected"}),e.jsx(s,{icon:e.jsx(I,{size:16}),text:"Response within 24 Hours"})]})})]}),e.jsx("div",{className:"flex w-full flex-col gap-3 sm:flex-row lg:w-[280px] lg:flex-col",children:e.jsx(x,{to:"/talk-to-expert",className:"inline-block",children:e.jsx(P,{children:"Talk to Our Experts"})})})]})})})})}function he(){return e.jsxs("main",{className:"education-page",children:[e.jsx("style",{children:`

        * {
          box-sizing: border-box;
        }

        html {
          scroll-behavior: smooth;
        }

        body {
          margin: 0;
          font-family: "Inter", sans-serif;
        }

        button {
          font-family: "Inter", sans-serif;
        }

        /* =====================================================
           PAGE
        ===================================================== */

        .education-page {
          width: 100%;
          min-height: 100vh;
          overflow-x: hidden;
          background: #f5f6f7;
          font-family: "Inter", sans-serif;
        }

        /* =====================================================
           COMMON HORIZONTAL SPACING SYSTEM
           
           Desktop  -> 100px
           Tablet   -> 40px
           Mobile   -> 24px
           Small    -> 16px
        ===================================================== */

        .education-section {
          width: 100%;
        }

        .education-container {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;
          padding-left: 100px;
          padding-right: 100px;
          box-sizing: border-box;
        }

        /* =====================================================
           HERO
        ===================================================== */

        .education-hero {
          padding-top: 24px;
        }

        .hero-card {
          width: 100%;
          border: 1px solid #e8e5e5;
          border-radius: 18px;
          background: #ffffff;
          padding-top: 56px;
          padding-bottom: 56px;
          padding-left: 48px;
          padding-right: 48px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
        }

        .hero-grid {
          display: grid;
          grid-template-columns: minmax(0, 1.08fr) minmax(340px, 0.92fr);
          align-items: stretch;
          gap: 48px;
        }

        .hero-content {
          display: flex;
          min-width: 0;
          height: 100%;
          flex-direction: column;
          justify-content: center;
        }

        .hero-image-column {
          display: flex;
          min-width: 0;
          height: 100%;
          align-items: stretch;
          justify-content: center;
        }

        .hero-image-wrapper {
          position: relative;
          width: 100%;
          height: 100%;
          min-height: 390px;
          overflow: hidden;
          border: 1px solid #ddd9d9;
          border-radius: 18px;
          background: #000000;
          box-shadow: 0 8px 24px rgba(0, 0, 0, 0.09);
        }

        .hero-image {
          display: block;
          width: 100%;
          height: 100%;
          min-height: 390px;
          object-fit: cover;
          object-position: center;
        }

        /* =====================================================
           EDITORIAL
        ===================================================== */

        .editorial-card {
          width: 100%;
          border: 1px solid #e7e1d8;
          border-radius: 18px;
          background: #fbfaf4;
          padding: 56px 48px;
        }

        /* =====================================================
           COMMON WHITE / CREAM CARDS
        ===================================================== */

        .white-section-card,
        .cream-section-card,
        .cta-card {
          width: 100%;
          border-radius: 18px;
        }

        .white-section-card {
          border: 1px solid #e4e4e3;
          background: #ffffff;
          padding: 56px 48px;
        }

        .cream-section-card {
          border: 1px solid #e6e1d8;
          background: #fbfaf4;
          padding: 56px 48px;
        }

        .implementation-card {
          text-align: center;
        }

        /* =====================================================
           INTEGRATION
        ===================================================== */

        .integration-card {
          width: 100%;
          border-radius: 18px;
          background: #730042;
          padding: 56px 48px;
          color: #ffffff;
          box-shadow: 0 12px 30px rgba(95, 0, 50, 0.16);
        }

        /* =====================================================
           CTA
        ===================================================== */

        .cta-card {
          border: 1px solid #e2e0e0;
          background: #ffffff;
          padding: 56px 48px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }

        /* =====================================================
           TABLET
           768px - 1199px
        ===================================================== */

        @media (min-width: 768px) and (max-width: 1199px) {
          .education-container {
            padding-left: 40px;
            padding-right: 40px;
          }

          .education-hero {
            padding-top: 20px;
          }

          .hero-card {
            padding: 40px;
          }

          .hero-grid {
            grid-template-columns: minmax(0, 1fr) minmax(300px, 0.85fr);
            gap: 36px;
          }

          .hero-image-wrapper,
          .hero-image {
            min-height: 360px;
          }

          .editorial-card,
          .white-section-card,
          .cream-section-card,
          .integration-card,
          .cta-card {
            padding: 44px 40px;
          }
        }

        /* =====================================================
           MOBILE
           481px - 767px
        ===================================================== */

        @media (max-width: 767px) {
          .education-container {
            padding-left: 24px;
            padding-right: 24px;
          }

          .education-hero {
            padding-top: 16px;
          }

          .hero-card {
            padding: 32px;
          }

          .hero-grid {
            grid-template-columns: 1fr;
            gap: 32px;
          }

          .hero-image-column {
            width: 100%;
          }

          .hero-image-wrapper {
            max-width: none;
            min-height: 360px;
          }

          .hero-image {
            min-height: 360px;
          }

          .editorial-card,
          .white-section-card,
          .cream-section-card,
          .integration-card,
          .cta-card {
            padding: 40px 32px;
          }

          .implementation-card {
            text-align: left;
          }
        }

        /* =====================================================
           SMALL MOBILE
           <= 480px
        ===================================================== */

        @media (max-width: 480px) {
          .education-container {
            padding-left: 16px;
            padding-right: 16px;
          }

          .education-hero {
            padding-top: 12px;
          }

          .hero-card {
            padding: 24px;
            border-radius: 16px;
          }

          .hero-grid {
            gap: 28px;
          }

          .hero-image-wrapper {
            min-height: 300px;
            border-radius: 15px;
          }

          .hero-image {
            min-height: 300px;
          }

          .editorial-card,
          .white-section-card,
          .cream-section-card,
          .integration-card,
          .cta-card {
            padding: 32px 24px;
            border-radius: 16px;
          }

          .integration-card {
            padding-top: 32px;
            padding-bottom: 32px;
          }

          .cta-card {
            padding-top: 32px;
            padding-bottom: 32px;
          }
        }

        /* =====================================================
           EXTRA SMALL
           <= 360px
        ===================================================== */

        @media (max-width: 360px) {
          .education-container {
            padding-left: 16px;
            padding-right: 16px;
          }

          .hero-card {
            padding: 20px;
          }

          .editorial-card,
          .white-section-card,
          .cream-section-card,
          .integration-card,
          .cta-card {
            padding-left: 20px;
            padding-right: 20px;
          }

          .hero-image-wrapper,
          .hero-image {
            min-height: 270px;
          }
        }

        /* =====================================================
           REDUCED MOTION
        ===================================================== */

        @media (prefers-reduced-motion: reduce) {
          html {
            scroll-behavior: auto !important;
          }

          *,
          *::before,
          *::after {
            transition-duration: 0.01ms !important;
            animation-duration: 0.01ms !important;
          }
        }
      `}),e.jsxs("div",{className:"flex w-full flex-col gap-5 sm:gap-6 md:gap-7 lg:gap-9",children:[e.jsx(_,{}),e.jsx(B,{}),e.jsx(U,{}),e.jsx(q,{}),e.jsx(K,{}),e.jsx(Z,{}),e.jsx(Q,{})]})]})}export{he as default};
