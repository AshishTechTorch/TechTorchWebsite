import{t as e}from"./index-BThRNyH6.js";const o={name:"arrow-down",size:24,node:[["path",{d:"M12 5v14",key:"s699le"}],["path",{d:"m19 12-7 7-7-7",key:"1idqje"}]]};o.node;const n=e(o);export{n as A};
