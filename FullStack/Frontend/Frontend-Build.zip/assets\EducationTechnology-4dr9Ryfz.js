import{j as e}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";import{T as m}from"./target-CywCxRzC.js";import{t as g,G as x,H as h,I as f}from"./index-BThRNyH6.js";import{F as w}from"./file-check-corner-B2WXpt3k.js";import{C as u}from"./check-Cj2_y9Sm.js";const s={name:"pen-tool",size:24,node:[["path",{d:"m18 13-.654-4.736a4 4 0 00-2.756-3.266l-9.163-2.9a2 2 0 00-2.017.493l-.82.819a2 2 0 00-.492 2.017l2.9 9.163a4 4 0 003.266 2.756L13 18",key:"93nyr4"}],["path",{d:"M18.648 12.352a1.205 1.205 0 011.704 0l1.296 1.296a1.205 1.205 0 010 1.704l-6.296 6.296a1.205 1.205 0 01-1.704 0l-1.296-1.296a1.205 1.205 0 010-1.704z",key:"lnux7s"}],["path",{d:"m3 3 6.586 6.586",key:"1igwcn"}],["circle",{cx:"11",cy:"11",r:"2",key:"xmgehs"}]]};s.node;const k=g(s),n="#7A1F3D",i="#1B1B2A",o="#5b5a63",b="/college.webp",y=[{icon:m,title:"Leadership",body:"Strategic clarity for institutional planning and cross-campus governance.",variant:"filled"},{icon:k,title:"Faculty",body:"Less administrative overhead and frictionless gradebook management.",iconBg:"#e8f3ef",iconColor:"#2f8768"},{icon:x,title:"Students",body:"Unified access to assignments, degree progress, and advisor guidance.",iconBg:"#eaf3e3",iconColor:"#5f8f3e"},{icon:h,title:"Parents",body:"Transparent visibility into academic milestones and fee schedules.",iconBg:"#fbf1de",iconColor:"#c08a2e"},{icon:w,title:"Registrars",body:"Automated compliance, rapid transcript delivery, and auditable records.",iconBg:"#e6eef6",iconColor:"#3b6ea5"}],N=["Fewer repetitive tasks","Easier access to information","Better coordination between teams","More organized records","Faster access to reports","Clearer communication","Greater visibility across operations"];function t({children:a}){return e.jsxs("div",{className:"education-eyebrow",children:[e.jsx(f,{size:14,strokeWidth:3}),e.jsx("span",{children:a})]})}function S(){return e.jsxs("div",{className:"people-work-section",children:[e.jsx("style",{children:`
        @import url(
          'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap'
        );

        /* =====================================================
           MAIN
        ===================================================== */

        .people-work-section {
          width: 100%;
          overflow: hidden;
          background: #ffffff;
          color: ${i};
          font-family: "Inter", sans-serif;
        }

        /* =====================================================
           COMMON CONTAINER
           
           Desktop  -> 100px
           Tablet   -> 40px
           Mobile   -> 24px
           Small    -> 16px
        ===================================================== */

        .people-work-container {
          width: 100%;
          max-width: 1600px;
          margin: 0 auto;
          padding-left: 100px;
          padding-right: 100px;
          box-sizing: border-box;
        }

        /* =====================================================
           SECTION 1
        ===================================================== */

        .personas-section {
          width: 100%;
          background: #ffffff;
          padding-top: 80px;
          padding-bottom: 80px;
        }

        /* =====================================================
           EYEBROW
           INTER
        ===================================================== */

        .education-eyebrow {
          display: flex;
          align-items: center;
          gap: 4px;
          width: fit-content;
          margin-bottom: 16px;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.4;
          font-weight: 700;
          letter-spacing: 0.06em;

          color: ${n};
        }

        /* =====================================================
           MAIN HEADING
           PLUS JAKARTA SANS
        ===================================================== */

        .people-work-heading {
          margin: 0;
          max-width: 680px;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 38px;
          line-height: 1.15;
          font-weight: 700;
          letter-spacing: -0.7px;

          color: ${i};
        }

        /* =====================================================
           MAIN SUBHEADING
           PLUS JAKARTA SANS
        ===================================================== */

        .people-work-subheading {
          margin: 16px 0 0;
          max-width: 680px;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 17px;
          line-height: 1.6;
          font-weight: 500;

          color: ${o};
        }

        /* =====================================================
           PERSONA GRID
        ===================================================== */

        .persona-grid {
          display: grid;
          grid-template-columns: repeat(5, minmax(0, 1fr));
          gap: 16px;
          margin-top: 40px;
        }

        /* =====================================================
           PERSONA CARD
        ===================================================== */

        .persona-card {
          min-width: 0;
          padding: 20px;

          border: 1px solid #ece9e4;
          border-radius: 12px;
          background: #ffffff;

          transition:
            transform 0.25s ease,
            box-shadow 0.25s ease,
            border-color 0.25s ease;
        }

        .persona-card:hover {
          transform: translateY(-4px);
          border-color: #e2d4d9;

          box-shadow:
            0 12px 28px rgba(0, 0, 0, 0.07);
        }

        /* =====================================================
           ICON
        ===================================================== */

        .persona-icon {
          width: 44px;
          height: 44px;

          display: flex;
          align-items: center;
          justify-content: center;

          margin-bottom: 16px;
          flex-shrink: 0;
        }

        .persona-icon-filled {
          border-radius: 50%;
          background: ${n};
          color: #ffffff;
        }

        .persona-icon-normal {
          border-radius: 8px;
        }

        /* =====================================================
           CARD HEADING
           INTER
        ===================================================== */

        .persona-title {
          margin: 0 0 8px;

          font-family: "Inter", sans-serif;
          font-size: 14px;
          line-height: 1.4;
          font-weight: 700;

          color: ${i};
        }

        /* =====================================================
           CARD BODY
           INTER
        ===================================================== */

        .persona-body {
          margin: 0;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.7;
          font-weight: 400;

          color: ${o};
        }

        /* =====================================================
           SECTION 2
        ===================================================== */

        .manual-work-section {
          width: 100%;
          background: #f3f1ec;

          padding-top: 72px;
          padding-bottom: 72px;
        }

        .manual-work-grid {
          display: grid;

          grid-template-columns:
            minmax(0, 0.9fr)
            minmax(0, 1.3fr)
            minmax(260px, 0.8fr);

          gap: 32px;
          align-items: start;
        }

        /* =====================================================
           IMAGE
        ===================================================== */

        .education-work-image-wrapper {
          width: 100%;
          overflow: hidden;

          border-radius: 16px;
          background: #e9e4e0;
        }

        .education-work-image {
          display: block;
          width: 100%;
          height: 288px;

          object-fit: cover;
          object-position: center;

          transition: transform 0.4s ease;
        }

        .education-work-image-wrapper:hover
        .education-work-image {
          transform: scale(1.025);
        }

        /* =====================================================
           SECTION 2 HEADING
           PLUS JAKARTA SANS
        ===================================================== */

        .manual-work-heading {
          margin: 0 0 16px;

          font-family: "Plus Jakarta Sans", sans-serif;
          font-size: 30px;
          line-height: 1.2;
          font-weight: 700;
          letter-spacing: -0.5px;

          color: ${i};
        }

        /* =====================================================
           SECTION 2 BODY
           INTER
        ===================================================== */

        .manual-work-body {
          margin: 0;

          font-family: "Inter", sans-serif;
          font-size: 15px;
          line-height: 1.75;
          font-weight: 400;

          color: ${o};
        }

        .manual-work-body + .manual-work-body {
          margin-top: 20px;
        }

        /* =====================================================
           MEANS CARD
        ===================================================== */

        .means-card {
          padding: 20px;

          border-radius: 12px;
          background: #ffffff;

          box-sizing: border-box;
        }

        /* =====================================================
           MEANS TITLE
           INTER
        ===================================================== */

        .means-title {
          margin: 0 0 16px;

          font-family: "Inter", sans-serif;
          font-size: 12px;
          line-height: 1.4;
          font-weight: 700;
          letter-spacing: 0.06em;

          color: #8a8378;
        }

        /* =====================================================
           LIST
           INTER
        ===================================================== */

        .means-list {
          display: flex;
          flex-direction: column;
          gap: 12px;

          margin: 0;
          padding: 0;

          list-style: none;
        }

        .means-item {
          display: flex;
          align-items: flex-start;
          gap: 8px;

          font-family: "Inter", sans-serif;
          font-size: 13px;
          line-height: 1.5;
          font-weight: 400;

          color: ${i};
        }

        .means-check {
          flex-shrink: 0;
          margin-top: 2px;
          color: ${n};
        }

        /* =====================================================
           LARGE DESKTOP
        ===================================================== */

        @media (min-width: 1440px) {
          .people-work-container {
            padding-left: 100px;
            padding-right: 100px;
          }

          .people-work-heading {
            font-size: 40px;
          }

          .people-work-subheading {
            font-size: 18px;
          }

          .manual-work-heading {
            font-size: 32px;
          }

          .persona-grid {
            gap: 20px;
          }

          .manual-work-grid {
            gap: 40px;
          }
        }

        /* =====================================================
           TABLET / SMALL LAPTOP
           768px - 1199px
        ===================================================== */

        @media (min-width: 768px) and (max-width: 1199px) {
          .people-work-container {
            padding-left: 40px;
            padding-right: 40px;
          }

          .personas-section {
            padding-top: 64px;
            padding-bottom: 64px;
          }

          .manual-work-section {
            padding-top: 56px;
            padding-bottom: 56px;
          }

          .people-work-heading {
            font-size: 36px;
          }

          .people-work-subheading {
            font-size: 16px;
          }

          .persona-grid {
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 16px;
            margin-top: 36px;
          }

          .manual-work-grid {
            grid-template-columns:
              minmax(0, 1fr)
              minmax(0, 1.25fr);
            gap: 28px;
          }

          .means-card {
            grid-column: 1 / -1;
          }

          .education-work-image {
            height: 320px;
          }

          .manual-work-heading {
            font-size: 30px;
          }

          .manual-work-body {
            font-size: 14px;
          }
        }

        /* =====================================================
           MOBILE
           481px - 767px
        ===================================================== */

        @media (max-width: 767px) {
          .people-work-container {
            padding-left: 24px;
            padding-right: 24px;
          }

          .personas-section {
            padding-top: 56px;
            padding-bottom: 56px;
          }

          .manual-work-section {
            padding-top: 52px;
            padding-bottom: 52px;
          }

          .education-eyebrow {
            font-size: 11px;
          }

          .people-work-heading {
            max-width: 600px;
            font-size: 32px;
            line-height: 1.18;
            letter-spacing: -0.5px;
          }

          .people-work-subheading {
            max-width: 600px;
            margin-top: 14px;
            font-size: 15px;
            line-height: 1.65;
          }

          .persona-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
            margin-top: 32px;
          }

          .persona-card {
            padding: 18px;
          }

          .manual-work-grid {
            grid-template-columns: 1fr;
            gap: 28px;
          }

          .education-work-image {
            height: 320px;
          }

          .manual-work-heading {
            font-size: 28px;
            line-height: 1.2;
          }

          .manual-work-body {
            font-size: 14px;
            line-height: 1.7;
          }

          .means-card {
            grid-column: auto;
            padding: 18px;
          }
        }

        /* =====================================================
           SMALL MOBILE
           <= 480px
        ===================================================== */

        @media (max-width: 480px) {
          .people-work-container {
            padding-left: 16px;
            padding-right: 16px;
          }

          .personas-section {
            padding-top: 48px;
            padding-bottom: 48px;
          }

          .manual-work-section {
            padding-top: 44px;
            padding-bottom: 44px;
          }

          .education-eyebrow {
            gap: 2px;
            margin-bottom: 12px;

            font-size: 10px;
            line-height: 1.5;
            letter-spacing: 0.045em;
          }

          .people-work-heading {
            max-width: 100%;
            font-size: 27px;
            line-height: 1.2;
            letter-spacing: -0.4px;
          }

          .people-work-subheading {
            max-width: 100%;
            margin-top: 12px;
            font-size: 14px;
            line-height: 1.65;
          }

          .persona-grid {
            grid-template-columns: 1fr;
            gap: 10px;
            margin-top: 28px;
          }

          .persona-card {
            display: grid;
            grid-template-columns: auto 1fr;
            column-gap: 12px;
            padding: 15px;
          }

          .persona-icon {
            grid-row: 1 / span 2;
            width: 40px;
            height: 40px;
            margin-bottom: 0;
          }

          .persona-title {
            margin-bottom: 4px;
            font-size: 13px;
          }

          .persona-body {
            font-size: 11.5px;
            line-height: 1.6;
          }

          .education-work-image-wrapper {
            border-radius: 14px;
          }

          .education-work-image {
            height: 260px;
          }

          .manual-work-heading {
            font-size: 25px;
            line-height: 1.22;
          }

          .manual-work-body {
            font-size: 13.5px;
            line-height: 1.7;
          }

          .manual-work-body + .manual-work-body {
            margin-top: 16px;
          }

          .means-card {
            padding: 16px;
          }

          .means-item {
            gap: 7px;
            font-size: 12px;
          }
        }

        /* =====================================================
           VERY SMALL MOBILE
           <= 360px
        ===================================================== */

        @media (max-width: 360px) {
          .people-work-container {
            padding-left: 16px;
            padding-right: 16px;
          }

          .people-work-heading {
            font-size: 24px;
            line-height: 1.22;
          }

          .people-work-subheading {
            font-size: 13px;
          }

          .manual-work-heading {
            font-size: 23px;
          }

          .education-work-image {
            height: 235px;
          }

          .persona-card {
            padding: 13px;
          }
        }

        /* =====================================================
           REDUCED MOTION
        ===================================================== */

        @media (prefers-reduced-motion: reduce) {
          .persona-card,
          .education-work-image {
            transition: none;
          }
        }
      `}),e.jsx("section",{className:"personas-section",children:e.jsxs("div",{className:"people-work-container",children:[e.jsx(t,{children:"TECHNOLOGY FOR THE PEOPLE BEHIND EDUCATION"}),e.jsx("h2",{className:"people-work-heading",children:"Better experiences start with understanding every user."}),e.jsx("p",{className:"people-work-subheading",children:"An education platform is only useful when it works well for the people using it."}),e.jsx("div",{className:"persona-grid",children:y.map(({icon:a,title:r,body:p,variant:d,iconBg:l,iconColor:c})=>e.jsxs("div",{className:"persona-card",children:[d==="filled"?e.jsx("span",{className:"persona-icon persona-icon-filled",children:e.jsx(a,{size:18,strokeWidth:1.8})}):e.jsx("span",{className:"persona-icon persona-icon-normal",style:{background:l,color:c},children:e.jsx(a,{size:18,strokeWidth:1.8})}),e.jsx("h3",{className:"persona-title",children:r}),e.jsx("p",{className:"persona-body",children:p})]},r))})]})}),e.jsx("section",{className:"manual-work-section",children:e.jsxs("div",{className:"people-work-container manual-work-grid",children:[e.jsx("div",{className:"education-work-image-wrapper",children:e.jsx("img",{loading:"lazy",decoding:"async",src:b,alt:"Two colleagues reviewing records",className:"education-work-image"})}),e.jsxs("div",{children:[e.jsx(t,{children:"LESS MANUAL WORK, MORE MEANINGFUL WORK"}),e.jsx("h2",{className:"manual-work-heading",children:"Give your teams more time for what matters."}),e.jsx("p",{className:"manual-work-body",children:"Manual processes often become part of an institution simply because they have always been there. But as an organization grows, repeated data entry, paper-based records, scattered files and separate systems can consume valuable time."}),e.jsx("p",{className:"manual-work-body",children:"TechTorch helps identify where technology can remove unnecessary steps and create simpler workflows."})]}),e.jsxs("div",{className:"means-card",children:[e.jsx("p",{className:"means-title",children:"THIS CAN MEAN:"}),e.jsx("ul",{className:"means-list",children:N.map(a=>e.jsxs("li",{className:"means-item",children:[e.jsx(u,{size:15,className:"means-check"}),e.jsx("span",{children:a})]},a))})]})]})})]})}export{S as default};
