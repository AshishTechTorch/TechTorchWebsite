import{j as e}from"./vendor-query-PraSc8EQ.js";import"./vendor-router-L4ZCoGSs.js";function d(){const n=[{number:"01",time:"Minutes 00 – 15",title:"Perimeter Telemetry Scan",description:"Review external attack surfaces, certificate exposures, unmonitored shadow APIs, and threat intelligence calibrated to your vertical."},{number:"02",time:"Minutes 15 – 35",title:"Defense Gap Diagnostics",description:"Deep-dive into multi-cloud configuration, IAM privilege sprawl, pipeline vulnerabilities, and agentic AI prompt injection risks."},{number:"03",time:"Minutes 35 – 45",title:"Vector Squad Mobilization & Playbook",description:"Agreement on immediate 30-60-90 day remediation objectives and handoff of your Board-ready security impact deck."}];return e.jsxs("section",{className:"structured-agenda",children:[e.jsxs("div",{className:"agenda-white-section",children:[e.jsxs("div",{className:"agenda-heading",children:[e.jsx("div",{className:"agenda-eyebrow",children:"STRICT TIMEBOX PROTOCOL"}),e.jsx("h2",{children:"The 45-Minute Structured Agenda"}),e.jsx("p",{children:"Every minute is architected for maximum executive value and actionable clarity."})]}),e.jsx("div",{className:"agenda-cards",children:n.map(i=>e.jsxs("div",{className:"agenda-card",children:[e.jsxs("div",{className:"agenda-card-top",children:[e.jsx("div",{className:"agenda-number",children:i.number}),e.jsx("div",{className:"agenda-time",children:i.time})]}),e.jsx("h3",{children:i.title}),e.jsx("p",{children:i.description})]},i.number))})]}),e.jsx("div",{className:"incident-section",children:e.jsxs("div",{className:"incident-inner",children:[e.jsx("div",{className:"incident-icon",children:e.jsx("span",{children:"✱"})}),e.jsxs("div",{className:"incident-content",children:[e.jsxs("div",{className:"incident-label",children:["ACTIVE INCIDENT ESCALATION",e.jsx("span",{className:"incident-dot"})]}),e.jsx("h3",{children:"Facing an Active Breach or Zero-Day Vector?"}),e.jsx("p",{children:"Bypass booking queue for priority triage directly with our Rapid Response Cyber Desk."})]}),e.jsxs("div",{className:"incident-contacts",children:[e.jsxs("div",{className:"incident-contact",children:[e.jsx("div",{className:"contact-icon",children:"☎"}),e.jsxs("div",{children:[e.jsx("span",{className:"contact-label",children:"Direct C-Suite Dispatch Line:"}),e.jsx("strong",{children:"+91 581 350 0381"})]})]}),e.jsxs("div",{className:"incident-contact",children:[e.jsx("div",{className:"contact-icon",children:"✉"}),e.jsxs("div",{children:[e.jsx("span",{className:"contact-label",children:"Direct Advisory Desk:"}),e.jsx("strong",{children:"advisory@techtorch.solutions"})]})]})]})]})}),e.jsx("style",{children:`

        * {
          box-sizing: border-box;
        }


        /* =========================================
           MAIN WRAPPER
        ========================================= */

        .structured-agenda {
          width: 100%;
          font-family: "Inter", Arial, sans-serif;
        }


        /* =========================================
           WHITE SECTION
        ========================================= */

        .agenda-white-section {
          width: 100%;
          min-height: auto;

          padding: 52px 42px 50px;

          background: #f1f2f4;
        }


        /* =========================================
           HEADING
        ========================================= */

        .agenda-heading {
          width: 100%;
          text-align: center;
          margin: 0 auto 42px;
        }


        .agenda-eyebrow {
          margin-bottom: 11px;
          color: #7b164c;
          font-size: 12px;
          font-weight: 900;
          letter-spacing: 1.5px;
        }


        .agenda-heading h2 {
          margin: 0;
          color: #172036;

          font-family:
            "Plus Jakarta Sans",
            "Inter",
            Arial,
            sans-serif;

          font-size: 32px;
          line-height: 1.15;
          font-weight: 600;
          letter-spacing: -1px;
        }


        .agenda-heading p {
          margin: 13px 0 0;
          color: #647188;
          font-size: 15px;
          line-height: 1.4;
          font-weight: 400;
        }


        /* =========================================
           CARDS
        ========================================= */

        .agenda-cards {
          width: 90%;
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 24px;
          margin: 0 auto;
          max-width: 1380px;
        }


        .agenda-card {
          min-height: 220px;

          padding: 26px 27px 24px;

          background: #ffffff;

          border: 1px solid #e0e5eb;

          border-radius: 15px;

          box-shadow:
            0 3px 8px rgba(20, 31, 50, 0.04);

          transition:
            transform 0.25s ease,
            box-shadow 0.25s ease;
        }


        .agenda-card:hover {
          transform: translateY(-3px);

          box-shadow:
            0 10px 25px rgba(20, 31, 50, 0.08);
        }


        .agenda-card-top {
          width: 100%;

          display: flex;

          align-items: center;

          justify-content: space-between;

          margin-bottom: 21px;
        }


        .agenda-number {
          color: #85004b;

          font-size: 30px;

          line-height: 1;

          font-weight: 800;

          letter-spacing: -1px;
        }


        .agenda-time {
          display: inline-flex;

          align-items: center;

          justify-content: center;

          min-height: 30px;

          padding: 0 12px;

          border-radius: 5px;

          background: #f0f3f7;

          color: #526075;

          font-size: 11px;

          font-weight: 650;

          white-space: nowrap;
        }


        .agenda-card h3 {
          margin: 0 0 11px;

          color: #1c263b;

          font-family:
            "Plus Jakarta Sans",
            "Inter",
            Arial,
            sans-serif;

          font-size: 18px;

          line-height: 1.25;

          font-weight: 750;

          letter-spacing: -0.3px;
        }


        .agenda-card p {
          margin: 0;

          max-width: 510px;

          color: #647188;

          font-size: 13px;

          line-height: 1.5;

          font-weight: 400;
        }


        /* =========================================
           PURPLE INCIDENT SECTION
        ========================================= */

        .incident-section {
          width: 100%;

          padding: 24px 42px 24px;

          background:
            linear-gradient(
              135deg,
              #810046 0%,
              #8b0750 45%,
              #79003f 100%
            );
        }


        .incident-inner {
          width: 92%;

          max-width: 1380px;

          min-height: 94px;

          margin: 0 auto;

          padding: 15px 20px;

          display: flex;

          align-items: center;

          gap: 18px;

          border: 1px solid rgba(255, 255, 255, 0.13);

          border-radius: 14px;

          background:
            rgba(255, 255, 255, 0.045);

          box-shadow:
            inset 0 1px 0 rgba(255, 255, 255, 0.07);
        }


        /* =========================================
           INCIDENT ICON
        ========================================= */

        .incident-icon {
          width: 48px;

          height: 48px;

          flex-shrink: 0;

          display: flex;

          align-items: center;

          justify-content: center;

          border-radius: 9px;

          background: #ffe6e6;
        }


        .incident-icon span {
          color: #c73535;

          font-size: 29px;

          line-height: 1;

          font-weight: 800;
        }


        /* =========================================
           INCIDENT CONTENT
        ========================================= */

        .incident-content {
          flex: 1;

          min-width: 0;
        }


        .incident-label {
          display: flex;

          align-items: center;

          gap: 9px;

          margin-bottom: 5px;

          color: #f3c6dc;

          font-size: 10px;

          font-weight: 800;

          letter-spacing: 1.5px;
        }


        .incident-dot {
          width: 9px;

          height: 9px;

          display: inline-block;

          border-radius: 50%;

          background: #ff684d;

          box-shadow:
            0 0 10px rgba(255, 104, 77, 0.5);
        }


        .incident-content h3 {
          margin: 0;

          color: #ffffff;

          font-family:
            "Plus Jakarta Sans",
            "Inter",
            Arial,
            sans-serif;

          font-size: 16px;

          line-height: 1.25;

          font-weight: 750;
        }


        .incident-content p {
          margin: 4px 0 0;

          color: #dca9c5;

          font-size: 11px;

          line-height: 1.4;
        }


        /* =========================================
           CONTACTS
        ========================================= */

        .incident-contacts {
          display: flex;

          align-items: center;

          gap: 25px;

          flex-shrink: 0;

          padding-right: 2px;
        }


        .incident-contact {
          display: flex;

          align-items: center;

          gap: 8px;
        }


        .contact-icon {
          color: #f4cade;

          font-size: 21px;

          line-height: 1;
        }


        .incident-contact > div:last-child {
          display: flex;

          flex-direction: column;

          gap: 2px;
        }


        .contact-label {
          color: #f0bfd6;

          font-size: 10px;

          line-height: 1.2;

          white-space: nowrap;
        }


        .incident-contact strong {
          color: #ffffff;

          font-size: 14px;

          line-height: 1.2;

          font-weight: 700;

          white-space: nowrap;
        }


        /* =========================================
           LARGE TABLET
        ========================================= */

        @media (max-width: 1200px) {

          .agenda-white-section {
            padding-left: 28px;
            padding-right: 28px;
          }


          .agenda-cards {
            width: 92%;
            gap: 18px;
          }


          .agenda-card {
            min-height: 215px;
            padding: 24px 23px;
          }


          .agenda-card h3 {
            font-size: 18px;
          }


          .agenda-card p {
            font-size: 13px;
          }


          .incident-section {
            padding-left: 28px;
            padding-right: 28px;
          }


          .incident-inner {
            width: 92%;
            padding: 15px;
          }


          .incident-contacts {
            gap: 16px;
          }


          .contact-label {
            font-size: 9px;
          }


          .incident-contact strong {
            font-size: 12px;
          }
        }


        /* =========================================
           TABLET
        ========================================= */

        @media (max-width: 950px) {

          .agenda-white-section {
            padding-top: 45px;
            padding-bottom: 45px;
          }


          .agenda-heading {
            margin-bottom: 35px;
          }


          .agenda-heading h2 {
            font-size: 34px;
          }


          .agenda-heading p {
            font-size: 16px;
          }


          .agenda-cards {
            width: 90%;
            grid-template-columns: 1fr;
            max-width: 600px;
            gap: 14px;
          }


          .agenda-card {
            min-height: auto;
            padding: 23px 24px;
          }


          .incident-inner {
            width: 90%;
            flex-wrap: wrap;
          }


          .incident-content {
            flex-basis: calc(100% - 90px);
          }


          .incident-contacts {
            width: 100%;

            justify-content: space-between;

            padding-left: 78px;
          }
        }


        /* =========================================
           MOBILE
        ========================================= */

        @media (max-width: 600px) {

          .agenda-white-section {
            padding: 40px 18px 42px;
          }


          .agenda-eyebrow {
            font-size: 10px;
            letter-spacing: 1.1px;
          }


          .agenda-heading {
            margin-bottom: 30px;
          }


          .agenda-heading h2 {
            font-size: 28px;
            letter-spacing: -0.5px;
          }


          .agenda-heading p {
            margin-top: 11px;
            font-size: 14px;
          }


          .agenda-cards {
            width: 94%;
            gap: 12px;
          }


          .agenda-card {
            padding: 22px 19px;
            border-radius: 13px;
          }


          .agenda-card-top {
            margin-bottom: 19px;
          }


          .agenda-number {
            font-size: 31px;
          }


          .agenda-time {
            min-height: 29px;
            padding: 0 9px;
            font-size: 9px;
          }


          .agenda-card h3 {
            font-size: 17px;
            margin-bottom: 10px;
          }


          .agenda-card p {
            font-size: 12px;
            line-height: 1.5;
          }


          /* =====================================
             PURPLE MOBILE
          ===================================== */

          .incident-section {
            padding: 20px 18px 21px;
          }


          .incident-inner {
            width: 94%;
            padding: 16px 14px;

            gap: 12px;

            align-items: flex-start;
          }


          .incident-icon {
            width: 47px;

            height: 47px;
          }


          .incident-icon span {
            font-size: 25px;
          }


          .incident-content {
            flex-basis: calc(100% - 59px);
          }


          .incident-label {
            font-size: 8px;
            letter-spacing: 0.9px;
          }


          .incident-dot {
            width: 7px;
            height: 7px;
          }


          .incident-content h3 {
            font-size: 15px;
          }


          .incident-content p {
            font-size: 10px;
            line-height: 1.45;
          }


          .incident-contacts {
            width: 100%;

            padding: 7px 0 0;

            flex-direction: column;

            align-items: flex-start;

            gap: 13px;
          }


          .contact-icon {
            font-size: 19px;
          }


          .contact-label {
            font-size: 8px;
          }


          .incident-contact strong {
            font-size: 11px;
          }
        }


        /* =========================================
           SMALL MOBILE
        ========================================= */

        @media (max-width: 420px) {

          .agenda-white-section {
            padding: 35px 15px 38px;
          }


          .agenda-heading h2 {
            font-size: 25px;
          }


          .agenda-heading p {
            font-size: 13px;
          }


          .agenda-cards {
            width: 94%;
          }


          .agenda-card {
            padding: 20px 17px;
          }


          .agenda-card-top {
            align-items: flex-start;
          }


          .agenda-number {
            font-size: 28px;
          }


          .agenda-time {
            font-size: 8px;
          }


          .agenda-card h3 {
            font-size: 16px;
          }


          .agenda-card p {
            font-size: 11px;
          }


          .incident-inner {
            width: 94%;
          }


          .incident-content h3 {
            font-size: 14px;
          }


          .incident-content p {
            font-size: 9px;
          }
        }

      `})]})}export{d as default};
